# Cyrus 0.5.0-dev — buildfix2

Исправлено падение `DefaultLinkParserTest.rejects garbage`: старое ожидание отклонения HTTPS противоречило добавленной поддержке HTTPS-прокси. Сам тест сохранён, добавлены шесть проверок нового контракта. Дополнительно исправлены API-26 вызов на minSdk 24, разрешение активного сетевого запроса и обновление FGS-уведомления.

**Исходники, не готовый APK. Полный buildfix2 pipeline здесь не выполнялся; локальные source checks проходят.** Успешная компиляция debug/release в присланном GitHub Actions относится к предыдущему buildfix1.

Отчёт: [docs/BUILD_FIX_0.5.0_2.md](docs/BUILD_FIX_0.5.0_2.md).

Загрузите `Cyrus-0.5.0-dev-buildfix2-source.zip` в корень Eren2932/Cyrus без распаковки. Установленный workflow менять не требуется. Для ручного запуска укажите новое имя ZIP в поле archive; не нажимайте Re-run старого запуска.

О клиенте и ограничениях: [docs/UPGRADE_0.5.0.md](docs/UPGRADE_0.5.0.md). Предыдущее исправление: [docs/BUILD_FIX_0.5.0.md](docs/BUILD_FIX_0.5.0.md).

Версия Android сохранена: 0.5.0-dev / code 7; applicationId dev.kentra.app. Не удаляйте установленный клиент без экспорта ключей при несовпадении подписи.
