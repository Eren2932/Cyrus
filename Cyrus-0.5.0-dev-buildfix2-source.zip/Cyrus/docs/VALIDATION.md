# Проверки buildfix2

Текущий отчёт: [BUILD_FIX_0.5.0_2.md](BUILD_FIX_0.5.0_2.md).

Source checks проходят. 17 buildfix guards и 16 мутационных случаев пройдены. 57 JUnit-тестов vpn:link существуют в исходниках, но здесь не запускались.

Подтверждено пользовательским CI только для buildfix1: компиляция debug/release прошла, 1 из 51 теста vpn:link упал на устаревшем ожидании HTTPS rejection. Лог не подтверждает успешный lint/native validation/APK.

Для нового buildfix2 Kotlin/Gradle/JUnit/lint/native/APK/device validation НЕ выполнялась. Текущий журнал: validation/source-checks.txt.
