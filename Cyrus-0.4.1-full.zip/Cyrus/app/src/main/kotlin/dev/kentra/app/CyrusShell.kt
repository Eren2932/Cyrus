package dev.kentra.app

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import dev.kentra.core.datastore.AppearanceSettings
import dev.kentra.core.datastore.SettingsStore
import dev.kentra.core.designsystem.*
import dev.kentra.feature.home.HomeRoute
import dev.kentra.feature.profiles.ProfilesRoute
import dev.kentra.feature.store.StoreRoute

private val tabs = listOf(
    CyrusNavigationItem("home", "Главная", CyrusSymbol.Shield),
    CyrusNavigationItem("profiles", "Ключи", CyrusSymbol.Key),
    CyrusNavigationItem("store", "Подписка", CyrusSymbol.Store),
)
private const val SettingsIndex = 3

/** Immediate selection; no queue, delayed callbacks or navigation back-stack feedback. */
@Composable
fun CyrusShell(appearance: AppearanceSettings, dark: Boolean, settings: SettingsStore) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var settingsOpen by rememberSaveable { mutableStateOf(false) }
    val stateHolder = rememberSaveableStateHolder()
    val reduced = LocalReducedMotion.current
    val target = if (settingsOpen) SettingsIndex else tab
    BackHandler(enabled = settingsOpen) { settingsOpen = false }
    BackHandler(enabled = !settingsOpen && tab != 0) { tab = 0 }

    Box(Modifier.fillMaxSize()) {
        // One decoded image outside the transition, not one bitmap per page.
        CyrusWallpaper(dark, Modifier.matchParentSize())
        Scaffold(
            modifier = Modifier.windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Horizontal)),
            containerColor = Color.Transparent, contentColor = MaterialTheme.colorScheme.onBackground,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            topBar = {
                Row(Modifier.fillMaxWidth().windowInsetsPadding(WindowInsets.statusBars)
                    .padding(horizontal = 20.dp).heightIn(min = 60.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (settingsOpen) {
                        IconButton(onClick = { settingsOpen = false },
                            modifier = Modifier.semantics { contentDescription = "Назад" }) {
                            CyrusIcon(CyrusSymbol.Back)
                        }
                    }
                    Text(if (settingsOpen) "Настройки" else tabs[tab].let {
                        if (it.route == "home") "Cyrus" else it.title
                    }, modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
                    if (!settingsOpen) {
                        IconButton(onClick = { settingsOpen = true },
                            modifier = Modifier.semantics { contentDescription = "Настройки" }) {
                            CyrusIcon(CyrusSymbol.Settings)
                        }
                    }
                }
            },
            bottomBar = {
                // Reserve the same height, but remove hidden hit targets and TalkBack nodes.
                Box(Modifier.fillMaxWidth().navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 12.dp).height(66.dp),
                    contentAlignment = Alignment.Center) {
                    if (!settingsOpen) CyrusNavigationBar(tabs, tabs[tab].route) { route ->
                        tab = tabs.indexOfFirst { it.route == route }.coerceAtLeast(0)
                    }
                }
            },
        ) { padding ->
            CyrusPagePush(target = target, reduced = reduced,
                modifier = Modifier.padding(padding).consumeWindowInsets(padding).fillMaxSize()) { index ->
                stateHolder.SaveableStateProvider(index) {
                    when (index) {
                        1 -> ProfilesRoute()
                        2 -> StoreRoute(onImport = { tab = 1 })
                        SettingsIndex -> SettingsScreen(appearance, settings)
                        else -> HomeRoute(onNavigateToProfiles = { tab = 1 }, pageActive = target == 0)
                    }
                }
            }
        }
    }
}

/** Full-width push: xIncoming = sign*W*(1-p), xOutgoing = -sign*W*p.
 * Their separation is exactly W for uninterrupted transitions. Compose retargets
 * interrupted motion from its current position. No fade, scale or size animation.
 */
@Composable
internal fun CyrusPagePush(
    target: Int,
    reduced: Boolean,
    modifier: Modifier = Modifier,
    content: @Composable (Int) -> Unit,
) {
    AnimatedContent(
        targetState = target,
        modifier = modifier.clipToBounds(),
        contentAlignment = Alignment.TopStart,
        label = "pagePush",
        transitionSpec = {
            val sign = if (targetState > initialState) 1 else -1
            val duration = if (reduced) 0 else CyrusMotion.Screen
            (slideInHorizontally(tween(duration, easing = CyrusMotion.Ease)) { sign * it } togetherWith
                slideOutHorizontally(tween(duration, easing = CyrusMotion.Ease)) { -sign * it })
                .using(null)
        },
    ) { index ->
        val outgoing = index != target
        Box(Modifier.fillMaxSize()
            .then(if (outgoing) Modifier.clearAndSetSemantics { } else Modifier)
            .pointerInput(outgoing) {
                if (outgoing) awaitPointerEventScope {
                    while (true) awaitPointerEvent(PointerEventPass.Initial).changes.forEach { it.consume() }
                }
            }) { content(index) }
    }
}
