package dev.kentra.core.designsystem

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.luminance
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup

@Composable
fun CyrusCard(modifier: Modifier = Modifier, highlighted: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier = modifier.fillMaxWidth(), shape = RoundedCornerShape(CyrusTokens.RadiusCard),
        border = BorderStroke(1.dp, if (highlighted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface)) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
    }
}

/** Visual state of the main control, derived from TunnelState by the caller. */
enum class CoreStatus { Idle, Busy, Active, Failed }

private val CoreSize = 216.dp

/**
 * Tactical Core — the primary connect control.
 *
 * Layers, cheapest first: a radial bloom driven only by a graphicsLayer alpha,
 * one Canvas that draws the ring track, the running sweep and the four corner
 * brackets, and the centred power glyph. Every animation value is read inside
 * draw/layer lambdas, so a running frame never invalidates composition or
 * layout — that is what keeps it smooth on cheap phones.
 */
@Composable
fun TacticalCore(
    label: String,
    status: CoreStatus,
    animate: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val reduced = LocalReducedMotion.current
    val interactions = remember { MutableInteractionSource() }
    val pressed by interactions.collectIsPressedAsState()
    val busy = status == CoreStatus.Busy
    val active = status == CoreStatus.Active
    val scheme = MaterialTheme.colorScheme
    val dark = scheme.background.luminance() < .5f
    val body = if (dark) CyrusTokens.CoreDark else CyrusTokens.CoreLight
    val ring = if (status == CoreStatus.Failed) scheme.error else scheme.primary
    val ringHot = if (status == CoreStatus.Failed) scheme.error else if (dark) CyrusTokens.AccentHot else ring

    val press = animateFloatAsState(if (pressed && !busy) 1f else 0f,
        tween(if (reduced) 0 else CyrusMotion.Fast, easing = CyrusMotion.Ease), label = "corePress")
    val engaged = animateFloatAsState(if (active) 1f else 0f,
        tween(if (reduced) 0 else CyrusMotion.Settle, easing = CyrusMotion.Ease), label = "coreEngaged")
    val working = animateFloatAsState(if (busy) 1f else 0f,
        tween(if (reduced) 0 else CyrusMotion.Screen, easing = CyrusMotion.Ease), label = "coreWorking")

    // No infinite work while idle; one clock only while busy or connected.
    val spin: State<Float> = if (busy && animate && !reduced) {
        rememberInfiniteTransition(label = "coreSpin").animateFloat(0f, 360f,
            infiniteRepeatable(tween(CyrusMotion.Spin, easing = LinearEasing)), label = "coreAngle")
    } else remember { mutableFloatStateOf(0f) }
    val breath: State<Float> = if (active && animate && !reduced) {
        rememberInfiniteTransition(label = "coreBreath").animateFloat(0f, 1f,
            infiniteRepeatable(tween(CyrusMotion.Breath, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "coreBreathValue")
    } else remember { mutableFloatStateOf(0f) }

    val glyphTint by animateColorAsState(
        if (active || busy || status == CoreStatus.Failed) ring else scheme.onBackground,
        tween(if (reduced) 0 else CyrusMotion.Screen), label = "coreGlyph")

    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(CoreSize)
                .graphicsLayer {
                    val s = 1f - .04f * press.value + .010f * engaged.value * (0.4f + breath.value)
                    scaleX = s; scaleY = s
                }
                .clickable(enabled = !busy, role = Role.Button, interactionSource = interactions,
                    indication = null, onClick = onClick)
                .semantics {
                    contentDescription = label
                    stateDescription = when (status) {
                        CoreStatus.Active -> "Подключено"
                        CoreStatus.Busy -> label
                        CoreStatus.Failed -> "Ошибка подключения"
                        CoreStatus.Idle -> "Не подключено"
                    }
                },
            contentAlignment = Alignment.Center,
        ) {
            // Bloom: pure layer work, never invalidates draw of anything else.
            Box(Modifier.fillMaxSize(.86f).graphicsLayer {
                alpha = engaged.value * (.55f + .35f * breath.value)
            }.background(Brush.radialGradient(listOf(CyrusTokens.Accent.copy(alpha = .30f), Color.Transparent)), CircleShape))

            Canvas(Modifier.fillMaxSize()) {
                val side = size.minDimension
                val center = Offset(side / 2f, side / 2f)
                val trackWidth = 2.dp.toPx()
                val radius = side / 2f - 26.dp.toPx()
                val p = press.value
                val e = engaged.value
                val wk = working.value

                // Theme-aware opaque disc: wallpaper cannot change glyph contrast.
                drawCircle(body, radius - trackWidth, center)

                // Opaque boundary in ALL states; geometry and label communicate status.
                drawCircle(ring, radius, center,
                    style = Stroke(trackWidth))
                if (e > 0f) {
                    drawCircle(ring.copy(alpha = .18f * e), radius + 5.dp.toPx(), center,
                        style = Stroke(6.dp.toPx()))
                }

                // Running sweep: a single rotated sweep-gradient stroke. Constant
                // angular speed, one full turn per 700ms, no per-frame layout.
                if (wk > 0.01f) {
                    rotate(spin.value, center) {
                        drawCircle(
                            brush = Brush.sweepGradient(
                                0.00f to Color.Transparent,
                                0.55f to ring.copy(alpha = .10f * wk),
                                0.88f to ring.copy(alpha = .75f * wk),
                                1.00f to ringHot.copy(alpha = wk),
                                center = center,
                            ),
                            radius = radius, center = center, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round),
                        )
                    }
                }

                // Tactical brackets: they pull inward on press and open up on connect.
                val half = side / 2f - 10.dp.toPx() - 9.dp.toPx() * p + 4.dp.toPx() * e
                val arm = side * (0.115f + 0.02f * e)
                val bracket = ring
                val stroke = 2.dp.toPx()
                val path = Path()
                for (sx in intArrayOf(-1, 1)) for (sy in intArrayOf(-1, 1)) {
                    val cx = center.x + sx * half
                    val cy = center.y + sy * half
                    path.moveTo(cx - sx * arm, cy)
                    path.lineTo(cx, cy)
                    path.lineTo(cx, cy - sy * arm)
                }
                drawPath(path, bracket, style = Stroke(stroke, cap = StrokeCap.Round))
            }

            CyrusIcon(CyrusSymbol.Power, Modifier.size(52.dp), glyphTint)
        }

        Spacer(Modifier.height(18.dp))
        AnimatedContent(targetState = label, label = "coreLabel", transitionSpec = {
            fadeIn(tween(if (reduced) 0 else CyrusMotion.Screen)) togetherWith
                fadeOut(tween(if (reduced) 0 else CyrusMotion.Fast))
        }) { text ->
            Text(text, style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onBackground)
        }
    }
}

data class CyrusNavigationItem(val route: String, val title: String, val icon: CyrusSymbol)

/** Fixed-width slots: no label timers or per-frame width/layout animation. */
@Composable
fun CyrusNavigationBar(items: List<CyrusNavigationItem>, current: String, onSelect: (String) -> Unit) {
    Row(
        Modifier.widthIn(max = 440.dp).fillMaxWidth()
            .clip(RoundedCornerShape(34.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(34.dp))
            .selectableGroup()
            .padding(horizontal = 6.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        items.forEach { item ->
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                CyrusNavigationItemView(item, item.route == current) { onSelect(item.route) }
            }
        }
    }
}

@Composable
private fun CyrusNavigationItemView(item: CyrusNavigationItem, isSelected: Boolean, onClick: () -> Unit) {
    val reduced = LocalReducedMotion.current
    val interactions = remember { MutableInteractionSource() }
    val pressed by interactions.collectIsPressedAsState()
    val press = animateFloatAsState(if (pressed) 1f else 0f,
        tween(if (reduced) 0 else CyrusMotion.Fast, easing = CyrusMotion.Ease), label = "pillPress")
    // Switch fill and foreground atomically. Cross-fading them independently
    // can create a low-contrast intermediate frame during fast tab changes.
    val pill = if (isSelected) CyrusTokens.Accent else Color.Transparent
    val tint = if (isSelected) CyrusTokens.OnAccent else MaterialTheme.colorScheme.onSurfaceVariant
    Box(
        Modifier.size(width = 66.dp, height = 52.dp)
            .graphicsLayer { val s = 1f - .04f * press.value; scaleX = s; scaleY = s }
            .clip(RoundedCornerShape(26.dp))
            .background(pill)
            .selectable(selected = isSelected, role = Role.Tab, indication = null,
                interactionSource = interactions, onClick = onClick)
            .semantics { contentDescription = item.title },
        contentAlignment = Alignment.Center,
    ) { CyrusIcon(item.icon, Modifier.size(25.dp), tint) }
}

/** Three-way segmented control used by the only remaining setting. */
@Composable
fun CyrusSegmented(labels: List<String>, selectedIndex: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    require(labels.isNotEmpty())
    BoxWithConstraints(modifier.fillMaxWidth().height(52.dp)
        .clip(RoundedCornerShape(26.dp))
        .background(MaterialTheme.colorScheme.surfaceVariant)
        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(26.dp))
        .padding(5.dp)) {
        val itemWidth = maxWidth / labels.size
        Box(Modifier.width(itemWidth).fillMaxHeight().graphicsLayer {
            translationX = selectedIndex.coerceIn(0, labels.lastIndex) * itemWidth.toPx()
        }.background(CyrusTokens.Accent, RoundedCornerShape(22.dp)))
        Row(Modifier.fillMaxSize()) {
            labels.forEachIndexed { i, text ->
                val tint = if (i == selectedIndex) CyrusTokens.OnAccent else MaterialTheme.colorScheme.onSurfaceVariant
                Box(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(22.dp))
                    .clickable(role = Role.RadioButton, indication = null,
                        interactionSource = remember { MutableInteractionSource() },
                        onClick = { onSelect(i) })
                    .semantics { selected = i == selectedIndex }, contentAlignment = Alignment.Center) {
                    Text(text, style = MaterialTheme.typography.titleMedium, color = tint)
                }
            }
        }
    }
}

@Composable
fun StatPill(title: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(MaterialTheme.colorScheme.surface, RoundedCornerShape(18.dp)).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text(title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.titleMedium)
    }
}

enum class CyrusSymbol { Shield, Key, Store, Power, Plus, Arrow, Check, Settings, Back }

@Composable
fun CyrusIcon(symbol: CyrusSymbol, modifier: Modifier = Modifier, color: Color = MaterialTheme.colorScheme.onSurface) {
    Canvas(modifier.size(24.dp)) {
        val s = size.minDimension / 24f
        fun point(x: Float, y: Float) = Offset(x * s, y * s)
        val stroke = Stroke(width = 1.8f * s, cap = StrokeCap.Round)
        fun line(x: Float, y: Float, x2: Float, y2: Float) = drawLine(color, point(x,y), point(x2,y2), 1.8f*s, StrokeCap.Round)
        when (symbol) {
            CyrusSymbol.Power -> { drawArc(color, -48f, 276f, false, point(4f,4f), androidx.compose.ui.geometry.Size(16*s,16*s), style=stroke); line(12f,2f,12f,11f) }
            CyrusSymbol.Shield -> {
                val path = Path().apply { moveTo(12*s,2*s); lineTo(20*s,5*s); lineTo(20*s,12*s); cubicTo(20*s,17*s,15*s,21*s,12*s,22*s); cubicTo(9*s,21*s,4*s,17*s,4*s,12*s); lineTo(4*s,5*s); close() }
                drawPath(path,color,style=stroke); line(8f,12f,11f,15f); line(11f,15f,16f,9f)
            }
            CyrusSymbol.Key -> { drawCircle(color,5*s,point(8f,8f),style=stroke); line(11.5f,11.5f,21f,21f); line(16f,16f,19f,13f); line(19f,19f,22f,16f) }
            CyrusSymbol.Store -> { drawRoundRect(color,point(3f,6f),androidx.compose.ui.geometry.Size(18*s,15*s),androidx.compose.ui.geometry.CornerRadius(3*s),style=stroke); line(8f,6f,8f,3f); line(8f,3f,16f,3f); line(16f,3f,16f,6f); line(8f,12f,16f,12f) }
            CyrusSymbol.Plus -> { line(12f,5f,12f,19f); line(5f,12f,19f,12f) }
            CyrusSymbol.Arrow -> { line(5f,12f,19f,12f); line(14f,7f,19f,12f); line(19f,12f,14f,17f) }
            CyrusSymbol.Settings -> {
                line(3f,6f,21f,6f); line(3f,12f,21f,12f); line(3f,18f,21f,18f)
                drawCircle(color,2.5f*s,point(8f,6f),style=stroke)
                drawCircle(color,2.5f*s,point(16f,12f),style=stroke)
                drawCircle(color,2.5f*s,point(10f,18f),style=stroke)
            }
            CyrusSymbol.Back -> { line(19f,12f,5f,12f); line(5f,12f,10f,7f); line(5f,12f,10f,17f) }
            CyrusSymbol.Check -> { line(5f,12f,10f,17f); line(10f,17f,19f,7f) }
        }
    }
}
