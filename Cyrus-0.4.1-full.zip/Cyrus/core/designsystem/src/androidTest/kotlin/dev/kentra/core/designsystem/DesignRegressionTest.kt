package dev.kentra.core.designsystem

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toPixelMap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.Parameterized
import kotlin.math.abs

/** Real rendering checks; run on Android, not replaced by the Python source gate. */
@RunWith(Parameterized::class)
class DesignRegressionTest(private val dark: Boolean, private val status: CoreStatus) {
    companion object {
        @JvmStatic @Parameterized.Parameters(name = "dark={0}, status={1}")
        fun cases(): List<Array<Any>> = listOf(false, true).flatMap { dark ->
            CoreStatus.entries.map { arrayOf<Any>(dark, it) }
        }
    }
    @get:Rule val compose = createComposeRule()

    @Test fun transparentScaffoldInheritsThemeForeground() {
        var actual = Color.Unspecified
        var expected = Color.Unspecified
        compose.setContent {
            CyrusTheme(dark) {
                expected = MaterialTheme.colorScheme.onBackground
                // Deliberately omit contentColor: verifies the theme-level safety net.
                Scaffold(containerColor = Color.Transparent) { padding ->
                    actual = LocalContentColor.current
                    Box(Modifier.padding(padding)) { }
                }
            }
        }
        compose.runOnIdle { assertEquals(expected, actual) }
    }

    @Test fun everyCoreStateHasVisibleOpaqueBoundary() {
        var boundary = Color.Unspecified
        compose.setContent {
            CyrusTheme(dark) {
                boundary = if (status == CoreStatus.Failed) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.primary
                Box(Modifier.background(MaterialTheme.colorScheme.background)) {
                    TacticalCore("Подключить", status, animate = false, onClick = {},
                        modifier = Modifier.testTag("core"))
                }
            }
        }
        val pixels = compose.onNodeWithTag("core").captureToImage().toPixelMap()
        var count = 0
        // Scan the outer portion (exclude the power glyph and the label).
        for (y in 0 until pixels.width.coerceAtMost(pixels.height)) {
            for (x in 0 until pixels.width) {
                val dx = x - pixels.width / 2f
                val dy = y - pixels.width / 2f
                if (dx*dx + dy*dy < pixels.width*pixels.width*.09f) continue
                val c = pixels[x,y]
                if (abs(c.red-boundary.red) < .02f && abs(c.green-boundary.green) < .02f &&
                    abs(c.blue-boundary.blue) < .02f && c.alpha > .99f) count++
            }
        }
        assertTrue("Ring/brackets missing in dark=$dark status=$status", count > pixels.width)
    }

    @Test fun tabSelectionRespondsImmediatelyAndSupportsRepeatTaps() {
        compose.setContent {
            CyrusTheme(dark) {
                var route by remember { mutableStateOf("home") }
                CyrusNavigationBar(listOf(
                    CyrusNavigationItem("home", "Главная", CyrusSymbol.Shield),
                    CyrusNavigationItem("profiles", "Ключи", CyrusSymbol.Key),
                    CyrusNavigationItem("store", "Подписка", CyrusSymbol.Store),
                ), route) { route = it }
            }
        }
        repeat(3) {
            compose.onNodeWithContentDescription("Ключи").performClick().assertIsSelected()
            compose.onNodeWithContentDescription("Ключи").performClick().assertIsSelected()
            compose.onNodeWithContentDescription("Подписка").performClick().assertIsSelected()
            compose.onNodeWithContentDescription("Главная").performClick().assertIsSelected()
        }
    }
}
