#!/usr/bin/env python3
"""Optional numeric/assets audit; requires Pillow. Does NOT execute Compose."""
from pathlib import Path
import math,re
from PIL import Image
root=Path(__file__).resolve().parents[1]
lines=[]
def out(s): print(s);lines.append(s)
# This is an independent numeric audit of the drawing formula, NOT running Compose.
for width,height in [(240,64),(280,64),(320,64),(320,90)]:
 length=2*(width-height)+math.pi*(height-4)
 for frame in range(1001):
  head=frame/1000
  for i in range(16):
   start=((head+i*.018)%1)*length;end=start+.019*length
   parts=[(start,min(end,length))]
   if end>length:parts.append((0,end-length))
   assert all(0<=a<=b<=length for a,b in parts)
   assert abs(sum(b-a for a,b in parts)-.019*length)<1e-8
out('PASS numeric audit: contour wraparound stays in bounds for 64,064 cases; segment length continuous across seam.')
def lum(h):
 v=[int(h[i:i+2],16)/255 for i in (0,2,4)]
 v=[x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4 for x in v]
 return sum(x*w for x,w in zip(v,[.2126,.7152,.0722]))
for name,a,b in [('dark text','E7E5E0','111827'),('light text','2C2E31','F9F8F3'),('CTA label','1B0C00','F97316')]:
 ratio=(max(lum(a),lum(b))+.05)/(min(lum(a),lum(b))+.05)
 assert ratio>=4.5
 out(f'PASS base colour contrast {name}: {ratio:.2f}:1 (not a full rendered accessibility audit).')
resources={f.stem for f in (root/'app/src/main/res/drawable-nodpi').glob('*.webp')}
for f in (root/'app/src/main/res/drawable-nodpi').glob('*.webp'):
 with Image.open(f) as im:
  im.load();assert im.width<=1080 and im.height<=2160
  out(f'PASS image decode: {f.name}, {im.width}x{im.height}, {f.stat().st_size} bytes')
s=(root/'app/src/main/kotlin/dev/kentra/app/CyrusWallpaper.kt').read_text()
assert set(re.findall(r'R.drawable.(wallpaper_\w+)',s))==resources
out('PASS every wallpaper resource referenced by Kotlin exists, including both light adaptations.')
out('NOT RUN: Android renderer, Kotlin compiler, JUnit, screenshot capture, runtime lifecycle, FPS/jank.')
(root/'validation/design-audit.txt').write_text('\n'.join(lines)+'\n')
