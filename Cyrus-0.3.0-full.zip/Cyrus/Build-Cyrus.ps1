$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
if (-not (Get-Command gradle -ErrorAction SilentlyContinue)) {
    throw "Install Gradle 8.11.1, JDK 17 and Android SDK 35, or run GitHub Actions. See README.md."
}
python tools/check_source.py
if ($LASTEXITCODE -ne 0) { throw "Static source checks failed" }
if (-not (Get-ChildItem -Path "vpn/service/libs/*.aar" -ErrorAction SilentlyContinue)) {
    throw "Provide a compatible libbox.aar in vpn/service/libs/. See README.md."
}
gradle --no-daemon --stacktrace test :app:lintDebug :app:assembleDebug
if ($LASTEXITCODE -ne 0) { throw "Android build or tests failed" }
