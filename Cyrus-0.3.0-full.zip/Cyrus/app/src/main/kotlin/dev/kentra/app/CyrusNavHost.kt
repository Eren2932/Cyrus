package dev.kentra.app

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.*
import dev.kentra.core.datastore.AppearanceSettings
import dev.kentra.core.datastore.SettingsStore
import dev.kentra.core.designsystem.*
import dev.kentra.feature.home.HomeRoute
import dev.kentra.feature.profiles.ProfilesRoute
import dev.kentra.feature.store.StoreRoute

private val tabs = listOf(
    CyrusNavigationItem("home", "Главная", CyrusSymbol.Shield),
    CyrusNavigationItem("profiles", "Ключи", CyrusSymbol.Key),
    CyrusNavigationItem("store", "Подписка", CyrusSymbol.Store),
)

@Composable
fun CyrusNavHost(appearance: AppearanceSettings, dark: Boolean, settings: SettingsStore) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val current = entry?.destination?.route ?: "home"
    val reduced = LocalReducedMotion.current
    val duration = if (reduced) 0 else CyrusMotion.Screen
    fun navigate(route: String) {
        if (current != route) nav.navigate(route) {
            popUpTo("home") { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }
    fun direction(from: String?, to: String?): Int {
        val order = listOf("home", "profiles", "store", "settings")
        return if (order.indexOf(to) >= order.indexOf(from)) 1 else -1
    }
    Box(Modifier.fillMaxSize()) {
        CyrusWallpaper(appearance.wallpaper, dark, Modifier.matchParentSize())
        Scaffold(modifier = Modifier.windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Horizontal)),
            containerColor = Color.Transparent,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            topBar = {
                Row(Modifier.fillMaxWidth().windowInsetsPadding(WindowInsets.statusBars)
                    .padding(horizontal = 20.dp).heightIn(min = 60.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (current == "settings") {
                        IconButton(onClick = { nav.popBackStack() }, modifier = Modifier.semantics { contentDescription = "Назад" }) {
                            CyrusIcon(CyrusSymbol.Back)
                        }
                    }
                    Text(when (current) {
                        "profiles" -> "Ключи"
                        "store" -> "Подписка"
                        "settings" -> "Настройки"
                        else -> "Cyrus"
                    }, Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
                    if (current != "settings") {
                        IconButton(onClick = { nav.navigate("settings") { launchSingleTop = true } },
                            modifier = Modifier.semantics { contentDescription = "Настройки" }) {
                            CyrusIcon(CyrusSymbol.Settings)
                        }
                    }
                }
            },
            bottomBar = {
                // Reserve the same height in settings: no content jump on entering/leaving.
                Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp)
                    .height(66.dp), contentAlignment = Alignment.Center) {
                    if (current != "settings") CyrusNavigationBar(tabs, current, ::navigate)
                }
            }) { padding ->
            NavHost(navController = nav, startDestination = "home",
                modifier = Modifier.padding(padding).consumeWindowInsets(padding),
                enterTransition = {
                    val sign = direction(initialState.destination.route, targetState.destination.route)
                    fadeIn(tween(duration)) + slideInHorizontally(tween(duration, easing = CyrusMotion.Ease)) { if (reduced) 0 else sign * it / 24 }
                },
                exitTransition = { fadeOut(tween(if (reduced) 0 else CyrusMotion.Fast)) },
                popEnterTransition = {
                    fadeIn(tween(duration)) + slideInHorizontally(tween(duration, easing = CyrusMotion.Ease)) { if (reduced) 0 else -it / 24 }
                },
                popExitTransition = { fadeOut(tween(if (reduced) 0 else CyrusMotion.Fast)) }) {
                composable("home") { HomeRoute(onNavigateToProfiles = { navigate("profiles") }) }
                composable("profiles") { ProfilesRoute() }
                composable("store") { StoreRoute(onImport = { navigate("profiles") }) }
                composable("settings") { SettingsScreen(appearance, dark, settings) }
            }
        }
    }
}
