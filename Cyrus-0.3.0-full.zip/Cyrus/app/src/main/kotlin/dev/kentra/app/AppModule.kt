package dev.kentra.app

import dev.kentra.domain.usecase.ConnectUseCase
import dev.kentra.domain.usecase.DeleteProfileUseCase
import dev.kentra.domain.usecase.DisconnectUseCase
import dev.kentra.domain.usecase.ImportKeysUseCase
import dev.kentra.feature.home.HomeViewModel
import dev.kentra.feature.profiles.ProfilesViewModel
import dev.kentra.feature.store.StoreViewModel
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module

/**
 * Use cases and view models live here because :app is the only module allowed to know
 * about every other module. Features stay independent of each other.
 */
val appModule = module {
    single { ImportKeysUseCase(parser = get(), profiles = get()) }
    factory { ConnectUseCase(profiles = get(), tunnel = get()) }
    factory { DisconnectUseCase(tunnel = get()) }
    factory { DeleteProfileUseCase(profiles = get(), tunnel = get()) }

    viewModel {
        HomeViewModel(
            profiles = get(),
            tunnel = get(),
            connect = get(),
            disconnect = get(),
        )
    }
    viewModel {
        ProfilesViewModel(
            profiles = get(),
            subscriptions = get(),
            importKeys = get(),
            deleteProfile = get(),
            parser = get(),
        )
    }
    viewModel { StoreViewModel(billing = get()) }
}
