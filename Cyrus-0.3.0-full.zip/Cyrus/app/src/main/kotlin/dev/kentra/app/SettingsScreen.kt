package dev.kentra.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import dev.kentra.core.datastore.*
import dev.kentra.core.designsystem.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.CancellationException

@Composable
fun SettingsScreen(appearance: AppearanceSettings, dark: Boolean, settings: SettingsStore) {
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    fun save(action: suspend () -> Unit) {
        scope.launch {
            try { action() }
            catch (e: Exception) {
                if (e is CancellationException) throw e
                snackbar.showSnackbar("Не удалось сохранить настройку")
            }
        }
    }
    Scaffold(containerColor = androidx.compose.ui.graphics.Color.Transparent,
        contentWindowInsets = WindowInsets(0, 0, 0, 0), snackbarHost = { SnackbarHost(snackbar) }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
            item {
                CyrusCard {
                    Text("Тема", style = MaterialTheme.typography.titleMedium)
                    ThemeMode.entries.forEach { mode ->
                        val chosen = appearance.theme == mode
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                            .clickable(role = Role.RadioButton) { save { settings.setTheme(mode) } }
                            .semantics { selected = chosen }.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = chosen, onClick = null)
                            Text(when (mode) { ThemeMode.SYSTEM -> "Системная"; ThemeMode.DARK -> "Тёмная"; ThemeMode.LIGHT -> "Светлая" }, Modifier.padding(start = 12.dp, top = 12.dp, bottom = 12.dp))
                        }
                    }
                }
            }
            item {
                Text("Фон", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(bottom = 12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Wallpaper.entries.forEach { wallpaper ->
                        val chosen = appearance.wallpaper == wallpaper
                        val title = when (wallpaper) { Wallpaper.NONE -> "Без обоев"; Wallpaper.GEOMETRY -> "Геометрия"; Wallpaper.ABSTRACT -> "Абстракция" }
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.fillMaxWidth().aspectRatio(.70f).clip(RoundedCornerShape(20.dp))
                                .border(if (chosen) 2.dp else 1.dp,
                                    if (chosen) CyrusTokens.Accent else MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(20.dp))
                                .clickable(role = Role.RadioButton) { save { settings.setWallpaper(wallpaper) } }
                                .semantics { selected = chosen; contentDescription = title }, contentAlignment = Alignment.BottomEnd) {
                                CyrusWallpaper(wallpaper, dark, Modifier.matchParentSize().padding(3.dp).clip(RoundedCornerShape(17.dp)), preview = true)
                                if (chosen) Box(Modifier.padding(8.dp).background(CyrusTokens.Accent, RoundedCornerShape(50)).padding(4.dp)) {
                                    CyrusIcon(CyrusSymbol.Check, Modifier.size(16.dp), CyrusTokens.OnAccent)
                                }
                            }
                            Text(title,
                                Modifier.padding(top = 8.dp), style = MaterialTheme.typography.labelSmall,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        }
                    }
                }
            }
            item {
                CyrusCard {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Меньше движения", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                        Switch(checked = appearance.reducedMotion, onCheckedChange = { value -> save { settings.setReducedMotion(value) } })
                    }
                }
            }
            item {
                CyrusCard {
                    Text("Снимки экрана", style = MaterialTheme.typography.titleMedium)
                    Text("Разрешены. Окна импорта и просмотра ключей защищены.",
                        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
