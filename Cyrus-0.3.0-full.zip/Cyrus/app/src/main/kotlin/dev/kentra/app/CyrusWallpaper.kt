package dev.kentra.app

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import dev.kentra.core.datastore.Wallpaper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun CyrusWallpaper(wallpaper: Wallpaper, dark: Boolean, modifier: Modifier = Modifier, preview: Boolean = false) {
    val resources = LocalContext.current.resources
    val resource = when (wallpaper) {
        Wallpaper.NONE -> null
        Wallpaper.GEOMETRY -> if (dark) R.drawable.wallpaper_geometry else R.drawable.wallpaper_geometry_light
        Wallpaper.ABSTRACT -> if (dark) R.drawable.wallpaper_abstract else R.drawable.wallpaper_abstract_light
    }
    // Decoding is off the UI thread and never repeated by the contour animation.
    val bitmap by produceState<ImageBitmap?>(null, resource, preview) {
        value = null
        value = resource?.let { id -> withContext(Dispatchers.IO) {
            BitmapFactory.decodeResource(resources, id, BitmapFactory.Options().apply {
                inSampleSize = if (preview) 4 else 1
            })?.asImageBitmap()
        } }
    }
    Box(modifier.background(MaterialTheme.colorScheme.background)) {
        bitmap?.let { image ->
            Image(image, contentDescription = null, modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop, alpha = if (dark) .72f else 1f)
        }
    }
}
