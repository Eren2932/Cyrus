package dev.kentra.app

import android.app.Application
import dev.kentra.data.dataModule
import dev.kentra.vpn.service.vpnModule
import org.koin.android.ext.koin.androidContext
import org.koin.android.ext.koin.androidLogger
import org.koin.core.context.startKoin
import org.koin.core.logger.Level

class CyrusApp : Application() {

    override fun onCreate() {
        super.onCreate()
        startKoin {
            androidLogger(if (BuildConfigFlags.DEBUG_DI) Level.DEBUG else Level.NONE)
            androidContext(this@CyrusApp)
            modules(dataModule, vpnModule, appModule)
        }
    }
}

/** Tiny indirection so modules do not depend on the app's generated BuildConfig. */
object BuildConfigFlags {
    const val DEBUG_DI = false
}
