package dev.kentra.vpn.config

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Typed sing-box configuration. We never build this JSON with string concatenation:
 * one wrong comma equals a dead tunnel on a user's phone with no way to debug it remotely.
 */
@Serializable
data class SingBoxConfig(
    val log: LogConfig = LogConfig(),
    val dns: DnsConfig,
    val inbounds: List<Inbound>,
    val outbounds: List<Outbound>,
    val route: RouteConfig,
    val experimental: Experimental = Experimental(),
)

@Serializable
data class LogConfig(
    val level: String = "warn",
    val timestamp: Boolean = true,
)

@Serializable
data class DnsConfig(
    val servers: List<DnsServer>,
    val rules: List<DnsRule> = emptyList(),
    val strategy: String = "prefer_ipv4",
    @SerialName("independent_cache") val independentCache: Boolean = true,
    val final: String? = null,
)

@Serializable
data class DnsServer(
    val tag: String,
    val address: String,
    @SerialName("address_resolver") val addressResolver: String? = null,
    val detour: String? = null,
    val strategy: String? = null,
)

@Serializable
data class DnsRule(
    val outbound: List<String>? = null,
    @SerialName("rule_set") val ruleSet: List<String>? = null,
    val server: String,
    @SerialName("disable_cache") val disableCache: Boolean? = null,
)

@Serializable
data class Inbound(
    val type: String,
    val tag: String,
    @SerialName("interface_name") val interfaceName: String? = null,
    val address: List<String>? = null,
    val mtu: Int? = null,
    @SerialName("auto_route") val autoRoute: Boolean? = null,
    @SerialName("strict_route") val strictRoute: Boolean? = null,
    val stack: String? = null,
    val sniff: Boolean? = null,
    @SerialName("sniff_override_destination") val sniffOverrideDestination: Boolean? = null,
    @SerialName("endpoint_independent_nat") val endpointIndependentNat: Boolean? = null,
)

@Serializable
data class Outbound(
    val type: String,
    val tag: String,
    val server: String? = null,
    @SerialName("server_port") val serverPort: Int? = null,
    val uuid: String? = null,
    val password: String? = null,
    val method: String? = null,
    val flow: String? = null,
    val security: String? = null,
    @SerialName("alter_id") val alterId: Int? = null,
    val tls: OutboundTls? = null,
    val transport: OutboundTransport? = null,
    val multiplex: Multiplex? = null,
    val outbounds: List<String>? = null,
    @SerialName("domain_strategy") val domainStrategy: String? = null,
)

@Serializable
data class OutboundTls(
    val enabled: Boolean,
    @SerialName("server_name") val serverName: String? = null,
    val insecure: Boolean? = null,
    val alpn: List<String>? = null,
    val utls: Utls? = null,
    val reality: Reality? = null,
)

@Serializable
data class Utls(val enabled: Boolean = true, val fingerprint: String = "chrome")

@Serializable
data class Reality(
    val enabled: Boolean = true,
    @SerialName("public_key") val publicKey: String,
    @SerialName("short_id") val shortId: String? = null,
)

@Serializable
data class OutboundTransport(
    val type: String,
    val path: String? = null,
    val headers: Map<String, String>? = null,
    @SerialName("service_name") val serviceName: String? = null,
    val host: List<String>? = null,
)

@Serializable
data class Multiplex(
    val enabled: Boolean = false,
    val protocol: String = "h2mux",
    @SerialName("max_connections") val maxConnections: Int = 4,
    val padding: Boolean = true,
)

@Serializable
data class RouteConfig(
    val rules: List<RouteRule> = emptyList(),
    @SerialName("rule_set") val ruleSet: List<RuleSet> = emptyList(),
    val final: String,
    @SerialName("auto_detect_interface") val autoDetectInterface: Boolean = true,
    @SerialName("override_android_vpn") val overrideAndroidVpn: Boolean = true,
)

@Serializable
data class RouteRule(
    val protocol: List<String>? = null,
    val port: List<Int>? = null,
    val network: List<String>? = null,
    @SerialName("ip_is_private") val ipIsPrivate: Boolean? = null,
    @SerialName("rule_set") val ruleSet: List<String>? = null,
    val domain: List<String>? = null,
    @SerialName("domain_suffix") val domainSuffix: List<String>? = null,
    @SerialName("package_name") val packageName: List<String>? = null,
    val outbound: String,
)

@Serializable
data class RuleSet(
    val tag: String,
    val type: String = "remote",
    val format: String = "binary",
    val url: String,
    @SerialName("download_detour") val downloadDetour: String? = null,
)

@Serializable
data class Experimental(
    @SerialName("cache_file") val cacheFile: CacheFile = CacheFile(),
    @SerialName("clash_api") val clashApi: ClashApi? = null,
)

@Serializable
data class CacheFile(
    val enabled: Boolean = true,
    val path: String = "cache.db",
    @SerialName("store_fakeip") val storeFakeip: Boolean = false,
)

@Serializable
data class ClashApi(
    @SerialName("external_controller") val externalController: String = "127.0.0.1:9090",
)
