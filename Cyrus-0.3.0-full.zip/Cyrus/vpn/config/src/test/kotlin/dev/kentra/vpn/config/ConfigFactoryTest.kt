package dev.kentra.vpn.config

import dev.kentra.domain.model.RealitySettings
import dev.kentra.domain.model.TlsSettings
import dev.kentra.domain.model.TransportSettings
import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.model.VpnProtocol
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ConfigFactoryTest {

    private val factory = ConfigFactory()

    private val reality = VpnProfile(
        id = "1",
        name = "NL",
        protocol = VpnProtocol.VLESS,
        server = "1.2.3.4",
        port = 443,
        uuid = "uuid-1",
        flow = "xtls-rprx-vision",
        tls = TlsSettings(
            enabled = true,
            serverName = "www.microsoft.com",
            fingerprint = "chrome",
            reality = RealitySettings(publicKey = "PK", shortId = "ab"),
        ),
    )

    @Test
    fun `vless reality maps to sing-box outbound`() {
        val config = factory.config(reality, TunnelOptions())
        val proxy = config.outbounds.first { it.tag == "proxy" }

        assertEquals("vless", proxy.type)
        assertEquals("uuid-1", proxy.uuid)
        assertEquals("xtls-rprx-vision", proxy.flow)
        assertEquals("www.microsoft.com", proxy.tls?.serverName)
        assertEquals("PK", proxy.tls?.reality?.publicKey)
        assertEquals("chrome", proxy.tls?.utls?.fingerprint)
    }

    @Test
    fun `tun inbound respects options`() {
        val config = factory.config(reality, TunnelOptions(mtu = 1420, stack = "gvisor", ipv6 = true))
        val tun = config.inbounds.single()

        assertEquals(1420, tun.mtu)
        assertEquals("gvisor", tun.stack)
        assertEquals(2, tun.address?.size)
    }

    @Test
    fun `dns route targets dns-out and default route targets proxy`() {
        val config = factory.config(reality, TunnelOptions())
        assertTrue(config.route.rules.any { it.protocol == listOf("dns") && it.outbound == "dns-out" })
        assertEquals("proxy", config.route.final)
    }

    @Test
    fun `ws transport is emitted with host header`() {
        val profile = reality.copy(transport = TransportSettings(type = "ws", path = "/ws", host = "cdn.tld"))
        val proxy = factory.config(profile, TunnelOptions()).outbounds.first { it.tag == "proxy" }

        assertEquals("ws", proxy.transport?.type)
        assertEquals("/ws", proxy.transport?.path)
        assertEquals("cdn.tld", proxy.transport?.headers?.get("Host"))
    }

    @Test
    fun `serialized json contains no null noise`() {
        val out = factory.build(reality.copy(transport = TransportSettings(type = "tcp")))
        assertFalse(out.contains(": null"))
        assertTrue(out.contains("\"type\": \"tun\""))
    }
}
