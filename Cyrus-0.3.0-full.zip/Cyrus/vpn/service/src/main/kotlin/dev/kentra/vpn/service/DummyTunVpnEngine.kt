package dev.kentra.vpn.service

import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log
import dev.kentra.domain.model.TrafficSample
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import kotlin.concurrent.thread

/**
 * A dummy engine used in Stage 2 to verify that TUN can be established,
 * permissions are granted, and there are no routing loops.
 */
class DummyTunVpnEngine : VpnEngine {
    override val id = "dummy_tun"

    @Volatile
    private var pfd: ParcelFileDescriptor? = null
    @Volatile
    private var isRunning = false

    override suspend fun start(service: VpnService, session: TunnelSession) {
        withContext(Dispatchers.IO) {
            Log.i("DummyTun", "Starting dummy TUN interface")
            isRunning = true
            
            // 1. Establish a dummy TUN with a local IP
            pfd = service.Builder()
                .setSession("Dummy VPN")
                .setMtu(1500)
                .addAddress("10.0.0.2", 24)
                .addRoute("0.0.0.0", 0) // Route all traffic to test loop
                .establish()
            
            if (pfd == null) {
                error("Failed to establish TUN. Permission revoked or used by another app.")
            }

            // 2. Start a simple UDP echo server to test protect() and loop protection
            thread(name = "DummyEchoServer") {
                try {
                    val socket = DatagramSocket(0)
                    // Protect the socket so its traffic goes over physical network, not TUN
                    if (!service.protect(socket)) {
                        Log.e("DummyTun", "Failed to protect socket!")
                    } else {
                        Log.i("DummyTun", "Socket protected successfully on port ${socket.localPort}")
                    }
                    
                    val buf = ByteArray(1024)
                    while (isRunning && !socket.isClosed) {
                        // In a real test, you'd send something to an external IP
                        // and see if it loops back to the TUN interface.
                        // Here we just keep the socket open and protected.
                        Thread.sleep(1000)
                    }
                    socket.close()
                } catch (e: Exception) {
                    Log.e("DummyTun", "Echo server error", e)
                }
            }
            
            // Wait while running
            while (isRunning && isActive) {
                delay(1000)
            }
        }
    }

    override suspend fun stop() {
        isRunning = false
        withContext(Dispatchers.IO) {
            try {
                pfd?.close()
            } catch (e: Exception) {
                Log.e("DummyTun", "Error closing PFD", e)
            }
            pfd = null
            Log.i("DummyTun", "Dummy TUN interface closed")
        }
    }

    override val traffic: Flow<TrafficSample> = flow {
        while (true) {
            delay(1000)
            emit(TrafficSample(1024L, 1024L)) // fake traffic
        }
    }
}
