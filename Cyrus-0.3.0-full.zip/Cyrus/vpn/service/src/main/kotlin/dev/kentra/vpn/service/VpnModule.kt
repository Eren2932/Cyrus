package dev.kentra.vpn.service

import dev.kentra.domain.repository.TunnelController
import dev.kentra.vpn.config.ConfigFactory
import org.koin.android.ext.koin.androidContext
import org.koin.dsl.module

val vpnModule = module {
    single { TunnelBus() }
    single { ConfigFactory() }

    // Real sing-box core (Phase 2)
    single<VpnEngine> { LibboxVpnEngine() }

    single<TunnelController> {
        TunnelControllerImpl(
            context = androidContext(),
            bus = get(),
            settings = get(),
            configFactory = get(),
            engine = get(),
        )
    }
}
