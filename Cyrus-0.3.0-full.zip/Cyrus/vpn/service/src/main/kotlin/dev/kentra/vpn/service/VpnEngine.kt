package dev.kentra.vpn.service

import android.net.VpnService
import dev.kentra.domain.model.TrafficSample
import kotlinx.coroutines.flow.Flow

/** Everything the engine needs to bring a tunnel up. Generated in :vpn:config, never hand-written. */
data class TunnelSession(
    val profileId: String,
    val profileName: String,
    val configJson: String,
)

/** Android engine boundary. Native integration must also implement protect(), DNS and lifecycle handling. */
interface VpnEngine {
    val id: String

    /** Must establish the TUN interface through [service] and return only after a real tunnel is established. */
    suspend fun start(service: VpnService, session: TunnelSession)

    suspend fun stop()

    val traffic: Flow<TrafficSample>
}
