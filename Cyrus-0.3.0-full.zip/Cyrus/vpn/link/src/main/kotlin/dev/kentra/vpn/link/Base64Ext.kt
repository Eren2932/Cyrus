package dev.kentra.vpn.link

import java.util.Base64
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction

internal fun String.decodeBase64OrNull(): String? {
    val cleaned = filterNot { it.isWhitespace() }
    if (cleaned.isEmpty() || cleaned.length % 4 == 1) return null
    val bytes = runCatching { Base64.getDecoder().decode(cleaned) }
        .recoverCatching { Base64.getUrlDecoder().decode(cleaned) }.getOrNull() ?: return null
    return runCatching {
        Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString()
    }.getOrNull()
}
