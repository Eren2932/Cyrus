package dev.kentra.vpn.link

import dev.kentra.domain.model.VpnProtocol
import org.junit.Assert.*
import org.junit.Test
import java.util.Base64

class ImportRegressionTest {
    private val parser = DefaultLinkParser(clock={0})
    private val uuid = "11111111-2222-3333-4444-555555555555"
    private fun b64(s:String) = Base64.getEncoder().encodeToString(s.toByteArray())
    @Test fun `tuic auth and query preserved`() {
        val p=parser.parse("tuic://$uuid:pass%3Aword@host.test:443?congestion_control=bbr&alpn=h3")!!
        assertEquals(VpnProtocol.TUIC,p.protocol);assertEquals("pass:word",p.password)
        assertEquals("bbr",p.parameters["congestion_control"]);assertEquals(listOf("h3"),p.tls.alpn)
    }
    @Test fun `literal plus survives credentials`() { assertEquals("a+b+c",parser.parse("trojan://a+b%2Bc@host.test:443")!!.password) }
    @Test fun `percent decoding occurs once`() { assertEquals("a%2Bb",parser.parse("trojan://a%252Bb@host.test:443")!!.password) }
    @Test fun `unicode name roundtrip`() { assertEquals("Россия + NL",parser.parse("vless://$uuid@host.test:443#Россия%20+%20NL")!!.name) }
    @Test fun `mixed case scheme`() { assertEquals(VpnProtocol.VLESS,parser.parse("VlEsS://$uuid@host.test:443")!!.protocol) }
    @Test fun `vless IPv6`() { val p=parser.parse("vless://$uuid@[2001:db8::1]:443")!!;assertEquals("2001:db8::1",p.server);assertEquals("[2001:db8::1]:443",p.displayEndpoint) }
    @Test fun `shadowsocks IPv6`() { assertEquals("2001:db8::2",parser.parse("ss://${b64("aes-256-gcm:password")}@[2001:db8::2]:8388")!!.server) }
    @Test fun `shadowsocks legacy full base64`() { assertEquals("secret:word",parser.parse("ss://${b64("aes-256-gcm:secret:word@host.test:8388")}")!!.password) }
    @Test fun `shadowsocks SIP plugin retained`() { assertEquals("v2ray-plugin;tls;host=cdn.test",parser.parse("ss://${b64("aes-256-gcm:secret")}@host.test:8388/?plugin=v2ray-plugin%3Btls%3Bhost%3Dcdn.test")!!.parameters["plugin"]) }
    @Test fun `shadowsocks percent credentials`() { assertEquals("secret+word",parser.parse("ss://aes-256-gcm%3Asecret%2Bword@host.test:8388")!!.password) }
    @Test fun `vmess JSON numeric port and aid`() {
        val p=parser.parse("vmess://${b64("""{"v":"2","add":"host.test","port":8443,"id":"$uuid","aid":0,"net":"ws","path":"/edge","tls":"tls","sni":"cdn.test"}""")}")!!
        assertEquals(8443,p.port);assertEquals("/edge",p.transport.path);assertTrue(p.tls.enabled)
    }
    @Test fun `hysteria alias and obfs retained`() {
        val p=parser.parse("HY2://token@host.test:443?obfs=salamander&obfs-password=some%2Bvalue")!!
        assertEquals(VpnProtocol.HYSTERIA2,p.protocol);assertEquals("some+value",p.parameters["obfs-password"])
    }
    @Test fun `xhttp additional options retained`() {
        val raw="vless://$uuid@host.test:443?type=xhttp&mode=auto&extra=%7B%22x%22%3A1%7D"
        val p=parser.parse(raw)!!;assertEquals(raw,p.rawLink);assertEquals("xhttp",p.transport.type);assertEquals("{\"x\":1}",p.parameters["extra"])
    }
    @Test fun `missing host rejected`() { assertNull(parser.parse("vless://$uuid@:443")) }
    @Test fun `missing credential rejected`() { assertNull(parser.parse("trojan://host.test:443")) }
    @Test fun `empty password rejected`() { assertNull(parser.parse("trojan://@host.test:443")) }
    @Test fun `invalid UUID rejected`() { assertNull(parser.parse("vless://abc@host.test:443")) }
    @Test fun `zero port rejected`() { assertNull(parser.parse("trojan://x@host.test:0")) }
    @Test fun `oversize port rejected`() { assertNull(parser.parse("trojan://x@host.test:65536")) }
    @Test fun `empty explicit port rejected`() { assertNull(parser.parse("trojan://x@host.test:")) }
    @Test fun `missing shadowsocks port rejected`() { assertNull(parser.parse("ss://${b64("aes-256-gcm:secret")}@host.test")) }
    @Test fun `reality missing public key rejected`() { assertNull(parser.parse("vless://$uuid@host.test:443?security=reality")) }
    @Test fun `partial errors retain line indices without secrets`() {
        val report=parser.inspect("trojan://secret@host.test:443\nBAD secret\ntrojan://other@second.test:443")
        assertEquals(2,report.profiles.size);assertEquals(2,report.issues.single().line)
        assertFalse(report.issues.single().reason.contains("secret"))
    }
    @Test fun `duplicates ignoring fragment counted`() { val r=parser.inspect("trojan://x@host.test:443#One\ntrojan://x@host.test:443#Two");assertEquals(1,r.profiles.size);assertEquals(1,r.duplicates) }
    @Test fun `base64 standard subscription`() { assertEquals(2,parser.inspect(b64("trojan://x@a.test:443\ntrojan://y@b.test:443")).profiles.size) }
    @Test fun `base64 urlsafe unpadded subscription`() { assertEquals(1,parser.inspect(Base64.getUrlEncoder().withoutPadding().encodeToString("trojan://x@host.test:443".toByteArray())).profiles.size) }
    @Test fun `comments and blank lines ignored`() { assertEquals(1,parser.inspect("# comment\n\ntrojan://x@host.test:443\n").profiles.size) }
    @Test fun `oversize input rejected`() { val r=parser.inspect("x".repeat(1_048_577));assertTrue(r.profiles.isEmpty());assertEquals(1,r.issues.size) }
    @Test fun `json whole config is not silently accepted`() { assertTrue(parser.inspect("{\"outbounds\":[]}").profiles.isEmpty()) }
    @Test fun `invalid Base64 is rejected`() { assertNull(parser.parse("vmess://!!!")) }
}
