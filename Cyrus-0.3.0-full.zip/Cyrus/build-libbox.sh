#!/usr/bin/env bash
set -e

# Version variables
SING_BOX_VERSION="1.11.1" # Example target version
GOMOBILE_REF="master" # Using master for SagerNet gomobile fork

echo "Installing SagerNet gomobile ($GOMOBILE_REF)..."
go install "github.com/sagernet/gomobile@$GOMOBILE_REF"
go install "github.com/sagernet/gomobile/cmd/gobind@$GOMOBILE_REF"
gomobile init

# Prepare sing-box source
rm -rf sing-box-build
git clone --depth 1 -b "v$SING_BOX_VERSION" https://github.com/SagerNet/sing-box.git sing-box-build
cd sing-box-build

echo "Building libbox AAR..."
# Minimal build tags for MVP
go run ./cmd/internal/build_libbox -tags "with_quic,with_wireguard,with_utls,with_reality_shadowsocks_obfs" -target android

cd ..
mkdir -p vpn/service/libs
cp sing-box-build/libbox.aar "vpn/service/libs/libbox-${SING_BOX_VERSION}.aar"

echo "Done! libbox-${SING_BOX_VERSION}.aar copied to vpn/service/libs/"
rm -rf sing-box-build
