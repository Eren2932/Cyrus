# Изменения 0.3.0

Актуальное описание: [DESIGN_0.3.md](DESIGN_0.3.md). Прежний анализ сохранён в `history/v0.2-ANALYSIS_AND_CHANGELOG.md`.

Основные затронутые области: design system, HomeScreen, CyrusNavHost, MainActivity, новый SettingsScreen и CyrusWallpaper, AppearanceSettings в существующем SettingsStore, secure-policy двух credential-окон. Profiles/Store очищены от рекламных заголовков; сохранены импорт, редактирование, экспорт, подписки и каталог. В LibboxVpnEngine удалена одна запись полного session.configJson в logcat.

Все изменения относительно фактически загруженного Cyrus.zip перечислены в `validation/changed-files.txt`. Контрольные суммы — `FILES.sha256`. Статус проверки — [VALIDATION.md](VALIDATION.md).
