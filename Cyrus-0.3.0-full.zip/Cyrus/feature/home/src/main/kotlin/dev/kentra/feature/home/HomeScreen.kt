package dev.kentra.feature.home

import android.app.Activity
import android.net.VpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.currentStateAsState
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.kentra.core.designsystem.*
import dev.kentra.core.ui.CollectEffects
import dev.kentra.core.ui.formatBytes
import dev.kentra.domain.model.TunnelState
import org.koin.androidx.compose.koinViewModel

@Composable
fun HomeRoute(
    onNavigateToProfiles: () -> Unit,
    viewModel: HomeViewModel = koinViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }

    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        viewModel.dispatch(
            if (result.resultCode == Activity.RESULT_OK) HomeIntent.VpnPermissionGranted
            else HomeIntent.VpnPermissionDenied,
        )
    }

    CollectEffects(viewModel.effects) { effect ->
        when (effect) {
            HomeEffect.RequestVpnPermission ->
                VpnService.prepare(context)?.let { vpnPermissionLauncher.launch(it) }
                    ?: viewModel.dispatch(HomeIntent.VpnPermissionGranted)
            HomeEffect.NavigateToProfiles -> onNavigateToProfiles()
            is HomeEffect.ShowMessage -> snackbar.showSnackbar(effect.text)
        }
    }

    Scaffold(containerColor = Color.Transparent, contentWindowInsets = WindowInsets(0,0,0,0), snackbarHost = { SnackbarHost(snackbar) }) { padding ->
        HomeContent(
            state = state,
            onToggle = { viewModel.dispatch(HomeIntent.ToggleConnection) },
            onPickProfile = { viewModel.dispatch(HomeIntent.OpenProfiles) },
            modifier = Modifier.padding(padding),
        )
    }
}

@Composable
private fun HomeContent(
    state: HomeState,
    onToggle: () -> Unit,
    onPickProfile: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val lifecycle by LocalLifecycleOwner.current.lifecycle.currentStateAsState()
    val active = state.tunnel is TunnelState.Connected
    BoxWithConstraints(modifier.fillMaxSize()) {
        // Anchor the button itself, not the whole button+statistics group, at the
        // usable viewport centre (+12dp to balance the taller bottom bar). Scrolling keeps content accessible on short displays.
        val top = (maxHeight / 2 - 20.dp).coerceAtLeast(24.dp)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = 28.dp).padding(top = top, bottom = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            ConnectButton(
                label = if (state.activeProfile == null && !active && !state.busy) "Добавить ключ" else state.tunnel.label(),
                active = active,
                busy = state.busy,
                animateContour = lifecycle == Lifecycle.State.RESUMED,
                onClick = onToggle,
            )
            Spacer(Modifier.height(16.dp))
            TextButton(onClick = onPickProfile,
                colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.onSurfaceVariant)) {
                Text(state.activeProfile?.name ?: "Выбрать ключ", maxLines = 1,
                    overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
            }
            Spacer(Modifier.height(16.dp))
            Row(Modifier.widthIn(max = 340.dp).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TrafficStat("Получено", if (active) state.traffic.downlinkBytes.formatBytes() else "—", Modifier.weight(1f))
                TrafficStat("Отправлено", if (active) state.traffic.uplinkBytes.formatBytes() else "—", Modifier.weight(1f))
            }
            if (state.tunnel is TunnelState.Failed) {
                Spacer(Modifier.height(20.dp))
                Text("Не удалось подключиться", style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun TrafficStat(title: String, value: String, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text(title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.titleMedium)
    }
}

private fun TunnelState.label(): String = when (this) {
    TunnelState.Idle -> "Подключить"
    TunnelState.Preparing -> "Подключение…"
    is TunnelState.Connected -> "Отключить"
    TunnelState.Stopping -> "Отключение…"
    is TunnelState.Failed -> "Повторить"
}
