package dev.kentra.feature.store

import dev.kentra.core.mvi.*
import dev.kentra.domain.model.Plan

data class StoreState(val plans:List<Plan> = emptyList(),val busy:Boolean=false):MviState
sealed interface StoreIntent:MviIntent { data object Load:StoreIntent }
sealed interface StoreEffect:MviEffect { data class ShowMessage(val text:String):StoreEffect }
