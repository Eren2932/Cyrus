package dev.kentra.feature.store

import dev.kentra.core.ui.MviViewModel
import dev.kentra.domain.repository.BillingRepository

class StoreViewModel(private val billing:BillingRepository):MviViewModel<StoreIntent,StoreState,StoreEffect>(StoreState()) {
    init { dispatch(StoreIntent.Load) }
    override suspend fun handle(intent:StoreIntent) {
        when(intent) {
            StoreIntent.Load -> {
                if(currentState.busy) return
                reduce { copy(busy=true) }
                billing.plans().onSuccess { plans -> reduce { copy(plans=plans,busy=false) } }
                    .onFailure { reduce { copy(busy=false) }; effect(StoreEffect.ShowMessage("Не удалось загрузить каталог")) }
            }
        }
    }
}
