package dev.kentra.feature.profiles

import androidx.lifecycle.viewModelScope
import dev.kentra.core.ui.MviViewModel
import dev.kentra.domain.repository.*
import dev.kentra.domain.usecase.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.withContext

class ProfilesViewModel(
    private val profiles: ProfileRepository,
    private val subscriptions: SubscriptionRepository,
    private val importKeys: ImportKeysUseCase,
    private val deleteProfile: DeleteProfileUseCase,
    private val parser: LinkParser,
) : MviViewModel<ProfilesIntent, ProfilesState, ProfilesEffect>(ProfilesState()) {
    init {
        combine(profiles.observeProfiles(), profiles.observeActiveProfileId()) { list, active ->
            reduce { copy(profiles = list, activeProfileId = active) }
        }.catch { effect(ProfilesEffect.ShowMessage("Не удалось открыть хранилище ключей. Данные не удалены.")) }.launchIn(viewModelScope)
        subscriptions.observeSources().onEach { reduce { copy(sources = it) } }
            .catch { effect(ProfilesEffect.ShowMessage("Не удалось прочитать подписки")) }.launchIn(viewModelScope)
    }
    override suspend fun handle(intent: ProfilesIntent) {
        when (intent) {
            ProfilesIntent.OpenImport -> if (!currentState.busy) reduce { copy(importSheetVisible = true, importText = "", report = null) }
            ProfilesIntent.CloseImport -> if (!currentState.busy) reduce { copy(importSheetVisible = false, importText = "", report = null) }
            is ProfilesIntent.ImportTextChanged -> if (!currentState.busy) reduce { copy(importText = intent.text, report = null) }
            is ProfilesIntent.QueryChanged -> reduce { copy(query = intent.query) }
            is ProfilesIntent.Filter -> reduce { copy(protocol = intent.protocol) }
            ProfilesIntent.PreviewImport -> operation {
                val payload = currentState.importText
                val report = withContext(Dispatchers.Default) { parser.inspect(payload) }
                reduce { copy(report = report) }
            }
            ProfilesIntent.ConfirmImport -> operation {
                val payload = currentState.importText.trim()
                val result = if (payload.startsWith("https://", true) || payload.startsWith("http://", true))
                    subscriptions.add("", payload).map { it.profileCount }
                else {
                    check(currentState.report != null)
                    importKeys(payload)
                }
                result.onSuccess { count ->
                    reduce { copy(importSheetVisible = false, importText = "", report = null) }
                    effect(ProfilesEffect.ShowMessage(if (count == 0) "Все ключи уже есть в библиотеке" else "Добавлено ключей: $count"))
                }.onFailure { effect(ProfilesEffect.ShowMessage(it.message ?: "Импорт не выполнен")) }
            }
            is ProfilesIntent.Select -> operation { profiles.setActiveProfileId(intent.profileId) }
            is ProfilesIntent.Rename -> operation {
                val name = intent.name.trim().take(160)
                if (name.isNotEmpty()) profiles.getProfile(intent.id)?.let { profiles.upsert(it.copy(name = name)) }
            }
            is ProfilesIntent.Delete -> operation {
                deleteProfile(intent.profile).onFailure { effect(ProfilesEffect.ShowMessage("Не удалось удалить ключ")) }
            }
            is ProfilesIntent.RemoveSource -> operation { subscriptions.remove(intent.id) }
            is ProfilesIntent.RefreshSource -> operation { showRefresh(subscriptions.refresh(intent.id)) }
            ProfilesIntent.RefreshSubscriptions -> operation { showRefresh(subscriptions.refreshAll()) }
        }
    }
    private fun showRefresh(result: Result<Int>) {
        result.onSuccess { effect(ProfilesEffect.ShowMessage("Обновлено ключей: $it")) }
            .onFailure { effect(ProfilesEffect.ShowMessage(it.message ?: "Ошибка обновления")) }
    }
    private suspend fun operation(block: suspend () -> Unit) {
        if (currentState.busy) return
        reduce { copy(busy = true) }
        try { block() }
        catch (e: Exception) {
            if (e is kotlinx.coroutines.CancellationException) throw e
            effect(ProfilesEffect.ShowMessage("Операция не выполнена. Проверьте данные и доступ к хранилищу."))
        } finally { reduce { copy(busy = false) } }
    }
}
