package dev.kentra.feature.profiles

import dev.kentra.core.mvi.*
import dev.kentra.domain.model.*

data class ProfilesState(
    val profiles: List<VpnProfile> = emptyList(), val sources: List<SubscriptionSource> = emptyList(),
    val activeProfileId: String? = null, val importSheetVisible: Boolean = false,
    val importText: String = "", val report: ImportReport? = null, val busy: Boolean = false,
    val query: String = "", val protocol: VpnProtocol? = null,
) : MviState

sealed interface ProfilesIntent : MviIntent {
    data object OpenImport : ProfilesIntent
    data object CloseImport : ProfilesIntent
    data class ImportTextChanged(val text: String) : ProfilesIntent
    data object PreviewImport : ProfilesIntent
    data object ConfirmImport : ProfilesIntent
    data class QueryChanged(val query: String) : ProfilesIntent
    data class Filter(val protocol: VpnProtocol?) : ProfilesIntent
    data class Select(val profileId: String) : ProfilesIntent
    data class Delete(val profile: VpnProfile) : ProfilesIntent
    data class Rename(val id: String, val name: String) : ProfilesIntent
    data class RemoveSource(val id: String) : ProfilesIntent
    data class RefreshSource(val id: String) : ProfilesIntent
    data object RefreshSubscriptions : ProfilesIntent
}
sealed interface ProfilesEffect : MviEffect {
    data class ShowMessage(val text: String) : ProfilesEffect
    data object ImportSucceeded : ProfilesEffect
}
