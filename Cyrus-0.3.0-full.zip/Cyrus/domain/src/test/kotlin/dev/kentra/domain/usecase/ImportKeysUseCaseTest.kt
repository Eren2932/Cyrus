package dev.kentra.domain.usecase

import dev.kentra.domain.model.*
import dev.kentra.domain.repository.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Test

class ImportKeysUseCaseTest {
    private val profile=VpnProfile("a","A",VpnProtocol.TROJAN,"host.test",443,password="test",rawLink="trojan://test@host.test:443")
    private class Repo:ProfileRepository {
        val entries=MutableStateFlow<List<VpnProfile>>(emptyList())
        val active=MutableStateFlow<String?>(null)
        override fun observeProfiles():Flow<List<VpnProfile>> = entries
        override fun observeActiveProfileId():Flow<String?> = active
        override suspend fun getProfile(id:String)=entries.value.firstOrNull{it.id==id}
        override suspend fun upsert(profile:VpnProfile) { entries.value=entries.value.filterNot{it.id==profile.id}+profile }
        override suspend fun upsertAll(profiles:List<VpnProfile>) { profiles.forEach { upsert(it) } }
        override suspend fun delete(id:String) { entries.value=entries.value.filterNot{it.id==id} }
        override suspend fun setActiveProfileId(id:String?) { active.value=id }
    }
    private fun parser(items:List<VpnProfile>)=object:LinkParser {
        override fun parse(uri:String)=items.firstOrNull()
        override fun parseMany(payload:String)=items
    }
    @Test fun `first import selects first profile`()=runTest {
        val repo=Repo();assertEquals(1,ImportKeysUseCase(parser(listOf(profile)),repo)("input").getOrThrow());assertEquals("a",repo.active.value)
    }
    @Test fun `repeat import does not duplicate credentials`()=runTest {
        val repo=Repo();repo.upsert(profile)
        assertEquals(0,ImportKeysUseCase(parser(listOf(profile.copy(id="b"))),repo)("input").getOrThrow());assertEquals(1,repo.entries.value.size)
    }
    @Test fun `import preserves selection`()=runTest {
        val repo=Repo();repo.active.value="existing"
        ImportKeysUseCase(parser(listOf(profile)),repo)("input").getOrThrow();assertEquals("existing",repo.active.value)
    }
    @Test fun `empty import does not change storage`()=runTest {
        val repo=Repo();repo.upsert(profile)
        assertTrue(ImportKeysUseCase(parser(emptyList()),repo)("bad").isFailure);assertEquals(listOf(profile),repo.entries.value)
    }
    @Test fun `delete unrelated profile does not stop connected tunnel`()=runTest {
        val repo=Repo();repo.upsert(profile)
        var stopped=false
        val tunnel=object:TunnelController {
            override val state=MutableStateFlow<TunnelState>(TunnelState.Connected("different",0))
            override val traffic:Flow<TrafficSample> = flowOf(TrafficSample())
            override suspend fun connect(profile:VpnProfile)=Unit
            override suspend fun disconnect() { stopped=true }
        }
        DeleteProfileUseCase(repo,tunnel)(profile).getOrThrow();assertFalse(stopped);assertTrue(repo.entries.value.isEmpty())
    }
}
