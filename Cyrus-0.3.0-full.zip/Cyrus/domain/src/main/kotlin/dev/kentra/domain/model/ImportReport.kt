package dev.kentra.domain.model

data class ImportIssue(val line: Int, val reason: String)
data class ImportReport(
    val profiles: List<VpnProfile> = emptyList(),
    val issues: List<ImportIssue> = emptyList(),
    val duplicates: Int = 0,
)

/** Excludes presentation fields but retains all protocol/security options. */
fun VpnProfile.connectionIdentity(): String = rawLink?.substringBefore('#')
    ?: copy(id = "", name = "", createdAt = 0, origin = ProfileOrigin.Manual).toString()
