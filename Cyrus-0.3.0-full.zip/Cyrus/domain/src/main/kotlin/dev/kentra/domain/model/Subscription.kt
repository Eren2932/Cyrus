package dev.kentra.domain.model

data class SubscriptionSource(
    val id: String,
    val name: String,
    val url: String,
    val lastSyncEpochMs: Long? = null,
    val profileCount: Int = 0,
    val lastError: String? = null,
)

/** What the user is entitled to right now. Mirrored from the backend, never trusted locally. */
data class Entitlement(
    val planId: String,
    val planName: String,
    val expiresAtEpochMs: Long,
    val trafficLimitBytes: Long?,
    val trafficUsedBytes: Long,
    val deviceLimit: Int,
) {
    fun isValidAt(nowMs: Long): Boolean = expiresAtEpochMs > nowMs
}

data class Plan(
    val id: String,
    val name: String,
    val days: Int,
    val priceMinor: Long,
    val currency: String = "RUB",
    val deviceLimit: Int,
    val highlighted: Boolean = false,
)
