package dev.kentra.domain.model

/** The single truth about the tunnel. Owned by the VPN process, never by the UI. */
sealed interface TunnelState {
    data object Idle : TunnelState
    data object Preparing : TunnelState
    data class Connected(val profileId: String, val sinceEpochMs: Long) : TunnelState
    data object Stopping : TunnelState
    data class Failed(val reason: String, val retryInMs: Long? = null) : TunnelState

    val isActive: Boolean get() = this is Connected || this is Preparing
}

data class TrafficSample(
    val uplinkBytes: Long = 0,
    val downlinkBytes: Long = 0,
    val uplinkSpeedBps: Long = 0,
    val downlinkSpeedBps: Long = 0,
)
