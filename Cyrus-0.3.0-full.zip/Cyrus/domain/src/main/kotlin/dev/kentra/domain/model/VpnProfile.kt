package dev.kentra.domain.model

enum class VpnProtocol { VLESS, VMESS, TROJAN, SHADOWSOCKS, HYSTERIA2, TUIC, UNKNOWN }

data class RealitySettings(
    val publicKey: String,
    val shortId: String? = null,
    val spiderX: String? = null,
)

data class TlsSettings(
    val enabled: Boolean = false,
    val serverName: String? = null,
    val allowInsecure: Boolean = false,
    val alpn: List<String> = emptyList(),
    val fingerprint: String? = null,
    val reality: RealitySettings? = null,
)

data class TransportSettings(
    /** tcp | ws | grpc | http | httpupgrade */
    val type: String = "tcp",
    val path: String? = null,
    val host: String? = null,
    val serviceName: String? = null,
)

sealed interface ProfileOrigin {
    /** Pasted by the user: a key bought somewhere else. */
    data object Manual : ProfileOrigin

    /** Came from a subscription URL, refreshable and rotatable. */
    data class Subscription(val sourceId: String) : ProfileOrigin

    /** Issued by our own panel after a purchase. */
    data object Store : ProfileOrigin
}

/**
 * Transport-agnostic description of one outbound. This is the ONLY key representation
 * the app knows about; sing-box JSON is generated from it in :vpn:config.
 */
data class VpnProfile(
    val id: String,
    val name: String,
    val protocol: VpnProtocol,
    val server: String,
    val port: Int,
    val uuid: String? = null,
    val password: String? = null,
    val method: String? = null,
    val flow: String? = null,
    val alterId: Int? = null,
    val tls: TlsSettings = TlsSettings(),
    val transport: TransportSettings = TransportSettings(),
    val origin: ProfileOrigin = ProfileOrigin.Manual,
    val createdAt: Long = 0L,
    /** Original credential, encrypted at rest; preserves vendor-specific parameters. */
    val rawLink: String? = null,
    val parameters: Map<String, String> = emptyMap(),
) {
    val displayEndpoint: String get() = if (server.contains(':')) "[$server]:$port" else "$server:$port"
}
