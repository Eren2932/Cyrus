#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v gradle >/dev/null 2>&1; then
  echo 'Нужен Gradle 8.11.1, JDK 17 и Android SDK 35. См. README.md или запустите GitHub Actions.' >&2
  exit 1
fi
python3 tools/check_source.py
if ! find vpn/service/libs -maxdepth 1 -name '*.aar' -print -quit 2>/dev/null | grep -q .; then
  echo 'Отсутствует совместимый libbox.aar в vpn/service/libs/. См. README.md.' >&2
  exit 1
fi
gradle --no-daemon --stacktrace test :app:lintDebug :app:assembleDebug
