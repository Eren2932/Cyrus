package dev.kentra.data

import dev.kentra.domain.model.ProfileOrigin
import dev.kentra.domain.model.RealitySettings
import dev.kentra.domain.model.TlsSettings
import dev.kentra.domain.model.TransportSettings
import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.model.VpnProtocol
import org.junit.Assert.assertEquals
import org.junit.Test

class ProfileMapperTest {

    @Test
    fun `round trip keeps every field`() {
        val profile = VpnProfile(
            id = "id",
            name = "NL-01",
            protocol = VpnProtocol.VLESS,
            server = "1.2.3.4",
            port = 443,
            uuid = "u",
            flow = "xtls-rprx-vision",
            tls = TlsSettings(
                enabled = true,
                serverName = "sni.tld",
                alpn = listOf("h2"),
                fingerprint = "chrome",
                reality = RealitySettings("PK", "ab", "/"),
            ),
            transport = TransportSettings(type = "ws", path = "/p", host = "h"),
            origin = ProfileOrigin.Subscription("src-1"),
            createdAt = 42L,
            rawLink = "vless://example",
            parameters = mapOf("extra" to "retained", "mode" to "auto"),
        )

        val restored = ProfileMapper.toDomain(ProfileMapper.toEntity(profile))

        assertEquals(profile, restored)
    }
}
