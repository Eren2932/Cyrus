package dev.kentra.data

import dev.kentra.core.database.CyrusDatabase
import dev.kentra.core.datastore.SettingsStore
import dev.kentra.core.network.ApiConfig
import dev.kentra.core.network.HttpClientFactory
import dev.kentra.domain.repository.BillingRepository
import dev.kentra.domain.repository.LinkParser
import dev.kentra.domain.repository.ProfileRepository
import dev.kentra.domain.repository.SubscriptionRepository
import dev.kentra.vpn.link.DefaultLinkParser
import org.koin.android.ext.koin.androidContext
import org.koin.dsl.module

val dataModule = module {
    single { CyrusDatabase.build(androidContext()) }
    single { get<CyrusDatabase>().profileDao() }
    single { get<CyrusDatabase>().subscriptionDao() }
    single { SettingsStore(androidContext()) }
    single { SecretCipher() }
    single { SecureStorage(get(), get()) }
    single { ApiConfig() }
    single { HttpClientFactory.create(get()) }

    single<LinkParser> { DefaultLinkParser() }
    single<ProfileRepository> { ProfileRepositoryImpl(dao = get(), settings = get(), secure = get()) }
    single<SubscriptionRepository> {
        SubscriptionRepositoryImpl(db = get(), client = get(), parser = get(), secure = get(), settings = get())
    }
    single<BillingRepository> { CatalogBillingRepository() }
}
