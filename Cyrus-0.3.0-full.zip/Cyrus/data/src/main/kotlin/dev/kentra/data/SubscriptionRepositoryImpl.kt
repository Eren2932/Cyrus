package dev.kentra.data

import androidx.room.withTransaction
import dev.kentra.core.common.AppError
import dev.kentra.core.common.appRunCatching
import dev.kentra.core.database.*
import dev.kentra.core.datastore.SettingsStore
import dev.kentra.domain.model.*
import dev.kentra.domain.repository.*
import io.ktor.client.HttpClient
import io.ktor.client.request.prepareGet
import io.ktor.client.statement.bodyAsChannel
import io.ktor.utils.io.readAvailable
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.net.URI
import java.util.UUID

class SubscriptionRepositoryImpl(
    private val db: CyrusDatabase,
    private val client: HttpClient,
    private val parser: LinkParser,
    private val secure: SecureStorage,
    private val settings: SettingsStore,
    private val clock: () -> Long = { System.currentTimeMillis() },
) : SubscriptionRepository {
    private val dao get() = db.subscriptionDao()
    private val profileDao get() = db.profileDao()
    private val mutex = Mutex()

    override fun observeSources(): Flow<List<SubscriptionSource>> = dao.observeAll()
        .onStart { secure.prepare() }.map { list -> list.map { domain(secure.open(it)) }.sortedBy { it.name.lowercase() } }.flowOn(Dispatchers.IO)

    override suspend fun add(name: String, url: String): Result<SubscriptionSource> = appRunCatching {
        mutex.withLock {
            secure.prepare()
            val uri = validate(url)
            val existing = dao.observeAll().first().map { secure.open(it) }.firstOrNull { it.url == url }
            val source = existing ?: SubscriptionEntity(UUID.randomUUID().toString(), name.ifBlank { uri.host }, url, null, 0, null)
            val parsed = fetch(url)
            save(source, parsed)
            domain(source.copy(lastSyncEpochMs = clock(), profileCount = parsed.size, lastError = null))
        }
    }

    override suspend fun refresh(sourceId: String): Result<Int> = appRunCatching {
        mutex.withLock {
            secure.prepare()
            val source = dao.byId(sourceId)?.let { secure.open(it) } ?: throw AppError.NotFound("Подписка")
            try {
                val parsed = fetch(source.url)
                save(source, parsed)
                parsed.size
            } catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                dao.upsert(secure.seal(source.copy(lastError = "Обновление не выполнено. Предыдущие ключи сохранены.")))
                throw AppError.Network("Не удалось обновить подписку. Проверьте сеть и формат ответа.")
            }
        }
    }

    override suspend fun refreshAll(): Result<Int> = appRunCatching {
        secure.prepare()
        var total = 0
        var failed = 0
        dao.observeAll().first().forEach { source ->
            refresh(source.id).onSuccess { total += it }.onFailure { failed++ }
        }
        if (failed > 0) throw AppError.Network("Обновлено ключей: $total. Ошибок источников: $failed; старые ключи сохранены.")
        total
    }

    override suspend fun remove(sourceId: String) {
        mutex.withLock {
            secure.prepare()
            val oldIds = profileDao.bySource(sourceId).map { it.id }.toSet()
            db.withTransaction { profileDao.deleteBySource(sourceId); dao.deleteById(sourceId) }
            if (settings.activeProfileId.first() in oldIds) settings.setActiveProfileId(profileDao.observeAll().first().firstOrNull()?.id)
        }
    }

    private suspend fun save(source: SubscriptionEntity, profiles: List<VpnProfile>) {
        val entities = withContext(Dispatchers.IO) {
            profiles.map { profile ->
                val id = UUID.nameUUIDFromBytes((source.id + ":" + profile.connectionIdentity()).toByteArray(Charsets.UTF_8)).toString()
                secure.seal(ProfileMapper.toEntity(profile.copy(id = id, origin = ProfileOrigin.Subscription(source.id))))
            }
        }
        val oldIds = profileDao.bySource(source.id).map { it.id }.toSet()
        db.withTransaction {
            profileDao.deleteBySource(source.id)
            profileDao.upsertAll(entities)
            dao.upsert(secure.seal(source.copy(lastSyncEpochMs = clock(), profileCount = entities.size, lastError = null)))
        }
        val active = settings.activeProfileId.first()
        if (active == null || (active in oldIds && entities.none { it.id == active })) settings.setActiveProfileId(entities.first().id)
    }

    private suspend fun fetch(url: String): List<VpnProfile> = withContext(Dispatchers.IO) {
        validate(url)
        val payload = client.prepareGet(url).execute { response ->
            require(response.status.value in 200..299) { "HTTP status" }
            val channel = response.bodyAsChannel()
            val output = ByteArrayOutputStream()
            val buffer = ByteArray(8192)
            while (true) {
                val read = channel.readAvailable(buffer, 0, buffer.size)
                if (read == -1) break
                require(output.size() + read <= 1_048_576) { "Response too large" }
                output.write(buffer, 0, read)
            }
            output.toString("UTF-8")
        }
        val report = parser.inspect(payload)
        if (report.profiles.isEmpty() || report.issues.isNotEmpty()) throw AppError.Parse("Ответ содержит неподдерживаемые или повреждённые строки")
        report.profiles
    }

    private fun validate(url: String): URI {
        val uri = runCatching { URI(url) }.getOrElse { throw AppError.Parse("Некорректная ссылка подписки") }
        if (!uri.scheme.equals("https", ignoreCase = true) || uri.host.isNullOrBlank() || uri.rawUserInfo != null || uri.fragment != null)
            throw AppError.Parse("Нужна HTTPS-ссылка без логина и фрагмента. HTTP не защищает ключи при передаче.")
        return uri
    }
    private fun domain(e: SubscriptionEntity) = SubscriptionSource(e.id, e.name, e.url, e.lastSyncEpochMs, e.profileCount, e.lastError)
}
