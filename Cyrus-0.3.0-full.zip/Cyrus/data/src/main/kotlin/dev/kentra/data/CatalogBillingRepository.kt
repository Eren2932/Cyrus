package dev.kentra.data

import dev.kentra.core.common.AppError
import dev.kentra.domain.model.Entitlement
import dev.kentra.domain.model.Plan
import dev.kentra.domain.repository.BillingRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Local, read-only price catalogue. No purchase or entitlement is simulated. */
class CatalogBillingRepository : BillingRepository {

    private val entitlement = MutableStateFlow<Entitlement?>(null)

    private val catalogue = listOf(
        Plan(id = "m1", name = "1 месяц", days = 30, priceMinor = 19900, deviceLimit = 3),
        Plan(id = "m3", name = "3 месяца", days = 90, priceMinor = 49900, deviceLimit = 3, highlighted = true),
        Plan(id = "m12", name = "12 месяцев", days = 365, priceMinor = 149900, deviceLimit = 5),
    )

    override suspend fun plans(): Result<List<Plan>> = Result.success(catalogue)

    override fun observeEntitlement(): Flow<Entitlement?> = entitlement.asStateFlow()

    override suspend fun createCheckout(planId: String): Result<String> =
        Result.failure(AppError.Unknown(IllegalStateException("Sales are not enabled")))

    override suspend fun activateCode(code: String): Result<Entitlement> =
        Result.failure(AppError.Unknown(IllegalStateException("Activation requires an authenticated control plane")))

    override suspend fun syncEntitlement(): Result<Entitlement?> = Result.success(entitlement.value)
}
