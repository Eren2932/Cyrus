package dev.kentra.core.designsystem

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Cyrus brand accent and the requested midnight / ivory palette. */
object CyrusTokens {
    val Accent = Color(0xFFF97316)
    val OnAccent = Color(0xFF1B0C00)
    val AccentPressed = Color(0xFFEA580C)
    val Danger = Color(0xFFFF8585)
    val Warning = Color(0xFFF8C578)
    val SurfaceDark = Color(0xFF111827)
    val SurfaceDarkElevated = Color(0xFF192232)
    val SurfaceControl = Color(0xFF232D3E)
    val OnDark = Color(0xFFE7E5E0)
    val OnDarkMuted = Color(0xFFA7ADB8)
    val RadiusCard = 24.dp
    val RadiusControl = 16.dp
    val SpaceXs = 4.dp
    val SpaceSm = 8.dp
    val SpaceMd = 16.dp
    val SpaceLg = 24.dp
    val SpaceXl = 32.dp
}

object CyrusMotion {
    const val Fast = 120
    const val Screen = 220
    const val Settle = 240
    val Ease = CubicBezierEasing(0.22f, 1f, 0.36f, 1f)
}

private val DarkScheme = darkColorScheme(
    primary = CyrusTokens.Accent, onPrimary = CyrusTokens.OnAccent,
    primaryContainer = Color(0xFF382012), onPrimaryContainer = CyrusTokens.Accent,
    secondary = CyrusTokens.Accent, onSecondary = CyrusTokens.OnAccent,
    secondaryContainer = CyrusTokens.SurfaceControl, onSecondaryContainer = CyrusTokens.Accent,
    background = CyrusTokens.SurfaceDark, onBackground = CyrusTokens.OnDark,
    surface = CyrusTokens.SurfaceDarkElevated, onSurface = CyrusTokens.OnDark,
    surfaceVariant = CyrusTokens.SurfaceControl, onSurfaceVariant = CyrusTokens.OnDarkMuted,
    outline = Color(0xFF485264), outlineVariant = Color(0xFF303A4A),
    surfaceTint = Color.Transparent, error = CyrusTokens.Danger,
)
private val LightScheme = lightColorScheme(
    primary = CyrusTokens.Accent, onPrimary = CyrusTokens.OnAccent,
    primaryContainer = Color(0xFFFFE7D5), onPrimaryContainer = Color(0xFF7C3109),
    secondary = Color(0xFF7C3109), onSecondary = Color.White,
    secondaryContainer = Color(0xFFEDEBE5), onSecondaryContainer = Color(0xFF2C2E31),
    background = Color(0xFFF9F8F3), onBackground = Color(0xFF2C2E31),
    surface = Color(0xFFF1F0EA), onSurface = Color(0xFF2C2E31),
    surfaceVariant = Color(0xFFE8E7E0), onSurfaceVariant = Color(0xFF606267),
    outline = Color(0xFF797B7D), outlineVariant = Color(0xFFD5D5CE),
    surfaceTint = Color.Transparent, error = Color(0xFFB3261E),
)

/** Explicit opt-out in addition to the system animator-duration scale. */
val LocalReducedMotion = staticCompositionLocalOf { false }

private val CyrusTypography = Typography(
    displaySmall = TextStyle(fontSize = 38.sp, fontWeight = FontWeight.Bold, letterSpacing = (-1).sp),
    headlineLarge = TextStyle(fontSize = 32.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.8).sp),
    titleLarge = TextStyle(fontSize = 23.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 21.sp),
    labelSmall = TextStyle(fontSize = 12.sp, lineHeight = 17.sp, fontWeight = FontWeight.Medium),
)
@Composable
fun CyrusTheme(darkTheme: Boolean = true, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (darkTheme) DarkScheme else LightScheme, typography = CyrusTypography, shapes = Shapes(
        small = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
        medium = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
        large = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
        extraLarge = androidx.compose.foundation.shape.RoundedCornerShape(28.dp),
    ), content = content)
}
