package dev.kentra.core.designsystem

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.*
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

@Composable
fun CyrusCard(modifier: Modifier = Modifier, highlighted: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier = modifier.fillMaxWidth(), shape = RoundedCornerShape(CyrusTokens.RadiusCard),
        border = BorderStroke(1.dp, if (highlighted) MaterialTheme.colorScheme.primary.copy(alpha = .55f) else MaterialTheme.colorScheme.outlineVariant),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
    }
}

/** A linear, constant-distance highlight around a capsule, not a rotating gradient. */
@Composable
fun ConnectButton(
    label: String,
    active: Boolean,
    busy: Boolean,
    animateContour: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val reduced = LocalReducedMotion.current
    val interactions = remember { MutableInteractionSource() }
    val pressed by interactions.collectIsPressedAsState()
    val scale = animateFloatAsState(if (pressed && !busy) .978f else 1f,
        tween(if (reduced) 0 else CyrusMotion.Fast, easing = CyrusMotion.Ease), label = "connectPress")
    val fill by animateColorAsState(
        if (active) CyrusTokens.Accent.copy(alpha = .15f) else MaterialTheme.colorScheme.background.copy(alpha = .90f),
        tween(if (reduced) 0 else CyrusMotion.Screen), label = "connectFill")
    // The infinite clock exists only while connecting/stopping AND the route is resumed.
    val phase: State<Float> = if (busy && animateContour && !reduced) {
        rememberInfiniteTransition(label = "contour").animateFloat(
            initialValue = 0f, targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(1250, easing = LinearEasing)), label = "distance")
    } else remember { mutableFloatStateOf(0f) }
    Box(modifier.widthIn(max = 320.dp).fillMaxWidth().heightIn(min = 64.dp)
        .graphicsLayer { scaleX = scale.value; scaleY = scale.value }
        .clip(RoundedCornerShape(50)).background(fill)
        .drawWithCache {
            val inset = 2.dp.toPx()
            val contour = Path().apply {
                addRoundRect(RoundRect(inset, inset, size.width - inset, size.height - inset,
                    CornerRadius((size.height - 2 * inset) / 2)))
            }
            val measure = PathMeasure().apply { setPath(contour, true) }
            val segment = Path()
            val stroke = Stroke(1.5.dp.toPx(), cap = StrokeCap.Round)
            val glowStroke = Stroke(2.5.dp.toPx(), cap = StrokeCap.Round)
            onDrawBehind {
                drawPath(contour, CyrusTokens.Accent.copy(alpha = if (busy) .32f else .9f), style = stroke)
                if (busy) {
                    val length = measure.length
                    // Read animation state in draw, never force layout/composition every frame.
                    val head = phase.value
                    for (i in 0 until 16) {
                        val start = ((head + i * .018f) % 1f) * length
                        val end = start + .019f * length
                        segment.reset()
                        measure.getSegment(start, minOf(end, length), segment, true)
                        if (end > length) measure.getSegment(0f, end - length, segment, true)
                        drawPath(segment, CyrusTokens.Accent.copy(alpha = .12f + .88f * i / 15), style = glowStroke)
                    }
                }
            }
        }
        .clickable(enabled = !busy, role = Role.Button, interactionSource = interactions,
            indication = null, onClick = onClick)
        .semantics { stateDescription = if (busy) label else if (active) "Подключено" else "Не подключено" },
        contentAlignment = Alignment.Center) {
        Text(label, modifier = Modifier.padding(horizontal = 24.dp, vertical = 18.dp),
            style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onBackground)
    }
}

data class CyrusNavigationItem(val route: String, val title: String, val icon: CyrusSymbol)

/** A single sliding indicator; the bar itself stays outside destination transitions. */
@Composable
fun CyrusNavigationBar(items: List<CyrusNavigationItem>, current: String, onSelect: (String) -> Unit) {
    val reduced = LocalReducedMotion.current
    val index = items.indexOfFirst { it.route == current }.coerceAtLeast(0)
    val position = animateFloatAsState(index.toFloat(),
        tween(if (reduced) 0 else CyrusMotion.Settle, easing = CyrusMotion.Ease), label = "tabPosition")
    BoxWithConstraints(Modifier.widthIn(max = 440.dp).fillMaxWidth()
        .clip(RoundedCornerShape(32.dp)).background(MaterialTheme.colorScheme.surface)
        .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = .55f), RoundedCornerShape(32.dp))
        .padding(6.dp)) {
        val itemWidth = maxWidth / items.size
        val rtl = androidx.compose.ui.platform.LocalLayoutDirection.current == androidx.compose.ui.unit.LayoutDirection.Rtl
        Box(Modifier.width(itemWidth).height(54.dp).graphicsLayer {
            translationX = (if (rtl) items.lastIndex - position.value else position.value) * itemWidth.toPx()
        }.padding(horizontal = 4.dp).background(MaterialTheme.colorScheme.onBackground, RoundedCornerShape(26.dp)))
        Row(Modifier.fillMaxWidth()) {
            items.forEachIndexed { i, item ->
                val tint by animateColorAsState(if (i == index) MaterialTheme.colorScheme.background else MaterialTheme.colorScheme.onSurfaceVariant,
                    tween(if (reduced) 0 else CyrusMotion.Fast), label = "tabTint")
                Box(Modifier.weight(1f).height(54.dp).clip(RoundedCornerShape(26.dp))
                    .clickable(role = Role.Tab, onClick = { onSelect(item.route) })
                    .semantics { contentDescription = item.title; selected = i == index },
                    contentAlignment = Alignment.Center) { CyrusIcon(item.icon, Modifier.size(25.dp), tint) }
            }
        }
    }
}

@Composable
fun StatPill(title: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(MaterialTheme.colorScheme.surface, RoundedCornerShape(18.dp)).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text(title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.titleMedium)
    }
}

enum class CyrusSymbol { Shield, Key, Store, Power, Plus, Arrow, Check, Settings, Back }
@Composable
fun CyrusIcon(symbol: CyrusSymbol, modifier: Modifier = Modifier, color: Color = MaterialTheme.colorScheme.onSurface) {
    Canvas(modifier.size(24.dp)) {
        val s = size.minDimension / 24f
        fun point(x: Float, y: Float) = Offset(x * s, y * s)
        val stroke = Stroke(width = 1.8f * s, cap = StrokeCap.Round)
        fun line(x: Float, y: Float, x2: Float, y2: Float) = drawLine(color, point(x,y), point(x2,y2), 1.8f*s, StrokeCap.Round)
        when (symbol) {
            CyrusSymbol.Power -> { drawArc(color, -48f, 276f, false, point(4f,4f), androidx.compose.ui.geometry.Size(16*s,16*s), style=stroke); line(12f,2f,12f,11f) }
            CyrusSymbol.Shield -> {
                val path = Path().apply { moveTo(12*s,2*s); lineTo(20*s,5*s); lineTo(20*s,12*s); cubicTo(20*s,17*s,15*s,21*s,12*s,22*s); cubicTo(9*s,21*s,4*s,17*s,4*s,12*s); lineTo(4*s,5*s); close() }
                drawPath(path,color,style=stroke); line(8f,12f,11f,15f); line(11f,15f,16f,9f)
            }
            CyrusSymbol.Key -> { drawCircle(color,5*s,point(8f,8f),style=stroke); line(11.5f,11.5f,21f,21f); line(16f,16f,19f,13f); line(19f,19f,22f,16f) }
            CyrusSymbol.Store -> { drawRoundRect(color,point(3f,6f),androidx.compose.ui.geometry.Size(18*s,15*s),androidx.compose.ui.geometry.CornerRadius(3*s),style=stroke); line(8f,6f,8f,3f); line(8f,3f,16f,3f); line(16f,3f,16f,6f); line(8f,12f,16f,12f) }
            CyrusSymbol.Plus -> { line(12f,5f,12f,19f); line(5f,12f,19f,12f) }
            CyrusSymbol.Arrow -> { line(5f,12f,19f,12f); line(14f,7f,19f,12f); line(19f,12f,14f,17f) }
            CyrusSymbol.Settings -> {
                line(3f,6f,21f,6f); line(3f,12f,21f,12f); line(3f,18f,21f,18f)
                drawCircle(color,2.5f*s,point(8f,6f),style=stroke)
                drawCircle(color,2.5f*s,point(16f,12f),style=stroke)
                drawCircle(color,2.5f*s,point(10f,18f),style=stroke)
            }
            CyrusSymbol.Back -> { line(19f,12f,5f,12f); line(5f,12f,10f,7f); line(5f,12f,10f,17f) }
            CyrusSymbol.Check -> { line(5f,12f,10f,17f); line(10f,17f,19f,7f) }
        }
    }
}
