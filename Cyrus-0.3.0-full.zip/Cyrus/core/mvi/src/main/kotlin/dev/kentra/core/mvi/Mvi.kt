package dev.kentra.core.mvi

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** Marker types keep the contract of every screen explicit and greppable. */
interface MviState
interface MviIntent
interface MviEffect

interface Store<I : MviIntent, S : MviState, E : MviEffect> {
    val state: StateFlow<S>
    val effects: Flow<E>
    fun dispatch(intent: I)
}

/**
 * The whole MVI engine, 40 lines, zero magic.
 *
 * - [state] is the single source of truth for a screen.
 * - [effects] are one-shot, non-replayable (navigate, show snackbar, ask permission).
 * - Intents are handled concurrently on [scope]; ordering guarantees must live in the handler.
 */
class MviMachine<I : MviIntent, S : MviState, E : MviEffect>(
    initialState: S,
    private val scope: CoroutineScope,
    private val handler: suspend MviMachine<I, S, E>.(I) -> Unit,
) : Store<I, S, E> {

    private val _state = MutableStateFlow(initialState)
    override val state: StateFlow<S> = _state.asStateFlow()

    private val _effects = Channel<E>(capacity = 16, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    override val effects: Flow<E> = _effects.receiveAsFlow()

    val current: S get() = _state.value

    override fun dispatch(intent: I) {
        // Explicit invoke: `handler` is an extension function type, so the receiver is passed directly.
        scope.launch { handler.invoke(this@MviMachine, intent) }
    }

    /** Pure state transition. Keep it free of side effects so it stays unit-testable. */
    fun reduce(reducer: S.() -> S) {
        _state.update { it.reducer() }
    }

    fun effect(effect: E) {
        _effects.trySend(effect)
    }
}
