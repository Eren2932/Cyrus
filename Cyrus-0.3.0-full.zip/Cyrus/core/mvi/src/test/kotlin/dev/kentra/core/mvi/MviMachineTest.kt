package dev.kentra.core.mvi

import app.cash.turbine.test
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Test

private data class CounterState(val value: Int = 0) : MviState
private sealed interface CounterIntent : MviIntent {
    data object Increment : CounterIntent
    data object Fail : CounterIntent
}
private sealed interface CounterEffect : MviEffect {
    data class Toast(val text: String) : CounterEffect
}

@OptIn(ExperimentalCoroutinesApi::class)
class MviMachineTest {

    @Test
    fun `increment reduces state`() = runTest {
        val machine = machine(this)

        machine.dispatch(CounterIntent.Increment)
        machine.dispatch(CounterIntent.Increment)
        testScheduler.advanceUntilIdle()

        assertEquals(2, machine.current.value)
    }

    @Test
    fun `effects are emitted once`() = runTest {
        val machine = machine(this)

        machine.effects.test {
            machine.dispatch(CounterIntent.Fail)
            testScheduler.advanceUntilIdle()
            assertEquals(CounterEffect.Toast("boom"), awaitItem())
            cancelAndIgnoreRemainingEvents()
        }
    }

    private fun machine(scope: kotlinx.coroutines.CoroutineScope) =
        MviMachine<CounterIntent, CounterState, CounterEffect>(CounterState(), scope) { intent ->
            when (intent) {
                CounterIntent.Increment -> reduce { copy(value = value + 1) }
                CounterIntent.Fail -> effect(CounterEffect.Toast("boom"))
            }
        }
}
