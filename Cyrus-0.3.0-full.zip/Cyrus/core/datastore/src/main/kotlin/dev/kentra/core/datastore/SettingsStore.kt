package dev.kentra.core.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dev.kentra.vpn.config.TunnelOptions
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.catch
import java.io.IOException
import androidx.datastore.preferences.core.emptyPreferences

enum class ThemeMode { SYSTEM, DARK, LIGHT }
enum class Wallpaper { NONE, GEOMETRY, ABSTRACT }
data class AppearanceSettings(
    val theme: ThemeMode = ThemeMode.DARK,
    val wallpaper: Wallpaper = Wallpaper.NONE,
    val reducedMotion: Boolean = false,
)

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "kentra_settings")

/**
 * Non-secret settings only. Auth tokens and subscription URLs belong in the encrypted store
 * (see data/SecretCipher and SecureStorage) — never here.
 */
class SettingsStore(private val context: Context) {

    private object Keys {
        val theme = stringPreferencesKey("appearance_theme")
        val wallpaper = stringPreferencesKey("appearance_wallpaper")
        val reducedMotion = booleanPreferencesKey("appearance_reduced_motion")
        val activeProfileId = stringPreferencesKey("active_profile_id")
        val mtu = intPreferencesKey("mtu")
        val stack = stringPreferencesKey("stack")
        val bypassLan = booleanPreferencesKey("bypass_lan")
        val blockAds = booleanPreferencesKey("block_ads")
        val ipv6 = booleanPreferencesKey("ipv6")
        val dnsRemote = stringPreferencesKey("dns_remote")
        val onboardingDone = booleanPreferencesKey("onboarding_done")
    }

    val appearance: Flow<AppearanceSettings> = context.dataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { prefs ->
            AppearanceSettings(
                theme = ThemeMode.entries.firstOrNull { it.name == prefs[Keys.theme] } ?: ThemeMode.DARK,
                wallpaper = Wallpaper.entries.firstOrNull { it.name == prefs[Keys.wallpaper] } ?: Wallpaper.NONE,
                reducedMotion = prefs[Keys.reducedMotion] ?: false,
            )
        }

    suspend fun setTheme(value: ThemeMode) = context.dataStore.edit { it[Keys.theme] = value.name }
    suspend fun setWallpaper(value: Wallpaper) = context.dataStore.edit { it[Keys.wallpaper] = value.name }
    suspend fun setReducedMotion(value: Boolean) = context.dataStore.edit { it[Keys.reducedMotion] = value }

    val activeProfileId: Flow<String?> = context.dataStore.data.map { it[Keys.activeProfileId] }

    val tunnelOptions: Flow<TunnelOptions> = context.dataStore.data.map { prefs ->
        TunnelOptions(
            mtu = prefs[Keys.mtu] ?: 9000,
            stack = prefs[Keys.stack] ?: "system",
            bypassLan = prefs[Keys.bypassLan] ?: true,
            blockAds = prefs[Keys.blockAds] ?: false,
            ipv6 = prefs[Keys.ipv6] ?: false,
            dnsRemote = prefs[Keys.dnsRemote] ?: "tls://1.1.1.1",
        )
    }

    val onboardingDone: Flow<Boolean> = context.dataStore.data.map { it[Keys.onboardingDone] ?: false }

    suspend fun setActiveProfileId(id: String?) = context.dataStore.edit { prefs ->
        if (id == null) prefs.remove(Keys.activeProfileId) else prefs[Keys.activeProfileId] = id
    }

    suspend fun setTunnelOptions(options: TunnelOptions) = context.dataStore.edit { prefs ->
        prefs[Keys.mtu] = options.mtu
        prefs[Keys.stack] = options.stack
        prefs[Keys.bypassLan] = options.bypassLan
        prefs[Keys.blockAds] = options.blockAds
        prefs[Keys.ipv6] = options.ipv6
        prefs[Keys.dnsRemote] = options.dnsRemote
    }

    suspend fun setOnboardingDone(done: Boolean) = context.dataStore.edit { it[Keys.onboardingDone] = done }
}
