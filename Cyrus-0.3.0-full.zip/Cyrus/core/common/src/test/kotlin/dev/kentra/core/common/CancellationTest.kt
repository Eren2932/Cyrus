package dev.kentra.core.common

import kotlinx.coroutines.CancellationException
import org.junit.Test

class CancellationTest {
    @Test(expected=CancellationException::class)
    fun `cancellation is never converted into an application error`() {
        appRunCatching<Unit> { throw CancellationException("cancelled") }
    }
}
