package dev.kentra.core.common

/** Single error taxonomy for the whole app. UI maps these to strings, never the other way around. */
sealed class AppError(message: String? = null, cause: Throwable? = null) : Exception(message, cause) {
    data class Network(val reason: String? = null) : AppError("network: $reason")
    data class Parse(val reason: String? = null) : AppError("parse: $reason")
    data class Tunnel(val reason: String? = null) : AppError("tunnel: $reason")
    data class Permission(val what: String) : AppError("permission: $what")
    data class NotFound(val what: String) : AppError("not found: $what")
    data class Unknown(override val cause: Throwable?) : AppError("unknown", cause)

    companion object {
        fun from(t: Throwable): AppError = t as? AppError ?: Unknown(t)
    }
}

inline fun <T> appRunCatching(block: () -> T): Result<T> =
    try {
        Result.success(block())
    } catch (t: Throwable) {
        if (t is kotlinx.coroutines.CancellationException) throw t
        Result.failure(AppError.from(t))
    }
