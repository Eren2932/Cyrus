package dev.kentra.core.common

/**
 * Logging port. The implementation in :app writes to logcat + an in-memory ring buffer
 * that the diagnostics screen reads. NEVER log keys, UUIDs or subscription URLs.
 */
interface Logger {
    fun d(tag: String, message: String)
    fun i(tag: String, message: String)
    fun w(tag: String, message: String, t: Throwable? = null)
    fun e(tag: String, message: String, t: Throwable? = null)
}

object NoopLogger : Logger {
    override fun d(tag: String, message: String) = Unit
    override fun i(tag: String, message: String) = Unit
    override fun w(tag: String, message: String, t: Throwable?) = Unit
    override fun e(tag: String, message: String, t: Throwable?) = Unit
}

/** Redacts secrets before they reach any log sink. */
fun String.redactSecrets(): String = this
    .replace(Regex("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"), "<uuid>")
    .replace(Regex("(?i)(vless|vmess|trojan|ss|hysteria2|tuic)://\\S+"), "<link>")
