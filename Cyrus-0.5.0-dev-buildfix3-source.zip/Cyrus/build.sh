#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
command -v gradle >/dev/null || { echo 'Install Gradle 8.11.1 and JDK 17 first.' >&2; exit 1; }
python3 tools/check_source.py
python3 tools/check_native.py
gradle --no-daemon --stacktrace test :app:lintDebug :app:assembleDebug
