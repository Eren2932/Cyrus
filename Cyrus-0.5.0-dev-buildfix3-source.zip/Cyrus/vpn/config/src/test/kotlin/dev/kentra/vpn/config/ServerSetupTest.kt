package dev.kentra.vpn.config

import kotlinx.serialization.json.*
import org.junit.Assert.*
import org.junit.Test
import java.io.File

class ServerSetupTest {
    private val options=ServerSetupOptions(ServerProtocol.VLESS_TLS,"1.11.1","amd64","a".repeat(64),443,
        "11111111-2222-4333-8444-555555555555","test-only-not-a-real-password")
    @Test fun `every supported wizard protocol emits a JSON server inbound`() {
        for(protocol in ServerProtocol.entries) {
            val c=Json.parseToJsonElement(ServerSetup.config(options.copy(protocol=protocol))).jsonObject
            assertEquals(443,c["inbounds"]!!.jsonArray.single().jsonObject["listen_port"]!!.jsonPrimitive.int)
        }
    }
    @Test fun `installation checks hash before unpack and config before install`() { val s=ServerSetup.script(options)
        assertTrue(s.indexOf("sha256sum --check")<s.indexOf("tar -xzf"));assertTrue(s.indexOf("check -c")<s.indexOf("install -m 755"))
        assertTrue(s.contains("test ! -e /etc/cyrus/config.json"));assertTrue(s.contains("umask 077"));assertTrue(s.contains("install -m 600"))
        assertFalse(s.contains("curl |"));assertFalse(s.contains("ufw allow"))
    }
    @Test fun `heredoc closing markers start in first column`() { val s=ServerSetup.script(options)
        assertTrue(s.lines().contains("CYRUS_CONFIG_END"));assertTrue(s.lines().contains("CYRUS_UNIT_END"));assertTrue(s.startsWith("#!/usr/bin/env bash"))
    }
    @Test fun `password is JSON escaped and never inserted as shell syntax`() {
        val password="test-only-$(touch /tmp/not-executed)-'quoted'"
        val s=ServerSetup.script(options.copy(password=password,protocol=ServerProtocol.TROJAN))
        assertTrue(s.contains("<<'CYRUS_CONFIG_END'"));assertTrue(s.contains(password))
    }
    @Test(expected=IllegalArgumentException::class) fun `version command injection blocked`() { ServerSetup.script(options.copy(version="1.11.1;id")) }
    @Test(expected=IllegalArgumentException::class) fun `checksum required`() { ServerSetup.script(options.copy(sha256="")) }
    @Test(expected=IllegalArgumentException::class) fun `unsafe certificate path blocked`() { ServerSetup.script(options.copy(certificate="/etc/a';id")) }
    @Test(expected=IllegalArgumentException::class) fun `password cannot break heredoc`() { ServerSetup.script(options.copy(password="a\nCYRUS_CONFIG_END\nexit 0")) }
    @Test fun `emit non-secret scripts for CI bash syntax check`() {
        val dir=File("build/server-script-fixtures").apply { mkdirs() }
        for(p in ServerProtocol.entries) File(dir,"${p.name}.sh").writeText(ServerSetup.script(options.copy(protocol=p)))
    }
}
