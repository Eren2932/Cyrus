package dev.kentra.vpn.config

import dev.kentra.domain.model.*
import kotlinx.serialization.json.*
import org.junit.Assert.*
import org.junit.Test
import java.io.File

class UpgradeConfigTest {
    private val factory=ConfigFactory()
    private val basic=VpnProfile("test","Test only",VpnProtocol.VLESS,"proxy.example",443,
        uuid="11111111-2222-4333-8444-555555555555",tls=TlsSettings(enabled=true,serverName="cdn.example"))
    private fun outbound(p:VpnProfile,options:TunnelOptions=TunnelOptions())=factory.config(p,options).outbounds.first()
    @Test fun `local proxy never creates a TUN or listens on LAN`() { val c=factory.config(basic,TunnelOptions(mode=ConnectionMode.PROXY));assertEquals("mixed",c.inbounds.single().type);assertEquals("127.0.0.1",c.inbounds.single().listen);assertEquals(2080,c.inbounds.single().listenPort);assertNull(c.inbounds.single().address) }
    @Test fun `Hysteria2 salamander emitted`() { val p=basic.copy(protocol=VpnProtocol.HYSTERIA2,password="test-only",parameters=mapOf("obfs" to "salamander","obfs-password" to "test-obfs","mport" to "443,5000-5010","upmbps" to "20"));val o=outbound(p);assertEquals("salamander",o.obfs?.type);assertEquals("test-obfs",o.obfs?.password);assertEquals(listOf("443","5000:5010"),o.serverPorts);assertEquals(20,o.upMbps) }
    @Test fun `TUIC options mapped`() { val p=basic.copy(protocol=VpnProtocol.TUIC,password="test-only",parameters=mapOf("congestion_control" to "bbr","udp_relay_mode" to "quic","zero_rtt_handshake" to "false","udp_over_stream" to "1","heartbeat" to "10s"));val o=outbound(p);assertEquals("bbr",o.congestionControl);assertEquals("quic",o.udpRelayMode);assertEquals(false,o.zeroRttHandshake);assertEquals(true,o.udpOverStream);assertEquals("10s",o.heartbeat) }
    @Test fun `SIP003 split plugin name from options`() { val o=outbound(basic.copy(protocol=VpnProtocol.SHADOWSOCKS,method="aes-256-gcm",password="test-only",parameters=mapOf("plugin" to "v2ray-plugin;tls;host=cdn.example")));assertEquals("v2ray-plugin",o.plugin);assertEquals("tls;host=cdn.example",o.pluginOpts) }
    @Test fun `HTTPUpgrade host is JSON string and HTTP host is JSON array`() { val upgrade=outbound(basic.copy(transport=TransportSettings("httpupgrade","/edge","cdn.example")));assertEquals(JsonPrimitive("cdn.example"),upgrade.transport?.host);assertNull(upgrade.transport?.headers)
        val http=outbound(basic.copy(transport=TransportSettings("http","/edge","a.example,b.example")));assertEquals(JsonArray(listOf(JsonPrimitive("a.example"),JsonPrimitive("b.example"))),http.transport?.host) }
    @Test fun `gRPC does not serialize ws path or headers`() { val o=outbound(basic.copy(transport=TransportSettings("grpc","legacy-service","cdn.example","service")));assertNull(o.transport?.path);assertNull(o.transport?.headers);assertEquals("service",o.transport?.serviceName) }
    @Test fun `per app include uses Android TUN filtering not ineffective route matching`() { val c=factory.config(basic,TunnelOptions(perAppMode=PerAppMode.Include(listOf("org.example.app"))));assertEquals(listOf("org.example.app"),c.inbounds.single().includePackage);assertFalse(c.route.rules.any { it.packageName != null }) }
    @Test fun `IPv6 setting affects VLESS resolution`() { assertEquals("prefer_ipv4",outbound(basic,TunnelOptions(ipv6=true)).domainStrategy) }
    @Test(expected=IllegalArgumentException::class) fun `certificate pin is never silently stripped`() { outbound(basic.copy(protocol=VpnProtocol.HYSTERIA2,password="test-only",parameters=mapOf("pinSHA256" to "test-only-pin"))) }
    @Test(expected=IllegalArgumentException::class) fun `XHTTP blocked before native startup`() { outbound(basic.copy(transport=TransportSettings("xhttp"))) }
    @Test(expected=IllegalArgumentException::class) fun `gRPC multiMode blocked`() { outbound(basic.copy(transport=TransportSettings("grpc"),parameters=mapOf("mode" to "multi"))) }
    @Test(expected=IllegalArgumentException::class) fun `unknown xray behavior blocked`() { outbound(basic.copy(parameters=mapOf("cyrus-unsupported" to "xray-options"))) }
    @Test(expected=IllegalArgumentException::class) fun `incomplete salamander blocked`() { outbound(basic.copy(protocol=VpnProtocol.HYSTERIA2,parameters=mapOf("obfs" to "salamander"))) }
    @Test(expected=IllegalArgumentException::class) fun `unknown SIP plugin blocked`() { outbound(basic.copy(protocol=VpnProtocol.SHADOWSOCKS,parameters=mapOf("plugin" to "unknown"))) }
    @Test(expected=IllegalArgumentException::class) fun `invalid proxy port blocked`() { factory.config(basic,TunnelOptions(mode=ConnectionMode.PROXY,proxyPort=0)) }
    @Test(expected=IllegalArgumentException::class) fun `empty include is not accidentally all apps`() { TunnelOptions(perAppMode=PerAppMode.Include(emptyList())).validate() }
    @Test(expected=IllegalArgumentException::class) fun `Vision cannot enable multiplex`() { outbound(basic.copy(flow="xtls-rprx-vision"),TunnelOptions(enableMultiplex=true)) }
    @Test fun `SOCKS HTTP config credentials map without changing TLS`() { val socks=outbound(basic.copy(protocol=VpnProtocol.SOCKS,password="test-only",parameters=mapOf("username" to "test-user","version" to "5")));assertEquals("socks",socks.type);assertNull(socks.tls);assertEquals("test-user",socks.username)
        val http=outbound(basic.copy(protocol=VpnProtocol.HTTP,password="test-only"));assertEquals("http",http.type);assertEquals(true,http.tls?.enabled) }
    @Test fun `emit synthetic configs for independent native schema check in CI`() {
        val dir=File("build/native-fixtures").apply { mkdirs() }
        val profiles=listOf(basic,basic.copy(protocol=VpnProtocol.TROJAN,password="test-only"),
            basic.copy(protocol=VpnProtocol.HYSTERIA2,password="test-only",parameters=mapOf("obfs" to "salamander","obfs-password" to "test-only-obfs")),
            basic.copy(protocol=VpnProtocol.TUIC,password="test-only",parameters=mapOf("congestion_control" to "bbr")),
            basic.copy(protocol=VpnProtocol.SHADOWSOCKS,method="aes-256-gcm",password="test-only"),
            basic.copy(protocol=VpnProtocol.HTTP),basic.copy(protocol=VpnProtocol.SOCKS)) +
            listOf("ws","grpc","http","httpupgrade").map { basic.copy(transport=TransportSettings(it,"/edge","cdn.example","service")) }
        profiles.forEachIndexed { index,p -> File(dir,"config-$index.json").writeText(factory.build(p,TunnelOptions(mode=ConnectionMode.PROXY))) }
        File(dir,"config-tun.json").writeText(factory.build(basic))
        assertEquals(12,dir.listFiles { f->f.extension=="json" }!!.size)
    }
}
