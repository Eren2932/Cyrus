package dev.kentra.vpn.config

import kotlinx.serialization.json.*

/** Pure text generation. No network requests, SSH, shell execution or background installation. */
enum class ServerProtocol { VLESS_TLS, TROJAN, HYSTERIA2, TUIC, SHADOWSOCKS }
data class ServerSetupOptions(
    val protocol: ServerProtocol,
    val version: String,
    val architecture: String = "amd64",
    val sha256: String,
    val port: Int = 443,
    val uuid: String,
    val password: String,
    val certificate: String = "/etc/ssl/cyrus/fullchain.pem",
    val privateKey: String = "/etc/ssl/cyrus/privkey.pem",
)
object ServerSetup {
    fun config(o: ServerSetupOptions): String {
        require(o.port in 1..65535) { "Порт: 1–65535" }
        require(Regex("[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}").matches(o.uuid)) { "Некорректный UUID" }
        require(o.password.length in 16..256 && o.password.none { it.isISOControl() }) { "Пароль: 16–256 символов без управляющих знаков" }
        val type = when(o.protocol) { ServerProtocol.VLESS_TLS -> "vless"; ServerProtocol.TROJAN -> "trojan"; ServerProtocol.HYSTERIA2 -> "hysteria2"; ServerProtocol.TUIC -> "tuic"; ServerProtocol.SHADOWSOCKS -> "shadowsocks" }
        val inbound = buildJsonObject {
            put("type", type); put("tag", "cyrus-in"); put("listen", "0.0.0.0"); put("listen_port", o.port)
            if(o.protocol == ServerProtocol.SHADOWSOCKS) { put("method", "chacha20-ietf-poly1305"); put("password", o.password) }
            else {
                putJsonArray("users") { add(buildJsonObject {
                    if(o.protocol in setOf(ServerProtocol.VLESS_TLS,ServerProtocol.TUIC)) put("uuid", o.uuid)
                    if(o.protocol != ServerProtocol.VLESS_TLS) put("password", o.password)
                }) }
                listOf(o.certificate, o.privateKey).forEach { path -> require(path.startsWith('/') && Regex("/[A-Za-z0-9_./-]+").matches(path) && ".." !in path) { "Нужны абсолютные пути сертификата и ключа" } }
                putJsonObject("tls") {
                    put("enabled", true); put("certificate_path", o.certificate); put("key_path", o.privateKey)
                    if(o.protocol in setOf(ServerProtocol.TUIC,ServerProtocol.HYSTERIA2)) putJsonArray("alpn") { add("h3") }
                }
            }
        }
        return Json { prettyPrint = true }.encodeToString(JsonObject.serializer(), buildJsonObject {
            putJsonObject("log") { put("level", "warn") }
            putJsonArray("inbounds") { add(inbound) }
            putJsonArray("outbounds") { add(buildJsonObject { put("type", "direct"); put("tag", "direct") }) }
            putJsonObject("route") { put("final", "direct") }
        })
    }
    fun script(o: ServerSetupOptions): String {
        require(Regex("[0-9]+\\.[0-9]+\\.[0-9]+").matches(o.version)) { "Укажите стабильную версию sing-box X.Y.Z из официального релиза" }
        require(o.architecture in setOf("amd64", "arm64")) { "Архитектура amd64 или arm64" }
        require(Regex("[0-9a-fA-F]{64}").matches(o.sha256)) { "Нужен SHA-256 именно выбранного Linux-архива из доверенного источника" }
        val json = config(o).prependIndent("            ").trimStart()
        val binary = "/usr/local/lib/cyrus/sing-box-${o.version}"
        val asset = "sing-box-${o.version}-linux-${o.architecture}"
        val tlsCheck = if(o.protocol == ServerProtocol.SHADOWSOCKS) "# TLS certificate not used by Shadowsocks" else
            "test -r '${o.certificate}'\n            test -r '${o.privateKey}'"
        // All interpolated shell fields are either constrained enums/numbers/paths or a quoted JSON heredoc.
        // JSON encoding escapes embedded newlines, preventing heredoc delimiter injection through passwords.
        return """
            #!/usr/bin/env bash
            # Cyrus: review first, then run as root on a dedicated Linux/systemd VPS.
            # Installs one independent service. Does not change firewall or existing sing-box config.
            set -euo pipefail
            test "${'$'}(id -u)" = 0 || { echo 'Run as root'; exit 1; }
            for tool in curl sha256sum tar systemctl install; do command -v "${'$'}tool" >/dev/null; done
            test ! -e /etc/systemd/system/cyrus-proxy.service || { echo 'Service already exists; back it up and review manually'; exit 1; }
            test ! -e /etc/cyrus/config.json || { echo 'Config already exists; refusing to overwrite'; exit 1; }
            test ! -e '$binary' || { echo 'Binary already exists; refusing to overwrite'; exit 1; }
            $tlsCheck
            umask 077
            work="${'$'}(mktemp -d)"
            trap 'rm -rf -- "${'$'}work"' EXIT
            curl --fail --location --proto '=https' --proto-redir '=https' --tlsv1.2 \
              'https://github.com/SagerNet/sing-box/releases/download/v${o.version}/$asset.tar.gz' -o "${'$'}work/core.tar.gz"
            printf '%s  %s\n' '${o.sha256.lowercase()}' "${'$'}work/core.tar.gz" | sha256sum --check --status
            tar -xzf "${'$'}work/core.tar.gz" -C "${'$'}work"
            cat > "${'$'}work/config.json" <<'CYRUS_CONFIG_END'
            $json
            CYRUS_CONFIG_END
            "${'$'}work/$asset/sing-box" check -c "${'$'}work/config.json"
            install -d -m 755 /usr/local/lib/cyrus
            install -d -m 700 /etc/cyrus
            install -m 755 "${'$'}work/$asset/sing-box" '$binary'
            install -m 600 "${'$'}work/config.json" /etc/cyrus/config.json
            cat > /etc/systemd/system/cyrus-proxy.service <<'CYRUS_UNIT_END'
            [Unit]
            Description=Cyrus server proxy
            After=network-online.target
            Wants=network-online.target
            [Service]
            ExecStart=$binary run -c /etc/cyrus/config.json
            Restart=on-failure
            RestartSec=5
            NoNewPrivileges=true
            PrivateTmp=true
            ProtectHome=true
            ProtectSystem=strict
            CapabilityBoundingSet=CAP_NET_BIND_SERVICE
            UMask=0077
            [Install]
            WantedBy=multi-user.target
            CYRUS_UNIT_END
            systemctl daemon-reload
            systemctl enable --now cyrus-proxy.service
            systemctl --no-pager --full status cyrus-proxy.service
            # Open port ${o.port}/${if(o.protocol in setOf(ServerProtocol.HYSTERIA2,ServerProtocol.TUIC)) "udp" else "tcp"} in provider firewall and local firewall manually.
            # Stop/rollback: systemctl disable --now cyrus-proxy.service
            # Files are intentionally retained for inspection; remove only after reviewing them.
        """.trimIndent() + "\n"
    }
}
