package dev.kentra.vpn.config

fun TunnelOptions.validate() {
    require(mtu in 1280..9000) { "MTU: 1280–9000" }
    require(proxyPort in 1024..65535) { "Порт прокси: 1024–65535" }
    require(stack in setOf("system", "gvisor", "mixed")) { "Неизвестный TUN stack" }
    require(logLevel in setOf("warn", "error", "fatal")) { "Разрешены только warn/error/fatal" }
    require(dnsRemote.isNotBlank() && dnsRemote.none { it.isWhitespace() }) { "Некорректный DNS" }
    require(dnsLocal == "local" || dnsLocal.isNotBlank() && dnsLocal.none { it.isWhitespace() }) { "Некорректный локальный DNS" }
    val packages = when (val p = perAppMode) { is PerAppMode.Include -> p.packages; is PerAppMode.Exclude -> p.packages; else -> emptyList() }
    require(packages.size <= 500 && packages.all { Regex("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+").matches(it) }) { "Некорректные package IDs" }
    require(perAppMode !is PerAppMode.Include || packages.isNotEmpty()) { "Укажите приложения для режима включения" }
    require(mode != ConnectionMode.PROXY || perAppMode == PerAppMode.Off) { "Фильтр приложений доступен только в VPN" }
}
