package dev.kentra.vpn.link

import dev.kentra.domain.model.*
import dev.kentra.domain.repository.LinkParser
import kotlinx.serialization.json.*
import java.net.URI
import java.net.URLDecoder
import java.util.UUID

/** No network, logging, Android API or credential-bearing exception messages. */
class DefaultLinkParser(
    private val idFactory: () -> String = { UUID.randomUUID().toString() },
    private val clock: () -> Long = { System.currentTimeMillis() },
) : LinkParser {
    private val json = Json { ignoreUnknownKeys = true }

    override fun export(profile: VpnProfile): String = ProfileLinkWriter.write(profile)

    override fun parse(uri: String): VpnProfile? = runCatching { parseChecked(uri.trim()) }.getOrNull()
    override fun parseMany(payload: String): List<VpnProfile> = inspect(payload).profiles

    override fun inspect(payload: String): ImportReport {
        if (payload.length > MAX_INPUT) return ImportReport(issues = listOf(ImportIssue(0, "Лимит импорта — 1 МиБ текста")))
        val clean = payload.trim().removePrefix("﻿")
        val text = if ("://" !in clean && !clean.startsWith('{') && !clean.startsWith('['))
            clean.decodeBase64OrNull() ?: clean else clean
        if (text.startsWith('{') || text.startsWith('[')) return XraySubscriptionReader(this).inspect(text)
        val profiles = mutableListOf<VpnProfile>()
        val issues = mutableListOf<ImportIssue>()
        val seen = mutableSetOf<String>()
        var duplicates = 0
        text.lineSequence().forEachIndexed { index, line ->
            val key = line.trim()
            if (key.isEmpty() || key.startsWith('#')) return@forEachIndexed
            if (index >= MAX_LINES) {
                if (index == MAX_LINES) issues += ImportIssue(index + 1, "Лимит — 2000 строк за импорт")
                return@forEachIndexed
            }
            val profile = parse(key)
            if (profile == null) issues += ImportIssue(index + 1, "Неизвестный формат или некорректный адрес, порт либо учётные данные")
            else if (!seen.add(profile.connectionIdentity())) duplicates++
            else profiles += profile
        }
        if (profiles.isEmpty() && issues.isEmpty()) issues += ImportIssue(0, "Вставьте ключ или список ключей")
        return ImportReport(profiles, issues, duplicates)
    }

    private fun parseChecked(raw: String): VpnProfile {
        require(raw.length in 1..MAX_LINK && raw.none { it == '\n' || it == '\r' })
        val scheme = raw.substringBefore("://").lowercase()
        val normalized = scheme + "://" + raw.substringAfter("://")
        val profile = when (scheme) {
            "vmess" -> vmess(normalized)
            "ss" -> shadowsocks(normalized)
            "socks", "socks5", "socks4", "socks4a", "http", "https" -> proxy(normalized, scheme)
            "vless", "trojan", "hysteria2", "hy2", "tuic" -> standard(normalized, scheme)
            else -> error("Unsupported format")
        }
        require(profile.server.isNotBlank() && profile.server.none { it.isWhitespace() || it == '/' })
        require(profile.port in 1..65535)
        require((profile.alterId ?: 0) >= 0)
        when (profile.protocol) {
            VpnProtocol.VLESS, VpnProtocol.VMESS -> require(validUuid(profile.uuid))
            VpnProtocol.TUIC -> require(validUuid(profile.uuid) && !profile.password.isNullOrEmpty())
            VpnProtocol.SOCKS, VpnProtocol.HTTP -> Unit
            else -> require(!profile.password.isNullOrEmpty())
        }
        profile.tls.reality?.let { require(it.publicKey.isNotBlank()) }
        return profile.copy(rawLink = normalized, name = profile.name.ifBlank { profile.server }.take(160))
    }

    private fun proxy(raw: String, scheme: String): VpnProfile {
        val uri = URI(raw)
        require(uri.rawPath.isNullOrEmpty() || uri.rawPath == "/")
        val credentials = uri.rawUserInfo
        val q = query(uri.rawQuery)
        val isHttp = scheme == "http" || scheme == "https"
        val version = when (scheme) { "socks4" -> "4"; "socks4a" -> "4a"; else -> "5" }
        if (credentials != null && (isHttp || version == "5")) require(':' in credentials)
        return VpnProfile(
            id = idFactory(), name = uri.rawFragment?.decode().orEmpty(),
            protocol = if (isHttp) VpnProtocol.HTTP else VpnProtocol.SOCKS,
            server = host(uri), port = port(uri, if (scheme == "https") 443 else if (isHttp) 8080 else 1080),
            password = credentials?.substringAfter(':', "")?.decode(),
            tls = TlsSettings(enabled = scheme == "https", serverName = q["sni"],
                allowInsecure = q["insecure"] in listOf("1", "true")),
            parameters = q + buildMap {
                if (!isHttp) put("version", version)
                credentials?.let { put("username", it.substringBefore(':').decode()) }
            }, createdAt = clock(),
        )
    }

    private fun standard(raw: String, scheme: String): VpnProfile {
        val uri = URI(raw)
        val q = query(uri.rawQuery)
        val credential = uri.rawUserInfo ?: error("Missing credential")
        val protocol = when (scheme) {
            "vless" -> VpnProtocol.VLESS
            "trojan" -> VpnProtocol.TROJAN
            "tuic" -> VpnProtocol.TUIC
            else -> VpnProtocol.HYSTERIA2
        }
        val security = q["security"]?.lowercase() ?: if (protocol == VpnProtocol.VLESS) "none" else "tls"
        if (security == "reality") require(!q["pbk"].isNullOrBlank())
        val transport = q["type"]?.lowercase() ?: "tcp"
        return VpnProfile(
            id = idFactory(), name = uri.rawFragment?.decode().orEmpty(), protocol = protocol,
            server = host(uri), port = port(uri, 443),
            uuid = if (protocol == VpnProtocol.VLESS) credential.decode()
                else if (protocol == VpnProtocol.TUIC) credential.substringBefore(':').decode() else null,
            password = if (protocol == VpnProtocol.TUIC) {
                require(':' in credential); credential.substringAfter(':').decode()
            } else if (protocol != VpnProtocol.VLESS) credential.decode() else null,
            flow = q["flow"],
            tls = TlsSettings(
                enabled = security != "none", serverName = q["sni"] ?: q["peer"],
                allowInsecure = (q["allowInsecure"] ?: q["insecure"]) in listOf("1", "true"),
                alpn = q["alpn"]?.split(',')?.filter { it.isNotBlank() }.orEmpty(), fingerprint = q["fp"],
                reality = if (security == "reality") RealitySettings(q.getValue("pbk"), q["sid"], q["spx"]) else null,
            ),
            transport = TransportSettings(transport, q["path"], q["host"], q["serviceName"] ?: q["path"].takeIf { transport == "grpc" }),
            parameters = q, createdAt = clock(),
        )
    }

    private fun vmess(raw: String): VpnProfile {
        val body = raw.substringAfter("://").substringBefore('#').decodeBase64OrNull() ?: error("Invalid Base64")
        val obj = json.parseToJsonElement(body).jsonObject
        fun str(key: String): String? = obj[key]?.jsonPrimitive?.contentOrNull?.takeIf { it.isNotBlank() }
        val net = str("net") ?: "tcp"
        return VpnProfile(
            id = idFactory(), name = raw.substringAfter('#', "").takeIf { it.isNotEmpty() }?.decode() ?: str("ps").orEmpty(), protocol = VpnProtocol.VMESS,
            server = str("add") ?: error("Missing host"), port = str("port")?.toIntOrNull() ?: error("Invalid port"),
            uuid = str("id"), alterId = str("aid")?.toIntOrNull() ?: 0,
            tls = TlsSettings(enabled = str("tls") in listOf("tls", "reality"), serverName = str("sni") ?: str("host"),
                fingerprint = str("fp"), alpn = str("alpn")?.split(',').orEmpty()),
            transport = TransportSettings(net, str("path"), str("host"), str("path").takeIf { net == "grpc" }),
            parameters = obj.mapValues { it.value.jsonPrimitive.content }, createdAt = clock(),
        )
    }

    private fun shadowsocks(raw: String): VpnProfile {
        val body = raw.substringAfter("://").substringBefore('#')
        val q = query(body.substringAfter('?', ""))
        val address = body.substringBefore('?').removeSuffix("/")
        val decoded = if ('@' in address) address else address.decodeBase64OrNull() ?: error("Invalid Base64")
        require('@' in decoded)
        val user = decoded.substringBeforeLast('@')
        val decodedUser = user.decode()
        val credentials = if (':' in decodedUser) decodedUser else user.decodeBase64OrNull() ?: error("Missing credentials")
        require(':' in credentials)
        val uri = URI("ss://" + decoded.substringAfterLast('@'))
        return VpnProfile(
            id = idFactory(), name = raw.substringAfter('#', "").decode(), protocol = VpnProtocol.SHADOWSOCKS,
            server = host(uri), port = port(uri, -1), method = credentials.substringBefore(':').also { require(it.isNotBlank()) },
            password = credentials.substringAfter(':'), parameters = q, createdAt = clock(),
        )
    }

    private fun query(raw: String?): Map<String, String> = raw?.split('&')?.filter { it.isNotEmpty() }?.associate {
        it.substringBefore('=').decode() to it.substringAfter('=', "").decode()
    }.orEmpty()
    private fun host(uri: URI): String = (uri.host ?: error("Invalid host")).removeSurrounding("[", "]")
    private fun port(uri: URI, default: Int): Int {
        require(uri.rawAuthority?.endsWith(':') != true)
        return if (uri.port == -1) default else uri.port
    }
    // URLDecoder normally corrupts '+' in passwords and Base64. URI components are not form data.
    private fun String.decode(): String = URLDecoder.decode(replace("+", "%2B"), "UTF-8")
    private fun validUuid(value: String?): Boolean = value != null && UUID_PATTERN.matches(value)

    companion object {
        const val MAX_INPUT = 1_048_576
        const val MAX_LINES = 2000
        const val MAX_LINK = 65_536
        private val UUID_PATTERN = Regex("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")
    }
}
