package dev.kentra.vpn.link

import dev.kentra.domain.model.*
import kotlinx.serialization.json.*
import java.util.Base64
import java.net.URLEncoder

/** Extract proxy nodes only. Never execute downloaded routing, DNS, local inbounds or policy. */
internal class XraySubscriptionReader(private val parser: DefaultLinkParser) {
    private fun JsonObject.str(key: String) = (get(key) as? JsonPrimitive)?.contentOrNull
    private fun JsonObject.obj(key: String) = get(key) as? JsonObject ?: JsonObject(emptyMap())
    private fun JsonObject.array(key: String) = get(key) as? JsonArray ?: JsonArray(emptyList())
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")
    fun inspect(text: String): ImportReport {
        val profiles = mutableListOf<VpnProfile>()
        val issues = mutableListOf<ImportIssue>()
        val seen = mutableSetOf<String>()
        var duplicates = 0
        try {
            require(boundedNesting(text))
            var generatedChars = 0
            val root = Json.parseToJsonElement(text)
            val configs = if (root is JsonArray) root else JsonArray(listOf(root))
            var index = 0
            for (config in configs) {
                require(config is JsonObject && config["outbounds"] is JsonArray)
                for (entry in config.array("outbounds")) {
                    index++
                    if (index > DefaultLinkParser.MAX_LINES) { issues += ImportIssue(index, "Слишком много JSON-узлов"); break }
                    val o = entry as? JsonObject ?: error("object required")
                    if (o.str("protocol") in setOf("freedom", "blackhole", "dns", "loopback")) continue
                    val converted = runCatching {
                        require(o.toString().length <= 32_768)
                        links(o)
                    }.getOrNull()
                    if (converted == null || converted.isEmpty()) { issues += ImportIssue(index, "Неподдерживаемый или повреждённый JSON outbound"); continue }
                    for (uri in converted) {
                        generatedChars += uri.length
                        require(generatedChars <= 4_194_304 && profiles.size < DefaultLinkParser.MAX_LINES)
                        val p = parser.parse(uri)
                        if (p == null) issues += ImportIssue(index, "Некорректные параметры JSON-узла")
                        else if (seen.add(p.connectionIdentity())) profiles += p else duplicates++
                    }
                }
            }
            if (profiles.isEmpty() && issues.isEmpty()) issues += ImportIssue(0, "В JSON нет поддерживаемых прокси-узлов")
        } catch (e: Exception) {
            // No source JSON, UUID, server or tokens in exception text.
            return ImportReport(issues = listOf(ImportIssue(0, "Нужен Xray JSON с массивом outbounds; sing-box/Clash JSON и YAML пока не поддерживаются")))
        }
        return ImportReport(profiles, issues, duplicates)
    }
    private fun boundedNesting(text: String): Boolean {
        var depth = 0
        var quoted = false
        var escaped = false
        for (ch in text) {
            if (quoted) {
                if (escaped) escaped = false else if (ch == '\\') escaped = true else if (ch == '"') quoted = false
            } else when (ch) {
                '"' -> quoted = true
                '{', '[' -> { depth++; if (depth > 64) return false }
                '}', ']' -> { depth--; if (depth < 0) return false }
            }
        }
        return depth == 0 && !quoted
    }
    private fun links(o: JsonObject): List<String> {
        val protocol = o.str("protocol") ?: error("protocol")
        val s = o.obj("settings")
        val stream = o.obj("streamSettings")
        val net = stream.str("network") ?: "tcp"
        val security = stream.str("security") ?: "none"
        val tls = stream.obj(if (security == "reality") "realitySettings" else "tlsSettings")
        val q = linkedMapOf<String, String>()
        fun put(key: String, value: String?) { if (value != null) q[key] = value }
        put("type", if (net == "hysteria") "tcp" else net)
        put("security", security); put("sni", tls.str("serverName")); put("fp", tls.str("fingerprint"))
        put("pbk", tls.str("publicKey")); put("sid", tls.str("shortId")); put("spx", tls.str("spiderX"))
        put("pinSHA256", tls.str("pinnedPeerCertSha256"))
        if (tls.str("allowInsecure") == "true") put("insecure", "1")
        val alpn = tls.array("alpn").mapNotNull { (it as? JsonPrimitive)?.contentOrNull }
        if (alpn.isNotEmpty()) put("alpn", alpn.joinToString(","))
        val tr = stream.obj(when (net) { "ws" -> "wsSettings"; "grpc" -> "grpcSettings"; "xhttp" -> "xhttpSettings"; "httpupgrade" -> "httpupgradeSettings"; else -> "tcpSettings" })
        put("host", tr.str("host") ?: tr.obj("headers").str("Host")); put("path", tr.str("path"))
        put("serviceName", tr.str("serviceName")); put("mode", tr.str("mode"))
        if (tr.str("multiMode") == "true") put("mode", "multi")
        // Preserve original outbound (encrypted by storage). Unknown behavior blocks connection,
        // not the entire subscription. Users can still inspect/export the node.
        put("cyrus-xray", Base64.getUrlEncoder().withoutPadding().encodeToString(o.toString().toByteArray(Charsets.UTF_8)))
        val allowedStream = setOf("network", "security", "tlsSettings", "realitySettings", "wsSettings", "grpcSettings", "xhttpSettings", "httpupgradeSettings", "tcpSettings", "hysteriaSettings")
        val allowedTls = setOf("serverName", "allowInsecure", "fingerprint", "alpn", "publicKey", "shortId", "spiderX", "pinnedPeerCertSha256")
        val allowedTransport = setOf("host", "path", "headers", "serviceName", "multiMode", "mode")
        if (stream.keys.any { it !in allowedStream } || tls.keys.any { it !in allowedTls } ||
            tr.keys.any { it !in allowedTransport } || tr.obj("headers").keys.any { it != "Host" } ||
            o.keys.any { it !in setOf("protocol", "settings", "streamSettings", "tag") })
            put("cyrus-unsupported", "xray-options")
        val knownSettings = when (protocol) {
            "vless" -> setOf("vnext")
            "trojan", "shadowsocks" -> setOf("servers")
            "hysteria" -> setOf("address", "port", "version")
            else -> emptySet()
        }
        if (s.keys.any { it !in knownSettings }) put("cyrus-unsupported", "settings-options")
        require(s.array("vnext").size <= 100 && s.array("servers").size <= 100)
        val name = o.str("tag") ?: protocol
        fun uri(scheme: String, auth: String, address: String, port: Int, options: Map<String,String> = q): String {
            require(port in 1..65535)
            val host = if (':' in address) "[$address]" else address
            return "$scheme://$auth@$host:$port?" + options.entries.joinToString("&") { enc(it.key) + "=" + enc(it.value) } + "#" + enc(name)
        }
        return when (protocol) {
            "vless" -> s.array("vnext").flatMap { endpoint ->
                val server = endpoint.jsonObject
                require(server.array("users").size <= 100)
                if (server.keys.any { it !in setOf("address", "port", "users") }) q["cyrus-unsupported"] = "server-options"
                server.array("users").map { item ->
                    val user = item.jsonObject
                    val params = q.toMutableMap()
                    user.str("flow")?.let { params["flow"] = it }
                    user.str("encryption")?.let { params["encryption"] = it }
                    if (user.keys.any { it !in setOf("id", "flow", "encryption", "level", "email") }) params["cyrus-unsupported"] = "user-options"
                    uri("vless", enc(requireNotNull(user.str("id"))), requireNotNull(server.str("address")), server.str("port")!!.toInt(), params)
                }
            }
            "trojan", "shadowsocks" -> s.array("servers").map { item ->
                val server = item.jsonObject
                if (server.keys.any { it !in setOf("address", "port", "password", "method", "level", "email") }) q["cyrus-unsupported"] = "server-options"
                val password = requireNotNull(server.str("password"))
                val auth = if (protocol == "trojan") enc(password) else Base64.getUrlEncoder().withoutPadding()
                    .encodeToString("${requireNotNull(server.str("method"))}:$password".toByteArray(Charsets.UTF_8))
                uri(if (protocol == "trojan") "trojan" else "ss", auth, requireNotNull(server.str("address")), server.str("port")!!.toInt())
            }
            "hysteria" -> {
                require(s.str("version") == "2" || stream.obj("hysteriaSettings").str("version") == "2")
                // QUIC cannot use uTLS. Retain original in cyrus-xray and block if fingerprint was specified.
                if ("fp" in q) q["cyrus-unsupported"] = "quic-fingerprint"
                listOf(uri("hy2", enc(requireNotNull(stream.obj("hysteriaSettings").str("auth"))), requireNotNull(s.str("address")), s.str("port")!!.toInt()))
            }
            else -> error("unsupported")
        }
    }
}
