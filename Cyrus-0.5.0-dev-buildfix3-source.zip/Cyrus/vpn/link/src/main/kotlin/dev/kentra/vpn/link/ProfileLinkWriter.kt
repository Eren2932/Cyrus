package dev.kentra.vpn.link

import dev.kentra.domain.model.*
import kotlinx.serialization.json.*
import java.net.URLEncoder
import java.util.Base64

/** Canonical export from current fields; retain unknown vendor query options. Never logs secrets. */
object ProfileLinkWriter {
    private fun enc(text: String) = URLEncoder.encode(text, "UTF-8").replace("+", "%20")
    fun write(p: VpnProfile): String {
        val host = if (':' in p.server) "[${p.server}]" else p.server
        val q = p.parameters.toMutableMap()
        fun set(key: String, value: String?) { if (value.isNullOrBlank()) q.remove(key) else q[key] = value }
        if (p.protocol == VpnProtocol.VMESS) {
            val fields = p.parameters.mapValues { JsonPrimitive(it.value) }.toMutableMap()
            fun field(key: String, value: String?) { if (value == null) fields.remove(key) else fields[key] = JsonPrimitive(value) }
            field("v", "2"); field("ps", p.name); field("add", p.server); field("port", p.port.toString())
            field("id", p.uuid); field("aid", (p.alterId ?: 0).toString()); field("tls", if (p.tls.enabled) "tls" else "")
            field("sni", p.tls.serverName); field("fp", p.tls.fingerprint); field("alpn", p.tls.alpn.joinToString(","))
            field("net", p.transport.type); field("host", p.transport.host)
            field("path", if (p.transport.type == "grpc") p.transport.serviceName else p.transport.path)
            return "vmess://" + Base64.getEncoder().encodeToString(JsonObject(fields).toString().toByteArray(Charsets.UTF_8))
        }
        // Remove alternate names to prevent stale aliases from winning on re-import.
        listOf("sni", "peer", "allowInsecure", "insecure", "alpn", "fp", "pbk", "sid", "spx", "security", "type", "path", "host", "serviceName").forEach { q.remove(it) }
        if (p.protocol !in setOf(VpnProtocol.SHADOWSOCKS, VpnProtocol.SOCKS)) {
            set("sni", p.tls.serverName)
            if (p.tls.allowInsecure) set("insecure", "1")
            set("alpn", p.tls.alpn.takeIf { it.isNotEmpty() }?.joinToString(","))
            set("fp", p.tls.fingerprint)
        }
        if (p.protocol in setOf(VpnProtocol.VLESS, VpnProtocol.TROJAN)) {
            set("security", if (p.tls.reality != null) "reality" else if (p.tls.enabled) "tls" else "none")
            set("type", p.transport.type); set("path", p.transport.path); set("host", p.transport.host)
            set("serviceName", p.transport.serviceName); set("flow", p.flow)
            p.tls.reality?.let { set("pbk", it.publicKey); set("sid", it.shortId); set("spx", it.spiderX) }
        }
        val scheme = when (p.protocol) {
            VpnProtocol.VLESS -> "vless"; VpnProtocol.TROJAN -> "trojan"; VpnProtocol.SHADOWSOCKS -> "ss"
            VpnProtocol.HYSTERIA2 -> "hysteria2"; VpnProtocol.TUIC -> "tuic"
            VpnProtocol.HTTP -> if (p.tls.enabled) "https" else "http"
            VpnProtocol.SOCKS -> when (q["version"]) { "4" -> "socks4"; "4a" -> "socks4a"; else -> "socks5" }
            else -> error("Неподдерживаемый формат экспорта")
        }
        val auth = when (p.protocol) {
            VpnProtocol.VLESS -> enc(requireNotNull(p.uuid))
            VpnProtocol.TUIC -> enc(requireNotNull(p.uuid)) + ":" + enc(requireNotNull(p.password))
            VpnProtocol.SHADOWSOCKS -> Base64.getUrlEncoder().withoutPadding().encodeToString("${p.method}:${p.password}".toByteArray(Charsets.UTF_8))
            VpnProtocol.SOCKS, VpnProtocol.HTTP -> q["username"]?.let { enc(it) + ":" + enc(p.password.orEmpty()) }
            else -> enc(requireNotNull(p.password))
        }
        q.remove("username"); q.remove("version")
        val query = q.entries.joinToString("&") { enc(it.key) + "=" + enc(it.value) }
        return "$scheme://" + (auth?.let { "$it@" } ?: "") + "$host:${p.port}" +
            (if (query.isEmpty()) "" else "?$query") + "#" + enc(p.name)
    }
}
