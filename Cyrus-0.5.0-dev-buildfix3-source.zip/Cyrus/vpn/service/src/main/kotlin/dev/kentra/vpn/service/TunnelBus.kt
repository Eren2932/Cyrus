package dev.kentra.vpn.service

import dev.kentra.domain.model.TrafficSample
import dev.kentra.domain.model.TunnelState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Single source of truth for tunnel state inside the app process.
 *
 * PHASE 1: the service runs in the main process, so a shared object is enough.
 * PHASE 2: the service moves to `android:process=":vpn"` and this class becomes
 * the client side of an AIDL/Messenger channel. The rest of the app will not notice,
 * because nothing outside this package reads the tunnel state directly.
 */
class TunnelBus {
    var owner: Any? = null
        private set
    fun claim(value: Any) { owner = value }
    fun release(value: Any) {
        if (owner === value) {
            owner = null
            if (state.value !is TunnelState.Failed) reset()
        }
    }

    private val _state = MutableStateFlow<TunnelState>(TunnelState.Idle)
    val state: StateFlow<TunnelState> = _state.asStateFlow()

    private val _traffic = MutableStateFlow(TrafficSample())
    val traffic: StateFlow<TrafficSample> = _traffic.asStateFlow()

    fun publish(state: TunnelState) {
        _state.value = state
    }

    fun publish(sample: TrafficSample) {
        _traffic.value = sample
    }

    fun reset() {
        _state.value = TunnelState.Idle
        _traffic.value = TrafficSample()
    }
}
