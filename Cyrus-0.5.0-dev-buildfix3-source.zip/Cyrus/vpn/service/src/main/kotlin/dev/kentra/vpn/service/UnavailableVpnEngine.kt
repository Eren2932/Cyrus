package dev.kentra.vpn.service

import android.app.Service
import android.net.VpnService
import dev.kentra.domain.model.TrafficSample
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf

/** Fail closed. A real engine must return from start only after TUN is established. */
class UnavailableVpnEngine : VpnEngine {
    override val id = "unavailable"
    override val traffic: Flow<TrafficSample> = flowOf(TrafficSample())
    override suspend fun start(service: Service, session: TunnelSession) {
        error("VPN-ядро не установлено. Трафик не защищён.")
    }
    override suspend fun stop() = Unit
}
