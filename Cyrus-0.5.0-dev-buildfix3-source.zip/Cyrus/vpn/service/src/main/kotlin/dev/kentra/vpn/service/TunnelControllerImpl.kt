package dev.kentra.vpn.service

import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import dev.kentra.core.common.AppError
import dev.kentra.core.datastore.SettingsStore
import dev.kentra.domain.model.TrafficSample
import dev.kentra.domain.model.TunnelState
import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.repository.TunnelController
import dev.kentra.vpn.config.ConfigFactory
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import dev.kentra.vpn.config.ConnectionMode

/**
 * The only bridge between the app and the VPN process.
 *
 * Note the permission contract: this class does NOT show UI. If the VPN consent dialog is
 * required it fails with [AppError.Permission] and the feature layer turns that into an
 * MVI effect. Keeping Android dialogs out of the data layer is what makes this testable.
 */
class TunnelControllerImpl(
    private val context: Context,
    private val bus: TunnelBus,
    private val settings: SettingsStore,
    private val configFactory: ConfigFactory,
    private val engine: VpnEngine,
) : TunnelController {

    override val state: StateFlow<TunnelState> = bus.state
    override val traffic: Flow<TrafficSample> = bus.traffic

    private val commands = Mutex()
    private var runningService: Class<out android.app.Service>? = null

    override suspend fun connect(profile: VpnProfile) = commands.withLock {
        if (engine.id == "unavailable") throw AppError.Tunnel("VPN-ядро не установлено. Ключ сохранён, но трафик не защищён.")

        if (bus.state.value is TunnelState.Preparing || bus.state.value is TunnelState.Stopping)
            throw AppError.Tunnel("Дождитесь завершения предыдущего подключения")
        val options = settings.tunnelOptions.first()
        val target = if (options.mode == ConnectionMode.PROXY) CyrusProxyService::class.java else CyrusVpnService::class.java
        if (runningService != null && runningService != target && bus.state.value !is TunnelState.Idle && bus.state.value !is TunnelState.Failed)
            throw AppError.Tunnel("Перед сменой режима отключите текущее соединение")
        if (options.mode == ConnectionMode.VPN && VpnService.prepare(context) != null) throw AppError.Permission("vpn-consent")
        val configJson = runCatching { configFactory.build(profile, options) }
            .getOrElse { throw AppError.Tunnel("config build failed: ${it.message}") }

        val intent = Intent(context, target).apply {
            action = CyrusVpnService.ACTION_START
            putExtra(CyrusVpnService.EXTRA_PROFILE_ID, profile.id)
            putExtra(CyrusVpnService.EXTRA_PROFILE_NAME, profile.name)
            putExtra(CyrusVpnService.EXTRA_CONFIG, configJson)
        }
        val previousState = bus.state.value
        val previousOwner = bus.owner
        val previousService = runningService
        runningService = target
        bus.claim(this)
        bus.publish(TunnelState.Preparing)
        try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
        } catch (error: Exception) {
            runningService = previousService
            previousOwner?.let { bus.claim(it) }
            if (previousState is TunnelState.Connected) bus.publish(previousState)
            else bus.publish(TunnelState.Failed("Android не разрешил запустить службу подключения"))
            throw AppError.Tunnel("Android не разрешил запустить службу подключения")
        }
        Unit
    }

    override suspend fun disconnect() = commands.withLock {
        if (engine.id == "unavailable") { bus.reset(); return@withLock }
        val previous = bus.state.value
        bus.publish(TunnelState.Stopping)
        try {
            context.startService(
                Intent(context, runningService ?: CyrusVpnService::class.java).setAction(CyrusVpnService.ACTION_STOP),
            )
        } catch (error: Exception) {
            bus.publish(previous)
            throw AppError.Tunnel("Android не разрешил отправить команду остановки; используйте уведомление или системные настройки VPN")
        }
        Unit
    }
}
