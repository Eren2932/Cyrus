package dev.kentra.vpn.service

import android.app.Service
import android.content.Intent
import android.os.IBinder
import org.koin.android.ext.android.inject

/** Loopback HTTP CONNECT / SOCKS5. No VpnService.prepare(), Builder or system-wide capture. */
class CyrusProxyService : Service() {
    private val bus: TunnelBus by inject()
    private val engine: VpnEngine by inject()
    private val runner by lazy { TunnelServiceRunner(this, bus, engine, true) }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        runner.command(intent, startId)
        return START_NOT_STICKY
    }
    override fun onDestroy() { runner.destroy(); super.onDestroy() }
}
