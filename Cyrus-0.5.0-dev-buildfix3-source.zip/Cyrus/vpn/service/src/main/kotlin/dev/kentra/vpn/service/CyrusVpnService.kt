package dev.kentra.vpn.service

import android.content.Intent
import android.net.VpnService
import org.koin.android.ext.android.inject

class CyrusVpnService : VpnService() {
    private val bus: TunnelBus by inject()
    private val engine: VpnEngine by inject()
    private val runner by lazy { TunnelServiceRunner(this, bus, engine, false) }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        runner.command(intent, startId)
        return START_NOT_STICKY
    }
    override fun onRevoke() { runner.revoke(); super.onRevoke() }
    override fun onDestroy() { runner.destroy(); super.onDestroy() }
    companion object {
        const val ACTION_START = "dev.kentra.vpn.START"
        const val ACTION_STOP = "dev.kentra.vpn.STOP"
        const val EXTRA_PROFILE_ID = "profile_id"
        const val EXTRA_PROFILE_NAME = "profile_name"
        const val EXTRA_CONFIG = "config"
    }
}
