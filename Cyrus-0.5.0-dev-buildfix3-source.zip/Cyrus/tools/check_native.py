#!/usr/bin/env python3
"""Validate AAR packaging; compilation still has to validate the complete Java API."""
import io
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]

def verify(folder):
    files = list(folder.glob('*.aar'))
    if len(files) != 1:
        raise ValueError(f'Expected exactly one libbox AAR in {folder}; found {len(files)}')
    with zipfile.ZipFile(files[0]) as aar:
        with zipfile.ZipFile(io.BytesIO(aar.read('classes.jar'))) as jar:
            for name in ('Libbox', 'BoxService', 'PlatformInterface', 'CommandClient', 'SetupOptions'):
                if f'io/nekohasekai/libbox/{name}.class' not in jar.namelist():
                    raise ValueError(f'Missing libbox binding: {name}')
        for abi in ('arm64-v8a', 'armeabi-v7a', 'x86_64'):
            name = f'jni/{abi}/libbox.so'
            if name not in aar.namelist() or aar.getinfo(name).file_size == 0:
                raise ValueError(f'Missing or empty native library: {abi}')
    return files[0]

if __name__ == '__main__':
    print('PASS native AAR packaging:', verify(ROOT / 'vpn/service/libs'))
    print('NOT VERIFIED: binary provenance, JNI/API compatibility, APK or runtime behaviour.')
