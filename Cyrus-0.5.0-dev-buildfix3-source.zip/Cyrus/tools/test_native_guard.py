#!/usr/bin/env python3
"""Synthetic ZIP fixture tests for check_native, not tests of a real libbox binary."""
import io
from pathlib import Path
import tempfile
import unittest
import zipfile
from check_native import verify

class NativePackagingTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
    def tearDown(self):
        self.temp.cleanup()
    def fixture(self, omit_class=None, omit_abi=None, empty_abi=None):
        jar_data = io.BytesIO()
        with zipfile.ZipFile(jar_data, 'w') as jar:
            for name in ('Libbox', 'BoxService', 'PlatformInterface', 'CommandClient', 'SetupOptions'):
                if name != omit_class:
                    jar.writestr(f'io/nekohasekai/libbox/{name}.class', b'fixture-only')
        path = self.root / 'libbox.aar'
        with zipfile.ZipFile(path, 'w') as aar:
            aar.writestr('classes.jar', jar_data.getvalue())
            for abi in ('arm64-v8a', 'armeabi-v7a', 'x86_64'):
                if abi != omit_abi:
                    aar.writestr(f'jni/{abi}/libbox.so', b'' if abi == empty_abi else b'fixture-only')
        return path
    def test_complete_packaging(self):
        expected = self.fixture()
        self.assertEqual(verify(self.root), expected)
    def test_absent(self):
        with self.assertRaises(ValueError): verify(self.root)
    def test_duplicate(self):
        p = self.fixture()
        (self.root/'second.aar').write_bytes(p.read_bytes())
        with self.assertRaises(ValueError): verify(self.root)
    def test_missing_binding(self):
        self.fixture(omit_class='BoxService')
        with self.assertRaises(ValueError): verify(self.root)
    def test_missing_abi(self):
        self.fixture(omit_abi='arm64-v8a')
        with self.assertRaises(ValueError): verify(self.root)
    def test_empty_native_library(self):
        self.fixture(empty_abi='x86_64')
        with self.assertRaises(ValueError): verify(self.root)

if __name__ == '__main__':
    unittest.main(verbosity=2)
