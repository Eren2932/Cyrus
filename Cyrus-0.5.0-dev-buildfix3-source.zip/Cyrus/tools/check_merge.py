#!/usr/bin/env python3
"""Static merge guards only: not coroutine execution or native/device tests."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
ENGINE = 'vpn/service/src/main/kotlin/dev/kentra/vpn/service/LibboxVpnEngine.kt'
SERVICE = 'vpn/service/src/main/kotlin/dev/kentra/vpn/service/TunnelServiceRunner.kt'
CONFIG = 'vpn/config/src/main/kotlin/dev/kentra/vpn/config/ConfigFactory.kt'
TEST = 'vpn/config/src/test/kotlin/dev/kentra/vpn/config/ConfigFactoryTest.kt'

def validate(root=ROOT):
    text = lambda path: (root / path).read_text()
    engine, service, config = map(text, (ENGINE, SERVICE, CONFIG))
    passed = []
    def check(name, ok):
        assert ok, name
        passed.append(name)
    check('UDP/443 blanket block not restored', not re.search(r'RouteRule\([^\n]*network[^\n]*udp[^\n]*port[^\n]*443[^\n]*outbound\s*=\s*"block"', config))
    check('Kotlin UDP/443 regression retained for both IPv6 modes', 'udp443 is never blanket-blocked' in text(TEST) and 'for (ipv6 in listOf(true, false))' in text(TEST))
    check('Engine lifecycle remains serialized', 'private val lifecycle = Mutex()' in engine and engine.count('lifecycle.withLock {') == 2)
    check('Teardown remains non-cancellable', 'withContext(NonCancellable + Dispatchers.IO)' in engine)
    check('Original TUN descriptor remains owned', 'return fd.getFd()' in engine and 'return fd.detachFd()' not in engine)
    check('TUN descriptor is explicitly released', 'tunFd.getAndSet(null)?.let' in engine and 'runCatching { fd.close() }' in engine)
    check('Full configuration never restored to logcat', 'Starting with config:' not in engine and not re.search(r'Log\.[a-z]\([^\n]*session\.configJson', engine))
    check('Real route ranges retained for both families', all(x in engine for x in ['options.getInet4RouteRange()', 'options.getInet6RouteRange()']))
    check('Physical-network routing and socket protection retained', 'vpnService.protect(fd)' in engine and 'NET_CAPABILITY_NOT_VPN' in engine and 'setFlags(computeFlags(nif))' in engine)
    check('Tunnel owns cleanup in finally', bool(re.search(r'finally\s*\{\s*//[^\n]*\n\s*//[^\n]*\n\s*runCatching \{ engine.stop\(\) \}', service)))
    check('Startup and collector have structured failure propagation', 'coroutineScope {' in service)
    check('Only cancellation is rethrown from engine failure handler', 'if (error is kotlinx.coroutines.CancellationException) throw error' in service and not re.search(r'^\s*throw error\s*$', service, re.M))
    check('Destroyed service cancels its entire scope', 'scope.cancel()' in service)
    check('Obsolete navigation host is not included', not (root / 'app/src/main/kotlin/dev/kentra/app/CyrusNavHost.kt').exists())
    check('Version distinguishes merged install', 'versionName = "0.5.0-dev"' in text('app/build.gradle.kts') and 'versionCode = 7' in text('app/build.gradle.kts'))
    check('Native build uses pinned compatible invocation', all(s in text('build-libbox.sh') for s in ['92d245ad040cbda2f84b21c2a847a470e532c179', "GOMOBILE_VERSION='v0.1.4'", 'gomobile/cmd/gomobile@', 'go run ./cmd/internal/build_libbox -target android -platform']) and not re.search(r'^go run .* -tags', text('build-libbox.sh'), re.M))
    return passed

if __name__ == '__main__':
    passed = validate()
    for name in passed:
        print('PASS', name)
    print(f'{len(passed)} merge source guards passed; runtime NOT tested.')
