#!/usr/bin/env bash
# CI only. Uses the same pinned core, does not connect to any fixture endpoint.
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
command -v go >/dev/null
WORK="$(mktemp -d)"
trap 'rm -rf -- "$WORK"' EXIT
REF='92d245ad040cbda2f84b21c2a847a470e532c179'
git init -q "$WORK/core"
git -C "$WORK/core" remote add origin https://github.com/SagerNet/sing-box.git
git -C "$WORK/core" fetch --depth 1 origin "$REF"
git -C "$WORK/core" checkout --detach FETCH_HEAD
test "$(git -C "$WORK/core" rev-parse HEAD)" = "$REF"
(cd "$WORK/core" && go build -tags with_quic,with_utls,with_gvisor,with_grpc -o "$WORK/sing-box" ./cmd/sing-box)
shopt -s nullglob
configs=("$ROOT"/vpn/config/build/native-fixtures/*.json)
test "${#configs[@]}" -ge 12
for config in "${configs[@]}"; do "$WORK/sing-box" check -c "$config"; done
scripts=("$ROOT"/vpn/config/build/server-script-fixtures/*.sh)
test "${#scripts[@]}" -eq 5
for script in "${scripts[@]}"; do bash -n "$script"; done
echo 'Native config syntax and generated shell syntax passed. No Android or server connectivity test.'
