$ErrorActionPreference = "Stop"
Push-Location $PSScriptRoot
try {
    if (-not (Get-Command gradle -ErrorAction SilentlyContinue)) {
        throw "Install Gradle 8.11.1 and JDK 17 first."
    }
    python tools/check_source.py
    if ($LASTEXITCODE -ne 0) { throw "Source checks failed" }
    python tools/check_native.py
    if ($LASTEXITCODE -ne 0) { throw "Provide exactly one compatible libbox AAR. See README.md." }
    gradle --no-daemon --stacktrace test :app:lintDebug :app:assembleDebug
    if ($LASTEXITCODE -ne 0) { throw "Android build or tests failed" }
} finally {
    Pop-Location
}
