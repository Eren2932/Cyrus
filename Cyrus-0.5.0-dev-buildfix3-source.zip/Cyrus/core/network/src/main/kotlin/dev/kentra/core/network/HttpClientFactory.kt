package dev.kentra.core.network

import io.ktor.client.HttpClient
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.HttpRequestRetry
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.plugins.defaultRequest
import io.ktor.client.request.header
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.json.Json

data class ApiConfig(
    /** Replace with your control-plane host. Must be HTTPS in release builds. */
    val baseUrl: String = "",
    val userAgent: String = "Cyrus/0.5.0-dev (Android)",
)

object HttpClientFactory {

    val json = Json {
        ignoreUnknownKeys = true
        explicitNulls = false
        isLenient = true
    }

    fun create(config: ApiConfig = ApiConfig()): HttpClient = HttpClient(OkHttp) {
        expectSuccess = true
        followRedirects = false // Never follow subscription redirects to HTTP or a different host.

        install(ContentNegotiation) { json(json) }

        install(HttpTimeout) {
            requestTimeoutMillis = 20_000
            connectTimeoutMillis = 10_000
            socketTimeoutMillis = 20_000
        }

        install(HttpRequestRetry) {
            maxRetries = 2
            retryOnServerErrors(maxRetries = 2)
            exponentialDelay()
        }

        defaultRequest {
            header("User-Agent", config.userAgent)
        }

        // No Authorization header is attached to arbitrary subscription hosts.
    }
}
