#!/usr/bin/env bash
# Same pinned toolchain as Eren2932/Cyrus .github/workflows/build.yml.
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SING_BOX_REF='92d245ad040cbda2f84b21c2a847a470e532c179'
GOMOBILE_VERSION='v0.1.4'
NATIVE_PLATFORMS='android/arm,android/arm64,android/amd64'
for tool in go git java; do
  command -v "$tool" >/dev/null || { echo "Missing tool: $tool" >&2; exit 1; }
done
: "${ANDROID_HOME:?Set ANDROID_HOME to the Android SDK directory}"
: "${ANDROID_NDK_HOME:?Set ANDROID_NDK_HOME to NDK 28.0.13004108}"
WORK="$(mktemp -d "${TMPDIR:-/tmp}/cyrus-libbox.XXXXXXXX")"
trap 'rm -rf -- "$WORK"' EXIT
mkdir -p "$ROOT/vpn/service/libs"
if find "$ROOT/vpn/service/libs" -maxdepth 1 -name '*.aar' -print -quit | grep -q .; then
  echo 'An AAR already exists. Back it up and remove it explicitly before rebuilding.' >&2
  exit 1
fi
git init -q "$WORK/source"
git -C "$WORK/source" remote add origin https://github.com/SagerNet/sing-box.git
git -C "$WORK/source" fetch --depth 1 origin "$SING_BOX_REF"
git -C "$WORK/source" checkout --detach FETCH_HEAD
test "$(git -C "$WORK/source" rev-parse HEAD)" = "$SING_BOX_REF"
export GOBIN="$WORK/bin"
export PATH="$GOBIN:$PATH"
export GOMAXPROCS="${GOMAXPROCS:-2}"
export GOFLAGS="${GOFLAGS:--p=2}"
cd "$WORK/source"
go install "github.com/sagernet/gomobile/cmd/gomobile@$GOMOBILE_VERSION"
go install "github.com/sagernet/gomobile/cmd/gobind@$GOMOBILE_VERSION"
# v1.11.1 build_libbox does not accept -tags; it chooses its own native tags.
go run ./cmd/internal/build_libbox -target android -platform "$NATIVE_PLATFORMS"
test -s libbox.aar
cp libbox.aar "$ROOT/vpn/service/libs/libbox.aar"
echo 'Built vpn/service/libs/libbox.aar; run python3 tools/check_native.py next.'
