# Cyrus 0.5.0-dev — buildfix3

Исправлено падение `:app:lintDebug`. Присланный лог подтвердил: компиляция debug/release и все unit-тесты 16 модулей проходят, сборку валили две lint-ошибки при `abortOnError = true`.

1. `NewApi` — `android:forceDarkAllowed` (API 29) в `values/themes.xml` при `minSdk 24`. Атрибут перенесён в новый `values-v29/themes.xml` без подавления lint и без потери поведения.
2. `ProduceStateDoesNotAssignValue` — `CyrusWallpaper.kt`. Декодирование обоев переведено на `remember` + `LaunchedEffect` с той же семантикой; декодирование осталось вне UI-потока.

Дополнительно lint теперь печатает полный отчёт в консоль CI (`textReport`, `textOutput = stdout`), поэтому следующий сбой, если он будет, покажет сразу все ошибки.

**Исходники, не готовый APK. Kotlin-компиляция, JUnit, lint, native validation и APK здесь НЕ выполнялись; локально проходят source guards и их мутационные тесты.**

Отчёт: [docs/BUILD_FIX_0.5.0_3.md](docs/BUILD_FIX_0.5.0_3.md).

Загрузите `Cyrus-0.5.0-dev-buildfix3-source.zip` в корень Eren2932/Cyrus без распаковки. Установленный workflow менять не требуется. Для ручного запуска укажите новое имя ZIP в поле archive; не нажимайте Re-run старого запуска.

О клиенте и ограничениях: [docs/UPGRADE_0.5.0.md](docs/UPGRADE_0.5.0.md). Предыдущие исправления: [docs/BUILD_FIX_0.5.0_2.md](docs/BUILD_FIX_0.5.0_2.md), [docs/BUILD_FIX_0.5.0.md](docs/BUILD_FIX_0.5.0.md).

Версия Android сохранена: 0.5.0-dev / code 7; applicationId dev.kentra.app. Не удаляйте установленный клиент без экспорта ключей при несовпадении подписи.
