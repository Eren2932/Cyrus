# Проверки buildfix2

Текущий отчёт: [BUILD_FIX_0.5.0_2.md](BUILD_FIX_0.5.0_2.md).

Source checks проходят. 17 buildfix guards и 16 мутационных случаев пройдены. 57 JUnit-тестов vpn:link существуют в исходниках, но здесь не запускались.

Подтверждено пользовательским CI только для buildfix1: компиляция debug/release прошла, 1 из 51 теста vpn:link упал на устаревшем ожидании HTTPS rejection. Лог не подтверждает успешный lint/native validation/APK.

Для нового buildfix2 Kotlin/Gradle/JUnit/lint/native/APK/device validation НЕ выполнялась. Текущий журнал: validation/source-checks.txt.

# Проверки buildfix3

Текущий отчёт: [BUILD_FIX_0.5.0_3.md](BUILD_FIX_0.5.0_3.md).

Присланный лог CI по buildfix2 подтверждает: компиляция debug и release прошла, `test` прошёл во всех 16 модулях. Сборку остановил `:app:lintDebug` — 2 ошибки, 43 предупреждения, `abortOnError = true`. Обе ошибки исправлены в исходниках, обе закрыты guards.

Локально проходят source/design/merge/upgrade suites, 27 buildfix source checks и 23 мутационных случая. Kotlin/Gradle-компиляция, JUnit, lint, native validation и APK для buildfix3 НЕ запускались. Текущий журнал: validation/source-checks.txt, validation/build-status.txt.
