# Cyrus 0.5.0-dev — buildfix3

## Основа

Архив подготовлен поверх `Cyrus-0.5.0-dev-buildfix2-source.zip`, SHA-256 `50b3717201c31be1ba5b0a508b1a82bdf98e8999558861537e196f8f5077ad6f`.

## Что показал присланный лог

Запуск дошёл дальше всех предыдущих. Подтверждено логом:

- `:app:compileDebugKotlin` и `:app:compileReleaseKotlin` — успех;
- `test` по всем 16 модулям — успех, включая `:vpn:link:test` и `:vpn:service:test`. Исправление buildfix2 тестового контракта HTTPS подтверждено реальным прогоном;
- падение произошло на `:app:lintDebug`: `Lint found 2 errors, 43 warnings`, `abortOnError = true` → `BUILD FAILED`.

В консоль Gradle выводит только первую ошибку. Обе взяты из `Cyrus-reports-23.zip`, файл `app/build/reports/lint-results-debug.xml`, AGP 8.7.3, проверка от 2026-09-18 13:13:51 UTC.

## Ошибка 1 — NewApi, `app/src/main/res/values/themes.xml:3`

`android:forceDarkAllowed` существует с API 29, а `minSdk` проекта — 24.

Атрибут не удалён и не подавлен. Стили не сливаются между квалификаторами ресурсов, поэтому создан `app/src/main/res/values-v29/themes.xml`, где стиль `Theme.Cyrus` повторяет все три базовых item и добавляет четвёртым отказ от force dark. На API 24..28 применяется базовый стиль, на API 29+ — v29. Поведение продукта не изменилось: системная инверсия по-прежнему отключена там, где она вообще существует, а камуфляжная палитра не выворачивается.

## Ошибка 2 — ProduceStateDoesNotAssignValue, `app/src/main/kotlin/dev/kentra/app/CyrusWallpaper.kt:26`

Проверка Compose-runtime забраковала форму `value = withContext(...) { ... }` внутри лямбды-продюсера: анализатор не признал присваивание и счёл, что State никогда не обновится.

Декодирование переписано на `var decoded by remember { mutableStateOf<Pair<Int, ImageBitmap>?>(null) }` плюс `LaunchedEffect(resource, preview)`. Семантика идентична прежней: начальное значение `null`, предыдущий bitmap переживает смену ключей, загрузчик перезапускается при смене темы или preview-режима. Декодирование по-прежнему уходит с UI-потока через `withContext(Dispatchers.IO)`, а защита от показа чужого bitmap (`it.first == resource`) сохранена. Подавления lint не добавлялись.

## Видимость будущих ошибок lint

В `app/build.gradle.kts` добавлены `textReport = true` и `textOutput = file("stdout")`. `abortOnError = true` сохранён. Теперь один прогон печатает в лог CI все ошибки lint сразу, а не только первую — артефакт с отчётом больше не нужен для диагностики.

## Новые guards

`tools/check_buildfix.py` вырос с 17 до 27 проверок:

- атрибут API 29 отсутствует в неквалифицированном `values/`;
- он присутствует в `values-v29/`;
- v29-стиль повторяет каждый базовый item и добавляет ровно один свой;
- оба варианта сохраняют один и тот же parent;
- в обоях нет забракованной формы продюсера состояния;
- состояние обоев именно remembered + заполняется эффектом;
- декодирование остаётся вне главного потока;
- lint по-прежнему валит сборку на ошибках;
- lint печатает полный отчёт в консоль.

`tools/check_design.py` теперь требует отказ от force dark в `values-v29` и запрещает его в `values/`. `tools/test_buildfix_guard.py` вырос с 16 до 23 мутационных случаев; каждая новая проверка доказана мутацией, которую она обязана отвергнуть.

## Что НЕ проверено здесь

Kotlin/Gradle-компиляция, JUnit, Android lint, native schema validation, сборка APK и устройство. Локально выполнены только source guards и их мутационные тесты. Успех компиляции и тестов — это результат присланного CI-запуска по buildfix2, а не по этому архиву.

Правки затрагивают один XML-ресурс, один Compose-файл, DSL lint и три файла guards. Kotlin-сигнатуры, модули, версии и ядро VPN не менялись.
