package dev.kentra.domain.usecase

import dev.kentra.core.common.AppError
import dev.kentra.core.common.appRunCatching
import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.model.connectionIdentity
import dev.kentra.domain.model.TunnelState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import dev.kentra.domain.repository.LinkParser
import dev.kentra.domain.repository.ProfileRepository
import dev.kentra.domain.repository.TunnelController

class ImportKeysUseCase(
    private val parser: LinkParser,
    private val profiles: ProfileRepository,
) {
    private val mutex = Mutex()
    /** @return number of imported profiles, or [AppError.Parse] when nothing was recognised. */
    suspend operator fun invoke(payload: String): Result<Int> = appRunCatching {
        mutex.withLock {
            val parsed = withContext(Dispatchers.Default) { parser.parseMany(payload) }
            if (parsed.isEmpty()) throw AppError.Parse("Не найдено корректных ключей")
            val existing = profiles.observeProfiles().first().map { it.connectionIdentity() }.toSet()
            val fresh = parsed.distinctBy { it.connectionIdentity() }.filterNot { it.connectionIdentity() in existing }
            profiles.upsertAll(fresh)
            if (profiles.observeActiveProfileId().first() == null && fresh.isNotEmpty()) profiles.setActiveProfileId(fresh.first().id)
            fresh.size
        }
    }
}

class ConnectUseCase(
    private val profiles: ProfileRepository,
    private val tunnel: TunnelController,
) {
    suspend operator fun invoke(profileId: String): Result<Unit> = appRunCatching {
        val profile = profiles.getProfile(profileId) ?: throw AppError.NotFound("profile $profileId")
        tunnel.connect(profile)
        profiles.setActiveProfileId(profileId)
    }
}

class DisconnectUseCase(private val tunnel: TunnelController) {
    suspend operator fun invoke(): Result<Unit> = appRunCatching { tunnel.disconnect() }
}

class DeleteProfileUseCase(
    private val profiles: ProfileRepository,
    private val tunnel: TunnelController,
) {
    suspend operator fun invoke(profile: VpnProfile): Result<Unit> = appRunCatching {
        val state = tunnel.state.value
        if ((state is TunnelState.Connected && state.profileId == profile.id) || state is TunnelState.Preparing) tunnel.disconnect()
        profiles.delete(profile.id)
    }
}
