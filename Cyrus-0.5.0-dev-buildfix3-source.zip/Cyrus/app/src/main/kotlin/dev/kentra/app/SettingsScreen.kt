package dev.kentra.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import dev.kentra.core.datastore.*
import dev.kentra.core.designsystem.*
import dev.kentra.vpn.config.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(appearance: AppearanceSettings, settings: SettingsStore) {
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val stored by settings.tunnelOptions.collectAsState(initial = null)
    var wizard by remember { mutableStateOf(false) }
    BackHandler(enabled = wizard) { wizard = false }
    if (wizard) { ServerWizardScreen(onBack = { wizard = false }); return }
    fun save(action: suspend () -> Unit) {
        scope.launch {
            try { action() } catch (e: Exception) {
                if (e is CancellationException) throw e
                snackbar.showSnackbar("Не удалось сохранить: ${e.message ?: "проверьте параметры"}")
            }
        }
    }
    Scaffold(containerColor = androidx.compose.ui.graphics.Color.Transparent, contentColor = MaterialTheme.colorScheme.onBackground,
        contentWindowInsets = WindowInsets(0, 0, 0, 0), snackbarHost = { SnackbarHost(snackbar) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)) {
            CyrusCard {
                Text("Тема", style = MaterialTheme.typography.titleMedium)
                val modes = ThemeMode.entries
                CyrusSegmented(labels = listOf("Система", "Тёмная", "Светлая"), selectedIndex = modes.indexOf(appearance.theme),
                    onSelect = { save { settings.setTheme(modes[it]) } })
            }
            stored?.let { options -> NetworkSettings(options) { updated -> save {
                settings.setTunnelOptions(updated)
                snackbar.showSnackbar("Сохранено. Настройки применятся при следующем подключении; перед сменой VPN/прокси отключитесь.")
            } } } ?: Text("Чтение настроек…")
            CyrusCard {
                Text("Свой сервер", style = MaterialTheme.typography.titleMedium)
                Text("Мастер конфигурации sing-box и команд для Linux VPS. Ничего не выполняет на сервере автоматически.")
                OutlinedButton(onClick = { wizard = true }) { Text("Настроить протокол на VPS") }
            }
        }
    }
}

@Composable
private fun NetworkSettings(initial: TunnelOptions, onSave: (TunnelOptions) -> Unit) {
    var mode by remember(initial) { mutableStateOf(initial.mode) }
    var port by remember(initial) { mutableStateOf(initial.proxyPort.toString()) }
    var mtu by remember(initial) { mutableStateOf(initial.mtu.toString()) }
    var stack by remember(initial) { mutableStateOf(initial.stack) }
    var ipv6 by remember(initial) { mutableStateOf(initial.ipv6) }
    var bypass by remember(initial) { mutableStateOf(initial.bypassLan) }
    var ads by remember(initial) { mutableStateOf(initial.blockAds) }
    var mux by remember(initial) { mutableStateOf(initial.enableMultiplex) }
    var dns by remember(initial) { mutableStateOf(initial.dnsRemote) }
    var localDns by remember(initial) { mutableStateOf(initial.dnsLocal) }
    var log by remember(initial) { mutableStateOf(initial.logLevel) }
    var appMode by remember(initial) { mutableIntStateOf(when(initial.perAppMode) { is PerAppMode.Include -> 1; is PerAppMode.Exclude -> 2; else -> 0 }) }
    var packages by remember(initial) { mutableStateOf(when(val p = initial.perAppMode) { is PerAppMode.Include -> p.packages; is PerAppMode.Exclude -> p.packages; else -> emptyList() }.joinToString("\n")) }
    var error by remember { mutableStateOf<String?>(null) }
    CyrusCard {
        Text("Режим подключения", style = MaterialTheme.typography.titleMedium)
        CyrusSegmented(listOf("VPN", "Прокси"), if (mode == ConnectionMode.VPN) 0 else 1, onSelect = {
            mode = if (it == 0) ConnectionMode.VPN else ConnectionMode.PROXY
        })
        Text(if (mode == ConnectionMode.VPN) "Системный VPN через TUN. Требует согласия Android."
            else "HTTP CONNECT и SOCKS5 на 127.0.0.1. Укажите адрес и порт в нужном приложении. Системный трафик не перехватывается; UDP у HTTP-прокси отсутствует.")
        if (mode == ConnectionMode.PROXY) {
            SettingsField("Локальный порт (1024–65535)", port) { port = it }
            Text("Доступ только с этого устройства, без авторизации. Другие локальные приложения тоже могут использовать этот порт.")
        } else {
            SettingsField("MTU (1280–9000)", mtu) { mtu = it }
            Text("TUN stack")
            val stacks = listOf("system", "gvisor", "mixed")
            CyrusSegmented(stacks, stacks.indexOf(stack).coerceAtLeast(0), onSelect = { stack = stacks[it] })
        }
        SettingSwitch("IPv6 в туннеле", ipv6) { ipv6 = it }
        SettingSwitch("Локальная сеть напрямую", bypass) { bypass = it }
        SettingSwitch("Блокировать рекламу (загрузка rule-set)", ads) { ads = it }
        SettingSwitch("Multiplex (только совместимые серверы)", mux) { mux = it }
        Text("Multiplex не нужен для Vision, Hysteria2 и TUIC. Сервер должен поддерживать выбранный режим.", style = MaterialTheme.typography.labelSmall)
    }
    CyrusCard {
        Text("DNS и журнал", style = MaterialTheme.typography.titleMedium)
        SettingsField("Удалённый DNS", dns) { dns = it }
        SettingsField("DNS для прямых запросов", localDns) { localDns = it }
        Text("Например tls://1.1.1.1 и local. DNS для имени сервера использует прямое соединение. Содержимое ключей в журнал не выводится.")
        val levels = listOf("warn", "error", "fatal")
        CyrusSegmented(levels, levels.indexOf(log).coerceAtLeast(0), onSelect = { log = levels[it] })
    }
    if (mode == ConnectionMode.VPN) CyrusCard {
        Text("Приложения в VPN", style = MaterialTheme.typography.titleMedium)
        CyrusSegmented(listOf("Все", "Только", "Кроме"), appMode, onSelect = { appMode = it })
        if (appMode != 0) {
            OutlinedTextField(packages, { packages = it }, modifier = Modifier.fillMaxWidth(), minLines = 3,
                label = { Text("Package IDs, по одному в строке") })
            Text("Например org.mozilla.firefox. Указывайте только установленные приложения; неверный ID может помешать запуску VPN.")
        }
    }
    error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    Button(onClick = {
        val updated = initial.copy(mode = mode, proxyPort = port.toIntOrNull() ?: 0, mtu = mtu.toIntOrNull() ?: 0,
            stack = stack, ipv6 = ipv6, bypassLan = bypass, blockAds = ads, enableMultiplex = mux,
            dnsRemote = dns.trim(), dnsLocal = localDns.trim(), logLevel = log,
            perAppMode = if (mode == ConnectionMode.PROXY || appMode == 0) PerAppMode.Off else {
                val list = packages.lines().map { it.trim() }.filter { it.isNotEmpty() }.distinct()
                if (appMode == 1) PerAppMode.Include(list) else PerAppMode.Exclude(list)
            })
        error = runCatching { updated.validate() }.exceptionOrNull()?.message
        if (error == null) onSave(updated)
    }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить сетевые настройки") }
}

@Composable
private fun SettingsField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(value, onChange, label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth())
}
@Composable
private fun SettingSwitch(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f)); Switch(value, onChange)
    }
}
