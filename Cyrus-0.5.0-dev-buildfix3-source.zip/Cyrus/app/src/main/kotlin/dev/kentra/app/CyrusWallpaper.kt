package dev.kentra.app

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Pre-toned camo assets: no alpha stacking or second scrim that crushes blacks.
 * The dark asset is bounded to neutral RGB 22..48; text is tested against its
 * brightest pixel, light-theme text against the light asset's darkest pixel.
 */
@Composable
fun CyrusWallpaper(dark: Boolean, modifier: Modifier = Modifier, preview: Boolean = false) {
    val resources = LocalContext.current.resources
    val resource = if (dark) R.drawable.wallpaper_camo else R.drawable.wallpaper_camo_light
    // remember + LaunchedEffect instead of the Compose state-producer helper: identical
    // semantics (the previous bitmap survives a key change, the loader restarts), and the
    // assignment shape the Compose runtime lint check rejects is gone for good.
    var decoded by remember { mutableStateOf<Pair<Int, ImageBitmap>?>(null) }
    LaunchedEffect(resource, preview) {
        val bitmap = withContext(Dispatchers.IO) {
            BitmapFactory.decodeResource(resources, resource, BitmapFactory.Options().apply {
                inSampleSize = if (preview) 4 else 1
            })?.asImageBitmap()
        }
        decoded = bitmap?.let { resource to it }
    }
    Box(modifier.background(MaterialTheme.colorScheme.background)) {
        // Do not display the previous theme's bitmap during asynchronous decoding.
        decoded?.takeIf { it.first == resource }?.second?.let { image ->
            Image(image, contentDescription = null, modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop)
        }
    }
}
