package dev.kentra.app

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.ContextWrapper
import android.os.PersistableBundle
import android.view.WindowManager
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.SecureFlagPolicy
import dev.kentra.core.designsystem.*
import dev.kentra.vpn.config.*
import java.security.SecureRandom
import java.util.Base64
import java.util.UUID

@Composable
fun ServerWizardScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val activity = remember(context) { generateSequence(context) { (it as? ContextWrapper)?.baseContext }.filterIsInstance<Activity>().firstOrNull() }
    DisposableEffect(activity) {
        val wasSecure = activity?.window?.attributes?.flags?.and(WindowManager.LayoutParams.FLAG_SECURE) != 0
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { if (!wasSecure) activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
    }
    var protocol by remember { mutableStateOf(ServerProtocol.VLESS_TLS) }
    var version by remember { mutableStateOf("") }
    var arch by remember { mutableStateOf("amd64") }
    var hash by remember { mutableStateOf("") }
    var port by remember { mutableStateOf("443") }
    var uuid by remember { mutableStateOf(UUID.randomUUID().toString()) }
    fun newPassword(): String = Base64.getUrlEncoder().withoutPadding().encodeToString(ByteArray(32).also { SecureRandom().nextBytes(it) })
    var password by remember { mutableStateOf(newPassword()) }
    var certificate by remember { mutableStateOf("/etc/ssl/cyrus/fullchain.pem") }
    var key by remember { mutableStateOf("/etc/ssl/cyrus/privkey.pem") }
    var script by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        TextButton(onClick=onBack) { Text("Назад к настройкам") }
        Text("Мастер своего VPS", style=MaterialTheme.typography.titleLarge)
        Text("Для Linux с systemd, curl, tar и sha256sum. Требует root, свободный порт и, кроме Shadowsocks, заранее выпущенный действительный TLS-сертификат. Команды не запускаются приложением.")
        Text("Используйте отдельный VPS или проверьте настройки сервера вручную. Мастер не меняет firewall, не выпускает сертификаты и не обновляет существующие установки.")
        ServerProtocol.entries.forEach { p ->
            FilterChip(protocol==p,onClick={protocol=p},label={Text(when(p){ServerProtocol.VLESS_TLS->"VLESS + TLS (TCP, без Reality)";else->p.name})})
        }
        WizardField("Версия sing-box X.Y.Z",version) { version=it.trim() }
        Text("Выберите поддерживаемый официальный релиз SagerNet/sing-box и его контрольную сумму. Мастер не гарантирует безопасность устаревших версий и не подставляет случайный latest.",style=MaterialTheme.typography.labelSmall)
        CyrusSegmented(listOf("amd64", "arm64"),if(arch=="amd64") 0 else 1,onSelect={arch=if(it==0) "amd64" else "arm64"})
        WizardField("SHA-256 Linux tar.gz выбранной архитектуры",hash) { hash=it.trim() }
        WizardField("Порт сервера",port) { port=it }
        WizardField("UUID клиента",uuid,true) { uuid=it }
        WizardField("Пароль клиента",password,true) { password=it }
        OutlinedButton(onClick={uuid=UUID.randomUUID().toString();password=newPassword()}) { Text("Новые UUID и пароль") }
        if(protocol!=ServerProtocol.SHADOWSOCKS) {
            WizardField("Полный путь fullchain.pem",certificate) { certificate=it }
            WizardField("Полный путь privkey.pem",key) { key=it }
            Text("Клиенту потребуются домен сервера/SNI, порт, UUID или пароль выше. Не включайте insecure вместо установки правильного сертификата.")
        }
        Text("Hysteria2/TUIC используют UDP; Shadowsocks в этом мастере — chacha20-ietf-poly1305. Для Reality/XHTTP и существующих панелей пока используйте их собственную установку.")
        error?.let { Text(it,color=MaterialTheme.colorScheme.error) }
        Button(onClick={
            val result=runCatching { ServerSetup.script(ServerSetupOptions(protocol,version,arch,hash,port.toIntOrNull() ?: 0,uuid,password,certificate,key)) }
            result.onSuccess { script=it;error=null }.onFailure { error=it.message ?: "Проверьте поля" }
        }) { Text("Подготовить команды") }
    }
    script?.let { text ->
        AlertDialog(onDismissRequest={script=null},properties=DialogProperties(securePolicy=SecureFlagPolicy.SecureOn),
            title={Text("Команды содержат секреты")},text={Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Сначала прочитайте команды. Они загрузят бинарник с GitHub, сверят SHA-256 и создадут отдельную службу cyrus-proxy. Существующие файлы не перезаписываются.")
                OutlinedTextField(text,{},readOnly=true,minLines=8,maxLines=16)
            }},confirmButton={TextButton(onClick={
                val clip=ClipData.newPlainText("Cyrus server setup · secret",text)
                clip.description.extras=PersistableBundle().apply { putBoolean("android.content.extra.IS_SENSITIVE",true) }
                (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(clip)
                script=null
            }) { Text("Копировать команды") }},dismissButton={TextButton(onClick={script=null}) { Text("Закрыть") }})
    }
}

@Composable
private fun WizardField(label:String,value:String,secret:Boolean=false,onChange:(String)->Unit) {
    OutlinedTextField(value,onChange,label={Text(label)},modifier=Modifier.fillMaxWidth(),singleLine=true,
        visualTransformation=if(secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None)
}
