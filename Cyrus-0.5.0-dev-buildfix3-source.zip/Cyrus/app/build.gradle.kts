plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.compose.compiler)
}

android {
    namespace = "dev.kentra.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "dev.kentra.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 7
        versionName = "0.5.0-dev"
        resourceConfigurations += setOf("ru", "en")
    }

    // Per-ABI APKs: a user downloads one architecture instead of four.
    // This is the single biggest win for install size once the Go core lands.
    splits {
        abi {
            isEnable = true
            reset()
            include("arm64-v8a", "armeabi-v7a", "x86_64")
            isUniversalApk = true
        }
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // Release signing must be configured by the distributor; never use the debug key.
        }
    }

    compileOptions {
        isCoreLibraryDesugaringEnabled = true
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildFeatures { compose = true }

    packaging {
        resources {
            excludes += setOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "/META-INF/*.version",
                "DebugProbesKt.bin",
                "kotlin-tooling-metadata.json",
            )
        }
    }

    lint {
        abortOnError = true
        // CI prints only the first failure otherwise; one run must reveal every error.
        textReport = true
        textOutput = file("stdout")
    }
}

dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")
    implementation(project(":core:ui"))
    implementation(project(":core:designsystem"))
    implementation(project(":core:datastore"))
    implementation(project(":domain"))
    implementation(project(":data"))
    implementation(project(":vpn:service"))
    implementation(project(":vpn:config"))
    implementation(project(":feature:home"))
    implementation(project(":feature:profiles"))
    implementation(project(":feature:store"))
    
    // Libbox AAR must be bundled into the app
    implementation(fileTree(mapOf("dir" to "../vpn/service/libs", "include" to listOf("*.aar"))))

    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.material3)
    implementation(libs.koin.android)
    implementation(libs.koin.compose)
    debugImplementation(libs.compose.ui.tooling)
}
