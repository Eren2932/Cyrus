package dev.kentra.feature.profiles

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.PersistableBundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.SecureFlagPolicy
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.kentra.core.designsystem.*
import dev.kentra.core.ui.CollectEffects
import dev.kentra.domain.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.koin.androidx.compose.koinViewModel
import java.io.ByteArrayOutputStream
import java.text.DateFormat
import java.util.Date
import android.content.Intent
import dev.kentra.domain.repository.LinkParser
import dev.kentra.vpn.config.ConfigFactory
import org.koin.compose.koinInject
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfilesRoute(viewModel: ProfilesViewModel = koinViewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val parser: LinkParser = koinInject()
    val configFactory = remember { ConfigFactory() }
    val incompatibilities = remember(state.profiles) {
        state.profiles.associate { it.id to runCatching { configFactory.validateProfile(it) }.exceptionOrNull()?.message }
    }
    var shareTarget by remember { mutableStateOf<String?>(null) }
    var editTarget by remember { mutableStateOf<VpnProfile?>(null) }
    var detailId by remember { mutableStateOf<String?>(null) }
    var deleteTarget by remember { mutableStateOf<VpnProfile?>(null) }
    var sourceTarget by remember { mutableStateOf<SubscriptionSource?>(null) }
    var pendingExport by remember { mutableStateOf<String?>(null) }
    var fileBusy by remember { mutableStateOf(false) }
    fun message(text: String) { scope.launch { snackbar.showSnackbar(text) } }
    fun exportLink(profile: VpnProfile): String? {
        val value = runCatching { parser.export(profile) }.getOrNull()
        if (value == null) message("Не удалось экспортировать этот профиль. Проверьте его параметры.")
        return value
    }

    val scan = rememberLauncherForActivityResult(ScanContract()) { result ->
        result.contents?.let { text ->
            if (text.length <= 65_536) viewModel.dispatch(ProfilesIntent.ImportTextChanged(text))
            else message("QR слишком большой")
        }
    }
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        val text = pendingExport
        pendingExport = null
        if (uri != null && text != null) scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    requireNotNull(context.contentResolver.openOutputStream(uri, "wt")).bufferedWriter().use { it.write(text) }
                }
                snackbar.showSnackbar("Ключ экспортирован. Файл содержит секрет — храните его безопасно.")
            } catch (e: Exception) { if (e is kotlinx.coroutines.CancellationException) throw e; snackbar.showSnackbar("Не удалось записать файл") }
        }
    }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            fileBusy = true
            try {
                val text = withContext(Dispatchers.IO) {
                    requireNotNull(context.contentResolver.openInputStream(uri)).use { input ->
                        val out = ByteArrayOutputStream()
                        val buffer = ByteArray(8192)
                        while (true) {
                            val count = input.read(buffer)
                            if (count < 0) break
                            require(out.size() + count <= 1_048_576)
                            out.write(buffer, 0, count)
                        }
                        out.toString("UTF-8")
                    }
                }
                viewModel.dispatch(ProfilesIntent.ImportTextChanged(text))
            } catch (e: Exception) { if (e is kotlinx.coroutines.CancellationException) throw e; snackbar.showSnackbar("Нужен текстовый UTF-8 файл размером до 1 МиБ") }
            finally { fileBusy = false }
        }
    }
    CollectEffects(viewModel.effects) { if (it is ProfilesEffect.ShowMessage) snackbar.showSnackbar(it.text) }
    val filtered = remember(state.profiles, state.query, state.protocol) {
        state.profiles.filter { p -> (state.protocol == null || p.protocol == state.protocol) &&
            (state.query.isBlank() || p.name.contains(state.query, true) || p.server.contains(state.query, true)) }
    }
    Scaffold(containerColor = Color.Transparent, contentColor = MaterialTheme.colorScheme.onBackground, contentWindowInsets = WindowInsets(0,0,0,0),
        snackbarHost = { SnackbarHost(snackbar) }, floatingActionButton = {
            ExtendedFloatingActionButton(onClick = { viewModel.dispatch(ProfilesIntent.OpenImport) },
                containerColor = CyrusTokens.Accent, contentColor = CyrusTokens.OnAccent,
                icon = { CyrusIcon(CyrusSymbol.Plus, color = CyrusTokens.OnAccent) }, text = { Text("Добавить ключ") })
        }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(start=20.dp,end=20.dp,bottom=100.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                OutlinedTextField(value=state.query, onValueChange={ viewModel.dispatch(ProfilesIntent.QueryChanged(it)) },
                    modifier=Modifier.fillMaxWidth(), singleLine=true, shape=RoundedCornerShape(18.dp),
                    label={ Text("Поиск по имени или серверу") })
            }
            item {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected=state.protocol==null, onClick={viewModel.dispatch(ProfilesIntent.Filter(null))}, label={Text("Все · ${state.profiles.size}")})
                    state.profiles.map { it.protocol }.distinct().forEach { protocol ->
                        FilterChip(selected=state.protocol==protocol, onClick={viewModel.dispatch(ProfilesIntent.Filter(protocol))},label={Text(protocol.name)})
                    }
                }
            }
            if (state.profiles.isEmpty()) item {
                CyrusCard {
                    CyrusIcon(CyrusSymbol.Key, Modifier.size(32.dp), CyrusTokens.Accent)
                    Text("Нет ключей", style=MaterialTheme.typography.titleLarge)
                    Text("VLESS, VMess, Trojan, Shadowsocks, Hysteria2, TUIC, HTTP и SOCKS. Вставьте список, Xray JSON, откройте файл, QR или HTTPS-подписку.",style=MaterialTheme.typography.bodyMedium)
                }
            } else if (filtered.isEmpty()) item { Text("Ничего не найдено. Измените запрос или фильтр.") }
            items(filtered, key={it.id}) { profile ->
                CyrusCard(highlighted=profile.id==state.activeProfileId) {
                    Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                        RadioButton(selected=profile.id==state.activeProfileId, onClick={viewModel.dispatch(ProfilesIntent.Select(profile.id))}, enabled=!state.busy)
                        Column(Modifier.weight(1f).clickable { detailId=profile.id }) {
                            Text(profile.name,style=MaterialTheme.typography.titleMedium,maxLines=1,overflow=TextOverflow.Ellipsis)
                            Text("${profile.protocol.name} · ${profile.displayEndpoint}",style=MaterialTheme.typography.labelSmall,
                                color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=1,overflow=TextOverflow.Ellipsis)
                        }
                        IconButton(onClick={detailId=profile.id}) { CyrusIcon(CyrusSymbol.Arrow, Modifier.semanticsLabel("Открыть сведения о ключе")) }
                    }
                    (profile.origin as? ProfileOrigin.Subscription)?.let { origin ->
                        state.sources.firstOrNull { it.id == origin.sourceId }?.let { source -> Text("Подписка: ${source.name}", style=MaterialTheme.typography.labelSmall) }
                    }
                    if ((state.tunnel as? TunnelState.Connected)?.profileId == profile.id) Text("Работает сейчас", style=MaterialTheme.typography.labelSmall)
                    incompatibilities[profile.id]?.let { Text(it, color=MaterialTheme.colorScheme.error, style=MaterialTheme.typography.labelSmall) }
                    if (profile.tls.allowInsecure) Text("Проверка TLS-сертификата отключена в ключе",color=MaterialTheme.colorScheme.error,style=MaterialTheme.typography.labelSmall)
                }
            }
            if (state.sources.isNotEmpty()) {
                item { Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) {
                    Text("Подписки",Modifier.weight(1f),style=MaterialTheme.typography.titleLarge)
                    TextButton(colors=ButtonDefaults.textButtonColors(contentColor=MaterialTheme.colorScheme.onSurface),onClick={viewModel.dispatch(ProfilesIntent.RefreshSubscriptions)},enabled=!state.busy){Text("Обновить все")}
                } }
                items(state.sources,key={"source:${it.id}"}) { source ->
                    CyrusCard {
                        Text(source.name,style=MaterialTheme.typography.titleMedium)
                        Text("${source.profileCount} ключей · ${source.lastSyncEpochMs?.let { DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT).format(Date(it)) } ?: "Без обновлений"}",style=MaterialTheme.typography.labelSmall)
                        source.lastError?.let { Text(it,color=MaterialTheme.colorScheme.error,style=MaterialTheme.typography.labelSmall) }
                        Row {
                            TextButton(colors=ButtonDefaults.textButtonColors(contentColor=MaterialTheme.colorScheme.onSurface),onClick={viewModel.dispatch(ProfilesIntent.RefreshSource(source.id))},enabled=!state.busy){Text("Обновить")}
                            TextButton(colors=ButtonDefaults.textButtonColors(contentColor=MaterialTheme.colorScheme.onSurface),onClick={sourceTarget=source},enabled=!state.busy){Text("Удалить источник")}
                        }
                    }
                }
            }
        }
    }
    if(state.importSheetVisible) ModalBottomSheet(onDismissRequest={viewModel.dispatch(ProfilesIntent.CloseImport)},
        properties = ModalBottomSheetProperties(securePolicy = SecureFlagPolicy.SecureOn),
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        containerColor=MaterialTheme.colorScheme.surface) {
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).imePadding().padding(horizontal=20.dp).padding(bottom=28.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
            Text("Добавить ключ",style=MaterialTheme.typography.titleLarge)
            CyrusSegmented(listOf("Ключи / JSON", "Подписка"), if (state.asSubscription) 1 else 0,
                onSelect = { viewModel.dispatch(ProfilesIntent.SubscriptionMode(it == 1)) })
            Text("Для HTTPS-подписки выберите «Подписка». Для HTTP/SOCKS-ключа — «Ключи / JSON».",style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedTextField(value=state.importText,onValueChange={viewModel.dispatch(ProfilesIntent.ImportTextChanged(it))},
                enabled=!state.busy && !fileBusy,modifier=Modifier.fillMaxWidth(),minLines=4,maxLines=7,
                label={Text("Ключ, Base64-список или HTTPS-ссылка")},shape=RoundedCornerShape(16.dp))
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                OutlinedButton(colors=ButtonDefaults.outlinedButtonColors(contentColor=MaterialTheme.colorScheme.onSurface),onClick={
                    val manager=context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val clip=manager.primaryClip
                    if(clip!=null && clip.itemCount>0) viewModel.dispatch(ProfilesIntent.ImportTextChanged(clip.getItemAt(0).coerceToText(context).toString()))
                    else message("Буфер обмена пуст")
                },enabled=!state.busy && !fileBusy){Text("Вставить")}
                OutlinedButton(colors=ButtonDefaults.outlinedButtonColors(contentColor=MaterialTheme.colorScheme.onSurface),onClick={filePicker.launch(arrayOf("text/*","application/octet-stream"))},enabled=!state.busy && !fileBusy){Text(if(fileBusy) "Читаем…" else "Из файла")}
            }
            OutlinedButton(onClick = {
                scan.launch(ScanOptions().setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                    .setPrompt("Наведите камеру на QR ключа или подписки")
                    .setBeepEnabled(false).setBarcodeImageEnabled(false).setOrientationLocked(false)
                    .setCaptureActivity(SecureCaptureActivity::class.java))
            }, enabled = !state.busy && !fileBusy) { Text("Сканировать QR-код") }
            Text("Из JSON импортируются только узлы. Правила маршрутизации, DNS и локальные порты чужого приложения не применяются.", style=MaterialTheme.typography.labelSmall)
            val isSubscription=state.asSubscription
            if(isSubscription) Text("Подписка: до 1 МиБ. Только HTTPS; автоматические перенаправления отключены. При ошибке старые ключи останутся на месте.",style=MaterialTheme.typography.labelSmall)
            state.report?.let { report ->
                Text("Готово к импорту: ${report.profiles.size} · Повторы: ${report.duplicates}",style=MaterialTheme.typography.titleMedium)
                if(report.issues.isNotEmpty()) Text("Не будут импортированы: ${report.issues.size}. Добавятся только распознанные ключи.",color=MaterialTheme.colorScheme.error)
                report.issues.take(4).forEach { Text("Строка ${it.line}: ${it.reason}",style=MaterialTheme.typography.labelSmall) }
                if(report.profiles.any { it.parameters.isNotEmpty() }) Text("Исходная ссылка и дополнительные параметры сохраняются без удаления. Совместимость с VPN-ядром проверяется отдельно.",style=MaterialTheme.typography.labelSmall)
            }
            Button(modifier=Modifier.fillMaxWidth().heightIn(min=52.dp),enabled=!state.busy && !fileBusy && state.importText.isNotBlank() &&
                (isSubscription || state.report==null || state.report!!.profiles.isNotEmpty()),onClick={
                    viewModel.dispatch(if(isSubscription || state.report!=null) ProfilesIntent.ConfirmImport else ProfilesIntent.PreviewImport)
                }) { Text(if(state.busy) "Обрабатываем…" else if(isSubscription) "Загрузить подписку" else if(state.report==null) "Проверить ключи" else "Импортировать ${state.report!!.profiles.size}") }
        }
    }
    state.profiles.firstOrNull { it.id==detailId }?.let { profile ->
        ProfileDetails(profile,onDismiss={detailId=null},onRename={viewModel.dispatch(ProfilesIntent.Rename(profile.id,it))},
            onDelete={deleteTarget=profile;detailId=null},onCopy={
                profile.rawLink?.let { _ ->
                    val raw = exportLink(profile) ?: return@let
                    val clip=ClipData.newPlainText("Cyrus · секретный ключ",raw)
                    clip.description.extras=PersistableBundle().apply { putBoolean("android.content.extra.IS_SENSITIVE",true) }
                    (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(clip)
                    message("Ключ скопирован. Не отправляйте его посторонним.")
                }
            },onExport={exportLink(profile)?.let { pendingExport=it;export.launch("cyrus-key.txt") }},
            onEdit={editTarget=profile;detailId=null}, onShare={shareTarget=exportLink(profile)})
    }
    editTarget?.let { profile -> ProfileEditor(profile, parser,
        onDismiss={editTarget=null}, onSave={viewModel.dispatch(ProfilesIntent.SaveProfile(it));editTarget=null}) }
    shareTarget?.let { secret ->
        AlertDialog(onDismissRequest={shareTarget=null}, title={Text("Передать секретный ключ?")},
            text={Text("Выбранное приложение и получатель получат полный доступ по этому ключу. Делитесь только с теми, кому доверяете.")},
            confirmButton={TextButton(onClick={
                shareTarget=null
                runCatching { context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                    type="text/plain"; putExtra(Intent.EXTRA_TEXT,secret)
                }, "Поделиться ключом Cyrus")) }.onFailure { message("Нет приложения для отправки") }
            }) { Text("Поделиться") }}, dismissButton={TextButton(onClick={shareTarget=null}) { Text("Отмена") }})
    }
    deleteTarget?.let { profile -> ConfirmDelete("Удалить «${profile.name}»?","Удалится локальный ключ. Из подписки он может вернуться после обновления.",
        onDismiss={deleteTarget=null},onConfirm={viewModel.dispatch(ProfilesIntent.Delete(profile));deleteTarget=null}) }
    sourceTarget?.let { source -> ConfirmDelete("Удалить подписку?","Источник и все его ${source.profileCount} ключей будут удалены с устройства.",
        onDismiss={sourceTarget=null},onConfirm={viewModel.dispatch(ProfilesIntent.RemoveSource(source.id));sourceTarget=null}) }
}

@Composable
private fun ProfileDetails(profile: VpnProfile,onDismiss:()->Unit,onRename:(String)->Unit,onDelete:()->Unit,onCopy:()->Unit,onExport:()->Unit,onEdit:()->Unit,onShare:()->Unit) {
    var name by remember(profile.id) { mutableStateOf(profile.name) }
    var reveal by remember(profile.id) { mutableStateOf(false) }
    AlertDialog(onDismissRequest=onDismiss,properties=DialogProperties(securePolicy=SecureFlagPolicy.SecureOn),title={Text("Сведения о ключе")},text={
        Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(name,{name=it.take(160)},label={Text("Название")},singleLine=true)
            Text("${profile.protocol.name} · ${profile.displayEndpoint}")
            Text("Транспорт: ${profile.transport.type} · TLS: ${if(profile.tls.enabled) "да" else "нет"}",style=MaterialTheme.typography.labelSmall)
            profile.tls.serverName?.let { Text("SNI: $it",style=MaterialTheme.typography.labelSmall) }
            if(profile.parameters.isNotEmpty()) Text("Дополнительных параметров: ${profile.parameters.size}. Сохранены в исходной ссылке.",style=MaterialTheme.typography.labelSmall)
            profile.rawLink?.let { raw ->
                OutlinedTextField(raw,{},readOnly=true,label={Text("Секретный ключ")},maxLines=4,
                    visualTransformation=if(reveal) VisualTransformation.None else PasswordVisualTransformation())
                TextButton(colors=ButtonDefaults.textButtonColors(contentColor=MaterialTheme.colorScheme.onSurface),onClick={reveal=!reveal}){Text(if(reveal) "Скрыть ключ" else "Показать ключ")}
                Text("Копирование и экспорт раскрывают секрет вне защищённого хранилища.",style=MaterialTheme.typography.labelSmall)
                Row { TextButton(colors=ButtonDefaults.textButtonColors(contentColor=MaterialTheme.colorScheme.onSurface),onClick=onCopy){Text("Копировать")};TextButton(colors=ButtonDefaults.textButtonColors(contentColor=MaterialTheme.colorScheme.onSurface),onClick=onExport){Text("Экспорт") } }
            } ?: Text("Этот ключ добавлен старой версией без исходной ссылки. Повторный импорт восстановит её.",style=MaterialTheme.typography.labelSmall)
            OutlinedButton(onClick=onEdit) { Text("Редактировать параметры") }
            TextButton(onClick=onShare) { Text("Поделиться ключом") }
            TextButton(colors=ButtonDefaults.textButtonColors(contentColor=MaterialTheme.colorScheme.onSurface),onClick=onDelete){Text("Удалить ключ",color=MaterialTheme.colorScheme.error)}
        }
    },confirmButton={TextButton(colors=ButtonDefaults.textButtonColors(contentColor=MaterialTheme.colorScheme.onSurface),onClick={onRename(name);onDismiss()}){Text("Сохранить")}},dismissButton={TextButton(colors=ButtonDefaults.textButtonColors(contentColor=MaterialTheme.colorScheme.onSurface),onClick=onDismiss){Text("Закрыть")}})
}
@Composable
private fun ConfirmDelete(title:String,text:String,onDismiss:()->Unit,onConfirm:()->Unit) {
    AlertDialog(onDismissRequest=onDismiss,title={Text(title)},text={Text(text)},confirmButton={TextButton(colors=ButtonDefaults.textButtonColors(contentColor=MaterialTheme.colorScheme.onSurface),onClick=onConfirm){Text("Удалить",color=MaterialTheme.colorScheme.error)}},dismissButton={TextButton(colors=ButtonDefaults.textButtonColors(contentColor=MaterialTheme.colorScheme.onSurface),onClick=onDismiss){Text("Отмена")}})
}
private fun Modifier.semanticsLabel(label:String):Modifier = this.then(Modifier.semantics { contentDescription=label })
