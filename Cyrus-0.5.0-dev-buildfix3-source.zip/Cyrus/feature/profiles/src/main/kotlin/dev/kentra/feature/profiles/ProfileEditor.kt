package dev.kentra.feature.profiles

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.SecureFlagPolicy
import dev.kentra.core.designsystem.CyrusSegmented
import dev.kentra.domain.model.*
import dev.kentra.domain.repository.LinkParser

@Composable
internal fun ProfileEditor(original: VpnProfile, parser: LinkParser, onDismiss: () -> Unit, onSave: (VpnProfile) -> Unit) {
    var draft by remember(original.id) { mutableStateOf(original) }
    var raw by remember(original.id) { mutableStateOf(runCatching { parser.export(original) }.getOrDefault(original.rawLink.orEmpty())) }
    var rawMode by remember { mutableStateOf(false) }
    var reveal by remember { mutableStateOf(false) }
    var port by remember { mutableStateOf(original.port.toString()) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(onDismissRequest=onDismiss, properties=DialogProperties(securePolicy=SecureFlagPolicy.SecureOn),
        title={Text("Редактор ключа")}, text={
            Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement=Arrangement.spacedBy(10.dp)) {
                CyrusSegmented(listOf("Параметры", "Ссылка"), if(rawMode) 1 else 0, onSelect={
                    if (it == 1 && !rawMode) raw=runCatching { parser.export(draft.copy(port=port.toIntOrNull() ?: 0)) }.getOrDefault(raw)
                    if (it == 0 && rawMode) {
                        val parsed=parser.parse(raw)
                        if(parsed!=null) { draft=parsed.copy(id=original.id,createdAt=original.createdAt,origin=original.origin);port=parsed.port.toString();rawMode=false;error=null }
                        else error="Исправьте ссылку перед переходом к полям"
                    } else rawMode=it==1
                })
                TextButton(onClick={reveal=!reveal}) { Text(if(reveal) "Скрыть секреты" else "Показать секреты") }
                if(rawMode) {
                    OutlinedTextField(raw,{raw=it.take(65_536)},label={Text("Полная ссылка с параметрами")},minLines=4,maxLines=10,
                        visualTransformation=if(reveal) VisualTransformation.None else PasswordVisualTransformation())
                    Text("Здесь можно изменить протокол и дополнительные query-параметры. Неизвестные параметры сохраняются, но могут не поддерживаться ядром.")
                } else {
                    EditorField("Название / регион провайдера",draft.name) { draft=draft.copy(name=it.take(160)) }
                    Text("${draft.protocol.name}. Регион по имени — метка провайдера, не проверенная геолокация IP.")
                    EditorField("Адрес сервера",draft.server) { draft=draft.copy(server=it.trim()) }
                    EditorField("Порт",port) { port=it }
                    if(draft.protocol in setOf(VpnProtocol.VLESS,VpnProtocol.VMESS,VpnProtocol.TUIC))
                        EditorField("UUID",draft.uuid.orEmpty(),!reveal) { draft=draft.copy(uuid=it.trim()) }
                    if(draft.protocol !in setOf(VpnProtocol.VLESS,VpnProtocol.VMESS))
                        EditorField("Пароль",draft.password.orEmpty(),!reveal) { draft=draft.copy(password=it) }
                    if(draft.protocol in setOf(VpnProtocol.HTTP,VpnProtocol.SOCKS))
                        EditorField("Имя пользователя",draft.parameters["username"].orEmpty(),!reveal) {
                            draft=draft.copy(parameters=draft.parameters.toMutableMap().apply { if(it.isEmpty()) remove("username") else put("username",it) })
                        }
                    if(draft.protocol==VpnProtocol.SHADOWSOCKS)
                        EditorField("Метод шифрования",draft.method.orEmpty()) { draft=draft.copy(method=it) }
                    if(draft.protocol==VpnProtocol.VLESS)
                        EditorField("Flow (например xtls-rprx-vision)",draft.flow.orEmpty()) { draft=draft.copy(flow=it.ifBlank { null }) }
                    if(draft.protocol in setOf(VpnProtocol.VLESS,VpnProtocol.VMESS,VpnProtocol.TROJAN)) {
                        EditorField("Транспорт: tcp / ws / grpc / http / httpupgrade",draft.transport.type) { draft=draft.copy(transport=draft.transport.copy(type=it.trim())) }
                        EditorField("Path",draft.transport.path.orEmpty()) { draft=draft.copy(transport=draft.transport.copy(path=it.ifBlank { null })) }
                        EditorField("Host транспорта",draft.transport.host.orEmpty()) { draft=draft.copy(transport=draft.transport.copy(host=it.ifBlank { null })) }
                        EditorField("gRPC serviceName",draft.transport.serviceName.orEmpty()) { draft=draft.copy(transport=draft.transport.copy(serviceName=it.ifBlank { null })) }
                    }
                    if(draft.protocol !in setOf(VpnProtocol.SOCKS,VpnProtocol.SHADOWSOCKS)) {
                        Row { Text("TLS",Modifier.weight(1f)); Switch(draft.tls.enabled,{draft=draft.copy(tls=draft.tls.copy(enabled=it))}) }
                        EditorField("SNI",draft.tls.serverName.orEmpty()) { draft=draft.copy(tls=draft.tls.copy(serverName=it.ifBlank { null })) }
                        EditorField("ALPN через запятую",draft.tls.alpn.joinToString(",")) { draft=draft.copy(tls=draft.tls.copy(alpn=it.split(',').map { a->a.trim() }.filter { a->a.isNotEmpty() })) }
                        EditorField("uTLS fingerprint",draft.tls.fingerprint.orEmpty()) { draft=draft.copy(tls=draft.tls.copy(fingerprint=it.ifBlank { null })) }
                        Row { Text("НЕ проверять сертификат (опасно)",Modifier.weight(1f)); Switch(draft.tls.allowInsecure,{draft=draft.copy(tls=draft.tls.copy(allowInsecure=it))}) }
                        if(draft.tls.allowInsecure) Text("Сервер может быть подменён. Предпочитайте корректный сертификат и SNI.",color=MaterialTheme.colorScheme.error)
                        if(draft.protocol==VpnProtocol.VLESS) {
                            EditorField("Reality public key (пусто — без Reality)",draft.tls.reality?.publicKey.orEmpty()) { key ->
                                draft=draft.copy(tls=draft.tls.copy(reality=if(key.isBlank()) null else (draft.tls.reality ?: RealitySettings(key)).copy(publicKey=key)))
                            }
                            draft.tls.reality?.let { r -> EditorField("Reality short ID",r.shortId.orEmpty()) { draft=draft.copy(tls=draft.tls.copy(reality=r.copy(shortId=it.ifBlank { null }))) } }
                        }
                    }
                    Text("Дополнительные опции Hysteria2, TUIC, SIP003 и vendor-параметры редактируются во вкладке «Ссылка».")
                }
                if(original.origin is ProfileOrigin.Subscription) Text("Обновление подписки может заменить эти изменения. Для независимой копии импортируйте отредактированную ссылку как ручной ключ.")
                error?.let { Text(it,color=MaterialTheme.colorScheme.error) }
            }
        },confirmButton={TextButton(onClick={
            val result=runCatching {
                val proposed=if(rawMode) requireNotNull(parser.parse(raw)) else draft.copy(port=port.toIntOrNull() ?: 0)
                val normalized=requireNotNull(parser.parse(parser.export(proposed)))
                require(normalized.name.isNotBlank())
                // Do not discard unsupported options: incompatibility is shown in the library.
                normalized.copy(id=original.id,createdAt=original.createdAt,origin=original.origin)
            }
            result.onSuccess(onSave).onFailure { error="Не сохранено: проверьте адрес, порт, UUID, пароль и синтаксис ссылки" }
        }){Text("Сохранить")}},dismissButton={TextButton(onClick=onDismiss){Text("Отмена")}})
}

@Composable
private fun EditorField(label:String,value:String,secret:Boolean=false,onChange:(String)->Unit) {
    OutlinedTextField(value,onChange,label={Text(label)},modifier=Modifier.fillMaxWidth(),singleLine=true,
        visualTransformation=if(secret) PasswordVisualTransformation() else VisualTransformation.None)
}
