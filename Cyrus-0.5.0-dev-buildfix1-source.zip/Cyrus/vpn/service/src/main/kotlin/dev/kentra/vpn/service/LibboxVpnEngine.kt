package dev.kentra.vpn.service

import android.net.IpPrefix
import android.app.Service
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.system.Os
import android.util.Log
import dev.kentra.domain.model.TrafficSample
import io.nekohasekai.libbox.BoxService
import io.nekohasekai.libbox.CommandClient
import io.nekohasekai.libbox.CommandClientHandler
import io.nekohasekai.libbox.CommandClientOptions
import io.nekohasekai.libbox.InterfaceUpdateListener
import io.nekohasekai.libbox.Libbox
import io.nekohasekai.libbox.NetworkInterface
import io.nekohasekai.libbox.NetworkInterfaceIterator
import io.nekohasekai.libbox.PlatformInterface
import io.nekohasekai.libbox.SetupOptions
import io.nekohasekai.libbox.StatusMessage
import io.nekohasekai.libbox.StringIterator
import io.nekohasekai.libbox.TunOptions
import io.nekohasekai.libbox.WIFIState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.net.InetAddress
import java.util.Collections
import java.util.concurrent.atomic.AtomicReference
import java.net.NetworkInterface as JavaNetworkInterface

/**
 * Real sing-box core (Phase 2). Wires libbox [PlatformInterface] to the Android VPN service:
 * TUN establishment, socket protection (routing-loop prevention) and traffic statistics.
 *
 * Integration checklist from docs/LibboxVpnEngine.kt.template:
 *   1. Libbox.setup(...)                 — once per process
 *   2. PlatformInterface implementation  — openTun / autoDetectInterfaceControl / monitor
 *   3. Libbox.newService(config, pi)     — start() throws if the core fails to come up
 *   4. stats via CommandClient(Libbox.CommandStatus) -> TrafficSample
 *   5. stop(): serialized, non-cancellable service.close(), then close our original fd
 */
class LibboxVpnEngine : VpnEngine {

    override val id = "libbox"

    private val serviceRef = AtomicReference<BoxService?>(null)
    private val tunFd = AtomicReference<ParcelFileDescriptor?>(null)
    private val statsHandler = AtomicReference<StatsHandler?>(null)
    private val statsThread = AtomicReference<Thread?>(null)

    /**
     * Serializes the start/stop lifecycle. A START intent racing an in-flight stop
     * would otherwise let stop() close the freshly created service (or vice versa),
     * leaving a dead tunnel and a stale TUN fd behind.
     */
    private val lifecycle = Mutex()

    @Volatile
    private var setupDone = false

    override suspend fun start(service: Service, session: TunnelSession) {
        withContext(Dispatchers.IO) {
            lifecycle.withLock {
                require(session.configJson.isNotBlank()) { "empty sing-box config" }

                if (!setupDone) {
                    val filesDir = service.filesDir.absolutePath
                    java.io.File(filesDir, "files").mkdirs()
                    Libbox.setup(
                        SetupOptions().apply {
                            basePath = filesDir
                            workingPath = "$filesDir/files"
                            tempPath = service.cacheDir.absolutePath
                            fixAndroidStack = true
                        },
                    )
                    setupDone = true
                }

                // Configuration contains credentials; never write it to logcat.

                val box = Libbox.newService(session.configJson, AndroidPlatformInterface(service))
                if (!serviceRef.compareAndSet(null, box)) {
                    runCatching { box.close() }
                    error("engine already running")
                }
                try {
                    // Returns only after the core is up; openTun() has been called by then.
                    box.start()
                    // Force the core to rebind all sockets to the physical network.
                    // Without this, it doesn't know about wlan0/rmnet despite the monitor.
                    box.resetNetwork()
                } catch (t: Throwable) {
                    serviceRef.set(null)
                    runCatching { box.close() }
                    throw t
                }
                startStats()
            }
        }
    }

    override suspend fun stop() {
        android.util.Log.d("LibboxVpnEngine", "stop: starting")
        // NonCancellable: stop() must complete even when the calling tunnelJob was
        // cancelled (a cancelled coroutine's withContext throws before running the
        // block, which would leak the BoxService and the TUN fd — and the system
        // VPN would keep routing after the user pressed disconnect).
        withContext(NonCancellable + Dispatchers.IO) {
            lifecycle.withLock {
                android.util.Log.d("LibboxVpnEngine", "stop: waiting for statsThread")
                statsThread.getAndSet(null)?.let { t ->
                    runCatching { clientRef.getAndSet(null)?.disconnect() }
                    runCatching { t.interrupt() }
                    runCatching { t.join(2_000) }
                }
                statsHandler.getAndSet(null)
                val box = serviceRef.getAndSet(null)
                if (box != null) {
                    android.util.Log.d("LibboxVpnEngine", "stop: closing libbox")
                    // The pinned core closes its instance in a Go goroutine; serialize lifecycle here.
                    runCatching { box.close() }
                    android.util.Log.d("LibboxVpnEngine", "stop: libbox closed")
                }
                tunFd.getAndSet(null)?.let { fd ->
                    android.util.Log.d("LibboxVpnEngine", "stop: closing tunFd")
                    // The ORIGINAL established descriptor (we kept ownership).
                    // Closing it kills the kernel TUN even if the Go core leaked
                    // its copy — the VPN agent then unregisters automatically.
                    runCatching { fd.close() } // never leak a stale tunnel fd
                    android.util.Log.d("LibboxVpnEngine", "stop: tunFd closed")
                }
            }
        }
        android.util.Log.d("LibboxVpnEngine", "stop: done")
    }

    private val clientRef = AtomicReference<CommandClient?>(null)

    /** Cumulative counters + instantaneous speeds reported by the core, polled once per second. */
    override val traffic: Flow<TrafficSample> = flow {
        while (true) {
            emit(statsHandler.get()?.latestSample ?: TrafficSample())
            delay(1_000)
        }
    }.flowOn(Dispatchers.IO)

    private inner class StatsHandler : CommandClientHandler {
        @Volatile
        var latestSample: TrafficSample = TrafficSample()

        override fun writeStatus(message: StatusMessage?) {
            if (message != null) {
                latestSample = TrafficSample(
                    available = true,
                    uplinkBytes = message.getUplinkTotal(),
                    downlinkBytes = message.getDownlinkTotal(),
                    uplinkSpeedBps = message.getUplink(),
                    downlinkSpeedBps = message.getDownlink(),
                )
            }
        }

        override fun connected() {}
        override fun disconnected(message: String?) { latestSample = TrafficSample() }
        override fun clearLogs() {}
        override fun writeLogs(messageList: StringIterator?) {}
        override fun writeGroups(message: io.nekohasekai.libbox.OutboundGroupIterator?) {}
        override fun initializeClashMode(modeList: StringIterator?, currentMode: String?) {}
        override fun updateClashMode(newMode: String?) {}
        override fun writeConnections(message: io.nekohasekai.libbox.Connections?) {}
    }

    private fun startStats() {
        val handler = StatsHandler()
        val client = CommandClient(handler, CommandClientOptions().apply {
            setCommand(Libbox.CommandStatus)
            // Go side does time.Duration(interval), i.e. nanoseconds.
            setStatusInterval(1_000_000_000L)
        })
        statsHandler.set(handler)
        clientRef.set(client)
        // Pinned Connect() already retries dialing and starts a Go reader; it does NOT
        // block for the lifetime of the stream. Do not connect five times on success.
        val thread = Thread({
            if (clientRef.get() === client && !Thread.currentThread().isInterrupted) {
                runCatching { client.connect() }
                // A stopped session must not retain a late connection to a new session.
                if (clientRef.get() !== client || Thread.currentThread().isInterrupted)
                    runCatching { client.disconnect() }
            }
        }, "libbox-stats")
        statsThread.set(thread)
        thread.isDaemon = true
        thread.start()
    }

    /**
     * Bridge from the sing-box core to Android VPN plumbing. Method semantics follow
     * sing-box-for-android — skipping protect() here is the only way to create a routing loop.
     */
    private inner class AndroidPlatformInterface(
        private val vpn: Service,
    ) : PlatformInterface {

        override fun openTun(options: TunOptions): Int {
            val builder = (vpn as? VpnService ?: error("TUN запрещён в режиме прокси")).Builder()
                .setSession("Cyrus")
                .setMtu(options.getMTU())
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                builder.setBlocking(true)
            }

            for (prefix in iterate(options.getInet4Address())) {
                builder.addAddress(prefix.address(), prefix.prefix())
            }
            for (prefix in iterate(options.getInet6Address())) {
                builder.addAddress(prefix.address(), prefix.prefix())
            }
            // DNS-hijack address: first tun address + 1, provided by the core.
            runCatching { options.getDNSServerAddress() }.getOrNull()?.let { dnsBox ->
                val dns = dnsBox.getValue()
                if (dns.isNotBlank()) builder.addDnsServer(dns)
            }
            for (prefix in iterate(options.getInet4RouteAddress())) {
                builder.addRoute(prefix.address(), prefix.prefix())
            }
            for (prefix in iterate(options.getInet6RouteAddress())) {
                builder.addRoute(prefix.address(), prefix.prefix())
            }
            // CRITICAL: RouteRange is the computed auto-route set (0.0.0.0/0 by default).
            // Without it the VPN gets NO default route and Android routes all traffic
            // around the tunnel — this was the cause of "no traffic through VPN".
            for (prefix in iterate(options.getInet4RouteRange())) {
                builder.addRoute(prefix.address(), prefix.prefix())
            }
            for (prefix in iterate(options.getInet6RouteRange())) {
                builder.addRoute(prefix.address(), prefix.prefix())
            }
            for (prefix in iterate(options.getInet4RouteExcludeAddress())) {
                excludeRoute(builder, prefix.address(), prefix.prefix())
            }
            for (prefix in iterate(options.getInet6RouteExcludeAddress())) {
                excludeRoute(builder, prefix.address(), prefix.prefix())
            }
            for (pkg in iterate(options.getIncludePackage())) {
                builder.addAllowedApplication(pkg)
            }
            for (pkg in iterate(options.getExcludePackage())) {
                builder.addDisallowedApplication(pkg)
            }

            val fd = runCatching { builder.establish() }.getOrNull()
                ?: return -1

            // libbox v1.11.1 service.go/OpenTun duplicates this descriptor with dup().
            // Keep ownership of the original: the core closes its duplicate, and
            // stop() closes our ParcelFileDescriptor. detachFd() would leak the original.
            val previous = tunFd.getAndSet(fd)
            previous?.let { runCatching { it.close() } }
            return fd.getFd()
        }

        private fun excludeRoute(builder: VpnService.Builder, address: String, prefix: Int) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                runCatching {
                    builder.excludeRoute(IpPrefix(InetAddress.getByName(address), prefix))
                }
            }
            // < API 33: route exclusions are not supported; auto-route ranges handle it.
        }

        /** CRITICAL: without protect() every core socket loops back into the TUN we just built. */
        override fun autoDetectInterfaceControl(fd: Int) {
            Log.d("sing-box", "autoDetectInterfaceControl called for fd=$fd")
            // The host is a plain Service in proxy mode. Capture the VPN-only API
            // in a typed local before entering the lambda; do not rely on a member smart cast.
            val vpnService: VpnService = vpn as? VpnService ?: return
            val protected: Boolean = runCatching { vpnService.protect(fd) }.getOrDefault(false)
            Log.d("sing-box", "protect(fd=$fd) result=$protected")
            if (!protected) {
                error("Не удалось защитить сокет VPN от петли маршрутизации")
            }
        }

        override fun usePlatformAutoDetectInterfaceControl(): Boolean = true

        private var defaultNetworkCallback: android.net.ConnectivityManager.NetworkCallback? = null
        private var monitorThread: android.os.HandlerThread? = null

        override fun startDefaultInterfaceMonitor(listener: InterfaceUpdateListener?) {
            if (listener == null) return
            val cm = vpn.getSystemService(android.net.ConnectivityManager::class.java) ?: return

            // Request only physical (non-VPN) networks — we must NOT report the TUN
            // interface back to the core, or it will try to route through itself.
            val request = android.net.NetworkRequest.Builder()
                .addCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .addCapability(android.net.NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
                .build()

            defaultNetworkCallback = object : android.net.ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: android.net.Network) {
                    notifyListener(cm, network, listener)
                }
                override fun onLinkPropertiesChanged(network: android.net.Network, linkProperties: android.net.LinkProperties) {
                    notifyListener(cm, network, listener)
                }
                override fun onCapabilitiesChanged(network: android.net.Network, caps: android.net.NetworkCapabilities) {
                    notifyListener(cm, network, listener)
                }
                override fun onLost(network: android.net.Network) {
                    runCatching {
                        listener.updateDefaultInterface("", 0, false, false)
                    }
                }
            }
            val handlerThread = android.os.HandlerThread("net-monitor")
            handlerThread.start()
            monitorThread = handlerThread
            val handler = android.os.Handler(handlerThread.looper)
            runCatching {
                cm.requestNetwork(request, defaultNetworkCallback!!, handler)
            }
            // Proactively find the current physical (non-VPN) network.
            for (network in cm.allNetworks) {
                val caps = cm.getNetworkCapabilities(network) ?: continue
                if (caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    && caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
                ) {
                    notifyListener(cm, network, listener)
                    break
                }
            }
        }

        private fun notifyListener(
            cm: android.net.ConnectivityManager,
            network: android.net.Network,
            listener: InterfaceUpdateListener,
        ) {
            val linkProperties = cm.getLinkProperties(network) ?: return
            val capabilities = cm.getNetworkCapabilities(network)
            val ifaceName = linkProperties.interfaceName ?: ""
            // Skip VPN/TUN interfaces that slipped through
            if (ifaceName.startsWith("tun")) return
            val ifaceIndex = runCatching { JavaNetworkInterface.getByName(ifaceName)?.index ?: 0 }.getOrDefault(0)
            val metered = capabilities?.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_NOT_METERED) == false
            Log.d("sing-box", "Default interface updated: $ifaceName idx=$ifaceIndex metered=$metered")
            runCatching {
                listener.updateDefaultInterface(ifaceName, ifaceIndex, metered, false)
            }.onFailure { Log.e("sing-box", "Failed to update default interface", it) }
            // Kick the core to rebind all sockets through the updated interface.
            runCatching { serviceRef.get()?.resetNetwork() }
        }

        override fun closeDefaultInterfaceMonitor(listener: InterfaceUpdateListener?) {
            defaultNetworkCallback?.let { callback ->
                runCatching {
                    val cm = vpn.getSystemService(android.net.ConnectivityManager::class.java)
                    cm?.unregisterNetworkCallback(callback)
                }
            }
            defaultNetworkCallback = null
            monitorThread?.quitSafely()
            monitorThread = null
        }

        override fun getInterfaces(): NetworkInterfaceIterator {
            val list = runCatching {
                Collections.list(JavaNetworkInterface.getNetworkInterfaces())
            }.getOrDefault(emptyList())
            Log.d("sing-box", "getInterfaces() returning ${list.size} interfaces")
            return object : NetworkInterfaceIterator {
                private var cursor = 0
                override fun hasNext(): Boolean = cursor < list.size
                override fun next(): NetworkInterface {
                    val nif = list[cursor++]
                    // Collect addresses as CIDR prefixes (e.g. "10.0.0.1/24").
                    // Go's netip.ParsePrefix panics on bare IPs or zone IDs like "%dummy0".
                    val prefixes = mutableListOf<String>()
                    for (ifAddr in nif.interfaceAddresses) {
                        val addr = ifAddr.address ?: continue
                        var host = addr.hostAddress ?: continue
                        // Strip IPv6 zone ID (e.g. "%dummy0") — Go doesn't accept it.
                        val pctIdx = host.indexOf('%')
                        if (pctIdx >= 0) host = host.substring(0, pctIdx)
                        val prefixLen = ifAddr.networkPrefixLength.toInt()
                        prefixes.add("$host/$prefixLen")
                    }
                    // The core filters interfaces by Flags&IFF_UP (route/network.go) and
                    // uses Type for network strategy. Java's getFlags() returns the raw
                    // IFF_* bits, but we must at least ensure UP is visible. Without flags
                    // the interface list is empty and every dial fails with
                    // "no available network interface".
                    val type = when {
                        nif.name.startsWith("wlan") || nif.name.startsWith("ap") -> TYPE_WIFI
                        nif.name.startsWith("rmnet") || nif.name.startsWith("ccmni") ||
                            nif.name.startsWith("swlan") || nif.name.startsWith("usb") -> TYPE_CELLULAR
                        nif.name.startsWith("eth") -> TYPE_ETHERNET
                        else -> TYPE_OTHER
                    }
                    val networkInterface = NetworkInterface().apply {
                        setName(nif.name)
                        setIndex(nif.index)
                        setMTU(runCatching { nif.mtu }.getOrDefault(0))
                        setFlags(computeFlags(nif)) // core keeps only Flags&IFF_UP != 0
                        setType(type)
                        setMetered(false)
                        setAddresses(
                            object : StringIterator {
                                private var idx = 0
                                override fun hasNext(): Boolean = idx < prefixes.size
                                override fun next(): String = prefixes[idx++]
                                override fun len(): Int = prefixes.size - idx
                            },
                        )
                        setDNSServer(emptyStringIterator())
                    }
                    Log.d("sing-box", "getInterfaces() yielding: ${nif.name} (idx=${nif.index}, type=$type, up=${nif.isUp}) with ${prefixes.size} prefixes")
                    return networkInterface
                }
            }
        }

        override fun underNetworkExtension(): Boolean = false
        override fun includeAllNetworks(): Boolean = false
        override fun useProcFS(): Boolean = false

        override fun findConnectionOwner(
            ipProtocol: Int,
            sourceAddress: String?,
            sourcePort: Int,
            destinationAddress: String?,
            destinationPort: Int,
        ): Int {
            val cm = vpn.getSystemService(android.net.ConnectivityManager::class.java) ?: return -1
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return -1
            val local = java.net.InetSocketAddress(runCatching { InetAddress.getByName(sourceAddress) }.getOrNull() ?: return -1, sourcePort)
            val remote = java.net.InetSocketAddress(runCatching { InetAddress.getByName(destinationAddress) }.getOrNull() ?: return -1, destinationPort)
            return runCatching { cm.getConnectionOwnerUid(ipProtocol, local, remote) }.getOrDefault(-1)
        }

        override fun packageNameByUid(uid: Int): String =
            runCatching { vpn.packageManager.getNameForUid(uid) ?: "unknown" }
                .getOrDefault("unknown")

        override fun uidByPackageName(packageName: String?): Int =
            runCatching { vpn.packageManager.getPackageUid(requireNotNull(packageName), 0) }
                .getOrDefault(-1)

        override fun readWIFIState(): WIFIState? = null

        override fun sendNotification(notification: io.nekohasekai.libbox.Notification?) = Unit

        override fun clearDNSCache() = Unit

        override fun writeLog(message: String?) {
            // Native messages may contain credentials or destination URLs; do not forward them to logcat.
        }
    }

    private companion object {
        // Must match io.nekohasekai.libbox constants (constant/network.go:
        // WIFI=0, Cellular=1, Ethernet=2, Other=3).
        const val TYPE_WIFI = 0
        const val TYPE_CELLULAR = 1
        const val TYPE_ETHERNET = 2
        const val TYPE_OTHER = 3

        // Linux IFF_* bits (see Go syscall/zerrors_linux_arm64.go); the core maps
        // rawFlags -> net.Flags via libbox linkFlags() and keeps UP interfaces only.
        const val IFF_UP = 0x1
        const val IFF_BROADCAST = 0x2
        const val IFF_LOOPBACK = 0x8
        const val IFF_POINTOPOINT = 0x10
        const val IFF_RUNNING = 0x40
        const val IFF_MULTICAST = 0x8000

        /** Android's java.net.NetworkInterface has no getFlags(); rebuild from predicates. */
        fun computeFlags(nif: JavaNetworkInterface): Int {
            var flags = 0
            if (runCatching { nif.isUp }.getOrDefault(false)) flags = flags or IFF_UP
            if (runCatching { nif.isLoopback }.getOrDefault(false)) flags = flags or IFF_LOOPBACK
            if (runCatching { nif.isPointToPoint }.getOrDefault(false)) flags = flags or IFF_POINTOPOINT
            if (runCatching { nif.supportsMulticast() }.getOrDefault(false)) flags = flags or IFF_MULTICAST
            if (!nif.isLoopback && !nif.isPointToPoint) flags = flags or IFF_BROADCAST
            if (runCatching { nif.isUp }.getOrDefault(false)) {
                // Most physical interfaces report RUNNING; core treats it as a bonus.
                flags = flags or IFF_RUNNING
            }
            return flags
        }

        fun emptyStringIterator(): StringIterator = object : StringIterator {
            override fun hasNext(): Boolean = false
            override fun next(): String = ""
            override fun len(): Int = 0
        }

        fun iterate(iterator: io.nekohasekai.libbox.RoutePrefixIterator?): List<io.nekohasekai.libbox.RoutePrefix> =
            buildList {
                if (iterator != null) {
                    while (iterator.hasNext()) add(iterator.next())
                }
            }

        fun iterate(iterator: StringIterator?): List<String> = buildList {
            if (iterator != null) {
                while (iterator.hasNext()) add(iterator.next())
            }
        }
    }
}
