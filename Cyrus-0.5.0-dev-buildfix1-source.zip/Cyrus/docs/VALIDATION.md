# Проверки Cyrus 0.5.0-dev buildfix1

Текущий отчёт: [BUILD_FIX_0.5.0.md](BUILD_FIX_0.5.0.md). Проверки исходников проходят; успешная компиляция и APK пока НЕ подтверждены.

Полный текущий журнал: `validation/source-checks.txt`. Дополнительные синтаксические проверки: `validation/buildfix-syntax-checks.txt`.

Исторический отчёт исходной версии: [UPGRADE_0.5.0.md](UPGRADE_0.5.0.md).
