#!/usr/bin/env python3
"""Narrow source regression guards. NOT Kotlin compilation or runtime tests."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
ENGINE = 'vpn/service/src/main/kotlin/dev/kentra/vpn/service/LibboxVpnEngine.kt'
CONFIG_BUILD = 'vpn/config/build.gradle.kts'
ZIP_WORKFLOW = 'docs/workflows/build-zip.yml'
SOURCE_WORKFLOW = '.github/workflows/android.yml'


def validate(root=ROOT):
    text = lambda path: (root / path).read_text(encoding='utf-8')
    engine = text(ENGINE)
    start = engine.index('override fun autoDetectInterfaceControl(fd: Int)')
    end = engine.index('override fun usePlatformAutoDetectInterfaceControl()', start)
    callback = engine[start:end]
    checks = {
        'VPN-only API captured in explicitly typed local':
            'val vpnService: VpnService = vpn as? VpnService ?: return' in callback,
        'Protection uses typed receiver and Boolean result':
            'val protected: Boolean = runCatching { vpnService.protect(fd) }.getOrDefault(false)' in callback,
        'Protection failure aborts callback':
            bool(re.search(r'if\s*\(!protected\)\s*\{\s*error\("Не удалось защитить сокет VPN от петли маршрутизации"\)', callback)),
        'No stale Service.protect expression': 'vpn.protect(fd)' not in callback,
        'Native callback remains enabled':
            'override fun usePlatformAutoDetectInterfaceControl(): Boolean = true' in engine,
        'Proxy cannot create TUN':
            'vpn as? VpnService ?: error("TUN запрещён в режиме прокси")' in engine,
        'Native fixtures registered as Gradle outputs':
            'outputs.dir(layout.buildDirectory.dir("native-fixtures"))' in text(CONFIG_BUILD),
        'Server fixtures registered as Gradle outputs':
            'outputs.dir(layout.buildDirectory.dir("server-script-fixtures"))' in text(CONFIG_BUILD),
    }
    zip_workflow = text(ZIP_WORKFLOW)
    go_step = zip_workflow.split('- name: Set up matching Go toolchain\n', 1)[1].split('\n      - name:', 1)[0]
    checks['Go pin is unconditional for native validation'] = (
        not re.search(r'^\s*if:', go_step, re.M)
        and 'go-version: ${{ env.GO_VERSION }}' in go_step
    )
    for workflow in (ZIP_WORKFLOW, SOURCE_WORKFLOW):
        source = text(workflow)
        compile_step = source.find(':app:compileDebugKotlin :app:compileReleaseKotlin')
        test_step = source.index('- name: Mandatory unit tests' if workflow == ZIP_WORKFLOW else '- name: Unit tests')
        checks['Both variants compiled before tests in ' + workflow] = 0 <= compile_step < test_step
    for name, ok in checks.items():
        if not ok:
            raise AssertionError(name)
    return list(checks)


if __name__ == '__main__':
    names = validate()
    for name in names:
        print('PASS', name)
    print(f'{len(names)} buildfix source checks passed. NOT compilation or runtime validation.')
