#!/usr/bin/env python3
"""Mutation-test the source guards; these do not execute Android or Kotlin."""
from pathlib import Path
import shutil
import tempfile
from check_buildfix import validate, ROOT, ENGINE, CONFIG_BUILD, ZIP_WORKFLOW, SOURCE_WORKFLOW

mutations = [
    ('original broken callback restored', ENGINE,
     'val vpnService: VpnService = vpn as? VpnService ?: return\n            val protected: Boolean = runCatching { vpnService.protect(fd) }.getOrDefault(false)',
     'if (vpn !is VpnService) return\n            val protected = runCatching { vpn.protect(fd) }.getOrDefault(false)'),
    ('unsafe proxy cast', ENGINE, 'vpn as? VpnService ?: return', 'vpn as VpnService'),
    ('exception treated as success', ENGINE, 'vpnService.protect(fd) }.getOrDefault(false)', 'vpnService.protect(fd) }.getOrDefault(true)'),
    ('false return ignored', ENGINE, 'if (!protected)', 'if (false)'),
    ('callback disabled', ENGINE, 'usePlatformAutoDetectInterfaceControl(): Boolean = true', 'usePlatformAutoDetectInterfaceControl(): Boolean = false'),
    ('proxy allowed to create TUN', ENGINE, 'vpn as? VpnService ?: error("TUN запрещён в режиме прокси")', 'vpn as VpnService'),
    ('native fixture outputs lost', CONFIG_BUILD, 'outputs.dir(layout.buildDirectory.dir("native-fixtures"))', '// removed'),
    ('server fixture outputs lost', CONFIG_BUILD, 'outputs.dir(layout.buildDirectory.dir("server-script-fixtures"))', '// removed'),
    ('Go setup skipped on cache hit', ZIP_WORKFLOW, '- name: Set up matching Go toolchain\n', '- name: Set up matching Go toolchain\n        if: false\n'),
    ('ZIP release preflight lost', ZIP_WORKFLOW, ':app:compileDebugKotlin :app:compileReleaseKotlin', ':app:compileDebugKotlin'),
    ('source release preflight lost', SOURCE_WORKFLOW, ':app:compileDebugKotlin :app:compileReleaseKotlin', ':app:compileDebugKotlin'),
]

with tempfile.TemporaryDirectory() as directory:
    root = Path(directory) / 'Cyrus'
    shutil.copytree(ROOT, root, ignore=shutil.ignore_patterns('__pycache__'))
    validate(root)
    for name, path, old, new in mutations:
        p = root / path
        original = p.read_text()
        assert old in original, name
        p.write_text(original.replace(old, new))
        try:
            validate(root)
        except (AssertionError, ValueError):
            print('PASS rejected:', name)
        else:
            raise AssertionError('Undetected mutation: ' + name)
        finally:
            p.write_text(original)
print(f'{len(mutations)} buildfix guard mutation cases passed. NOT Kotlin/runtime tests.')
