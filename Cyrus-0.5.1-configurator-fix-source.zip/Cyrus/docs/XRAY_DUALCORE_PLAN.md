# Stage 2: Xray-core as a second engine

Status: design, not implemented. Stage 1 (transport canonicalisation, honest
diagnostics, configurator rework) landed first and deliberately created the
seams this stage plugs into.

## Why a second core at all

`xhttp` (ex `splithttp`), `mKCP` and V2Ray `quic` are Xray-only transports.
sing-box does not implement them, and no renaming can emulate them: a sing-box
outbound built from such a key would dial and then stall, which is strictly
worse for the user than the explicit refusal Stage 1 now produces
(`TransportCompat.singBoxRejection`). The only honest way to run those keys is
to run the core that implements them.

## Seams that already exist after Stage 1

| Seam | Location | Purpose |
| --- | --- | --- |
| `VpnEngineKind` | `domain/model/TransportCompat.kt` | Engine identity, no database column: derived from the transport, so no Room migration. |
| `TransportCompat.requiredEngine(type)` | same | Single decision point for routing a key to a core. |
| `TransportCompat.XRAY_ONLY` | same | The exact set that Stage 2 turns from "refused" into "supported". |
| `VpnEngine` / `TunnelSession` | `vpn/service/VpnEngine.kt` | Engine boundary is already config-JSON shaped and core-agnostic. |
| `cyrus-xray` parameter | `vpn/link/XraySubscriptionReader.kt` | Base64 of the **original** Xray outbound is already preserved per node. For JSON subscriptions this lets Stage 2 replay the vendor outbound verbatim instead of re-deriving it. |

## Work items

1. **`:vpn:xray` module** (`kotlin-jvm`, mirrors `:vpn:config`)
   - `XrayConfigFactory.build(profile, options): String` producing Xray JSON.
   - Two paths: (a) `cyrus-xray` present -> decode the original outbound and
     splice it into a generated inbound/routing shell; (b) absent -> derive
     `streamSettings` from `TransportSettings` + `TlsSettings`.
   - `XrayOptionsValidation` for the xhttp `mode` values sing-box never had
     (`auto`, `packet-up`, `stream-up`, `stream-one`).
   - Golden tests in the same style as `ConfigFactoryTest`, including the rule
     that a generated config never contains the credential in plaintext logs.
2. **`XrayVpnEngine : VpnEngine`** in `:vpn:service`, over a `libXray` AAR.
   Must implement `protect()`, TUN fd hand-off, DNS and serialized teardown,
   exactly like `LibboxVpnEngine`. Traffic sampling via the Xray stats API.
3. **Engine selection** in `TunnelControllerImpl`: resolve
   `TransportCompat.requiredEngine(profile.transport.type)`, then pick from a
   Koin-provided `Map<VpnEngineKind, VpnEngine>`. `vpnModule` gains named
   singles; `UnavailableVpnEngine` becomes the fallback when an AAR is absent
   from the build, so a Xray-less build still compiles and refuses honestly.
4. **CI**: `.github/workflows/build-xray.yml` cloned from `build-libbox.yml`,
   pinned to an explicit upstream commit, with the same provenance recording in
   `docs/PROVENANCE.md`. Both AARs must be reproducible from the pin.
5. **Size**: two Go cores land in the same APK. Keep the three-ABI split, and
   re-measure `docs/APK_SIZE.md`. Expect a material increase; if it is not
   acceptable, the fallback is a separate `xray` product flavour rather than
   silently shipping a core nobody uses.
6. **Guards**: extend `tools/check_native.py` to verify both AARs, and add a
   mutation case asserting that `XRAY_ONLY` keys are never routed to the
   sing-box engine.

## Order of execution

Steps 1 and 4 can run in parallel; step 2 needs the AAR from step 4; step 3 is
a small change once 1 and 2 exist. Nothing in Stage 1 has to be revisited.
