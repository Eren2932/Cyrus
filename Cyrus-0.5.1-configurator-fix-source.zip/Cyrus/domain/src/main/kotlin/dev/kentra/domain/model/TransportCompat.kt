package dev.kentra.domain.model

/** Which native core is able to carry a given transport. */
enum class VpnEngineKind { SING_BOX, XRAY }

/**
 * The single source of truth for transport naming.
 *
 * Panels hand out the same wire transport under several names: Xray renamed
 * "tcp" to "raw" in 1.8.16, "splithttp" became "xhttp", HTTP/2 appears as "h2"
 * or "h2c", and gRPC is still written as "gun" by older generators. A raw value
 * taken from a key must therefore never be compared against core capabilities
 * directly - it has to be canonicalised first, otherwise a perfectly supported
 * key is rejected only because of its spelling.
 *
 * Canonical names are the ones the sing-box JSON schema uses.
 */
object TransportCompat {

    /** Implemented by the pinned sing-box core. */
    val SING_BOX: Set<String> = setOf("tcp", "ws", "grpc", "http", "httpupgrade")

    /**
     * Real transports that only Xray-core implements. Renaming cannot emulate
     * them: a sing-box outbound built from such a key would connect and then
     * stall, which is worse for the user than an explicit refusal.
     */
    val XRAY_ONLY: Set<String> = setOf("xhttp", "kcp", "quic")

    /** Canonical transports offered in the key editor, in order. */
    val EDITOR_CHOICES: List<String> = listOf("tcp", "ws", "grpc", "http", "httpupgrade")

    private val ALIASES: Map<String, String> = mapOf(
        // Xray 1.8.16+ calls plain TCP "raw"; some generators write nothing at all.
        "" to "tcp", "tcp" to "tcp", "raw" to "tcp", "none" to "tcp", "original" to "tcp",
        "ws" to "ws", "websocket" to "ws",
        "grpc" to "grpc", "gun" to "grpc",
        "http" to "http", "h2" to "http", "h2c" to "http", "http2" to "http",
        "httpupgrade" to "httpupgrade", "upgrade" to "httpupgrade",
        // Known-but-unsupported: canonicalised so the diagnostic can name them.
        "xhttp" to "xhttp", "splithttp" to "xhttp",
        "kcp" to "kcp", "mkcp" to "kcp",
        "quic" to "quic",
    )

    /**
     * Canonical transport name. Unknown values are returned squashed and
     * lowercased so they can be shown back to the user without echoing markup.
     */
    fun normalize(type: String?): String {
        val cleaned = type?.trim()?.lowercase().orEmpty()
        ALIASES[cleaned]?.let { return it }
        val squashed = cleaned.filter { it.isLetterOrDigit() }
        return ALIASES[squashed] ?: squashed.ifEmpty { "tcp" }
    }

    fun isSingBox(type: String?): Boolean = normalize(type) in SING_BOX
    fun isXrayOnly(type: String?): Boolean = normalize(type) in XRAY_ONLY
    fun isKnown(type: String?): Boolean = isSingBox(type) || isXrayOnly(type)

    /** Engine a key needs. Derived, never stored, so no database migration. */
    fun requiredEngine(type: String?): VpnEngineKind =
        if (isXrayOnly(type)) VpnEngineKind.XRAY else VpnEngineKind.SING_BOX

    /**
     * Human-readable reason a transport cannot be used by the sing-box core, or
     * null when it can. Names the canonical transport and the way out; never
     * claims support that does not exist.
     */
    fun singBoxRejection(type: String?): String? {
        val canonical = normalize(type)
        return when {
            canonical in SING_BOX -> null
            canonical in XRAY_ONLY ->
                "Транспорт «$canonical» реализован только в Xray-ядре, sing-box его не умеет. " +
                    "Запросите у провайдера ключ на ws, grpc, httpupgrade или tcp/raw к тому же серверу."
            else ->
                "Неизвестный транспорт «$canonical». Поддерживаются: ${SING_BOX.joinToString(", ")} " +
                    "(синонимы raw, h2, gun, websocket распознаются автоматически)."
        }
    }
}
