package dev.kentra.domain.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TransportCompatTest {

    @Test fun `xray raw is plain tcp`() {
        for (alias in listOf("raw", "RAW", " raw ", "none", "original", "", "tcp")) assertEquals("tcp", TransportCompat.normalize(alias))
        assertEquals("tcp", TransportCompat.normalize(null))
    }

    @Test fun `http aliases collapse to the sing-box name`() {
        for (alias in listOf("h2", "h2c", "http2", "HTTP")) assertEquals("http", TransportCompat.normalize(alias))
    }

    @Test fun `grpc and ws aliases collapse`() {
        assertEquals("grpc", TransportCompat.normalize("gun"))
        assertEquals("ws", TransportCompat.normalize("WebSocket"))
        assertEquals("httpupgrade", TransportCompat.normalize("http-upgrade"))
    }

    @Test fun `unsupported transports keep their canonical name`() {
        assertEquals("xhttp", TransportCompat.normalize("splithttp"))
        assertEquals("kcp", TransportCompat.normalize("mKCP"))
        assertEquals("quic", TransportCompat.normalize("quic"))
    }

    @Test fun `every sing-box transport is accepted and every alias of it too`() {
        for (type in TransportCompat.SING_BOX) assertNull(TransportCompat.singBoxRejection(type))
        for (alias in listOf("raw", "h2", "gun", "websocket", "upgrade")) assertNull(TransportCompat.singBoxRejection(alias))
    }

    @Test fun `xray only transports are refused by name, not silently accepted`() {
        for (type in TransportCompat.XRAY_ONLY) {
            val reason = TransportCompat.singBoxRejection(type)
            assertTrue("must name the transport: " + reason, reason != null && reason.contains(type))
            assertTrue("must name Xray: " + reason, reason!!.contains("Xray"))
            assertEquals(VpnEngineKind.XRAY, TransportCompat.requiredEngine(type))
        }
        assertEquals(VpnEngineKind.SING_BOX, TransportCompat.requiredEngine("raw"))
    }

    @Test fun `unknown transport is reported without echoing markup`() {
        val reason = TransportCompat.singBoxRejection("we<b>ird")
        assertTrue(reason != null && !reason.contains("<"))
    }

    @Test fun `normalization is idempotent`() {
        for (alias in listOf("raw", "h2", "gun", "websocket", "splithttp", "mkcp", "weird")) {
            val once = TransportCompat.normalize(alias)
            assertEquals(once, TransportCompat.normalize(once))
        }
    }
}
