package dev.kentra.feature.profiles

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.SecureFlagPolicy
import androidx.compose.foundation.text.KeyboardOptions
import dev.kentra.core.designsystem.CyrusSegmented
import dev.kentra.domain.model.*
import dev.kentra.domain.repository.LinkParser
import dev.kentra.vpn.config.ConfigFactory

/** Protocols the editor can build from scratch, in the order panels use them. */
private val EditableProtocols = listOf(
    VpnProtocol.VLESS, VpnProtocol.VMESS, VpnProtocol.TROJAN, VpnProtocol.SHADOWSOCKS,
    VpnProtocol.HYSTERIA2, VpnProtocol.TUIC, VpnProtocol.SOCKS, VpnProtocol.HTTP,
)

@Composable
internal fun ProfileEditor(original: VpnProfile, parser: LinkParser, onDismiss: () -> Unit, onSave: (VpnProfile) -> Unit) {
    var draft by remember(original.id) { mutableStateOf(original) }
    var raw by remember(original.id) { mutableStateOf(runCatching { parser.export(original) }.getOrDefault(original.rawLink.orEmpty())) }
    var rawMode by remember { mutableStateOf(false) }
    var reveal by remember { mutableStateOf(false) }
    var port by remember(original.id) { mutableStateOf(original.port.toString()) }
    var error by remember { mutableStateOf<String?>(null) }

    /** Candidate as the core would see it: the editor judges the same object it saves. */
    val candidate = draft.copy(port = port.toIntOrNull() ?: 0)
    // Live verdict from the single validator in :vpn:config. No second rule set here,
    // so the editor can never promise something the engine will later refuse.
    val verdict = remember(candidate) {
        runCatching { ConfigFactory().validateProfile(candidate) }.exceptionOrNull()?.message
    }

    fun setParam(key: String, value: String?) {
        draft = draft.copy(parameters = draft.parameters.toMutableMap().apply {
            if (value.isNullOrBlank()) remove(key) else put(key, value)
        })
    }

    AlertDialog(onDismissRequest=onDismiss, properties=DialogProperties(securePolicy=SecureFlagPolicy.SecureOn),
        title={Text("Редактор ключа")}, text={
            Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement=Arrangement.spacedBy(10.dp)) {
                CyrusSegmented(listOf("Параметры", "Ссылка"), if(rawMode) 1 else 0, onSelect={
                    if (it == 1 && !rawMode) raw=runCatching { parser.export(candidate) }.getOrDefault(raw)
                    if (it == 0 && rawMode) {
                        val parsed=parser.parse(raw)
                        if(parsed!=null) { draft=parsed.copy(id=original.id,createdAt=original.createdAt,origin=original.origin);port=parsed.port.toString();rawMode=false;error=null }
                        else error="Исправьте ссылку перед переходом к полям"
                    } else rawMode=it==1
                })
                TextButton(onClick={reveal=!reveal}) { Text(if(reveal) "Скрыть секреты" else "Показать секреты") }
                if(rawMode) {
                    OutlinedTextField(raw,{raw=it.take(65_536)},label={Text("Полная ссылка с параметрами")},minLines=4,maxLines=10,
                        visualTransformation=if(reveal) VisualTransformation.None else PasswordVisualTransformation())
                    Text("Принимаются vless, vmess, trojan, ss, hysteria2/hy2, tuic, socks, http(s) и Base64-подписки. Неизвестные параметры сохраняются как есть.")
                } else {
                    // Protocol is editable in the fields view too: a key of any type can be
                    // repaired here without falling back to hand-editing a URL.
                    ChipRow("Протокол", EditableProtocols.map { it.name }, EditableProtocols.indexOf(draft.protocol)) { index ->
                        val next = EditableProtocols[index]
                        if (next != draft.protocol) draft = draft.copy(
                            protocol = next,
                            // Reality and V2Ray transports do not exist outside the VLESS/VMESS/Trojan family.
                            transport = if (next in TransportCapable) draft.transport else TransportSettings(),
                            tls = if (next in setOf(VpnProtocol.HYSTERIA2, VpnProtocol.TUIC))
                                draft.tls.copy(enabled = true, reality = null, fingerprint = null)
                            else if (next == VpnProtocol.VLESS) draft.tls
                            else draft.tls.copy(reality = null),
                            flow = if (next == VpnProtocol.VLESS) draft.flow else null,
                        )
                    }
                    EditorField("Название / регион провайдера",draft.name) { draft=draft.copy(name=it.take(160)) }
                    Text("Регион по имени — метка провайдера, не проверенная геолокация IP.")
                    EditorField("Адрес сервера",draft.server) { draft=draft.copy(server=it.trim()) }
                    EditorField("Порт",port,numeric=true) { port=it.filter { c->c.isDigit() }.take(5) }
                    if(draft.protocol in setOf(VpnProtocol.VLESS,VpnProtocol.VMESS,VpnProtocol.TUIC))
                        EditorField("UUID",draft.uuid.orEmpty(),secret=!reveal) { draft=draft.copy(uuid=it.trim()) }
                    if(draft.protocol !in setOf(VpnProtocol.VLESS,VpnProtocol.VMESS))
                        EditorField("Пароль",draft.password.orEmpty(),secret=!reveal) { draft=draft.copy(password=it) }
                    if(draft.protocol in setOf(VpnProtocol.HTTP,VpnProtocol.SOCKS))
                        EditorField("Имя пользователя",draft.parameters["username"].orEmpty(),secret=!reveal) { setParam("username", it) }
                    if(draft.protocol==VpnProtocol.SHADOWSOCKS) {
                        EditorField("Метод шифрования",draft.method.orEmpty()) { draft=draft.copy(method=it.trim()) }
                        EditorField("SIP003 plugin (obfs-local;obfs=http;... )",draft.parameters["plugin"].orEmpty()) { setParam("plugin", it) }
                    }
                    if(draft.protocol==VpnProtocol.VMESS) {
                        EditorField("alterId",(draft.alterId ?: 0).toString(),numeric=true) { draft=draft.copy(alterId=it.toIntOrNull() ?: 0) }
                        ChipRow("Шифрование VMess", VmessSecurity, VmessSecurity.indexOf(draft.parameters["scy"] ?: "auto")) { setParam("scy", VmessSecurity[it]) }
                    }
                    if(draft.protocol==VpnProtocol.VLESS) {
                        EditorField("Flow (например xtls-rprx-vision)",draft.flow.orEmpty()) { draft=draft.copy(flow=it.ifBlank { null }) }
                        ChipRow("packetEncoding", PacketEncodings, PacketEncodings.indexOf(draft.parameters["packetEncoding"] ?: "—")) {
                            setParam("packetEncoding", PacketEncodings[it].takeIf { v->v!="—" })
                        }
                    }
                    if(draft.protocol in TransportCapable) {
                        // Canonical choices only. raw/h2/gun/websocket coming from a key are
                        // already normalised by the parser, so the selection cannot drift.
                        val current = TransportCompat.normalize(draft.transport.type)
                        ChipRow("Транспорт", TransportCompat.EDITOR_CHOICES, TransportCompat.EDITOR_CHOICES.indexOf(current)) {
                            draft = draft.copy(transport = draft.transport.copy(type = TransportCompat.EDITOR_CHOICES[it]))
                        }
                        if (current !in TransportCompat.EDITOR_CHOICES)
                            Text("Ключ пришёл с транспортом «$current». " + (TransportCompat.singBoxRejection(current) ?: ""),
                                color=MaterialTheme.colorScheme.error)
                        if (current in setOf("ws","http","httpupgrade","grpc"))
                            EditorField("Path",draft.transport.path.orEmpty()) { draft=draft.copy(transport=draft.transport.copy(path=it.ifBlank { null })) }
                        if (current in setOf("ws","http","httpupgrade"))
                            EditorField(if (current=="http") "Host (через запятую)" else "Host транспорта",draft.transport.host.orEmpty()) {
                                draft=draft.copy(transport=draft.transport.copy(host=it.ifBlank { null }))
                            }
                        if (current == "grpc")
                            EditorField("gRPC serviceName",draft.transport.serviceName.orEmpty()) { draft=draft.copy(transport=draft.transport.copy(serviceName=it.ifBlank { null })) }
                        if (current == "ws") {
                            EditorField("Early data: max bytes (ed)",draft.parameters["ed"].orEmpty(),numeric=true) { setParam("ed", it) }
                            EditorField("Early data header (eh)",draft.parameters["eh"].orEmpty()) { setParam("eh", it) }
                        }
                    }
                    if(draft.protocol !in setOf(VpnProtocol.SOCKS,VpnProtocol.SHADOWSOCKS)) {
                        val tlsLocked = draft.protocol in setOf(VpnProtocol.HYSTERIA2,VpnProtocol.TUIC,VpnProtocol.TROJAN)
                        EditorSwitch(if (tlsLocked) "TLS (обязателен для этого протокола)" else "TLS", draft.tls.enabled, enabled = !tlsLocked) {
                            draft=draft.copy(tls=draft.tls.copy(enabled=it))
                        }
                        if (draft.tls.enabled) {
                            EditorField("SNI",draft.tls.serverName.orEmpty()) { draft=draft.copy(tls=draft.tls.copy(serverName=it.ifBlank { null })) }
                            EditorField("ALPN через запятую",draft.tls.alpn.joinToString(",")) { draft=draft.copy(tls=draft.tls.copy(alpn=it.split(',').map { a->a.trim() }.filter { a->a.isNotEmpty() })) }
                            // uTLS and Reality are TCP-stack features: QUIC protocols reject them.
                            if (draft.protocol !in setOf(VpnProtocol.HYSTERIA2,VpnProtocol.TUIC))
                                EditorField("uTLS fingerprint (chrome, firefox, safari…)",draft.tls.fingerprint.orEmpty()) { draft=draft.copy(tls=draft.tls.copy(fingerprint=it.ifBlank { null })) }
                            EditorSwitch("НЕ проверять сертификат (опасно)", draft.tls.allowInsecure) { draft=draft.copy(tls=draft.tls.copy(allowInsecure=it)) }
                            if(draft.tls.allowInsecure) Text("Сервер может быть подменён. Предпочитайте корректный сертификат и SNI.",color=MaterialTheme.colorScheme.error)
                            if(draft.protocol==VpnProtocol.VLESS) {
                                EditorField("Reality public key (пусто — без Reality)",draft.tls.reality?.publicKey.orEmpty()) { key ->
                                    draft=draft.copy(tls=draft.tls.copy(reality=if(key.isBlank()) null else (draft.tls.reality ?: RealitySettings(key)).copy(publicKey=key)))
                                }
                                draft.tls.reality?.let { r ->
                                    EditorField("Reality short ID",r.shortId.orEmpty()) { draft=draft.copy(tls=draft.tls.copy(reality=r.copy(shortId=it.ifBlank { null }))) }
                                    EditorField("Reality spiderX",r.spiderX.orEmpty()) { draft=draft.copy(tls=draft.tls.copy(reality=r.copy(spiderX=it.ifBlank { null }))) }
                                }
                            }
                        }
                    }
                    // Protocol-specific knobs used to be reachable only by hand-editing the URL.
                    if(draft.protocol==VpnProtocol.HYSTERIA2) {
                        EditorSwitch("Обфускация salamander", draft.parameters["obfs"]=="salamander") {
                            setParam("obfs", if (it) "salamander" else null)
                            if (!it) setParam("obfs-password", null)
                        }
                        if (draft.parameters["obfs"]=="salamander")
                            EditorField("obfs-password",draft.parameters["obfs-password"].orEmpty(),secret=!reveal) { setParam("obfs-password", it) }
                        EditorField("Полоса вверх, Мбит/с (upmbps)",draft.parameters["upmbps"].orEmpty(),numeric=true) { setParam("upmbps", it) }
                        EditorField("Полоса вниз, Мбит/с (downmbps)",draft.parameters["downmbps"].orEmpty(),numeric=true) { setParam("downmbps", it) }
                        EditorField("Диапазон портов (mport, например 20000-30000)",draft.parameters["mport"].orEmpty()) { setParam("mport", it) }
                        EditorField("Интервал прыжков (hop_interval, например 30s)",draft.parameters["hop_interval"].orEmpty()) { setParam("hop_interval", it) }
                    }
                    if(draft.protocol==VpnProtocol.TUIC) {
                        ChipRow("congestion_control", TuicCongestion, TuicCongestion.indexOf(draft.parameters["congestion_control"] ?: "—")) {
                            setParam("congestion_control", TuicCongestion[it].takeIf { v->v!="—" })
                        }
                        ChipRow("udp_relay_mode", TuicRelay, TuicRelay.indexOf(draft.parameters["udp_relay_mode"] ?: "—")) {
                            setParam("udp_relay_mode", TuicRelay[it].takeIf { v->v!="—" })
                        }
                        EditorSwitch("udp_over_stream", draft.parameters["udp_over_stream"] in setOf("1","true")) { setParam("udp_over_stream", if (it) "true" else null) }
                        EditorSwitch("zero_rtt_handshake", draft.parameters["zero_rtt_handshake"] in setOf("1","true")) { setParam("zero_rtt_handshake", if (it) "true" else null) }
                        EditorField("heartbeat (например 10s)",draft.parameters["heartbeat"].orEmpty()) { setParam("heartbeat", it) }
                    }
                    if(draft.protocol==VpnProtocol.SOCKS)
                        ChipRow("Версия SOCKS", SocksVersions, SocksVersions.indexOf(draft.parameters["version"] ?: "5")) { setParam("version", SocksVersions[it]) }
                }
                // One honest verdict, always visible, from the same validator the tunnel uses.
                if (verdict == null) Text("Ядро принимает этот ключ.", style=MaterialTheme.typography.labelLarge)
                else Text("Ядро отвергнет этот ключ: $verdict", color=MaterialTheme.colorScheme.error, style=MaterialTheme.typography.labelLarge)
                if(original.origin is ProfileOrigin.Subscription) Text("Обновление подписки может заменить эти изменения. Для независимой копии импортируйте отредактированную ссылку как ручной ключ.")
                error?.let { Text(it,color=MaterialTheme.colorScheme.error) }
            }
        },confirmButton={TextButton(onClick={
            val result=runCatching {
                val proposed=if(rawMode) requireNotNull(parser.parse(raw)) else candidate
                val normalized=requireNotNull(parser.parse(parser.export(proposed)))
                require(normalized.name.isNotBlank())
                // Do not discard unsupported options: incompatibility is shown in the library.
                normalized.copy(id=original.id,createdAt=original.createdAt,origin=original.origin)
            }
            result.onSuccess(onSave).onFailure { error="Не сохранено: проверьте адрес, порт, UUID, пароль и синтаксис ссылки" }
        }){Text("Сохранить")}},dismissButton={TextButton(onClick=onDismiss){Text("Отмена")}})
}

/** Only these carry a V2Ray transport layer; the rest are single-stack by design. */
private val TransportCapable = setOf(VpnProtocol.VLESS, VpnProtocol.VMESS, VpnProtocol.TROJAN)
private val VmessSecurity = listOf("auto", "aes-128-gcm", "chacha20-poly1305", "none")
private val PacketEncodings = listOf("—", "xudp", "packetaddr")
private val TuicCongestion = listOf("—", "cubic", "new_reno", "bbr")
private val TuicRelay = listOf("—", "native", "quic")
private val SocksVersions = listOf("5", "4a", "4")

@Composable
private fun ChipRow(label: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Text(label, style = MaterialTheme.typography.labelMedium)
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { index, option ->
            FilterChip(selected = index == selected, onClick = { onSelect(index) }, label = { Text(option) })
        }
    }
}

@Composable
private fun EditorSwitch(label: String, value: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f)); Switch(value, onChange, enabled = enabled)
    }
}

@Composable
private fun EditorField(label:String,value:String,secret:Boolean=false,numeric:Boolean=false,onChange:(String)->Unit) {
    OutlinedTextField(value,onChange,label={Text(label)},modifier=Modifier.fillMaxWidth(),singleLine=true,
        keyboardOptions=KeyboardOptions(keyboardType=if(numeric) KeyboardType.Number else KeyboardType.Text),
        visualTransformation=if(secret) PasswordVisualTransformation() else VisualTransformation.None)
}
