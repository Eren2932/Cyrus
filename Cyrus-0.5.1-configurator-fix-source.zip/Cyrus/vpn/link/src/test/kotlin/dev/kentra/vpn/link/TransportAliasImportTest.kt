package dev.kentra.vpn.link

import dev.kentra.domain.model.TransportCompat
import org.junit.Assert.assertEquals
import org.junit.Test

/** Keys from panels that renamed transports must import as first-class, not as errors. */
class TransportAliasImportTest {
    private val parser = DefaultLinkParser({ "fixed-id" }, { 0L })
    private val uuid = "11111111-2222-3333-4444-555555555555"

    @Test fun `xray raw key imports as tcp`() {
        val p = parser.parse("vless://$uuid@host.test:443?type=raw&security=reality&pbk=key&sid=ab#Node")!!
        assertEquals("tcp", p.transport.type)
    }

    @Test fun `h2 gun and websocket aliases import canonically`() {
        assertEquals("http", parser.parse("vless://$uuid@host.test:443?type=h2&path=/p")!!.transport.type)
        assertEquals("grpc", parser.parse("vless://$uuid@host.test:443?type=gun&serviceName=svc")!!.transport.type)
        assertEquals("ws", parser.parse("vless://$uuid@host.test:443?type=WebSocket&path=/w")!!.transport.type)
    }

    @Test fun `vmess net alias is normalized too`() {
        val body = """{"v":"2","ps":"n","add":"host.test","port":"443","id":"$uuid","net":"raw","tls":"tls"}"""
        val encoded = java.util.Base64.getEncoder().encodeToString(body.toByteArray())
        assertEquals("tcp", parser.parse("vmess://$encoded")!!.transport.type)
    }

    @Test fun `unsupported transport still imports so the user can inspect and fix it`() {
        val p = parser.parse("vless://$uuid@host.test:443?type=splithttp&path=/x")!!
        assertEquals("xhttp", p.transport.type)
        assertEquals(TransportCompat.XRAY_ONLY.contains(p.transport.type), true)
    }

    @Test fun `round trip through export keeps the canonical transport`() {
        val p = parser.parse("vless://$uuid@host.test:443?type=raw&security=tls#Node")!!
        val again = parser.parse(parser.export(p))!!
        assertEquals("tcp", again.transport.type)
        assertEquals(p.connectionIdentity(), again.connectionIdentity())
    }
}
