package dev.kentra.vpn.config

import dev.kentra.domain.model.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TransportCompatConfigTest {
    private val base = VpnProfile(
        id = "id", name = "n", protocol = VpnProtocol.VLESS, server = "host.test", port = 443,
        uuid = "11111111-2222-3333-4444-555555555555", tls = TlsSettings(enabled = true),
    )
    private fun outbound(p: VpnProfile) = ConfigFactory().config(p, TunnelOptions()).outbounds.first()

    @Test fun `raw transport produces no transport block, exactly like tcp`() {
        assertNull(outbound(base.copy(transport = TransportSettings("raw"))).transport)
        assertNull(outbound(base.copy(transport = TransportSettings("tcp"))).transport)
    }

    @Test fun `h2 becomes the http transport and gun becomes grpc`() {
        assertEquals("http", outbound(base.copy(transport = TransportSettings("h2", "/p", "cdn.example"))).transport?.type)
        assertEquals("grpc", outbound(base.copy(transport = TransportSettings("gun", serviceName = "svc"))).transport?.type)
    }

    @Test fun `grpc falls back to path when serviceName is absent`() {
        assertEquals("svc", outbound(base.copy(transport = TransportSettings("grpc", "svc"))).transport?.serviceName)
    }

    @Test fun `xray only transport is refused with an actionable message`() {
        for (type in listOf("xhttp", "splithttp", "kcp", "quic")) {
            val error = runCatching { ConfigFactory().validateProfile(base.copy(transport = TransportSettings(type))) }.exceptionOrNull()
            assertTrue("must fail: $type", error is IllegalArgumentException)
            assertTrue("must mention Xray: ${error?.message}", error!!.message!!.contains("Xray"))
        }
    }

    @Test fun `alias keys are no longer rejected by name`() {
        for (type in listOf("raw", "RAW", "h2", "gun", "WebSocket", "http-upgrade")) {
            ConfigFactory().validateProfile(base.copy(transport = TransportSettings(type)))
        }
    }
}
