package dev.kentra.vpn.config

import dev.kentra.domain.model.TransportCompat
import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.model.VpnProtocol
import kotlinx.serialization.json.*

enum class ConnectionMode { VPN, PROXY }

/** User-tunable knobs that must never leak into the UI layer as raw JSON. */
data class TunnelOptions(
    val mode: ConnectionMode = ConnectionMode.VPN,
    val proxyPort: Int = 2080,
    val mtu: Int = 9000,
    /** "system" is lighter on battery, "gvisor" is more compatible. */
    val stack: String = "system",
    val bypassLan: Boolean = true,
    val blockAds: Boolean = false,
    val ipv6: Boolean = false,
    val perAppMode: PerAppMode = PerAppMode.Off,
    val dnsRemote: String = "tls://1.1.1.1",
    val dnsLocal: String = "local",
    val enableMultiplex: Boolean = false,
    val logLevel: String = "warn",
)

sealed interface PerAppMode {
    data object Off : PerAppMode
    data class Include(val packages: List<String>) : PerAppMode
    data class Exclude(val packages: List<String>) : PerAppMode
}

/**
 * The single place where a [VpnProfile] becomes a sing-box configuration.
 * Covered by golden tests: if you change output, you must update the golden file consciously.
 */
class ConfigFactory(
    private val json: Json = Json {
        prettyPrint = true
        encodeDefaults = true
        explicitNulls = false
    },
) {

    fun build(profile: VpnProfile, options: TunnelOptions = TunnelOptions()): String =
        json.encodeToString(SingBoxConfig.serializer(), config(profile, options))

    fun config(profile: VpnProfile, options: TunnelOptions): SingBoxConfig {
        options.validate()
        validateProfile(profile)
        require(!options.enableMultiplex || profile.flow != "xtls-rprx-vision") { "Multiplex несовместим с Vision: отключите его в настройках" }
        val proxyTag = "proxy"
        return SingBoxConfig(
            log = LogConfig(level = options.logLevel),
            dns = dns(options),
            inbounds = listOf(if (options.mode == ConnectionMode.VPN) tun(options) else
                Inbound(type = "mixed", tag = "proxy-in", listen = "127.0.0.1", listenPort = options.proxyPort, sniff = true)),
            outbounds = listOf(
                outbound(profile, proxyTag, options),
                Outbound(type = "direct", tag = "direct"),
                Outbound(type = "block", tag = "block"),
                Outbound(type = "dns", tag = "dns-out"),
            ),
            route = route(proxyTag, options),
        )
    }

    fun validateProfile(profile: VpnProfile) {
        require(profile.protocol != VpnProtocol.UNKNOWN) { "Неизвестный протокол" }
        require(profile.server.isNotBlank() && profile.port in 1..65535) { "Некорректный адрес или порт" }
        // Synonyms (raw, h2, gun, websocket) are canonicalised first: a supported
        // transport must never be refused because of the name a panel chose.
        val transportType = TransportCompat.normalize(profile.transport.type)
        TransportCompat.singBoxRejection(transportType)?.let { reason -> throw IllegalArgumentException(reason) }
        val q = profile.parameters
        require("pinSHA256" !in q) { "Этот ключ требует pinSHA256: закреплённое ядро не реализует проверку pin; ключ не запускается без неё" }
        require(q.keys.none { it in setOf("extra", "ech", "echConfigList", "pqv", "pinSHA256", "cyrus-unsupported") }) {
            "Ключ содержит расширение, которое этот адаптер не реализует"
        }
        require(q["mode"] in listOf(null, "", "gun")) { "gRPC multiMode / XHTTP mode не поддерживаются этим ядром" }
        require(q["headerType"] in listOf(null, "", "none")) { "TCP header camouflage не поддерживается" }
        require(q["encryption"] in listOf(null, "", "none")) { "VLESS encryption не поддерживается этим ядром" }
        require(q["security"] in listOf(null, "", "none", "tls", "reality")) { "Неизвестная защита транспорта" }
        if (profile.protocol in setOf(VpnProtocol.HYSTERIA2, VpnProtocol.TUIC, VpnProtocol.TROJAN))
            require(profile.tls.enabled) { "Этот протокол требует TLS" }
        if (profile.protocol !in setOf(VpnProtocol.VLESS, VpnProtocol.VMESS, VpnProtocol.TROJAN))
            require(transportType == "tcp") { "V2Ray-транспорт не применим к этому протоколу" }
        if (profile.protocol in setOf(VpnProtocol.HYSTERIA2, VpnProtocol.TUIC))
            require(profile.tls.reality == null && profile.tls.fingerprint == null) { "Reality/uTLS не применимы к QUIC-протоколу" }
        if ("plugin" in q) require(profile.protocol == VpnProtocol.SHADOWSOCKS &&
            q.getValue("plugin").substringBefore(';') in setOf("obfs-local", "v2ray-plugin")) { "SIP003 plugin не встроен в ядро" }
        if ("obfs" in q || "obfs-password" in q) require(profile.protocol == VpnProtocol.HYSTERIA2 &&
            q["obfs"] == "salamander" && !q["obfs-password"].isNullOrEmpty()) { "Нужны obfs=salamander и obfs-password" }
        for (key in listOf("upmbps", "downmbps", "ed")) q[key]?.let {
            require((it.toIntOrNull() ?: -1) in 1..1_000_000) { "Некорректный числовой параметр" }
        }
        q["congestion_control"]?.let { require(profile.protocol == VpnProtocol.TUIC && it in setOf("cubic", "new_reno", "bbr")) { "Неизвестный congestion_control" } }
        q["udp_relay_mode"]?.let { require(profile.protocol == VpnProtocol.TUIC && it in setOf("native", "quic")) { "Неизвестный udp_relay_mode" } }
        for (key in listOf("udp_over_stream", "zero_rtt_handshake")) q[key]?.let {
            require(profile.protocol == VpnProtocol.TUIC && it in setOf("true", "false", "1", "0")) { "Некорректный TUIC флаг" }
        }
        q["mport"]?.let { ports ->
            require(profile.protocol == VpnProtocol.HYSTERIA2 && ports.split(',').all { range ->
                val ends = range.replace('-', ':').split(':').map { it.toIntOrNull() ?: 0 }
                ends.size in 1..2 && ends.all { it in 1..65535 } && ends.first() <= ends.last()
            }) { "Некорректный диапазон Hysteria2 портов" }
        }
        for (key in listOf("hop_interval", "heartbeat")) q[key]?.let {
            require(Regex("[1-9][0-9]*(ms|s|m)").matches(it)) { "Некорректный интервал" }
            require(if (key == "heartbeat") profile.protocol == VpnProtocol.TUIC else profile.protocol == VpnProtocol.HYSTERIA2) { "Интервал не применим к этому протоколу" }
        }
        q["packetEncoding"]?.let { require(it in setOf("xudp", "packetaddr")) { "Неизвестный packetEncoding" } }
    }

    private fun dns(options: TunnelOptions) = DnsConfig(
        servers = listOf(
            DnsServer(tag = "dns-remote", address = options.dnsRemote, addressResolver = "dns-direct", detour = "proxy"),
            DnsServer(tag = "dns-direct", address = options.dnsLocal, detour = "direct"),
        ),
        rules = listOf(
            DnsRule(outbound = listOf("any"), server = "dns-direct", disableCache = true),
        ),
        strategy = if (options.ipv6) "prefer_ipv4" else "ipv4_only",
        final = "dns-remote",
    )

    private fun tun(options: TunnelOptions) = Inbound(
        type = "tun",
        tag = "tun-in",
        interfaceName = "tun0",
        address = buildList {
            add("172.19.0.1/28")
            if (options.ipv6) add("fdfe:dcba:9876::1/126")
        },
        mtu = options.mtu,
        autoRoute = true,
        strictRoute = false,
        stack = options.stack,
        sniff = true,
        sniffOverrideDestination = false,
        endpointIndependentNat = true,
        includePackage = (options.perAppMode as? PerAppMode.Include)?.packages,
        excludePackage = (options.perAppMode as? PerAppMode.Exclude)?.packages,
    )

    private fun outbound(profile: VpnProfile, tag: String, options: TunnelOptions): Outbound {
        val tls = profile.tls.takeIf { it.enabled }?.let { t ->
            OutboundTls(
                enabled = true,
                serverName = t.serverName ?: profile.server,
                insecure = t.allowInsecure.takeIf { it },
                alpn = t.alpn.takeIf { it.isNotEmpty() },
                utls = t.fingerprint?.let { Utls(fingerprint = it) }
                    ?: t.reality?.let { Utls(fingerprint = "chrome") },
                reality = t.reality?.let { Reality(publicKey = it.publicKey, shortId = it.shortId) },
            )
        }
        val transportType = TransportCompat.normalize(profile.transport.type)
        val transport = profile.transport.takeIf { transportType != "tcp" }?.let { tr ->
            OutboundTransport(
                type = transportType,
                path = tr.path.takeIf { transportType != "grpc" },
                headers = tr.host?.takeIf { transportType == "ws" }?.let { mapOf("Host" to it) },
                host = tr.host?.let { h -> when (transportType) {
                    "http" -> JsonArray(h.split(',').map { JsonPrimitive(it.trim()) })
                    "httpupgrade" -> JsonPrimitive(h)
                    else -> null
                } },
                serviceName = (tr.serviceName ?: tr.path).takeIf { transportType == "grpc" },
                maxEarlyData = profile.parameters["ed"]?.toIntOrNull().takeIf { transportType == "ws" },
                earlyDataHeaderName = profile.parameters["eh"].takeIf { transportType == "ws" },
            )
        }
        val multiplex = Multiplex(enabled = options.enableMultiplex).takeIf { options.enableMultiplex }

        return when (profile.protocol) {
            VpnProtocol.VLESS -> Outbound(
                type = "vless",
                tag = tag,
                server = profile.server,
                serverPort = profile.port,
                uuid = profile.uuid,
                flow = profile.flow?.takeIf { it.isNotBlank() },
                tls = tls,
                transport = transport,
                multiplex = multiplex,
                domainStrategy = if (options.ipv6) "prefer_ipv4" else "ipv4_only",
                packetEncoding = profile.parameters["packetEncoding"],
            )
            VpnProtocol.VMESS -> Outbound(
                type = "vmess",
                tag = tag,
                server = profile.server,
                serverPort = profile.port,
                uuid = profile.uuid,
                security = profile.parameters["scy"] ?: "auto",
                packetEncoding = profile.parameters["packetEncoding"],
                alterId = profile.alterId ?: 0,
                tls = tls,
                transport = transport,
                multiplex = multiplex,
            )
            VpnProtocol.TROJAN -> Outbound(
                type = "trojan",
                tag = tag,
                server = profile.server,
                serverPort = profile.port,
                password = profile.password,
                tls = tls,
                transport = transport,
                multiplex = multiplex,
            )
            VpnProtocol.SHADOWSOCKS -> Outbound(
                type = "shadowsocks",
                tag = tag,
                server = profile.server,
                serverPort = profile.port,
                method = profile.method,
                plugin = profile.parameters["plugin"]?.substringBefore(';'),
                pluginOpts = profile.parameters["plugin"]?.substringAfter(';', ""),
                password = profile.password,
                multiplex = multiplex,
            )
            VpnProtocol.HYSTERIA2 -> Outbound(
                type = "hysteria2",
                obfs = profile.parameters["obfs"]?.let { HysteriaObfs(it, profile.parameters.getValue("obfs-password")) },
                upMbps = profile.parameters["upmbps"]?.toIntOrNull(),
                downMbps = profile.parameters["downmbps"]?.toIntOrNull(),
                serverPorts = profile.parameters["mport"]?.split(',')?.map { it.replace('-', ':') },
                hopInterval = profile.parameters["hop_interval"],
                tag = tag,
                server = profile.server,
                serverPort = profile.port,
                password = profile.password,
                tls = tls ?: OutboundTls(enabled = true, serverName = profile.server),
            )
            VpnProtocol.TUIC -> Outbound(
                type = "tuic",
                congestionControl = profile.parameters["congestion_control"],
                udpRelayMode = profile.parameters["udp_relay_mode"],
                udpOverStream = profile.parameters["udp_over_stream"]?.let { it == "true" || it == "1" },
                zeroRttHandshake = profile.parameters["zero_rtt_handshake"]?.let { it == "true" || it == "1" },
                heartbeat = profile.parameters["heartbeat"],
                tag = tag,
                server = profile.server,
                serverPort = profile.port,
                uuid = profile.uuid,
                password = profile.password,
                tls = tls ?: OutboundTls(enabled = true, serverName = profile.server),
            )
            VpnProtocol.SOCKS -> Outbound(type = "socks", tag = tag, server = profile.server,
                serverPort = profile.port, username = profile.parameters["username"], password = profile.password,
                version = profile.parameters["version"] ?: "5")
            VpnProtocol.HTTP -> Outbound(type = "http", tag = tag, server = profile.server,
                serverPort = profile.port, username = profile.parameters["username"], password = profile.password, tls = tls)
            VpnProtocol.UNKNOWN -> error("Неизвестный протокол")
        }
    }

    private fun route(proxyTag: String, options: TunnelOptions): RouteConfig {
        val rules = buildList {
            add(RouteRule(protocol = listOf("dns"), outbound = "dns-out"))
            if (options.bypassLan) add(RouteRule(ipIsPrivate = true, outbound = "direct"))
            // NOTE: do not add a blanket "udp/443 -> block" (QUIC) rule here. The block
            // outbound fails every packet with a bare syscall.EPERM, which apps treat as a
            // dead network and often never fall back from QUIC to TCP ("no internet").
            if (options.blockAds) add(RouteRule(ruleSet = listOf("geosite-ads"), outbound = "block"))

        }
        val sets = buildList {
            if (options.blockAds) {
                add(
                    RuleSet(
                        tag = "geosite-ads",
                        url = "https://raw.githubusercontent.com/SagerNet/sing-geosite/rule-set/geosite-category-ads-all.srs",
                        downloadDetour = "direct",
                    ),
                )
            }
        }
        return RouteConfig(rules = rules, ruleSet = sets, final = proxyTag)
    }
}
