package dev.kentra.feature.store

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.kentra.core.designsystem.*
import dev.kentra.core.ui.CollectEffects
import org.koin.androidx.compose.koinViewModel
import java.text.NumberFormat
import java.util.Locale

@Composable
fun StoreRoute(onImport: () -> Unit, viewModel: StoreViewModel = koinViewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    CollectEffects(viewModel.effects) { if(it is StoreEffect.ShowMessage) snackbar.showSnackbar(it.text) }
    Scaffold(containerColor=MaterialTheme.colorScheme.background,contentWindowInsets=WindowInsets(0,0,0,0),snackbarHost={SnackbarHost(snackbar)}) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding),contentPadding=PaddingValues(start=20.dp,end=20.dp,bottom=28.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
            item { SectionHeading("Cyrus Plus", "Больше свободы", "Тарифы нашей подписки. Ваши сторонние ключи всегда можно добавить бесплатно.") }
            items(state.plans,key={it.id}) { plan ->
                CyrusCard(highlighted=plan.highlighted) {
                    if(plan.highlighted) Text("ОПТИМАЛЬНЫЙ ПЕРИОД",style=MaterialTheme.typography.labelSmall,color=CyrusTokens.Accent)
                    Text(plan.name,style=MaterialTheme.typography.titleLarge)
                    Text("${formatPrice(plan.priceMinor)} ₽",style=MaterialTheme.typography.displaySmall)
                    Text("за весь период · ${plan.days} дней",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                    HorizontalDivider(Modifier.padding(vertical=8.dp),color=MaterialTheme.colorScheme.outlineVariant)
                    Text("До ${plan.deviceLimit} устройств",style=MaterialTheme.typography.bodyMedium)
                    if(plan.days>30) {
                        val months=if(plan.id=="m12") 12 else 3
                        Text("≈ ${formatPrice(plan.priceMinor/months)} ₽ / месяц",style=MaterialTheme.typography.labelSmall,color=CyrusTokens.Accent)
                    }
                }
            }
            item {
                CyrusCard {
                    Text("Каталог тарифов",style=MaterialTheme.typography.titleMedium)
                    Text("Продажи в этой сборке не открыты. Оплата не списывается, заказы и подписки не создаются.",style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            item {
                Button(onClick=onImport,modifier=Modifier.fillMaxWidth().heightIn(min=54.dp)) { Text("Уже есть ключ? Добавить бесплатно") }
            }
            item { Text("Приём платежей, выдача персональных ключей и условия продаж должны быть подключены и проверены перед открытием магазина.",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
}
private fun formatPrice(minor:Long):String = NumberFormat.getNumberInstance(Locale.forLanguageTag("ru-RU")).apply {
    maximumFractionDigits=2
}.format(minor/100.0)
