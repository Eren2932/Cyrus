package dev.kentra.feature.home

import androidx.compose.runtime.getValue
import android.app.Activity
import android.net.VpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.heightIn
import androidx.compose.ui.unit.dp
import dev.kentra.core.designsystem.SectionHeading
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.kentra.core.designsystem.ConnectOrb
import dev.kentra.core.designsystem.CyrusCard
import dev.kentra.core.designsystem.CyrusTheme
import dev.kentra.core.designsystem.CyrusTokens
import dev.kentra.core.designsystem.StatPill
import dev.kentra.core.ui.CollectEffects
import dev.kentra.core.ui.formatBytes
import dev.kentra.core.ui.formatSpeed
import dev.kentra.domain.model.TunnelState
import org.koin.androidx.compose.koinViewModel

@Composable
fun HomeRoute(
    onNavigateToProfiles: () -> Unit,
    viewModel: HomeViewModel = koinViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }

    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        viewModel.dispatch(
            if (result.resultCode == Activity.RESULT_OK) HomeIntent.VpnPermissionGranted
            else HomeIntent.VpnPermissionDenied,
        )
    }

    CollectEffects(viewModel.effects) { effect ->
        when (effect) {
            HomeEffect.RequestVpnPermission ->
                VpnService.prepare(context)?.let { vpnPermissionLauncher.launch(it) }
                    ?: viewModel.dispatch(HomeIntent.VpnPermissionGranted)
            HomeEffect.NavigateToProfiles -> onNavigateToProfiles()
            is HomeEffect.ShowMessage -> snackbar.showSnackbar(effect.text)
        }
    }

    Scaffold(containerColor = MaterialTheme.colorScheme.background, contentWindowInsets = WindowInsets(0,0,0,0), snackbarHost = { SnackbarHost(snackbar) }) { padding ->
        HomeContent(
            state = state,
            onToggle = { viewModel.dispatch(HomeIntent.ToggleConnection) },
            onPickProfile = { viewModel.dispatch(HomeIntent.OpenProfiles) },
            modifier = Modifier.padding(padding),
        )
    }
}

@Composable
private fun HomeContent(
    state: HomeState,
    onToggle: () -> Unit,
    onPickProfile: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(CyrusTokens.SpaceMd),
    ) {
        SectionHeading("Сеть под вашим контролем", "Cyrus", "Личная библиотека ключей и подписок")

        ConnectOrb(
            label = if (state.activeProfile == null) "Добавить первый ключ" else "Проверить готовность",
            sublabel = state.activeProfile?.name ?: "Ключ не выбран",
            active = state.tunnel is TunnelState.Connected,
            busy = state.busy,
            onClick = onToggle,
        )

        Row(horizontalArrangement = Arrangement.spacedBy(CyrusTokens.SpaceSm)) {
            StatPill(title = "Ключей", value = state.profileCount.toString(), modifier = Modifier.weight(1f))
            StatPill(title = "Отдано", value = state.traffic.uplinkBytes.formatBytes())
        }

        CyrusCard {
            Text("VPN-ядро не установлено", style = MaterialTheme.typography.titleMedium, color = CyrusTokens.Warning)
            Text("Импорт и управление ключами доступны. Сетевой туннель в этой сборке не создаётся; ваш трафик не защищён Cyrus.", style = MaterialTheme.typography.bodyMedium)
            Text("Не показываем выдуманный IP, пинг или трафик. Состояние подключения появится только после интеграции настоящего ядра.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        CyrusCard {
            Text("Текущий ключ", style = MaterialTheme.typography.labelSmall)
            Text(
                text = state.activeProfile?.let { "${it.name} · ${it.protocol.name} · ${it.displayEndpoint}" }
                    ?: "Добавьте ключ: вставьте ссылку vless/trojan/ss или подписку",
                style = MaterialTheme.typography.bodyMedium,
            )
            Spacer(Modifier.height(CyrusTokens.SpaceSm))
            Text(
                text = "${if (state.activeProfile?.tls?.enabled == true) "TLS включён в ключе" else "TLS не задан"} · Секреты зашифрованы на устройстве",
                style = MaterialTheme.typography.labelSmall,
            )
            Spacer(Modifier.height(CyrusTokens.SpaceSm))
            OutlinedButton(onClick = onPickProfile, modifier = Modifier.fillMaxWidth()) {
                Text(if (state.profileCount == 0) "Добавить ключ" else "Выбрать другой (${state.profileCount})")
            }
        }
    }
}

private fun TunnelState.label(): String = when (this) {
    TunnelState.Idle -> "Подключить"
    TunnelState.Preparing -> "Подключение…"
    is TunnelState.Connected -> "Отключить"
    TunnelState.Stopping -> "Отключение…"
    is TunnelState.Failed -> "Повторить"
}

@Composable
private fun HomePreview() {
    CyrusTheme {
        HomeContent(state = HomeState(), onToggle = {}, onPickProfile = {})
    }
}
