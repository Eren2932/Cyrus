package dev.kentra.core.designsystem

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

@Composable
fun CyrusCard(modifier: Modifier = Modifier, highlighted: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier = modifier.fillMaxWidth(), shape = RoundedCornerShape(CyrusTokens.RadiusCard),
        border = BorderStroke(1.dp, if (highlighted) MaterialTheme.colorScheme.primary.copy(alpha = .55f) else MaterialTheme.colorScheme.outlineVariant),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
    }
}

@Composable
fun SectionHeading(eyebrow: String, title: String, description: String) {
    Column(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 20.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text(eyebrow.uppercase(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
        Text(title, style = MaterialTheme.typography.headlineLarge)
        Text(description, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun ConnectOrb(label: String, sublabel: String, active: Boolean, busy: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val interactions = remember { MutableInteractionSource() }
    val pressed by interactions.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) .95f else 1f, tween(CyrusMotion.Fast), label = "press")
    val color by animateColorAsState(if (active) CyrusTokens.Accent else MaterialTheme.colorScheme.surfaceVariant,
        tween(CyrusMotion.Screen), label = "connection")
    val foreground = if (active) CyrusTokens.OnAccent else MaterialTheme.colorScheme.onSurface
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Box(modifier.size(184.dp).scale(scale).border(1.dp, CyrusTokens.Accent.copy(alpha = .25f), CircleShape).padding(10.dp)
            .clip(CircleShape).background(color)
            .clickable(enabled = !busy, role = Role.Button, interactionSource = interactions, indication = null, onClick = onClick)
            .semantics { contentDescription = label }, contentAlignment = Alignment.Center) {
            if (busy) CircularProgressIndicator(color = CyrusTokens.Accent, modifier = Modifier.size(58.dp), strokeWidth = 3.dp)
            else CyrusIcon(CyrusSymbol.Power, Modifier.size(52.dp), color = if (active) foreground else CyrusTokens.Accent)
        }
        Text(label, style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
        Text(sublabel, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium,
            maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
    }
}

@Composable
fun StatPill(title: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(MaterialTheme.colorScheme.surface, RoundedCornerShape(18.dp)).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text(title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.titleMedium)
    }
}

enum class CyrusSymbol { Shield, Key, Store, Power, Plus, Arrow, Check }
@Composable
fun CyrusIcon(symbol: CyrusSymbol, modifier: Modifier = Modifier, color: Color = MaterialTheme.colorScheme.onSurface) {
    Canvas(modifier.size(24.dp)) {
        val s = size.minDimension / 24f
        fun point(x: Float, y: Float) = Offset(x * s, y * s)
        val stroke = Stroke(width = 1.8f * s, cap = StrokeCap.Round)
        fun line(x: Float, y: Float, x2: Float, y2: Float) = drawLine(color, point(x,y), point(x2,y2), 1.8f*s, StrokeCap.Round)
        when (symbol) {
            CyrusSymbol.Power -> { drawArc(color, -48f, 276f, false, point(4f,4f), androidx.compose.ui.geometry.Size(16*s,16*s), style=stroke); line(12f,2f,12f,11f) }
            CyrusSymbol.Shield -> {
                val path = Path().apply { moveTo(12*s,2*s); lineTo(20*s,5*s); lineTo(20*s,12*s); cubicTo(20*s,17*s,15*s,21*s,12*s,22*s); cubicTo(9*s,21*s,4*s,17*s,4*s,12*s); lineTo(4*s,5*s); close() }
                drawPath(path,color,style=stroke); line(8f,12f,11f,15f); line(11f,15f,16f,9f)
            }
            CyrusSymbol.Key -> { drawCircle(color,5*s,point(8f,8f),style=stroke); line(11.5f,11.5f,21f,21f); line(16f,16f,19f,13f); line(19f,19f,22f,16f) }
            CyrusSymbol.Store -> { drawRoundRect(color,point(3f,6f),androidx.compose.ui.geometry.Size(18*s,15*s),androidx.compose.ui.geometry.CornerRadius(3*s),style=stroke); line(8f,6f,8f,3f); line(8f,3f,16f,3f); line(16f,3f,16f,6f); line(8f,12f,16f,12f) }
            CyrusSymbol.Plus -> { line(12f,5f,12f,19f); line(5f,12f,19f,12f) }
            CyrusSymbol.Arrow -> { line(5f,12f,19f,12f); line(14f,7f,19f,12f); line(19f,12f,14f,17f) }
            CyrusSymbol.Check -> { line(5f,12f,10f,17f); line(10f,17f,19f,7f) }
        }
    }
}
