package dev.kentra.core.designsystem

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Brand & matte palette verified against ZiziPlayer 6.27.0 / desktop 0.3.4 source. */
object CyrusTokens {
    val Accent = Color(0xFFF97316)
    val OnAccent = Color(0xFF1B0C00)
    val AccentPressed = Color(0xFFEA580C)
    val Danger = Color(0xFFFF8585)
    val Warning = Color(0xFFF8C578)
    val SurfaceDark = Color(0xFF000000)
    val SurfaceDarkElevated = Color(0xFF101010)
    val SurfaceControl = Color(0xFF1B1B1B)
    val OnDark = Color(0xFFF6F7F8)
    val OnDarkMuted = Color(0xFF9A9A9A)
    val RadiusCard = 24.dp
    val RadiusControl = 16.dp
    val SpaceXs = 4.dp
    val SpaceSm = 8.dp
    val SpaceMd = 16.dp
    val SpaceLg = 24.dp
    val SpaceXl = 32.dp
}

object CyrusMotion {
    const val Fast = 160
    const val Screen = 260
    const val Settle = 340
    val Ease = FastOutSlowInEasing
}

private val DarkScheme = darkColorScheme(
    primary = CyrusTokens.Accent, onPrimary = CyrusTokens.OnAccent,
    primaryContainer = Color(0xFF382012), onPrimaryContainer = CyrusTokens.Accent,
    secondary = CyrusTokens.Accent, onSecondary = CyrusTokens.OnAccent,
    secondaryContainer = CyrusTokens.SurfaceControl, onSecondaryContainer = CyrusTokens.Accent,
    background = CyrusTokens.SurfaceDark, onBackground = CyrusTokens.OnDark,
    surface = CyrusTokens.SurfaceDarkElevated, onSurface = CyrusTokens.OnDark,
    surfaceVariant = CyrusTokens.SurfaceControl, onSurfaceVariant = CyrusTokens.OnDarkMuted,
    outline = Color(0xFF393939), outlineVariant = Color(0xFF262626),
    surfaceTint = Color.Transparent, error = CyrusTokens.Danger,
)
private val LightScheme = lightColorScheme(
    primary = Color(0xFFA83D00), onPrimary = Color.White,
    background = Color(0xFFF7F7F7), surface = Color.White,
    surfaceVariant = Color(0xFFECECEC), onSurfaceVariant = Color(0xFF505050),
)
private val CyrusTypography = Typography(
    displaySmall = TextStyle(fontSize = 38.sp, fontWeight = FontWeight.Bold, letterSpacing = (-1).sp),
    headlineLarge = TextStyle(fontSize = 32.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.8).sp),
    titleLarge = TextStyle(fontSize = 23.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 21.sp),
    labelSmall = TextStyle(fontSize = 12.sp, lineHeight = 17.sp, fontWeight = FontWeight.Medium),
)
@Composable
fun CyrusTheme(darkTheme: Boolean = true, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (darkTheme) DarkScheme else LightScheme, typography = CyrusTypography, content = content)
}
