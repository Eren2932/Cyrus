package dev.kentra.core.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dev.kentra.vpn.config.TunnelOptions
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "kentra_settings")

/**
 * Non-secret settings only. Auth tokens and subscription URLs belong in the encrypted store
 * (see data/SecretCipher and SecureStorage) — never here.
 */
class SettingsStore(private val context: Context) {

    private object Keys {
        val activeProfileId = stringPreferencesKey("active_profile_id")
        val mtu = intPreferencesKey("mtu")
        val stack = stringPreferencesKey("stack")
        val bypassLan = booleanPreferencesKey("bypass_lan")
        val blockAds = booleanPreferencesKey("block_ads")
        val ipv6 = booleanPreferencesKey("ipv6")
        val dnsRemote = stringPreferencesKey("dns_remote")
        val onboardingDone = booleanPreferencesKey("onboarding_done")
    }

    val activeProfileId: Flow<String?> = context.dataStore.data.map { it[Keys.activeProfileId] }

    val tunnelOptions: Flow<TunnelOptions> = context.dataStore.data.map { prefs ->
        TunnelOptions(
            mtu = prefs[Keys.mtu] ?: 9000,
            stack = prefs[Keys.stack] ?: "system",
            bypassLan = prefs[Keys.bypassLan] ?: true,
            blockAds = prefs[Keys.blockAds] ?: false,
            ipv6 = prefs[Keys.ipv6] ?: false,
            dnsRemote = prefs[Keys.dnsRemote] ?: "tls://1.1.1.1",
        )
    }

    val onboardingDone: Flow<Boolean> = context.dataStore.data.map { it[Keys.onboardingDone] ?: false }

    suspend fun setActiveProfileId(id: String?) = context.dataStore.edit { prefs ->
        if (id == null) prefs.remove(Keys.activeProfileId) else prefs[Keys.activeProfileId] = id
    }

    suspend fun setTunnelOptions(options: TunnelOptions) = context.dataStore.edit { prefs ->
        prefs[Keys.mtu] = options.mtu
        prefs[Keys.stack] = options.stack
        prefs[Keys.bypassLan] = options.bypassLan
        prefs[Keys.blockAds] = options.blockAds
        prefs[Keys.ipv6] = options.ipv6
        prefs[Keys.dnsRemote] = options.dnsRemote
    }

    suspend fun setOnboardingDone(done: Boolean) = context.dataStore.edit { it[Keys.onboardingDone] = done }
}
