#!/usr/bin/env python3
"""Offline source invariants. Not a Kotlin compiler, Android lint or runtime test suite."""
from pathlib import Path
import re
import sys
import tomllib
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
passed=[]
def check(name, condition):
    if not condition: raise AssertionError(name)
    passed.append(name)
def text(path):return (ROOT/path).read_text(encoding='utf-8')

def delimiters(source):
    """Check Kotlin delimiter nesting, respecting comments, strings and interpolation."""
    n=len(source)
    def string(i, quote):
        i+=len(quote)
        while i<n:
            if source.startswith(quote,i):return i+len(quote)
            if quote!='"""' and source[i]=='\\':i+=2;continue
            if quote!="'" and source.startswith('${',i):i=code(i+2,'}');continue
            i+=1
        raise AssertionError('Unclosed string')
    def code(i,end=None):
        while i<n:
            if source.startswith('//',i):
                j=source.find('\n',i);i=n if j<0 else j+1;continue
            if source.startswith('/*',i):
                depth=1;i+=2
                while i<n and depth:
                    if source.startswith('/*',i):depth+=1;i+=2
                    elif source.startswith('*/',i):depth-=1;i+=2
                    else:i+=1
                if depth:raise AssertionError('Unclosed comment')
                continue
            if source.startswith('"""',i):i=string(i,'"""');continue
            ch=source[i]
            if ch in ['"',"'"]:i=string(i,ch);continue
            if ch in '([{':i=code(i+1,{'(':')','[':']','{':'}'}[ch]);continue
            if ch in ')]}':
                if ch!=end:raise AssertionError(f'Unexpected {ch} at offset {i}, expected {end}')
                return i+1
            i+=1
        if end:raise AssertionError(f'Missing {end}')
        return i
    code(0)

kt=list(ROOT.rglob('*.kt'))
for f in kt:
    try:delimiters(f.read_text())
    except AssertionError as e:raise AssertionError(f'{f.relative_to(ROOT)}: {e}') from e
check('Kotlin lexical delimiter balance',True)
for f in ROOT.rglob('*.xml'):ET.parse(f)
check('All Android XML parses',True)
tomllib.loads(text('gradle/libs.versions.toml'))
check('Version catalogue parses',True)
modules=re.findall(r'include\("(:[^\"]+)"\)',text('settings.gradle.kts'))
check('Every included Gradle module exists',all((ROOT/m.strip(':').replace(':','/')/'build.gradle.kts').exists() for m in modules))
main='\n'.join(f.read_text() for f in kt if '/src/main/' in str(f))
check('No hard Kotlin keyword variable names',not re.search(r'\b(?:val|var)\s+(?:import|class|object|when|fun|is|in|return|break|continue|interface|package|this|super)\b',main))
check('No simulator implementation in production','class SimulatedVpnEngine' not in main and 'kotlin.random.Random' not in main)
check('No fake billing repository','StubBillingRepository' not in main)
check('No phase-4 UI placeholders',not re.search(r'этап[ае]?\s*4|phase\s*4',main,re.I))
check('Brand orange preserved','0xFFF97316' in text('core/designsystem/src/main/kotlin/dev/kentra/core/designsystem/Theme.kt'))
check('Brand foreground preserved','0xFF1B0C00' in main)
check('Application identity preserved','applicationId = "dev.kentra.app"' in text('app/build.gradle.kts'))
check('Database identity preserved','"kentra.db"' in text('core/database/src/main/kotlin/dev/kentra/core/database/CyrusDatabase.kt'))
check('Backups disabled','android:allowBackup="false"' in text('app/src/main/AndroidManifest.xml'))
check('Cleartext network disabled','android:usesCleartextTraffic="false"' in text('app/src/main/AndroidManifest.xml'))
check('Release is not debug signed','signingConfig = signingConfigs.getByName("debug")' not in text('app/build.gradle.kts'))
check('Android Keystore and authenticated encryption','AES/GCM/NoPadding' in main and 'updateAAD' in main and 'AndroidKeyStore' in main)
check('Cancellation is rethrown','if (t is kotlinx.coroutines.CancellationException) throw t' in text('core/common/src/main/kotlin/dev/kentra/core/common/AppError.kt'))
check('Subscription replacement is transactional','db.withTransaction' in text('data/src/main/kotlin/dev/kentra/data/SubscriptionRepositoryImpl.kt'))
check('Subscription redirects disabled','followRedirects = false' in text('core/network/src/main/kotlin/dev/kentra/core/network/HttpClientFactory.kt'))
check('Native start precedes connected event',text('vpn/service/src/main/kotlin/dev/kentra/vpn/service/CyrusVpnService.kt').index('engine.start(')<text('vpn/service/src/main/kotlin/dev/kentra/vpn/service/CyrusVpnService.kt').index('bus.publish(TunnelState.Connected'))
check('Original link survives storage mapping','rawLink = profile.rawLink' in main and 'rawLink = transport.rawLink' in main)
check('Screenshots protected','FLAG_SECURE' in main)
check('No compiled artifacts required in source ZIP',not list(ROOT.rglob('*.apk')) and not list(ROOT.rglob('*.aar')))
for name in passed:print('PASS',name)
print(f'\n{len(passed)} source checks passed; {len(kt)} Kotlin files; {len(modules)} modules.')
print('NOT RUN: Kotlin compilation, JUnit, Android lint, emulator/device, VPN/DNS tests.')
