package dev.kentra.app

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.*
import dev.kentra.core.designsystem.*
import dev.kentra.feature.home.HomeRoute
import dev.kentra.feature.profiles.ProfilesRoute
import dev.kentra.feature.store.StoreRoute

private data class Tab(val route:String,val title:String,val icon:CyrusSymbol)
private val tabs=listOf(Tab("home","Главная",CyrusSymbol.Shield),Tab("profiles","Ключи",CyrusSymbol.Key),Tab("store","Подписка",CyrusSymbol.Store))

@Composable
fun CyrusNavHost() {
    val nav=rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val current=entry?.destination?.route ?: "home"
    fun navigate(route:String) {
        if(current!=route) nav.navigate(route) {
            popUpTo("home") { saveState=true }
            launchSingleTop=true
            restoreState=true
        }
    }
    Scaffold(containerColor=MaterialTheme.colorScheme.background,
        contentWindowInsets=WindowInsets.statusBars,
        bottomBar={
            NavigationBar(containerColor=MaterialTheme.colorScheme.background,tonalElevation=0.dp) {
                tabs.forEach { tab ->
                    NavigationBarItem(selected=current==tab.route,onClick={navigate(tab.route)},
                        icon={CyrusIcon(tab.icon,color=if(current==tab.route) CyrusTokens.Accent else MaterialTheme.colorScheme.onSurfaceVariant)},
                        label={Text(tab.title)},colors=NavigationBarItemDefaults.colors(
                            selectedTextColor=CyrusTokens.Accent,indicatorColor=Color(0xFF25180F),unselectedTextColor=MaterialTheme.colorScheme.onSurfaceVariant))
                }
            }
        }) { padding ->
        NavHost(navController=nav,startDestination="home",modifier=Modifier.padding(padding),
            enterTransition={fadeIn(tween(CyrusMotion.Screen))+slideInHorizontally(tween(CyrusMotion.Screen,easing=CyrusMotion.Ease)){it/18}},
            exitTransition={fadeOut(tween(CyrusMotion.Fast))},
            popEnterTransition={fadeIn(tween(CyrusMotion.Screen))},
            popExitTransition={fadeOut(tween(CyrusMotion.Fast))}) {
            composable("home"){HomeRoute(onNavigateToProfiles={navigate("profiles")})}
            composable("profiles"){ProfilesRoute()}
            composable("store"){StoreRoute(onImport={navigate("profiles")})}
        }
    }
}
