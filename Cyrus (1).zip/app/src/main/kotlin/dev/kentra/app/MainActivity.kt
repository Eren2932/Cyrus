package dev.kentra.app

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import dev.kentra.core.designsystem.CyrusTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(statusBarStyle=SystemBarStyle.dark(android.graphics.Color.TRANSPARENT), navigationBarStyle=SystemBarStyle.dark(android.graphics.Color.BLACK))
        // Prevent credentials appearing in screenshots, recordings or recents snapshots.
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        setContent { CyrusTheme { CyrusNavHost() } }
    }
}
