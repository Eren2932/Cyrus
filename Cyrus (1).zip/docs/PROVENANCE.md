# Происхождение исходников и дизайн-токенов

Снимки загружены 12 сентября 2026 через публичные GitHub codeload URL. Идентификаторы ниже получены из ZIP comment GitHub-архивов; история Git не клонировалась и подписи коммитов не проверялись.

## Cyrus

Репозиторий: https://github.com/Eren2932/Cyrus

Повторно загруженный HEAD snapshot: `3e786ba888e8e9a9782ccc276ae27bd6fdb55993`.

SHA-256 внешнего архива: `49dd4d14be00363181f0ec3ddac6fee770d45695c6fa0502652c84a71a241a03`.

Использован вложенный `kentra-phase1.zip`, SHA-256: `388c9714249df285561771052e1961d1a680a4948486907a24edcd06ee6bdfac`.

## ZiziPlayer

Репозиторий: https://github.com/Eren2932/ZiziPlayer

HEAD snapshot: `29db324ee27d3e1d5fa9b2597b65b8a5a445d553`.

SHA-256 внешнего архива: `1b0919d5c38b5a9e7cdfa258141b71028dba996ecc7c1274ef136b88708cc7df`.

Просмотрены mobile release/changelog документы и извлечён `releases/ZiziDesktop-0.3.4-preview-source.zip`. Архив `ZiziPlayer-APK-v6.40.2.zip` содержит APK, а не мобильные исходники; точный перенос всей текущей mobile-анимационной реализации не заявляется.

Подтверждения:

- `CHANGELOG_v6.27.0.md`, раздел «Фирменный оранжевый»: `#F97316`, `onBrand #1B0C00` и обоснование контраста.
- `src/main/kotlin/app/ziziplayer/desktop/ui/DesktopMain.kt` вложенного desktop source: строки 84/86/87 — Brand `0xFFF97316`, Panel `0xFF101010`, Chip `0xFF1B1B1B`.
- Тот же файл, около строк 1016–1020: 900 мс LinearEasing для вращения и 340 мс FastOutSlowInEasing для завершения.
- `docs/desktop/REVIEW_0.3.1.md`: матовый фон, поверхности и текст `#F6F7F8` / `#9A9A9A`.

Cyrus использует проверенные цвета и адаптированный motion-подход. Музыкальные экраны, обложки, APK, видео и весь Zizi source в результирующий ZIP не включены. Новые иконки Cyrus нарисованы отдельно Canvas-примитивами. Глобальная мобильная система жестов Zizi не переносилась.

## Артефакт

Проект переименован в Cyrus 0.2.0; technical application ID и DB ID сохранены для совместимости. В `validation/changed-files.txt` перечислены отличия от вложенного Kentra исходника. Контрольные суммы итоговых файлов находятся в `FILES.sha256`.
