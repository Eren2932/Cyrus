package dev.kentra.vpn.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import androidx.core.app.NotificationCompat
import dev.kentra.domain.model.TunnelState
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.launch
import org.koin.android.ext.android.inject

/**
 * Owns the tunnel lifecycle. It is the only component allowed to change [TunnelBus] state.
 *
 * Contract with the UI: the UI sends intents and observes state. It never assumes success.
 */
class CyrusVpnService : VpnService() {

    private val bus: TunnelBus by inject()
    private val engine: VpnEngine by inject()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default + CoroutineName("vpn"))
    private var tunnelJob: Job? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopTunnel()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                val session = TunnelSession(
                    profileId = intent.getStringExtra(EXTRA_PROFILE_ID).orEmpty(),
                    profileName = intent.getStringExtra(EXTRA_PROFILE_NAME).orEmpty(),
                    configJson = intent.getStringExtra(EXTRA_CONFIG).orEmpty(),
                )
                startTunnel(session)
                return START_STICKY
            }
            else -> return START_NOT_STICKY
        }
    }

    private fun startTunnel(session: TunnelSession) {
        if (tunnelJob?.isActive == true) return
        bus.publish(TunnelState.Preparing)
        startForeground(NOTIFICATION_ID, notification(session.profileName, connected = false))

        // The job owns its whole lifecycle: whatever way it exits (engine failure,
        // cancellation via stopTunnel, service destroyed), the engine is always
        // stopped and the TUN fd released. A leaked session is what left a stale
        // system VPN (tunX) routing traffic after the user pressed disconnect.
        tunnelJob = scope.launch {
            try {
                launch {
                    engine.traffic.collect { bus.publish(it) }
                }
                engine.start(this@CyrusVpnService, session)
                bus.publish(TunnelState.Connected(session.profileId, System.currentTimeMillis()))
                notifyConnected(session.profileName)
                kotlinx.coroutines.awaitCancellation()
            } catch (error: Throwable) {
                if (error !is kotlinx.coroutines.CancellationException) {
                    bus.publish(TunnelState.Failed(error.message ?: "engine failure"))
                }
                throw error
            }            finally {
                // Runs even when this job was cancelled — withContext(NonCancellable)
                // inside stop() guarantees the teardown completes.
                runCatching { engine.stop() }
                // Keep Failed visible for the UI; everything else resolves to Idle.
                if (bus.state.value !is TunnelState.Failed) bus.reset()
                stopSelfSafely()
            }
        }
    }

    private fun stopTunnel() {
        android.util.Log.d("CyrusVpnService", "stopTunnel: starting")
        bus.publish(TunnelState.Stopping)
        scope.launch {
            android.util.Log.d("CyrusVpnService", "stopTunnel: cancelling tunnelJob")
            try {
                // Cancelling the job triggers its finally-block, which stops the
                // engine and releases the TUN fd (see startTunnel).
                tunnelJob?.cancelAndJoin()
                android.util.Log.d("CyrusVpnService", "stopTunnel: tunnelJob joined")
            } catch (error: Throwable) {
                android.util.Log.e("CyrusVpnService", "stopTunnel: join failed", error)
                // Belt-and-braces: if the join itself failed, tear down directly.
                runCatching { engine.stop() }
            }
            bus.reset()
            android.util.Log.d("CyrusVpnService", "stopTunnel: calling stopSelfSafely")
            stopSelfSafely()
        }
    }

    private fun stopSelfSafely() {
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE)
            else @Suppress("DEPRECATION") stopForeground(true)
        }
        stopSelf()
    }

    /** The user killed the VPN from system settings. Treat it as an explicit disconnect. */
    override fun onRevoke() {
        stopTunnel()
        super.onRevoke()
    }

    override fun onDestroy() {
        tunnelJob?.cancel()
        if (bus.state.value !is TunnelState.Failed) bus.reset()
        super.onDestroy()
    }

    private fun notifyConnected(name: String) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, notification(name, connected = true))
    }

    private fun notification(profileName: String, connected: Boolean): Notification {
        ensureChannel()
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, CyrusVpnService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_vpn)
            .setContentTitle(if (connected) "Подключено" else "Подключение…")
            .setContentText(profileName.ifBlank { "VPN" })
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(0, "Отключить", stopIntent)
            .build()
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Статус VPN", NotificationManager.IMPORTANCE_LOW).apply {
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_SECRET
            },
        )
    }

    companion object {
        const val ACTION_START = "dev.kentra.vpn.START"
        const val ACTION_STOP = "dev.kentra.vpn.STOP"
        const val EXTRA_PROFILE_ID = "profile_id"
        const val EXTRA_PROFILE_NAME = "profile_name"
        const val EXTRA_CONFIG = "config"

        private const val CHANNEL_ID = "vpn_status"
        private const val NOTIFICATION_ID = 0x4B45
    }
}
