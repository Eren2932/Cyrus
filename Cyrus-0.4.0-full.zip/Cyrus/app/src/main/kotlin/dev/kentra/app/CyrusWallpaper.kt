package dev.kentra.app

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * The single standard background: the camo texture, dark and light adaptation.
 * There is no picker and no plain-colour variant any more — this is the default
 * for both themes. A flat scrim keeps text contrast independent of the texture.
 */
@Composable
fun CyrusWallpaper(dark: Boolean, modifier: Modifier = Modifier, preview: Boolean = false) {
    val resources = LocalContext.current.resources
    val resource = if (dark) R.drawable.wallpaper_camo else R.drawable.wallpaper_camo_light
    // Decoding stays off the UI thread and is never repeated by an animation.
    val bitmap by produceState<ImageBitmap?>(null, resource, preview) {
        value = null
        value = withContext(Dispatchers.IO) {
            BitmapFactory.decodeResource(resources, resource, BitmapFactory.Options().apply {
                inSampleSize = if (preview) 4 else 1
            })?.asImageBitmap()
        }
    }
    Box(modifier.background(MaterialTheme.colorScheme.background)) {
        bitmap?.let { image ->
            Image(image, contentDescription = null, modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop, alpha = if (dark) .58f else .90f)
        }
        Box(Modifier.fillMaxSize().background(
            if (dark) Brush.verticalGradient(listOf(Color.Black.copy(alpha = .58f), Color.Black.copy(alpha = .30f), Color.Black.copy(alpha = .72f)))
            else Brush.verticalGradient(listOf(Color.White.copy(alpha = .42f), Color.White.copy(alpha = .16f), Color.White.copy(alpha = .52f)))
        ))
    }
}
