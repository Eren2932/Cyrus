package dev.kentra.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import dev.kentra.core.datastore.*
import dev.kentra.core.designsystem.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

/** Only the theme remains; every other 0.3 toggle was removed. */
@Composable
fun SettingsScreen(appearance: AppearanceSettings, settings: SettingsStore) {
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val modes = ThemeMode.entries
    fun save(action: suspend () -> Unit) {
        scope.launch {
            try { action() } catch (e: Exception) {
                if (e is CancellationException) throw e
                snackbar.showSnackbar("Не удалось сохранить настройку")
            }
        }
    }
    Scaffold(containerColor = androidx.compose.ui.graphics.Color.Transparent,
        contentWindowInsets = WindowInsets(0, 0, 0, 0), snackbarHost = { SnackbarHost(snackbar) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)) {
            CyrusCard {
                Text("Тема", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                CyrusSegmented(
                    labels = modes.map { when (it) { ThemeMode.SYSTEM -> "Система"; ThemeMode.DARK -> "Тёмная"; ThemeMode.LIGHT -> "Светлая" } },
                    selectedIndex = modes.indexOf(appearance.theme),
                    onSelect = { index -> save { settings.setTheme(modes[index]) } },
                )
                Text("Фон и анимации — стандартные, отдельных переключателей нет.",
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
