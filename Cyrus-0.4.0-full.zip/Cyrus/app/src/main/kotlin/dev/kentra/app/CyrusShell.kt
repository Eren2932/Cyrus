package dev.kentra.app

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import dev.kentra.core.datastore.AppearanceSettings
import dev.kentra.core.datastore.SettingsStore
import dev.kentra.core.designsystem.*
import dev.kentra.feature.home.HomeRoute
import dev.kentra.feature.profiles.ProfilesRoute
import dev.kentra.feature.store.StoreRoute

private val tabs = listOf(
    CyrusNavigationItem("home", "Главная", CyrusSymbol.Shield),
    CyrusNavigationItem("profiles", "Ключи", CyrusSymbol.Key),
    CyrusNavigationItem("store", "Подписка", CyrusSymbol.Store),
)

private const val SettingsIndex = 3

/**
 * The shell owns exactly two pieces of state: the selected tab and whether
 * settings is open.
 *
 * 0.3 derived the current screen from `currentBackStackEntryAsState()`, which
 * only emits once the destination has finished animating. During those ~220ms
 * the shell still believed it was on the previous screen, the `current != route`
 * guard dropped the tap and the tab indicator lagged — that is the "buttons get
 * stuck / cannot get back to the start" bug. Selection is now immediate and
 * synchronous, the system back button is handled explicitly, and no navigation
 * back stack can desynchronise from the UI.
 */
@Composable
fun CyrusShell(appearance: AppearanceSettings, dark: Boolean, settings: SettingsStore) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var settingsOpen by rememberSaveable { mutableStateOf(false) }
    val reduced = LocalReducedMotion.current
    val target = if (settingsOpen) SettingsIndex else tab

    BackHandler(enabled = settingsOpen) { settingsOpen = false }
    BackHandler(enabled = !settingsOpen && tab != 0) { tab = 0 }

    val enter = if (reduced) 0 else CyrusMotion.Screen
    val exit = if (reduced) 0 else CyrusMotion.Fast

    Box(Modifier.fillMaxSize()) {
        CyrusWallpaper(dark, Modifier.matchParentSize())
        Scaffold(
            modifier = Modifier.windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Horizontal)),
            containerColor = Color.Transparent,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            topBar = {
                Row(Modifier.fillMaxWidth().windowInsetsPadding(WindowInsets.statusBars)
                    .padding(horizontal = 20.dp).heightIn(min = 60.dp), verticalAlignment = Alignment.CenterVertically) {
                    AnimatedVisibility(settingsOpen, enter = fadeIn(tween(enter)), exit = fadeOut(tween(exit))) {
                        IconButton(onClick = { settingsOpen = false },
                            modifier = Modifier.semantics { contentDescription = "Назад" }) {
                            CyrusIcon(CyrusSymbol.Back)
                        }
                    }
                    AnimatedContent(targetState = target, modifier = Modifier.weight(1f), label = "title",
                        transitionSpec = { fadeIn(tween(enter)) togetherWith fadeOut(tween(exit)) }) { index ->
                        Text(if (index == SettingsIndex) "Настройки" else when (index) {
                            1 -> "Ключи"; 2 -> "Подписка"; else -> "Cyrus"
                        }, style = MaterialTheme.typography.titleLarge)
                    }
                    AnimatedVisibility(!settingsOpen, enter = fadeIn(tween(enter)), exit = fadeOut(tween(exit))) {
                        IconButton(onClick = { settingsOpen = true },
                            modifier = Modifier.semantics { contentDescription = "Настройки" }) {
                            CyrusIcon(CyrusSymbol.Settings)
                        }
                    }
                }
            },
            bottomBar = {
                // Constant height and a layer-only fade: entering settings never
                // reflows the content above it.
                val hidden = animateFloatAsStateCompat(settingsOpen, reduced)
                Box(Modifier.fillMaxWidth().navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 12.dp).height(66.dp)
                    .graphicsLayer { alpha = 1f - hidden.value; translationY = 26f * hidden.value },
                    contentAlignment = Alignment.Center) {
                    CyrusNavigationBar(tabs, tabs[tab].route) { route ->
                        tab = tabs.indexOfFirst { it.route == route }.coerceAtLeast(0)
                    }
                }
            },
        ) { padding ->
            AnimatedContent(
                targetState = target,
                modifier = Modifier.padding(padding).consumeWindowInsets(padding),
                label = "screen",
                transitionSpec = {
                    val sign = if (targetState >= initialState) 1 else -1
                    val shift = if (reduced) 0 else sign * 18
                    (fadeIn(tween(enter, easing = CyrusMotion.Ease)) +
                        slideInHorizontally(tween(enter, easing = CyrusMotion.Ease)) { shift }) togetherWith
                        fadeOut(tween(exit)) using SizeTransform(clip = false)
                },
            ) { index ->
                when (index) {
                    1 -> ProfilesRoute()
                    2 -> StoreRoute(onImport = { tab = 1 })
                    SettingsIndex -> SettingsScreen(appearance, settings)
                    else -> HomeRoute(onNavigateToProfiles = { tab = 1 })
                }
            }
        }
    }
}

@Composable
private fun animateFloatAsStateCompat(flag: Boolean, reduced: Boolean) =
    androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (flag) 1f else 0f,
        animationSpec = tween(if (reduced) 0 else CyrusMotion.Fast, easing = CyrusMotion.Ease),
        label = "barHide",
    )
