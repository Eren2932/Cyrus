package dev.kentra.app

import android.os.Bundle
import android.provider.Settings as AndroidSettings
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.kentra.core.datastore.AppearanceSettings
import dev.kentra.core.datastore.SettingsStore
import dev.kentra.core.datastore.ThemeMode
import dev.kentra.core.designsystem.CyrusTheme
import dev.kentra.core.designsystem.LocalReducedMotion
import org.koin.android.ext.android.inject

class MainActivity : ComponentActivity() {
    private val settings: SettingsStore by inject()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // Ordinary screens intentionally allow capture and recent-apps snapshots.
        // Credential dialogs/sheets opt into SecureOn on their own windows.
        setContent {
            val saved by settings.appearance.collectAsStateWithLifecycle<AppearanceSettings?>(initialValue = null)
            val appearance = saved
            if (appearance == null) {
                Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF080808)) { }
            } else {
                val dark = when (appearance.theme) {
                    ThemeMode.SYSTEM -> isSystemInDarkTheme()
                    ThemeMode.DARK -> true
                    ThemeMode.LIGHT -> false
                }
                SideEffect {
                    val transparent = android.graphics.Color.TRANSPARENT
                    val style = if (dark) SystemBarStyle.dark(transparent) else SystemBarStyle.light(transparent, transparent)
                    enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
                }
                // Reduced motion now follows the platform animator scale instead of
                // an in-app toggle: one less setting, correct accessibility behaviour.
                val reduced = remember {
                    AndroidSettings.Global.getFloat(contentResolver,
                        AndroidSettings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
                }
                CompositionLocalProvider(LocalReducedMotion provides reduced) {
                    CyrusTheme(darkTheme = dark) {
                        CyrusShell(appearance = appearance, dark = dark, settings = settings)
                    }
                }
            }
        }
    }
}
