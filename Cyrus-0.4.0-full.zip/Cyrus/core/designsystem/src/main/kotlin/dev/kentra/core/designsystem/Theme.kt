package dev.kentra.core.designsystem

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.SpringSpec
import androidx.compose.animation.core.spring
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Cyrus 0.4 palette: deep matte black with no blue cast, warm ivory white,
 * single brand accent. Greys are strictly neutral (R=G=B) so the camo
 * wallpaper never turns the UI slate-blue like 0.3 did.
 */
object CyrusTokens {
    val Accent = Color(0xFFF97316)
    val AccentHot = Color(0xFFFFA24C)
    val AccentPressed = Color(0xFFD95F0E)
    val OnAccent = Color(0xFF1B0C00)
    val Danger = Color(0xFFFF7A7A)
    val Warning = Color(0xFFF8C578)

    // Dark: matte black stack.
    val Ink = Color(0xFF080808)
    val InkSurface = Color(0xFF101010)
    val InkControl = Color(0xFF171717)
    val InkOutline = Color(0xFF2A2A2A)
    val InkOutlineSoft = Color(0xFF1D1D1D)
    val OnInk = Color(0xFFEDEDEA)
    val OnInkMuted = Color(0xFF9A9A96)

    // Light: warm paper white.
    val Paper = Color(0xFFF7F7F3)
    val PaperSurface = Color(0xFFFFFFFF)
    val PaperControl = Color(0xFFEDEDE7)
    val PaperOutline = Color(0xFFD8D8D2)
    val OnPaper = Color(0xFF17171A)
    val OnPaperMuted = Color(0xFF5C5C60)

    val RadiusCard = 24.dp
    val RadiusControl = 16.dp
    val SpaceXs = 4.dp
    val SpaceSm = 8.dp
    val SpaceMd = 16.dp
    val SpaceLg = 24.dp
    val SpaceXl = 32.dp
}

/**
 * Motion budget. Everything the user can trigger by tapping resolves in under
 * 160ms; nothing that moves layout runs longer than 200ms. Positional moves use
 * a slightly under-damped spring so bars settle without a mechanical snap.
 */
object CyrusMotion {
    const val Instant = 0
    const val Fast = 90
    const val Screen = 150
    const val Settle = 190
    const val Spin = 700
    const val Breath = 2600

    /** Emphasized decelerate: fast off the mark, soft landing. */
    val Ease = CubicBezierEasing(0.16f, 1f, 0.3f, 1f)
    val EaseIn = CubicBezierEasing(0.4f, 0f, 0.9f, 1f)

    fun <T> settle(): SpringSpec<T> = spring(dampingRatio = 0.82f, stiffness = 900f)
    fun <T> snap(): SpringSpec<T> = spring(dampingRatio = 0.9f, stiffness = 1600f)
}

private val DarkScheme = darkColorScheme(
    primary = CyrusTokens.Accent, onPrimary = CyrusTokens.OnAccent,
    primaryContainer = Color(0xFF2A1608), onPrimaryContainer = CyrusTokens.AccentHot,
    secondary = CyrusTokens.Accent, onSecondary = CyrusTokens.OnAccent,
    secondaryContainer = CyrusTokens.InkControl, onSecondaryContainer = CyrusTokens.AccentHot,
    background = CyrusTokens.Ink, onBackground = CyrusTokens.OnInk,
    surface = CyrusTokens.InkSurface, onSurface = CyrusTokens.OnInk,
    surfaceVariant = CyrusTokens.InkControl, onSurfaceVariant = CyrusTokens.OnInkMuted,
    outline = CyrusTokens.InkOutline, outlineVariant = CyrusTokens.InkOutlineSoft,
    surfaceTint = Color.Transparent, error = CyrusTokens.Danger,
)
private val LightScheme = lightColorScheme(
    primary = CyrusTokens.Accent, onPrimary = CyrusTokens.OnAccent,
    primaryContainer = Color(0xFFFFE7D5), onPrimaryContainer = Color(0xFF7C3109),
    secondary = Color(0xFF7C3109), onSecondary = Color.White,
    secondaryContainer = CyrusTokens.PaperControl, onSecondaryContainer = CyrusTokens.OnPaper,
    background = CyrusTokens.Paper, onBackground = CyrusTokens.OnPaper,
    surface = CyrusTokens.PaperSurface, onSurface = CyrusTokens.OnPaper,
    surfaceVariant = CyrusTokens.PaperControl, onSurfaceVariant = CyrusTokens.OnPaperMuted,
    outline = CyrusTokens.PaperOutline, outlineVariant = Color(0xFFE2E2DC),
    surfaceTint = Color.Transparent, error = Color(0xFFB3261E),
)

/**
 * Mirrors the system animator-duration scale (Settings > Developer options /
 * accessibility). There is no in-app switch any more: the platform value wins.
 */
val LocalReducedMotion = staticCompositionLocalOf { false }

private val CyrusTypography = Typography(
    displaySmall = TextStyle(fontSize = 38.sp, fontWeight = FontWeight.Bold, letterSpacing = (-1).sp),
    headlineLarge = TextStyle(fontSize = 32.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.8).sp),
    titleLarge = TextStyle(fontSize = 23.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 21.sp),
    labelSmall = TextStyle(fontSize = 12.sp, lineHeight = 17.sp, fontWeight = FontWeight.Medium),
)

@Composable
fun CyrusTheme(darkTheme: Boolean = true, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (darkTheme) DarkScheme else LightScheme, typography = CyrusTypography, shapes = Shapes(
        small = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
        medium = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
        large = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
        extraLarge = androidx.compose.foundation.shape.RoundedCornerShape(28.dp),
    ), content = content)
}
