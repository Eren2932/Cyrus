#!/usr/bin/env python3
"""Optional numeric/assets audit; requires Pillow. Does NOT execute Compose."""
from pathlib import Path
import math,re
from PIL import Image
root=Path(__file__).resolve().parents[1]
lines=[]
def out(s): print(s);lines.append(s)
# Independent numeric audit of the drawing maths, NOT running Compose.
# 1) The Tactical Core geometry must stay inside its own box at every animation value.
for side in (180.,216.,260.):
 for p in [i/100 for i in range(101)]:
  for e in [i/100 for i in range(101)]:
   radius=side/2-26
   half=side/2-10-9*p+4*e
   arm=side*(0.115+0.02*e)
   assert 0<radius<side/2, (side,radius)
   assert half<=side/2-6, (side,half)
   assert arm<half, (side,arm,half)
   assert radius<half, 'brackets must never cross the ring'
out('PASS numeric audit: core ring and brackets stay inside bounds across 30,603 animation states.')
# 2) The bar choreography must match the measured reference capture (60fps).
reference={'expand_ms':150,'dwell_ms':317,'collapse_ms':190}
comp=(root/'core/designsystem/src/main/kotlin/dev/kentra/core/designsystem/Components.kt').read_text()
got={'expand_ms':int(re.search(r'Expand = (\d+)',comp).group(1)),
     'dwell_ms':int(re.search(r'Dwell = (\d+)L',comp).group(1)),
     'collapse_ms':int(re.search(r'Collapse = (\d+)',comp).group(1))}
for k,v in reference.items():
 assert abs(got[k]-v)<=15, (k,got[k],v)
 out(f'PASS bar timing {k}: {got[k]}ms vs measured reference {v}ms (within one frame at 60fps).')
def lum(h):
 v=[int(h[i:i+2],16)/255 for i in (0,2,4)]
 v=[x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4 for x in v]
 return sum(x*w for x,w in zip(v,[.2126,.7152,.0722]))
for name,a,b in [('dark text','EDEDEA','080808'),('dark muted','9A9A96','080808'),('light text','17171A','F7F7F3'),('bar label on accent','1B0C00','F97316')]:
 ratio=(max(lum(a),lum(b))+.05)/(min(lum(a),lum(b))+.05)
 assert ratio>=4.5
 out(f'PASS base colour contrast {name}: {ratio:.2f}:1 (not a full rendered accessibility audit).')
resources={f.stem for f in (root/'app/src/main/res/drawable-nodpi').glob('*.webp')}
for f in (root/'app/src/main/res/drawable-nodpi').glob('*.webp'):
 with Image.open(f) as im:
  im.load();assert im.width<=1080 and im.height<=2160
  out(f'PASS image decode: {f.name}, {im.width}x{im.height}, {f.stat().st_size} bytes')
s=(root/'app/src/main/kotlin/dev/kentra/app/CyrusWallpaper.kt').read_text()
assert set(re.findall(r'R.drawable.(wallpaper_\w+)',s))==resources=={'wallpaper_camo','wallpaper_camo_light'}
out('PASS the only bundled wallpaper is the standard camo pair, and Kotlin references exactly it.')
out('NOT RUN: Android renderer, Kotlin compiler, JUnit, screenshot capture, runtime lifecycle, FPS/jank.')
(root/'validation/design-audit.txt').write_text('\n'.join(lines)+'\n')
