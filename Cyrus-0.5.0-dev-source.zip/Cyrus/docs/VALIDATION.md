# Проверки Cyrus 0.5.0-dev

Выполнены проверки **исходников**, а не сетевой работоспособности:

- 48 исходных source checks: баланс Kotlin-скобок, XML, TOML, модульные/безопасностные/дизайнерские инварианты.
- 16 merge backend guards; старые проверки адаптированы к новому владельцу lifecycle `TunnelServiceRunner` и версии code 7, а не удалены.
- 10 160 дизайнерских assertions и 71 цветовая пара; это расчёт цветов/геометрии, НЕ измерение реального UI/FPS.
- 12 design mutation cases, 10 merge mutation cases, 6 synthetic AAR-validator tests.
- 89 новых source assertions (включая простую проверку файлов) и 10 upgrade mutation cases.
- Сверены 27 новых JSON field names с соответствующими Go structs pinned core и host types HTTP/HTTPUpgrade. Это НЕ выполнение sing-box check.
- `bash -n` трёх shell-файлов проекта; целостность fixtures, отсутствие предоставленных секретов, ZIP и SHA256 manifest проверены при упаковке.

Исходный журнал: `validation/source-checks.txt`. Поля Go: `validation/native-schema-source-audit.json`.

Добавлены **48 JUnit тестов**, но они НЕ запускались. Внешний workflow и внутренний Android CI должны выполнить их, lint и native config check перед APK. Наличие тестового исходника не означает, что тест проходит.

Kotlin-компиляция, Gradle, Android lint, Go native validation, APK, сценарии гонок на Android, TLS/DNS/UDP через реальные серверы и серверный installer не выполнялись. JDK/Gradle/SDK/NDK/Go и native library должен подготовить CI. Отчёт не является сертификатом безопасности и не подтверждает отсутствие багов.

Изменены два исторических source-условия: «только тема в настройках» заменено наличием явного сохранения сетевых настроек; lifecycle guards перенесены с CyrusVpnService на общий runner. Все прежние design/merge mutation gates продолжают исполняться. Оставленные исторические отчёты вынесены в docs/history и относятся к 0.4.2.
