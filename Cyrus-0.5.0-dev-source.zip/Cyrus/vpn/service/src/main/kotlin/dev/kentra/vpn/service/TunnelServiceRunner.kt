package dev.kentra.vpn.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import dev.kentra.domain.model.TunnelState
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel

/** FIFO owns start/replace/stop; cancellation always joins native teardown before the next start. */
internal class TunnelServiceRunner(
    private val service: Service,
    private val bus: TunnelBus,
    private val engine: VpnEngine,
    private val proxy: Boolean,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private data class Command(val session: TunnelSession?, val startId: Int)
    private val commands = Channel<Command>(Channel.UNLIMITED)
    private var tunnelJob: Job? = null
    private var latestStartId = 0
    private var generation = 0L
    private val notificationId = if (proxy) 0x4B46 else 0x4B45

    init {
        scope.launch {
            for (command in commands) {
                generation++
                val token = generation
                bus.publish(TunnelState.Stopping)
                tunnelJob?.cancelAndJoin()
                tunnelJob = null
                val session = command.session
                if (session == null) {
                    bus.reset()
                    finish(command.startId)
                    continue
                }
                bus.publish(TunnelState.Preparing)
                tunnelJob = scope.launch {
                    var failed = false
                    try {
                        coroutineScope {
                            launch { engine.traffic.collect { bus.publish(it) } }
                            engine.start(service, session)
                            bus.publish(TunnelState.Connected(session.profileId, System.currentTimeMillis(), proxy))
                            (service.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                                .notify(notificationId, notification(true))
                            awaitCancellation()
                        }
                    } catch (error: Throwable) {
                        if (error is kotlinx.coroutines.CancellationException) throw error
                        // Native exceptions may embed a key/config. Do not expose the exception verbatim.
                        failed = true
                        bus.publish(TunnelState.Stopping)
                    } finally {
                        // Cancellation cannot interrupt the engine's serialized teardown.
                        // Replacement commands must wait for this cleanup to finish.
                        runCatching { engine.stop() }
                        if (failed && token == generation) bus.publish(TunnelState.Failed("Ядро не запустилось. Проверьте параметры, доступность порта и поддержку ключа."))
                        if (token == generation) finish(command.startId)
                    }
                }
            }
        }
    }

    fun command(intent: Intent?, startId: Int) {
        latestStartId = startId
        bus.claim(this)
        if (intent?.action == CyrusVpnService.ACTION_START) {
            // Must happen synchronously, before awaiting an older session's teardown.
            service.startForeground(notificationId, notification(false))
            val session = TunnelSession(
                intent.getStringExtra(CyrusVpnService.EXTRA_PROFILE_ID).orEmpty(),
                intent.getStringExtra(CyrusVpnService.EXTRA_PROFILE_NAME).orEmpty(),
                intent.getStringExtra(CyrusVpnService.EXTRA_CONFIG).orEmpty(),
            )
            commands.trySend(Command(session, startId))
        } else commands.trySend(Command(null, startId))
    }

    fun revoke() { commands.trySend(Command(null, latestStartId)) }
    fun destroy() {
        generation++
        commands.close()
        scope.cancel()
        bus.release(this)
    }
    private fun finish(startId: Int) {
        if (startId != latestStartId) return
        service.stopForeground(Service.STOP_FOREGROUND_REMOVE)
        service.stopSelfResult(startId)
    }
    private fun notification(connected: Boolean): Notification {
        val channel = "cyrus_connection"
        val manager = service.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26 && manager.getNotificationChannel(channel) == null)
            manager.createNotificationChannel(NotificationChannel(channel, "Подключение Cyrus", NotificationManager.IMPORTANCE_LOW).apply {
                lockscreenVisibility = Notification.VISIBILITY_SECRET
                setShowBadge(false)
            })
        val intent = Intent(service, service.javaClass).setAction(CyrusVpnService.ACTION_STOP)
        val stop = PendingIntent.getService(service, notificationId, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(service, channel).setSmallIcon(R.drawable.ic_stat_vpn)
            .setContentTitle(if (connected) (if (proxy) "Локальный прокси запущен" else "VPN-интерфейс запущен") else "Подключение…")
            .setContentText(if (proxy) "Только приложения с настроенным прокси" else "Cyrus · сетевое ядро активно")
            .setVisibility(NotificationCompat.VISIBILITY_SECRET).setOngoing(true).setOnlyAlertOnce(true)
            .addAction(0, "Отключить", stop).build()
    }
}
