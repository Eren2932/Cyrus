package dev.kentra.vpn.link

import dev.kentra.domain.model.*
import org.junit.Assert.*
import org.junit.Test

class UpgradeImportTest {
    private val parser = DefaultLinkParser(clock={0})
    private val uuid = "11111111-2222-4333-8444-555555555555"
    @Test fun `sanitized real provider format variants preserve all nodes`() {
        val expected=mapOf("happ.json" to 4,"v2raytun.json" to 3,"v2rayng.txt" to 4,"nekobox.txt" to 2,"hiddify.txt" to 1)
        for((name,count) in expected) {
            val content=requireNotNull(javaClass.getResource("/subscriptions/$name")).readText()
            val report=parser.inspect(content)
            assertTrue("$name: ${report.issues}",report.issues.isEmpty())
            assertEquals(name,count,report.profiles.size)
        }
    }
    @Test fun `deeply nested JSON fails without parsing recursion`() {
        val r=parser.inspect("[".repeat(1000)+"0"+"]".repeat(1000))
        assertTrue(r.profiles.isEmpty());assertTrue(r.issues.isNotEmpty())
    }
    @Test fun `oversize JSON outbound is rejected not expanded`() {
        val r=parser.inspect("""{"outbounds":[{"protocol":"vless","tag":"${"x".repeat(40_000)}"}]}""")
        assertTrue(r.profiles.isEmpty());assertTrue(r.issues.isNotEmpty())
    }
    @Test fun `anonymous SOCKS5`() { val p=parser.parse("socks5://proxy.example:1080")!!;assertEquals(VpnProtocol.SOCKS,p.protocol);assertNull(p.password);assertEquals("5",p.parameters["version"]) }
    @Test fun `SOCKS4a username and IPv6`() { val p=parser.parse("socks4a://name@[2001:db8::1]:1081")!!;assertEquals("4a",p.parameters["version"]);assertEquals("name",p.parameters["username"]) }
    @Test fun `HTTP proxy auth survives escaped separators`() { val p=parser.parse("http://us%3Aer:p%40ss+word@proxy.example:3128")!!;assertEquals("us:er",p.parameters["username"]);assertEquals("p@ss+word",p.password);assertFalse(p.tls.enabled) }
    @Test fun `HTTPS proxy TLS default`() { val p=parser.parse("https://user:password@proxy.example")!!;assertTrue(p.tls.enabled);assertEquals(443,p.port) }
    @Test fun `subscription path is not a proxy`() { assertNull(parser.parse("https://sub.example/sub/test-only-token?app=happ")) }
    @Test fun `proxy malformed port fails`() { assertNull(parser.parse("socks5://proxy.example:0"));assertNull(parser.parse("http://u:p@proxy.example:65536")) }
    @Test fun `editing fields changes exported Reality connection without dropping extra fields`() {
        val p=parser.parse("vless://$uuid@old.example:443?security=reality&pbk=test-public-key&sid=ab&flow=xtls-rprx-vision&vendor=test-only#Old")!!
        val exported=parser.export(p.copy(server="new.example",port=8443,name="Новый + узел",tls=p.tls.copy(serverName="cdn.example")))
        val result=parser.parse(exported)!!
        assertEquals("new.example",result.server);assertEquals(8443,result.port);assertEquals("Новый + узел",result.name)
        assertEquals("cdn.example",result.tls.serverName);assertEquals("test-only",result.parameters["vendor"]);assertEquals("ab",result.tls.reality?.shortId)
    }
    @Test fun `export clear SNI does not resurrect peer alias`() {
        val p=parser.parse("trojan://test-only-secret@proxy.example?peer=old.example")!!
        assertNull(parser.parse(parser.export(p.copy(tls=p.tls.copy(serverName=null))))!!.tls.serverName)
    }
    @Test fun `all canonical formats roundtrip secrets`() {
        val links=listOf("vless://$uuid@proxy.example?security=tls&sni=cdn.example&type=ws&path=%2Fedge&host=cdn.example",
            "trojan://p%3A%40%2B%25@proxy.example", "tuic://$uuid:p%3A%40%2B%25@proxy.example?congestion_control=bbr&alpn=h3",
            "hy2://p%3A%40%2B%25@proxy.example?obfs=salamander&obfs-password=test-only", "ss://aes-256-gcm:p%3A%40%2B%25@proxy.example:8388",
            "socks5://u:p%3A%40%2B%25@proxy.example:1080", "https://u:p%3A%40%2B%25@proxy.example:443")
        for(link in links) { val p=parser.parse(link)!!;val q=parser.parse(parser.export(p))!!
            assertEquals(p.protocol,q.protocol);assertEquals(p.server,q.server);assertEquals(p.port,q.port);assertEquals(p.password,q.password);assertEquals(p.uuid,q.uuid)
        }
    }
    @Test fun `Xray list imports nodes but never DNS inbound or routing policy`() {
        val text="""[{"inbounds":[{"protocol":"socks","port":9999}],"dns":{"servers":["localhost"]},"routing":{"domainStrategy":"AsIs"},"outbounds":[
          {"tag":"WS region label","protocol":"vless","settings":{"vnext":[{"address":"ws.example","port":8443,"users":[{"id":"$uuid","encryption":"none"}]}]},"streamSettings":{"network":"ws","security":"tls","tlsSettings":{"serverName":"cdn.example","fingerprint":"firefox"},"wsSettings":{"host":"cdn.example","path":"/edge"}}},
          {"tag":"XHTTP preserved","protocol":"vless","settings":{"vnext":[{"address":"xh.example","port":443,"users":[{"id":"$uuid"}]}]},"streamSettings":{"network":"xhttp","security":"tls","xhttpSettings":{"host":"cdn.example","path":"/x","mode":"auto"}}},
          {"protocol":"freedom"},{"protocol":"blackhole"}]}]"""
        val report=parser.inspect(text);assertTrue(report.issues.toString(),report.issues.isEmpty());assertEquals(2,report.profiles.size)
        assertEquals("ws",report.profiles[0].transport.type);assertEquals("xhttp",report.profiles[1].transport.type)
        assertNotNull(report.profiles[0].parameters["cyrus-xray"]);assertFalse(report.profiles[0].parameters.containsKey("routing"))
    }
    @Test fun `unknown Xray behavioral fields remain marked unsupported`() {
        val text="""{"outbounds":[{"protocol":"vless","settings":{"vnext":[{"address":"proxy.example","port":443,"users":[{"id":"$uuid"}]}]},"streamSettings":{"network":"tcp","sockopt":{"dialerProxy":"other"}}}]}"""
        val p=parser.inspect(text).profiles.single();assertNotNull(p.parameters["cyrus-unsupported"])
    }
    @Test fun `malformed JSON issue does not contain secrets`() { val r=parser.inspect("{\"outbounds\": SECRET-TEST-ONLY}");assertTrue(r.profiles.isEmpty());assertFalse(r.issues.toString().contains("SECRET-TEST-ONLY")) }
    @Test fun `unknown JSON protocol is explicit not silently dropped`() { val r=parser.inspect("""{"outbounds":[{"protocol":"unsupported-vendor"}]}""");assertEquals(1,r.issues.size) }
}
