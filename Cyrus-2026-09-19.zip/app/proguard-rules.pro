# --- kotlinx.serialization -------------------------------------------------
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.**
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class kotlinx.serialization.json.** { kotlinx.serialization.KSerializer serializer(...); }
-keep,includedescriptorclasses class dev.kentra.**$$serializer { *; }
-keepclassmembers class dev.kentra.** { *** Companion; }
-keepclasseswithmembers class dev.kentra.** { kotlinx.serialization.KSerializer serializer(...); }

# --- Room ------------------------------------------------------------------
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-dontwarn androidx.room.paging.**

# --- Koin ------------------------------------------------------------------
-keep class org.koin.** { *; }
-keepclassmembers class * { public <init>(...); }

# --- Ktor / OkHttp ---------------------------------------------------------
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn io.ktor.**
-keepclassmembers class io.ktor.** { volatile <fields>; }

# --- VpnService ------------------------------------------------------------
# Keep the service that AndroidManifest.xml actually registers. The previous
# rule named a class that does not exist in the tree, so it protected nothing.
-keep class dev.kentra.vpn.service.CyrusVpnService { *; }

# --- Native cores (gomobile) — JNI entry points must survive R8 ------------
# Release builds enable minification and R8 fullMode, which removes classes that
# are only reachable from JNI. The AAR consumer rules are not a reliable
# substitute for an explicit keep, so all three binding packages are pinned:
#   io.nekohasekai.libbox.** -> sing-box (libbox.aar)
#   go.**                    -> gomobile runtime glue shared by both cores
#   libXray.**               -> Xray core (libXray.aar)
-keep class io.nekohasekai.libbox.** { *; }
-keep class go.** { *; }
-keep class libXray.** { *; }
