package dev.kentra.app

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Pre-toned camo assets: no alpha stacking or second scrim that crushes blacks.
 * The dark asset is bounded to neutral RGB 22..48; text is tested against its
 * brightest pixel, light-theme text against the light asset's darkest pixel.
 */
@Composable
fun CyrusWallpaper(dark: Boolean, modifier: Modifier = Modifier, preview: Boolean = false) {
    val resources = LocalContext.current.resources
    val resource = if (dark) R.drawable.wallpaper_camo else R.drawable.wallpaper_camo_light
    // remember + LaunchedEffect instead of the Compose state-producer helper: identical
    // semantics (the previous bitmap survives a key change, the loader restarts), and the
    // assignment shape the Compose runtime lint check rejects is gone for good.
    var decoded by remember { mutableStateOf<Pair<Int, ImageBitmap>?>(null) }
    LaunchedEffect(resource, preview) {
        val bitmap = withContext(Dispatchers.IO) {
            // Both assets are 1080x2160 in drawable-nodpi, so at ARGB_8888 one bitmap
            // costs ~9.3 MB. Deliberately NOT reduced:
            //
            // - RGB_565 would halve it, but the dark asset is tone-bounded to neutral
            //   RGB 22..48. Five bits per channel leaves about four distinguishable
            //   levels across that whole range, which bands the camo badly. Memory is
            //   cheaper than a visibly broken brand asset.
            // - inSampleSize > 1 is not safe either: with ContentScale.Crop the bitmap
            //   must stay at least screen-sized, and on a 1080-wide device the asset is
            //   already exactly that. Downsampling only buys something on displays the
            //   app does not target.
            //
            // If this ever has to shrink, shrink the asset, not the decode.
            BitmapFactory.decodeResource(resources, resource, BitmapFactory.Options().apply {
                inSampleSize = if (preview) 4 else 1
            })?.asImageBitmap()
        }
        decoded = bitmap?.let { resource to it }
    }
    Box(modifier.background(MaterialTheme.colorScheme.background)) {
        // Do not display the previous theme's bitmap during asynchronous decoding.
        decoded?.takeIf { it.first == resource }?.second?.let { image ->
            Image(image, contentDescription = null, modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop)
        }
    }
}
