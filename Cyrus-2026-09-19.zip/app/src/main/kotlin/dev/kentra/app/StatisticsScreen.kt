package dev.kentra.app

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.kentra.core.datastore.ProtectionStatsStore
import dev.kentra.core.datastore.SettingsStore
import dev.kentra.core.designsystem.CyrusCard
import dev.kentra.core.designsystem.CyrusTokens
import dev.kentra.core.ui.formatBytes
import dev.kentra.domain.model.ProtectionStats
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date
import java.util.Locale

@Composable
fun StatisticsScreen(settings: SettingsStore, protectionStats: ProtectionStatsStore) {
    val stats by protectionStats.stats.collectAsStateWithLifecycle(initialValue = ProtectionStats())
    val options by settings.tunnelOptions.collectAsStateWithLifecycle(initialValue = null)
    val scope = rememberCoroutineScope()
    var confirmReset by remember { mutableStateOf(false) }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Очистить статистику?") },
            text = { Text("Счётчики рекламы, трекеров и трафика будут удалены с этого устройства.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmReset = false
                    scope.launch { protectionStats.reset() }
                }) { Text("Очистить") }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Отмена") } },
        )
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("Статистика", style = MaterialTheme.typography.headlineLarge)
        Text(
            "Сводка по трафику, который Cyrus заблокировал или пропустил через VPN",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        CyrusCard {
            Text("Запросы", style = MaterialTheme.typography.titleLarge)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Metric("реклама", stats.adsBlocked, CyrusTokens.Accent, Modifier.weight(1f))
                Metric("трекеры", stats.trackersBlocked, Color(0xFFE8A317), Modifier.weight(1f))
                Metric("всего", stats.blockedRequests, MaterialTheme.colorScheme.onSurface, Modifier.weight(1f))
            }
            BlockedDistribution(stats)
            Text(
                "Считаются уникальные заблокированные соединения. Один домен может создать несколько запросов.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        CyrusCard {
            Text("Трафик", style = MaterialTheme.typography.titleLarge)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Metric("отправлено", stats.uploadedBytes.formatBytes(), Color(0xFFB16BC4), Modifier.weight(1f))
                Metric("скачано", stats.downloadedBytes.formatBytes(), Color(0xFF55C878), Modifier.weight(1f))
                Metric("всего", (stats.uploadedBytes + stats.downloadedBytes).formatBytes(), MaterialTheme.colorScheme.onSurface, Modifier.weight(1f))
            }
            Text(
                "Объём трафика берётся из счётчиков sing-box. «Сэкономлено» здесь нет: соединение, отклонённое ядром, не передаёт байтов, поэтому любой такой объём был бы выдуман.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        CyrusCard {
            Text("Недавняя активность", style = MaterialTheme.typography.titleLarge)
            val lastBlocked = stats.lastBlockedAtEpochMs?.let {
                DateFormat.getTimeInstance(DateFormat.SHORT, Locale.getDefault()).format(Date(it))
            }
            ActivityRow("Последняя блокировка", lastBlocked ?: "Нет данных")
            ActivityRow(
                "Активные фильтры",
                options?.let { countActiveFilters(it).toString() } ?: "—",
            )
            ActivityRow("Режим", if (options?.protectionEnabled == true || options?.blockAds == true) "Защита включена" else "Защита выключена")
        }

        Button(onClick = { confirmReset = true }, modifier = Modifier.fillMaxWidth()) {
            Text("Очистить статистику")
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun Metric(title: String, value: Any, tint: Color, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            value.toString().compactCount(),
            style = MaterialTheme.typography.titleLarge,
            color = tint,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
        )
        Text(title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun BlockedDistribution(stats: ProtectionStats) {
    val values = listOf(
        stats.adsBlocked to CyrusTokens.Accent,
        stats.trackersBlocked to Color(0xFFE8A317),
        stats.annoyancesBlocked to Color(0xFF6CC6D6),
        stats.threatsBlocked to Color(0xFFE95D5D),
        stats.firewallBlocked to Color(0xFF8E9BFF),
        stats.otherBlocked to MaterialTheme.colorScheme.outline,
    )
    val total = values.sumOf { it.first }
    Row(
        Modifier.fillMaxWidth().height(8.dp).background(MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp)),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (total == 0L) {
            Box(Modifier.fillMaxWidth().height(8.dp).background(MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp)))
        } else {
            values.filter { it.first > 0L }.forEach { (value, tint) ->
                Box(
                    Modifier
                        .weight(value.toFloat().coerceAtLeast(1f))
                        .height(8.dp)
                        .background(tint),
                )
            }
        }
    }
}

@Composable
private fun ActivityRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(8.dp).height(8.dp).background(CyrusTokens.Accent, RoundedCornerShape(4.dp)))
        Spacer(Modifier.width(12.dp))
        Text(label, Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End)
    }
}

private fun countActiveFilters(options: dev.kentra.vpn.config.TunnelOptions): Int = listOf(
    options.blockAds,
    options.blockTrackers,
    options.blockAnnoyances,
    options.blockThreats,
    options.dnsProtection,
).count { it }

private fun String.compactCount(): String {
    val value = replace(',', '.').toDoubleOrNull() ?: return this
    return when {
        value < 1000 -> this
        value < 1_000_000 -> String.format(Locale.getDefault(), "%.1f тыс.", value / 1000)
        else -> String.format(Locale.getDefault(), "%.1f млн", value / 1_000_000)
    }
}
