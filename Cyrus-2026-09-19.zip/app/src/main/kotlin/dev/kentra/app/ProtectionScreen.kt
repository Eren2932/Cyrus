package dev.kentra.app

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.kentra.core.datastore.SettingsStore
import dev.kentra.core.designsystem.CyrusCard
import dev.kentra.core.designsystem.CyrusTokens
import dev.kentra.vpn.config.TunnelOptions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

private data class ProtectionDraft(
    val enabled: Boolean,
    val ads: Boolean,
    val trackers: Boolean,
    val annoyances: Boolean,
    val threats: Boolean,
    val dns: Boolean,
    val firewall: Boolean,
) {
    val selectedCount: Int
        get() = listOf(ads, trackers, annoyances, threats, dns, firewall).count { it }

    fun toOptions(base: TunnelOptions): TunnelOptions = base.copy(
        protectionEnabled = enabled,
        blockAds = ads,
        blockTrackers = trackers,
        blockAnnoyances = annoyances,
        blockThreats = threats,
        dnsProtection = dns,
        firewallEnabled = firewall,
    )
}

/** 1 фильтр, 2–4 фильтра, 5+ фильтров. */
private fun filtersPlural(count: Int): String = when {
    count % 100 in 11..14 -> "фильтров"
    count % 10 == 1 -> "фильтр"
    count % 10 in 2..4 -> "фильтра"
    else -> "фильтров"
}

private fun TunnelOptions.toProtectionDraft(): ProtectionDraft = ProtectionDraft(
    enabled = protectionEnabled || blockAds,
    ads = blockAds,
    trackers = blockTrackers,
    annoyances = blockAnnoyances,
    threats = blockThreats,
    dns = dnsProtection,
    firewall = firewallEnabled,
)

@Composable
fun ProtectionScreen(
    settings: SettingsStore,
    onNavigateToApplications: () -> Unit,
    onNavigateToStatistics: () -> Unit,
    onNavigateToInspection: () -> Unit,
) {
    val options by settings.tunnelOptions.collectAsStateWithLifecycle(initialValue = null)
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    Scaffold(
        containerColor = Color.Transparent,
        contentColor = MaterialTheme.colorScheme.onBackground,
        contentWindowInsets = androidx.compose.foundation.layout.WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        options?.let { initial ->
            var draft by remember(initial) { mutableStateOf(initial.toProtectionDraft()) }
            LaunchedEffect(initial) { draft = initial.toProtectionDraft() }

            fun save(next: ProtectionDraft) {
                draft = next
                scope.launch {
                    try {
                        settings.setTunnelOptions(next.toOptions(initial))
                        snackbar.showSnackbar("Настройки защиты сохранены")
                    } catch (error: Exception) {
                        if (error is CancellationException) throw error
                        snackbar.showSnackbar("Не удалось сохранить: ${error.message ?: "проверьте настройки"}")
                    }
                }
            }

            Column(
                Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Text("Защита", style = MaterialTheme.typography.headlineLarge)
                Text(
                    if (draft.enabled) "Фильтрация работает внутри VPN-туннеля"
                    else "Включите защиту, чтобы фильтровать трафик до прокси",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )

                CyrusCard(highlighted = draft.enabled) {
                    ProtectionSwitchRow(
                        badge = "CY",
                        title = "Защита включена",
                        subtitle = if (draft.enabled) {
                            "${draft.selectedCount} ${filtersPlural(draft.selectedCount)} активно"
                        } else {
                            "Фильтры не применяются к трафику"
                        },
                        value = draft.enabled,
                        onChange = { enabled ->
                            save(
                                if (enabled && draft.selectedCount == 0) draft.copy(enabled = true, ads = true)
                                else draft.copy(enabled = enabled),
                            )
                        },
                        accent = CyrusTokens.Accent,
                    )
                    Text(
                        "Изменения применятся при следующем подключении. При активном VPN отключите его и подключитесь снова.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }

                CyrusCard {
                    Text("Фильтры", style = MaterialTheme.typography.titleMedium)
                    ProtectionSwitchRow(
                        badge = "AD",
                        title = "Блокировка рекламы",
                        subtitle = "Баннеры, видеореклама и pop-up",
                        value = draft.ads,
                        enabled = draft.enabled,
                        onChange = { save(draft.copy(ads = it)) },
                    )
                    ProtectionSwitchRow(
                        badge = "TR",
                        title = "Защита от трекинга",
                        subtitle = "Рекламные и аналитические домены",
                        value = draft.trackers,
                        enabled = draft.enabled,
                        onChange = { save(draft.copy(trackers = it)) },
                    )
                    ProtectionSwitchRow(
                        badge = "IR",
                        title = "Блокировка раздражителей",
                        subtitle = "Cookie-баннеры, pop-up и подписки",
                        value = draft.annoyances,
                        enabled = draft.enabled,
                        onChange = { save(draft.copy(annoyances = it)) },
                    )
                }

                CyrusCard {
                    Text("DNS и угрозы", style = MaterialTheme.typography.titleMedium)
                    ProtectionSwitchRow(
                        badge = "DNS",
                        title = "DNS-защита",
                        subtitle = "AdGuard DNS блокирует рекламу и трекеры",
                        value = draft.dns,
                        enabled = draft.enabled,
                        onChange = { save(draft.copy(dns = it)) },
                    )
                    ProtectionSwitchRow(
                        badge = "SAFE",
                        title = "Защита от фишинга",
                        subtitle = "Quad9 DNS блокирует известные вредоносные домены",
                        value = draft.threats,
                        enabled = draft.enabled,
                        onChange = { save(draft.copy(threats = it)) },
                    )
                    Text(
                        "DNS-защита и защита от фишинга используют защищённый DNS вместо адреса из сетевых настроек. Данные запросов не сохраняются Cyrus.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }

                CyrusCard {
                    Text("Фаервол", style = MaterialTheme.typography.titleMedium)
                    ProtectionSwitchRow(
                        badge = "FW",
                        title = "Блокировать интернет",
                        subtitle = "Запрещает выбранным приложениям доступ к сети",
                        value = draft.firewall,
                        enabled = draft.enabled,
                        onChange = { save(draft.copy(firewall = it)) },
                    )
                    TextButton(onClick = onNavigateToApplications, modifier = Modifier.fillMaxWidth()) {
                        Text("Выбрать приложения")
                    }
                }

                CyrusCard {
                    Text("Управление", style = MaterialTheme.typography.titleMedium)
                    TextButton(onClick = onNavigateToApplications, modifier = Modifier.fillMaxWidth()) {
                        Text("Приложения в VPN")
                    }
                    TextButton(onClick = onNavigateToStatistics, modifier = Modifier.fillMaxWidth()) {
                        Text("Открыть статистику")
                    }
                    TextButton(onClick = onNavigateToInspection, modifier = Modifier.fillMaxWidth()) {
                        Text("HTTPS-инспекция")
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        } ?: Text("Чтение настроек…", modifier = Modifier.padding(20.dp))
    }
}

@Composable
private fun ProtectionSwitchRow(
    badge: String,
    title: String,
    subtitle: String,
    value: Boolean,
    onChange: (Boolean) -> Unit,
    enabled: Boolean = true,
    accent: Color = MaterialTheme.colorScheme.primary,
) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
            Text(
                badge,
                modifier = Modifier
                    .size(38.dp)
                    .background(accent.copy(alpha = if (enabled) .16f else .07f), RoundedCornerShape(12.dp))
                    .padding(top = 10.dp),
                color = if (enabled) accent else MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
            )
            Spacer(Modifier.width(12.dp))
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Switch(
            checked = value,
            onCheckedChange = onChange,
            enabled = enabled,
            colors = SwitchDefaults.colors(
                checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                checkedTrackColor = MaterialTheme.colorScheme.primary,
            ),
        )
    }
}
