package dev.kentra.app

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.Switch
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import android.content.Intent
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import dev.kentra.core.datastore.SettingsStore
import dev.kentra.core.designsystem.CyrusCard
import dev.kentra.vpn.service.ProtectionCa
import java.security.MessageDigest
import java.security.cert.X509Certificate
import java.text.DateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * HTTPS inspection: the root certificate and the switch that turns decryption
 * on.
 *
 * The switch is only offered once the root is actually trusted. A toggle that
 * silently does nothing would be worse than no toggle: the user would believe
 * traffic is being inspected when it is going through untouched.
 */
@Composable
fun InspectionScreen(protectionCa: ProtectionCa, settings: SettingsStore) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val options by settings.tunnelOptions.collectAsState(initial = null)
    var state by remember { mutableStateOf<ProtectionCa.State?>(null) }
    var installIntent by remember { mutableStateOf<Intent?>(null) }
    var busy by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var refresh by remember { mutableIntStateOf(0) }

    suspend fun reload() {
        state = withContext(Dispatchers.IO) { protectionCa.state() }
        // Null on Android 13+: there the root can only go in through Settings.
        installIntent = withContext(Dispatchers.IO) { protectionCa.installIntent() }
    }

    // The user saves the certificate wherever they want and installs it from
    // Settings. Writing it ourselves into a shared folder would need storage
    // permissions, and a file the user did not choose is a file they did not ask for.
    val saveLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/x-x509-ca-cert"),
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            val pem = withContext(Dispatchers.IO) { protectionCa.pem() }
            if (pem == null) {
                snackbar.showSnackbar("Сначала создайте сертификат")
                return@launch
            }
            val saved = withContext(Dispatchers.IO) {
                runCatching {
                    context.contentResolver.openOutputStream(uri)?.use {
                        it.write(pem.toByteArray(Charsets.US_ASCII))
                    } != null
                }.getOrDefault(false)
            }
            snackbar.showSnackbar(
                if (saved) "Сертификат сохранён — установите его через настройки"
                else "Не удалось сохранить сертификат",
            )
        }
    }

    LaunchedEffect(refresh) { reload() }

    // The install dialog is a system activity, so the trust state can change
    // while this screen is in the background. Re-read it whenever we come back.
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) refresh++
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    Scaffold(
        containerColor = Color.Transparent,
        contentColor = MaterialTheme.colorScheme.onBackground,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        val current = state
        val certificate = current?.certificate
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text("HTTPS-инспекция", style = MaterialTheme.typography.headlineLarge)
            Text(
                "Этап 2 из 7: ядро уже подменяет TLS и видит сами запросы, но решений по их " +
                    "содержимому пока не принимает — фильтрация и вырезание рекламы это следующие этапы.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            CyrusCard(highlighted = current?.installed == true) {
                Text("Состояние", style = MaterialTheme.typography.titleMedium)
                StatusRow("Корневой сертификат", if (certificate == null) "не создан" else "создан")
                if (certificate != null) {
                    StatusRow("Действует до", format(certificate.notAfter))
                    StatusRow("Отпечаток SHA-256", fingerprint(certificate))
                }
                StatusRow(
                    "Установлен в систему",
                    when {
                        current == null -> "проверка…"
                        current.installed -> "да"
                        else -> "нет"
                    },
                )
            }

            CyrusCard(highlighted = options?.inspectHttps == true) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Расшифровывать HTTPS", style = MaterialTheme.typography.titleMedium)
                        Text(
                            when {
                                current == null -> "Проверяем состояние…"
                                current.installed -> "Ядро подменяет TLS на порту 443 и читает сами запросы"
                                else -> "Сначала установите корень — без него перехват невозможен"
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(
                        checked = options?.inspectHttps == true,
                        enabled = options != null, // TEMP-TEST
                        onCheckedChange = { enabled ->
                            val currentOptions = options ?: return@Switch
                            scope.launch {
                                settings.setTunnelOptions(currentOptions.copy(inspectHttps = enabled))
                                snackbar.showSnackbar(
                                    if (enabled) "Инспекция включена — переподключитесь, чтобы она заработала"
                                    else "Инспекция выключена",
                                )
                            }
                        },
                    )
                }
            }

            CyrusCard {
                Text("Действия", style = MaterialTheme.typography.titleMedium)
                when {
                    current == null -> Text("Чтение состояния…")
                    certificate == null -> Button(
                        onClick = {
                            scope.launch {
                                busy = true
                                try {
                                    withContext(Dispatchers.IO) { protectionCa.create() }
                                    reload()
                                    snackbar.showSnackbar("Корневой сертификат создан")
                                } catch (error: Exception) {
                                    if (error is CancellationException) throw error
                                    snackbar.showSnackbar(
                                        "Не удалось создать сертификат: ${error.message ?: "ошибка хранилища ключей"}",
                                    )
                                } finally {
                                    busy = false
                                }
                            }
                        },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Создать корневой сертификат") }

                    else -> if (!current.installed) {
                        val intent = installIntent
                        if (intent != null) {
                            Button(
                                onClick = {
                                    runCatching { context.startActivity(intent) }
                                        .onFailure {
                                            scope.launch { snackbar.showSnackbar("Не удалось открыть установку сертификата") }
                                        }
                                },
                                modifier = Modifier.fillMaxWidth(),
                            ) { Text("Установить сертификат") }
                        }
                        Button(
                            onClick = { saveLauncher.launch("cyrus-protection-ca.crt") },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("Сохранить сертификат (PEM)") }
                        TextButton(
                            onClick = {
                                runCatching { context.startActivity(protectionCa.settingsIntent()) }
                                    .onFailure {
                                        scope.launch { snackbar.showSnackbar("Не удалось открыть настройки") }
                                    }
                            },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("Открыть настройки безопасности") }
                        Text(
                            if (intent != null) {
                                "Откроется системный диалог — подтвердите установку. Cyrus не может " +
                                    "установить корень без вашего подтверждения, и не должен."
                            } else {
                                "Android 13+ принимает корневые сертификаты только через «Настройки». " +
                                    "Сохраните файл, затем: Настройки → Безопасность → Установить сертификат → Сертификат ЦС."
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    } else {
                        Text("Корень установлен и виден приложениям в хранилище доверия.")
                    }
                }

                if (certificate != null) {
                    if (confirmDelete) {
                        TextButton(
                            onClick = {
                                scope.launch {
                                    withContext(Dispatchers.IO) { protectionCa.delete() }
                                    reload()
                                    confirmDelete = false
                                    snackbar.showSnackbar("Сертификат и ключ удалены")
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("Точно удалить сертификат и ключ") }
                    } else {
                        TextButton(
                            onClick = { confirmDelete = true },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("Удалить сертификат и ключ") }
                    }
                }
            }

            CyrusCard {
                Text("Что это даст", style = MaterialTheme.typography.titleMedium)
                Bullet("Фильтрацию по адресу запроса, а не только по домену.")
                Bullet("Вырезание рекламы из ответа сайта.")
                Bullet("Работу там, где реклама и контент живут на одном домене.")
                Text(
                    "Перехват работает; ничего из списка выше ещё нет. Сейчас расшифрованный " +
                        "запрос просто уходит дальше — правила по URL и по телу ответа это следующие этапы.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            CyrusCard {
                Text("Что не изменится даже с корнем", style = MaterialTheme.typography.titleMedium)
                Bullet("Приложения с targetSdk 24+ доверяют пользовательским корням, только если разрешили это сами.")
                Bullet("Приложения с pinning — банки, соцсети — откажутся от соединения; их придётся исключать.")
                Bullet("Firefox и приложения со своим хранилищем корней сертификат не увидят.")
                Bullet("ECH скрывает имя сайта, а QUIC (HTTP/3) идёт по UDP и минует перехват.")
                Bullet("Перехват говорит по HTTP/1.1: HTTP/2 он пока не умеет, трафик пойдёт в обход или упадёт.")
                Bullet("Сайт видит TLS-отпечаток ядра, а не браузера, и может по нему узнать перехват.")
            }

            CyrusCard {
                Text("Ключи и приватность", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Приватный ключ создаётся внутри Android Keystore и не покидает устройство: " +
                        "он неизвлекаем, не попадает в резервные копии и не сохраняется в файлах. " +
                        "Cyrus не ведёт журналов содержимого трафика.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun StatusRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Text(
            value,
            modifier = Modifier.padding(start = 12.dp),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun Bullet(text: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text("•", modifier = Modifier.padding(end = 8.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
    }
}

private fun format(date: Date): String =
    DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT, Locale.getDefault()).format(date)

private fun fingerprint(certificate: X509Certificate): String =
    MessageDigest.getInstance("SHA-256").digest(certificate.encoded).joinToString(" ") { "%02X".format(it) }
