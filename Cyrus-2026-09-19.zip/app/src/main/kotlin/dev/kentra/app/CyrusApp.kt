package dev.kentra.app

import android.app.Application
import dev.kentra.data.dataModule
import dev.kentra.vpn.service.ProtectionRuleSets
import dev.kentra.vpn.service.vpnModule
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.koin.android.ext.koin.androidContext
import org.koin.android.ext.koin.androidLogger
import org.koin.core.context.startKoin
import org.koin.core.logger.Level

class CyrusApp : Application() {

    override fun onCreate() {
        super.onCreate()
        startKoin {
            androidLogger(if (BuildConfigFlags.DEBUG_DI) Level.DEBUG else Level.NONE)
            androidContext(this@CyrusApp)
            modules(dataModule, vpnModule, appModule)
        }
        // Lists are shipped in the APK, so a filter list is only ever refreshed
        // here — never on the connect path, where a download would be another way
        // for the tunnel to fail to come up. A stale list still filters; a failed
        // refresh keeps the installed copy.
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            runCatching { ProtectionRuleSets(this@CyrusApp).refreshIfStale() }
        }
    }
}

/** Tiny indirection so modules do not depend on the app's generated BuildConfig. */
object BuildConfigFlags {
    const val DEBUG_DI = false
}
