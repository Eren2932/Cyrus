package dev.kentra.app

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.kentra.core.datastore.SettingsStore
import dev.kentra.core.designsystem.CyrusCard
import dev.kentra.core.designsystem.CyrusSegmented
import dev.kentra.core.designsystem.CyrusTokens
import dev.kentra.vpn.config.PerAppMode
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private data class AppEntry(val packageName: String, val label: String)

@Composable
fun ApplicationsScreen(settings: SettingsStore) {
    val context = LocalContext.current
    val options by settings.tunnelOptions.collectAsStateWithLifecycle(initialValue = null)
    var apps by remember(context) { mutableStateOf(emptyList<AppEntry>()) }
    LaunchedEffect(context) {
        apps = withContext(Dispatchers.Default) { launcherApps(context) }
    }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    options?.let { initial ->
        var listTab by remember(initial) { mutableIntStateOf(0) }
        var mode by remember(initial) { mutableIntStateOf(modeOf(initial.perAppMode)) }
        var selected by remember(initial) { mutableStateOf(packagesOf(initial.perAppMode).toSet()) }
        var firewallEnabled by remember(initial) { mutableStateOf(initial.firewallEnabled) }
        var blocked by remember(initial) { mutableStateOf(initial.blockedPackages.toSet()) }
        var search by remember { mutableStateOf("") }
        LaunchedEffect(initial) {
            mode = modeOf(initial.perAppMode)
            selected = packagesOf(initial.perAppMode).toSet()
            firewallEnabled = initial.firewallEnabled
            blocked = initial.blockedPackages.toSet()
        }

        fun save(nextMode: Int, nextSelected: Set<String>) {
            val perApp = when (nextMode) {
                1 -> PerAppMode.Include(nextSelected.toList().sorted())
                2 -> PerAppMode.Exclude(nextSelected.toList().sorted())
                else -> PerAppMode.Off
            }
            scope.launch {
                try {
                    settings.setTunnelOptions(initial.copy(perAppMode = perApp))
                    snackbar.showSnackbar("Настройки приложений сохранены")
                } catch (error: Exception) {
                    if (error is CancellationException) throw error
                    snackbar.showSnackbar("Не удалось сохранить: ${error.message ?: "проверьте список"}")
                }
            }
        }

        fun saveFirewall(nextEnabled: Boolean, nextBlocked: Set<String>) {
            scope.launch {
                try {
                    settings.setTunnelOptions(
                        initial.copy(
                            firewallEnabled = nextEnabled,
                            blockedPackages = nextBlocked.toList().sorted(),
                        ),
                    )
                    snackbar.showSnackbar("Настройки фаервола сохранены")
                } catch (error: Exception) {
                    if (error is CancellationException) throw error
                    snackbar.showSnackbar("Не удалось сохранить фаервол: ${error.message ?: "проверьте список"}")
                }
            }
        }

        androidx.compose.material3.Scaffold(
            containerColor = Color.Transparent,
            contentColor = MaterialTheme.colorScheme.onBackground,
            contentWindowInsets = androidx.compose.foundation.layout.WindowInsets(0, 0, 0, 0),
            snackbarHost = { SnackbarHost(snackbar) },
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp, vertical = 12.dp)) {
                Text("Приложения", style = MaterialTheme.typography.headlineLarge)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Выберите, какие приложения должны проходить через Cyrus. Сам Cyrus всегда остаётся вне собственного туннеля.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(14.dp))
                CyrusCard {
                    Text("Управление трафиком", style = MaterialTheme.typography.titleMedium)
                    CyrusSegmented(
                        labels = listOf("VPN", "Firewall"),
                        selectedIndex = listTab,
                        onSelect = { listTab = it },
                    )
                    Spacer(Modifier.height(4.dp))
                    if (listTab == 0) {
                        Text("Режим VPN", style = MaterialTheme.typography.titleMedium)
                        CyrusSegmented(
                            labels = listOf("Все", "Только", "Кроме"),
                            selectedIndex = mode,
                            onSelect = { next ->
                                if (next == 1 && selected.isEmpty()) {
                                    scope.launch { snackbar.showSnackbar("Сначала выберите хотя бы одно приложение") }
                                } else {
                                    mode = next
                                    save(next, selected)
                                }
                            },
                        )
                        Text(
                            when (mode) {
                                1 -> "Через VPN пойдут только отмеченные приложения."
                                2 -> "Отмеченные приложения останутся вне VPN."
                                else -> "Через VPN идут все приложения, кроме Cyrus."
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    } else {
                        Text("Фаервол", style = MaterialTheme.typography.titleMedium)
                        Switch(
                            checked = firewallEnabled,
                            onCheckedChange = {
                                firewallEnabled = it
                                saveFirewall(it, blocked)
                            },
                            colors = SwitchDefaults.colors(checkedTrackColor = MaterialTheme.colorScheme.primary),
                        )
                        Text(
                            if (firewallEnabled) "Отмеченные ниже приложения не получат доступ к сети."
                            else "Включите фаервол и отметьте приложения ниже.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Поиск приложений") },
                )
                Spacer(Modifier.height(10.dp))
                if (apps.isEmpty()) {
                    Text("Не удалось получить список приложений", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    val visible = apps.filter {
                        search.isBlank() || it.label.contains(search, true) || it.packageName.contains(search, true)
                    }
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(2.dp),
                    ) {
                        items(visible, key = { it.packageName }) { app ->
                            if (listTab == 0) {
                                val checked = app.packageName in selected
                                AppRow(
                                    app = app,
                                    checked = checked,
                                    enabled = mode != 0,
                                    onChange = { value ->
                                        val next = selected.toMutableSet().apply {
                                            if (value) add(app.packageName) else remove(app.packageName)
                                        }.toSet()
                                        selected = next
                                        if (mode == 1 && next.isEmpty()) {
                                            mode = 0
                                            save(0, emptySet())
                                        } else if (mode != 0) {
                                            save(mode, next)
                                        }
                                    },
                                )
                            } else {
                                val checked = app.packageName in blocked
                                AppRow(
                                    app = app,
                                    checked = checked,
                                    enabled = firewallEnabled,
                                    onChange = { value ->
                                        val next = blocked.toMutableSet().apply {
                                            if (value) add(app.packageName) else remove(app.packageName)
                                        }.toSet()
                                        blocked = next
                                        saveFirewall(firewallEnabled, next)
                                    },
                                )
                            }
                        }
                    }
                }
            }
        }
    } ?: Text("Чтение настроек…", modifier = Modifier.padding(20.dp))
}

@Composable
private fun AppRow(app: AppEntry, checked: Boolean, enabled: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            app.label.take(1).uppercase(),
            modifier = Modifier.size(40.dp).clip(CircleShape).background(CyrusTokens.Accent.copy(alpha = .18f)).padding(top = 11.dp),
            color = CyrusTokens.Accent,
            fontWeight = FontWeight.Bold,
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(app.label, style = MaterialTheme.typography.titleMedium)
            Text(app.packageName, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            enabled = enabled,
            colors = SwitchDefaults.colors(checkedTrackColor = MaterialTheme.colorScheme.primary),
        )
    }
}

private fun launcherApps(context: Context): List<AppEntry> {
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return context.packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        .mapNotNull { info ->
            val app = info.activityInfo?.applicationInfo ?: return@mapNotNull null
            val packageName = app.packageName
            if (packageName == context.packageName) return@mapNotNull null
            AppEntry(packageName, app.loadLabel(context.packageManager).toString().ifBlank { packageName })
        }
        .distinctBy { it.packageName }
        .sortedBy { it.label.lowercase() }
}

private fun modeOf(mode: PerAppMode): Int = when (mode) {
    is PerAppMode.Include -> 1
    is PerAppMode.Exclude -> 2
    PerAppMode.Off -> 0
}

private fun packagesOf(mode: PerAppMode): List<String> = when (mode) {
    is PerAppMode.Include -> mode.packages
    is PerAppMode.Exclude -> mode.packages
    PerAppMode.Off -> emptyList()
}
