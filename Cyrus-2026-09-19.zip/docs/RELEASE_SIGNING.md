# Подпись релизной сборки

> Статус: инструкция для распространителя. `app/build.gradle.kts` намеренно не
> содержит `signingConfig`: репозиторий не должен хранить ключ. Этот файл
> описывает, как подключить подпись снаружи, не коммитя секреты.
> См. `docs/CODE_REVIEW_ORCHESTRATED_2026-09-19.md` H-16.

## Что сейчас

В `app/build.gradle.kts:35-40` у `release` включены `isMinifyEnabled` и
`isShrinkResources`, но `signingConfig` не задан. Поэтому `assembleRelease`
выпускает **неподписанный** APK: его нельзя установить на устройство без
ручной подписи `apksigner`, и он не обновится поверх установленного клиента.

Использовать debug-ключ для release запрещено: у него публично известный
пароль, он не годится для распространения и ломает обновление при смене ключа.

## Переменные окружения

Подпись включается только когда заданы все четыре переменные:

| Переменная | Значение |
|---|---|
| `CYRUS_KEYSTORE` | абсолютный путь к `.jks`/`.keystore` вне репозитория |
| `CYRUS_KEYSTORE_PASSWORD` | пароль хранилища |
| `CYRUS_KEY_ALIAS` | alias ключа внутри хранилища |
| `CYRUS_KEY_PASSWORD` | пароль ключа |

Если хотя бы одна не задана, release остаётся неподписанным. Это fail-closed:
лучше неподписанный артефакт, чем артефакт, подписанный не тем ключом.

## Подключение в `app/build.gradle.kts`

Блок ниже применяет другой агент-владелец файла; он приведён как есть, чтобы
правка была механической. Добавить перед `android { ... }`:

```kotlin
val keystorePath = System.getenv("CYRUS_KEYSTORE")
val keystorePassword = System.getenv("CYRUS_KEYSTORE_PASSWORD")
val keyAlias = System.getenv("CYRUS_KEY_ALIAS")
val keyPassword = System.getenv("CYRUS_KEY_PASSWORD")
val releaseSigningReady = listOf(keystorePath, keystorePassword, keyAlias, keyPassword)
    .all { !it.isNullOrBlank() }
```

Внутри `android { ... }` добавить `signingConfigs` и сослаться на него из
`buildTypes.release`:

```kotlin
    signingConfigs {
        if (releaseSigningReady) {
            create("release") {
                storeFile = file(keystorePath!!)
                storePassword = keystorePassword
                this.keyAlias = keyAlias
                this.keyPassword = keyPassword
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (releaseSigningReady) signingConfig = signingConfigs.getByName("release")
        }
    }
```

Ключ хранится вне дерева проекта: `.gitignore` уже исключает `*.keystore`
(кроме debug). Никогда не коммитьте `.jks` и не печатайте пароли в лог.

## Настройка в GitHub Actions

Хранилище и пароли кладутся в Secrets репозитория, а не в файлы:

1. Закодировать хранилище в base64: `base64 -i release.jks | pbcopy`.
2. Создать секреты `CYRUS_KEYSTORE_BASE64`, `CYRUS_KEYSTORE_PASSWORD`,
   `CYRUS_KEY_ALIAS`, `CYRUS_KEY_PASSWORD`.
3. В workflow материализовать файл и пробросить путь в `CYRUS_KEYSTORE`:

```yaml
      - name: Materialise release keystore
        env:
          CYRUS_KEYSTORE_BASE64: ${{ secrets.CYRUS_KEYSTORE_BASE64 }}
        run: |
          printf '%s' "$CYRUS_KEYSTORE_BASE64" | base64 --decode > "$RUNNER_TEMP/cyrus-release.jks"
          echo "CYRUS_KEYSTORE=$RUNNER_TEMP/cyrus-release.jks" >> "$GITHUB_ENV"

      - name: Assemble signed release
        env:
          CYRUS_KEYSTORE_PASSWORD: ${{ secrets.CYRUS_KEYSTORE_PASSWORD }}
          CYRUS_KEY_ALIAS: ${{ secrets.CYRUS_KEY_ALIAS }}
          CYRUS_KEY_PASSWORD: ${{ secrets.CYRUS_KEY_PASSWORD }}
        run: gradle --no-daemon :app:assembleRelease
```

Секреты не попадают в кэш, артефакты и логи: `printf` без `echo`, файл — в
`$RUNNER_TEMP`, а не в рабочем каталоге.

## Проверка подписи

```bash
apksigner verify --print-certs app/build/outputs/apk/release/app-release.apk
```

`apksigner` должен показать ваш `CN`, а не `CN=Android Debug`. Проверьте также,
что `versionCode` (`app/build.gradle.kts:15`) выше установленной версии — иначе
Android откажет в обновлении.

## TODO(verify)

Инструкция не проверялась реальным прогоном `assembleRelease`: в текущем
окружении нет release-ключа и запрещён запуск Gradle. Перед первым релизом
подтвердите, что:
- `signingConfigs` подключается до `buildTypes` (иначе `getByName("release")`
  не найдёт конфигурацию);
- `apksigner verify` показывает ожидаемый отпечаток;
- собранный release-APK устанавливается поверх предыдущей версии с той же
  подписью.
