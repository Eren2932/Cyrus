# Cyrus 0.5.0-dev — независимое ревью

**Дата:** 2026-09-18
**Объект:** `/Users/sabir/Downloads/Cyrus`, 83 `.kt` под `src/` (~6 942 строки), 16 Gradle-модулей
**Метод:** чтение исходников + ручная верификация каждой находки. Сборка, lint, JUnit и native-валидация **не запускались** — все выводы о компиляции статические, по коду и build-файлам.
**Статус документа:** отчёт ревью, не часть продукта.

---

## Резюме

Архитектурный скелет проекта крепкий: слоистость `domain` действительно чистая (JVM-модуль без Android API), фичи не зависят друг от друга, SDK/JVM-консистентность по всем модулям, конфиг sing-box собирается типизированной моделью, а не строковой склейкой, крипто-ядро `SecretCipher` использует AES-256-GCM с Keystore и AAD.

Проблемы сосредоточены не в архитектуре, а в **трёх местах**: (1) текущее дерево **не проходит собственные гейты сборки** и не собирается с нуля; (2) **Xray dual-core не работает ни в одном режиме**, хотя считается поставленной фичей; (3) **VPN-специфичная безопасность**: учётные данные лежат в базе открытым текстом, а DNS принудительно уходит мимо туннеля.

Отдельно: проект **не находится под контролем версий**, а в корне лежат **живые ключи доступа**.

---

## CRITICAL — блокеры

### C1. Дерево не проходит собственный гейт `check_native.py`

`vpn/service/libs/` содержит **два** AAR:

```
libXray.aar   95 393 457 байт
libbox.aar    31 667 302 байта
```

`tools/check_native.py:13-14` требует ровно один: `if len(files) != 1: raise ValueError(...)`. Этот гейт вызывается из `build.sh:7`, `Build-Cyrus.ps1:9`, `.github/workflows/android.yml:60`, `.github/workflows/build-libbox.yml:31`, `docs/workflows/build-zip.yml:192-193`.

**Следствие:** ни один путь сборки не проходит дальше проверки AAR. Плюс `build-libbox.sh:20-23` отказывается пересобирать libbox, если в каталоге есть *любой* `*.aar` — то есть наличие `libXray.aar` блокирует и пересборку sing-box.

### C2. `libXray.aar` невоспроизводим

`XrayVpnEngine.kt:8` импортирует `libXray.LibXray`. Но `.gitignore:22` игнорирует `vpn/service/libs/*.aar`, а скрипта сборки libXray **не существует** — `build-libbox.sh` собирает только sing-box. Чистый checkout не соберётся: `:vpn:service:compileDebugKotlin` упадёт на неразрешённом `libXray.LibXray`.

Рядом лежат распакованные `libxray_tmp/`, `tmp_xray2/`, `tmp_xray3/`, `tmp_classes/` — по ~228 МБ каждый. Это следы ручной сборки, не воспроизводимый процесс.

### C3. Xray dual-core не работает ни в одном режиме

**VPN-режим** (основной): `XrayConfigFactory.kt:21` при `ConnectionMode.VPN` безусловно вызывает `error("Xray engine does not support native VPN mode without external tun2socks...")`. А `TunnelControllerImpl.kt:56` направляет в Xray именно xhttp/kcp/quic-ключи, затем `:61` строит конфиг. Итог: **любой XHTTP/mKCP/QUIC-ключ падает на connect()** с «Xray config build failed». `XrayVpnEngine` не запускается никогда.

**Proxy-режим:** `XrayConfigFactory.kt:22-36` биндит `mixed` на `127.0.0.1:options.proxyPort`, и `ConfigFactory.kt:83-84` строит **второй** `mixed` inbound на том же порту. Плюс `TunnelControllerImpl.kt:66-72` наводит SOCKS-outbound на тот же порт. Результат — либо `address already in use` при `box.start()`, либо петля в себя.

**Следствие:** заявленная в `XRAY_DUALCORE_PLAN.md` и в README фича не существует. `CompositeVpnEngine.kt:28-34` при этом запускает **оба ядра одновременно** без координации владения TUN.

### C4. Учётные данные лежат в Room открытым текстом

`SecureStorage.transform()` шифрует `name, server, uuid, password, tlsJson, transportJson` — и **не** шифрует `connectionIdentity`.

При этом:
- `ImportReport.kt:11` — `connectionIdentity()` = `rawLink.substringBefore('#')`
- `DefaultLinkParser.kt:74` — `rawLink = normalized` (полная ссылка)
- `ProfileMapper.kt:85` — `connectionIdentity = profile.connectionIdentity()`
- `Entities.kt:26` — колонка `connectionIdentity` в `profiles`

**Следствие:** в `kentra.db` в открытом виде лежат `vless://<uuid>@host:port?...`, `trojan://<password>@...`, `ss://base64(method:password)@...`, приватные ключи WireGuard/SSH. Вся обвязка `SecretCipher` + Keystore обходится стороной. Любой доступ к файлу БД (root, forensic-извлечение, OEM-бэкап) отдаёт все ключи.

**Фикс:** хранить `HMAC-SHA256(dek, rawLink.substringBefore('#'))` — колонке нужна только дедупликация, обратимость не требуется.

### C5. Живые ключи доступа в репозитории

- `scratch.kts:2` — реальный URL подписки с токеном: `https://mc.minecraft.webcam/sub/f3b23a84e818d73fb61c865265b1e33d5a5a?app=v2rayng`
- `scratch3.kts:22` — base64-блob подписки с UUID `4c7a0b95-1dcb-4044-b948-69e1b4881733`, Reality `pbk=9ngNG5S7MWDT7blqRQZix2-Ze24yRxj8nNNmEU8lTkg`, хост `dbkv4jecap48.minecraft.webcam`

`.gitignore` их не покрывает (`:19` содержит только `test_*.kt`).

**Действие:** удалить `scratch*.kts`, **отозвать/ротировать токен подписки и ключи**. Считать скомпрометированными.

### C6. Нет контроля версий

Каталог `.git` отсутствует, `git log` возвращает код 128. `FILES.sha256` (198 записей) — ручная замена истории. Для VPN-клиента с двумя нативными ядрами это означает отсутствие отката, bisect, blame и аудита изменений.

### C7. Тесты `domain` не компилируются

`domain/src/test/.../ImportKeysUseCaseTest.kt:14-23` реализует `ProfileRepository`, но **не переопределяет** `getAllIdentities()`, объявленный в `Repositories.kt:20` без дефолта. Модуль тестов не собирается, заявленные сценарии не выполняются.

---

## HIGH

### H1. Одна плохая строка убивает всю подписку

`SubscriptionRepositoryImpl.kt:118-119`:
```kotlin
if (report.profiles.isEmpty() || report.issues.isNotEmpty()) throw AppError.Parse(...)
```
Подписка из 500 ключей с одной мусорной строкой импортирует **ноль** профилей. Старые ключи при этом сохраняются, поэтому пользователь молча остаётся на устаревшем наборе. Противоречит `UPGRADE_0.5.0.md:43` («несовместимый узел сохраняется и виден с предупреждением»).

**Фикс:** условие `profiles.isEmpty()`; `issues` — в предупреждения.

### H2. DNS принудительно уходит мимо туннеля

`ConfigFactory.kt:144-148`:
```kotlin
rules = listOf(DnsRule(outbound = listOf("any"), server = "dns-direct", disableCache = true)),
final = "dns-remote",
```
Правило с `outbound = ["any"]` перехватывает **все** запросы, поэтому `final = "dns-remote"` (`:141`, TLS поверх прокси) не срабатывает никогда. Весь DNS резолвится через `dns-direct` → `detour = "direct"` (`:142`).

**Следствие:** DNS-утечка к локальному резолверу при активном VPN + неверная geo/CDN-резолюция. Для VPN-клиента это дефект уровня «продукт не выполняет обещанное».

**Фикс:** убрать безусловное правило, развести сплит-DNS через `rule_set`/`domain`.

### H3. Движок AmneziaWG недостижим, но тянет 5 МБ AAR

`CompositeVpnEngine.kt:22-26` выбирает `AmneziaVpnEngine` только если конфиг содержит `[Interface]`/`PrivateKey`. Но `TunnelControllerImpl.kt:72-77` всегда строит sing-box JSON через `ConfigFactory`, а `VpnEngineKind` (`TransportCompat.kt:4`) знает только `SING_BOX`/`XRAY`.

**Следствие:** `AmneziaVpnEngine` не исполняется никогда, при этом в поставку входят `amneziawg-android-1.2.2.aar` (4.9 МБ в корне), распакованный `awg-aar/` и `test-awg.gradle`. Мёртвый вес в APK.

### H4. Fail-closed путь — мёртвый код

`TunnelControllerImpl.kt:47,109` ветвятся по `engine.id == "unavailable"`, но `VpnModule.kt:13` подключает только `CompositeVpnEngine` (`id = "composite"`). `UnavailableVpnEngine` не инстанцируется нигде. Задокументированная гарантия «без ядра — честный отказ» недостижима.

### H5. UI показывает «Connected» без реального туннеля

Два независимых пути:

1. **Xray:** `XrayVpnEngine.kt:42-43` лишь логирует результат `LibXray.invoke(...)` и не проверяет его; `:50` бесконечно эмитит `TrafficSample(0, 0)`. `TunnelServiceRunner.kt:48` затем публикует `Connected`.
2. **AmneziaWG:** `AmneziaVpnEngine.kt:29` — `b.setState(...)` возвращается сразу; `:20` — `onStateChange` пустой. `TunnelServiceRunner.kt:47-48` безусловно публикует `Connected`, `traffic = emptyFlow()` (`:49`) скрывает отсутствие трафика.

**Следствие:** пользователь видит «VPN включён» при неработающем туннеле. Для VPN-продукта это опаснее обычного бага — человек считает себя защищённым.

Плюс `XrayVpnEngine.kt:47` создаёт `CoroutineScope(Dispatchers.IO).launch{...}`, отвязанный от родителя.

### H6. `SecretCipher.decrypt` принимает открытый текст (downgrade)

`SecretCipher.kt:65`: `if (!isEncrypted(value)) return value`. Любое значение без префикса `cyrus:enc:v1:`/`v2:` возвращается как есть. Атакующий с записью в БД (подмена бэкапа, root) подставляет свои `uuid`/`password` — приложение подключается к его серверу без сигнала о подмене. `SecureStorage.prepare()` пересечёт строку только на следующем старте, то есть **после** использования.

### H7. Xray логирует конфиг с учётными данными

`XrayVpnEngine.kt:43` — `Log.d("XrayVpnEngine", "Xray start result: $result")`, где `result` — сырой ответ `LibXray.invoke(requestJson)`, а `requestJson` содержит весь `session.xrayJson` (UUID, пароли, ключи Reality). `:54` — `Log.e(..., e)`, `:17` — `printStackTrace()`.

### H8. Экспорт падает для WireGuard/SSH/Naive/Tor

`ProfileLinkWriter.kt:39-45` умеет только VLESS/Trojan/SS/TUIC/Hysteria2/HTTP/SOCKS; остальные попадают в `else -> error("Неподдерживаемый формат экспорта")`. Так как `ProfileEditor.kt` сохраняет через `parser.parse(parser.export(proposed))`, такие профили **нельзя отредактировать, сохранить или расшарить** — пользователь получает «Не сохранено» без объяснения.

### H9. Критичные для безопасности пути не покрыты тестами

Нет ни одного теста для `SecretCipher`, `SecureStorage`, `SubscriptionRepositoryImpl`, `TunnelControllerImpl`, `TunnelServiceRunner`. Инструментальных тестов VPN-сервиса (`CyrusVpnService`/`CyrusProxyService`) нет вообще — единственный `androidTest` это `DesignRegressionTest` в `core:designsystem`.

**7 из 16 модулей без тестов:** `app`, `core:ui`, `core:database`, `core:datastore`, `core:network`, `feature:profiles`, `feature:store`.

### H10. Release/R8-путь не проверяется

`.github/workflows/android.yml:63-75` выполняет только `compileDebugKotlin`, `compileReleaseKotlin`, `test`, `lintDebug`, `assembleDebug`. `assembleRelease` не запускается, хотя `app/build.gradle.kts:36` включает `isMinifyEnabled = true`, а `gradle.properties:9` — R8 full mode. Невалидированная конфигурация минификации для релиза.

### H11. ProGuard хранит несуществующий класс

`app/proguard-rules.pro:26` — keep для `dev.kentra.vpn.service.KentraVpnService`. Такого класса в проекте нет (grep находит его только в самом правиле); реальный компонент — `CyrusVpnService`. Правило — no-op. Плюс `:17` `-keepclassmembers class * { public <init>(...); }` сохраняет **все** публичные конструкторы, сводя на нет обфускацию и shrinking. И `:2` не сохраняет `SourceFile,LineNumberTable` → стектрейсы релиза нечитаемы.

### H12. Нарушения слоистости

- `core/datastore/build.gradle.kts:19` — `api(project(":vpn:config"))`: модуль `core:*` зависит от `vpn:*`
- `vpn/service/build.gradle.kts:20` — `:core:datastore`, используется в `TunnelControllerImpl.kt:8`
- `feature/profiles/build.gradle.kts:20` — `:vpn:config`

Циклов нет, но направление зависимостей противоречит заявленной схеме «core → data → vpn → feature».

### H13. Нет Gradle wrapper

`gradlew`, `gradlew.bat`, `gradle/wrapper/` отсутствуют. Workflow хардкодят `8.11.1` (`android.yml:41`, `build-zip.yml:26`), при этом в `.gradle/` лежат кэши 8.9, 9.2.0, 9.5.1 — локальные сборки шли на версиях, несовместимых с AGP 8.7.3.

### H14. Лимит импорта — 50 МиБ, а сообщение врёт про 1 МиБ

`DefaultLinkParser.kt:244` — `const val MAX_INPUT = 52_428_800 // 50 MiB`, но `:23` возвращает «Лимит импорта — 1 МиБ текста», и то же утверждают `CLAUDE.md:21` и `IMPORT_FORMATS.md:9`. `inspect` затем прогоняет `decodeBase64OrNull` по всему payload (`:26`) — 50 МиБ Base64 разворачиваются в ~150-200 МБ аллокаций, что даёт OOM/ANR на слабом устройстве.

`MAX_LINES = 2000` и `MAX_LINK = 65536` объявлены, но `MAX_LINES` **не ограничивает работу**: `:32-33` вычисляет `line.trim()` **до** проверки `index >= MAX_LINES`, поэтому все 50 МиБ строк всё равно сканируются и тримятся.

### H15. Один переразмеренный узел убивает весь Xray-JSON импорт

`XraySubscriptionReader.kt:66-68` — `require(generatedChars <= 4_194_304 ...)` находится внутри внешнего `try` (`:39`), но **снаружи** per-node `runCatching` (`:60-64`). Превышение уходит в catch на `:76` и возвращает **ноль** профилей: подписка на 100+ узлов от панели отбрасывается целиком.

### H16. Секреты WireGuard/SSH не URL-декодируются

`DefaultLinkParser.kt:171,182` (WG) и `:194` (SSH) берут `uri.rawUserInfo` как есть. Query-параметры декодируются (`:231-232`), `standard()`/`proxy()` — тоже. Приватный ключ WireGuard с `+`, `/`, `=` приходит percent-encoded и сохраняется искажённым → подключение не состоится.

### H17. Tor принимается, но запуститься не может

`tor()` (`DefaultLinkParser.kt:222-229`) парсит, `validateProfile` пропускает TOR (`ConfigFactory.kt:112`, `:70`), редактор показывает «Ядро принимает этот ключ». Но `ConfigFactory.kt:350-353` эмитит `{"type":"tor"}` без `executable_path`, а tor-outbound в pin-нутой версии требует внешний бинарь. Гарантированный провал на `box.start()`.

---

## MEDIUM

| # | Находка | Доказательство | Последствие |
|---|---------|----------------|-------------|
| M1 | Движок выбирается по неверному полю | `TunnelControllerImpl.kt:56` читает `profile.parameters["type"]`, а не `profile.transport.type`; у профилей из редактора этого параметра нет | xray-only транспорт может уйти в sing-box |
| M2 | INI-инъекция в AmneziaWG | `ConfigFactory.kt:48-70` интерполирует декодированные query-параметры (`public_key`, `dns`) в INI через `buildString` | `%0A` вставляет произвольные директивы |
| M3 | Нет валидации наличия ключей WG | `validateProfile` не проверяет `password`/`public_key` | `{"type":"wireguard"}` с null-ключами уходит в `box.start()` |
| M4 | DEK пишется через `apply()` | `SecretCipher.kt:46` | убийство процесса до flush → новый DEK, старые данные нерасшифровываемы (необратимая потеря) |
| M5 | SSRF: нет блокировки loopback/private | `SubscriptionRepositoryImpl.kt:125` требует только `https` + непустой host | `https://127.0.0.1`, `https://169.254.169.254` допустимы — проба локальных/метадата-сервисов |
| M6 | Одноразовые эффекты теряются | `Mvi.kt:41` — `Channel(16, DROP_OLDEST)` | запрос разрешения VPN/навигация молча теряются при всплеске |
| M7 | Неограниченный буфер | `TunnelServiceRunner.kt:21` — `Channel.UNLIMITED` | неограниченный рост |
| M8 | Неотменяемое завершение | `LibboxVpnEngine.kt:117` — `NonCancellable` без таймаута вокруг `box.close()` | зависший native close делает `stop()` неотменяемым |
| M9 | Тяжёлая работа в композиции | `ProfilesScreen.kt:55-57` — `configFactory.validateProfile(it)` внутри `remember` | синхронная валидация всех профилей на потоке композиции |
| M10 | Неконсистентный сбор состояния | `SettingsScreen.kt:21` — `collectAsState` вместо `collectAsStateWithLifecycle` | утечка работы вне STARTED |
| M11 | Busy-guard с гонкой | `HomeViewModel.kt:59-62` читает `currentState` вне корутины | двойной тап проходит проверку; спасает только Mutex в контроллере |
| M12 | Schema drift к 1.11.1 | AAR содержит миграции для используемых полей: `migrate-wireguard-outbound-to-endpoint` (`ConfigFactory.kt:315`), `migrate-legacy-special-outbounds-to-rule-actions` (`:87-88`), `migrate-destination-override-fields-to-route-options` (`:163-164`) | работает сейчас, сломается на 1.12/1.13 |
| M13 | Статистика: доки устарели, сбой молчит | `LibboxVpnEngine.kt:182-204` **подключает** `CommandClient(Libbox.CommandStatus)`, но `:195` `runCatching { client.connect() }` глотает ошибку | UI вечно показывает «—» без диагностики. `UPGRADE_0.5.0.md:51` и pain #6 неверны |
| M14 | Импорт сериализован глобальным мутexом | `UseCases.kt:21-24` — singleton `Mutex` вокруг parse+DB | все импорты и refresh подписок идут по очереди |
| M15 | Дублирование извлечения | `XraySubscriptionReader.kt:61` ре-сериализует каждый outbound через `o.toString()`; `getAllIdentities()` грузит все идентификаторы на каждый импорт | двойная работа |
| M16 | Конфиг для AWG может отдать `direct` | `ConfigFactory.kt:327-330` при прямом вызове `config()` | весь трафик открытым текстом под тегом прокси; безопасно только потому, что `build()` выходит раньше (`:46`) |

---

## LOW

- **L1.** `DummyTunVpnEngine.kt` — мёртвый код: `:96` эмитит фейковую статистику `TrafficSample(1024L, 1024L)`, `:42` маршрутизирует `0.0.0.0/0` без прокси. Не подключён нигде. **Удалить.**
- **L2.** 37 скомпилированных файлов под `core/common/bin`, `core/mvi/bin`, `domain/bin`, `vpn/config/bin`, `vpn/link/bin`. `.gitignore` не покрывает `bin/`.
- **L3.** Репозиторий ~2.0 ГБ: `app/build` 1.1 ГБ, `libxray_tmp`/`tmp_xray2`/`tmp_xray3` ~228 МБ каждый, `libbox_tmp` 83 МБ, `amneziawg-android-1.2.2.aar` 4.9 МБ в корне (не используется).
- **L4.** `.DS_Store` в 5 местах. `FILES.sha256` расходится с `BUILD_FIX_0.5.0.md:11` (198 против «175 записей»).
- **L5.** Lint запускается только для `:app` (`android.yml:72`, без `checkDependencies = true`) — lint остальных 15 модулей молча пропускается.
- **L6.** `build-zip.yml:9` триггерится на `.github/workflows/build.yml`, которого не существует. README:14 при этом утверждает, что workflow установлен и менять его не нужно.
- **L7.** `build-libbox.sh:9` пинит `GOMOBILE_VERSION='latest'`, `build-zip.yml:28` — `v0.1.4`. Расхождение тулчейна.
- **L8.** `android.yml:57-59` молча пропускает `build-libbox.sh`, так как AAR уже есть — этот путь не выполняется никогда.
- **L9.** Версии вне `libs.versions.toml`: `app:72` desugar `2.1.4`; `core/designsystem:32-34` (`ui-test-junit4`, `androidx.test.ext:junit:1.2.1`, `runner:1.6.2`); `vpn/service:24` amneziawg `1.2.2`; `feature/profiles:21` ZXing `4.3.0`.
- **L10.** `vpn/config/build.gradle.kts:24-27` объявляет `outputs.dir` для fixtures, которые JUnit пишет как побочный эффект; `tools/check_generated_configs.sh:14-19` требует ≥12 fixtures — корректность сборки зависит от недекларированных side-effect'ов.
- **L11.** `MainActivity.kt:52-55` читает `Settings.Global.getFloat` на главном потоке в композиции.
- **L12.** Мёртвые члены: `HomeState.message` (`HomeContract.kt:20`), `HomeState.canConnect` (`:22`), `ProfilesEffect.ImportSucceeded` (`ProfilesContract.kt:34`).
- **L13.** `XrayVpnEngine.kt:16` — `catch (Throwable) { e.printStackTrace() }` скрывает отказ `loadLibrary("gojni")`.

**Статистика обработки ошибок:** 18 `catch` в `src/main`, из них **5 глушат молча** (`XrayVpnEngine.kt:16,72`, `AmneziaVpnEngine.kt:39`, `DummyTunVpnEngine.kt:68,85`). Отдельно **52 `runCatching`** в `src/main`, **33 из них в `LibboxVpnEngine.kt`**, большинство отбрасывает результат (`getOrNull()` ×9, `getOrDefault()` ×15).

---

## Что проверено и держится

Не всё плохо — эти заявления из документации подтверждены кодом:

- **`domain` действительно чистый:** `domain/build.gradle.kts:2` — `org.jetbrains.kotlin.jvm`, ни одного импорта `android`/`androidx` во всём модуле.
- **Фичи не зависят друг от друга:** ни в одном `feature/*/build.gradle.kts` нет зависимости на другую фичу.
- **SDK/JVM-консистентность:** все 12 Android-модулей — `compileSdk 35`, `minSdk 24`, Java 17, `jvmTarget 17`; все 5 JVM-модулей — `jvmToolchain(17)`.
- **Манифест VPN-сервиса корректен:** `CyrusVpnService` — `exported="false"` + `android:permission="android.permission.BIND_VPN_SERVICE"` + фильтр `android.net.VpnService`. `CyrusProxyService` не экспортирован. `SecureCaptureActivity` — `exported="false"` и `FLAG_SECURE`. `allowBackup="false"`, `fullBackupContent="false"`, `usesCleartextTraffic="false"`. Разрешения минимальны.
- **Крипто-ядро:** AES-256-GCM, 12-байтовый `SecureRandom` IV на каждое шифрование (`SecretCipher.kt:58`), 128-битный тег, AAD с привязкой к полю (`:60`), версионированный конверт V1/V2, KEK из `AndroidKeyStore` (`:19-23`), `decrypt` бросает исключение при сбое (`:77-80`). Единственная дыра — C4.
- **Сеть:** `followRedirects = false` подтверждён (`HttpClientFactory.kt:29`); нет `trustAllCerts`/`hostnameVerifier`/кастомного `X509TrustManager`; нет Ktor `Logging`, поэтому заголовки и тела не печатаются; HTTPS-only, без userinfo и фрагмента.
- **Парсинг:** `Base64Ext` валидирует padding и длину, декодирует UTF-8 с `CodingErrorAction.REPORT`; регэкспы линейные, катастрофического бэктрекинга нет; битые ссылки возвращают `null` и попадают в `issues`, а не коэрсятся.
- **Fail-closed валидация:** `OptionsValidation.validate()` и `ConfigFactory.validateProfile` (`:94-137`) громко отклоняют неподдерживаемое — включая `pinSHA256`, `cyrus-unsupported`, ECH, XHTTP-режимы.
- **Таблица алиасов транспортов корректна и полна:** `TransportCompat.kt:33-44` — tcp/raw/none/original, ws/websocket, grpc/gun, http/h2/h2c/http2, httpupgrade/upgrade, xhttp/splithttp/xhttps, kcp/mkcp, quic; неизвестные значения отклоняются через `singBoxRejection` (`:70-81`).
- **Конфиг собирается типизированной моделью** (`SingBoxModel.kt`), а не строковой склейкой — инъекции через JSON нет.
- **Корутины:** `runBlocking`/`GlobalScope` в проекте отсутствуют; `CancellationException` перебрасывается во всех 5 местах широкого перехвата; `NonCancellable` ограничен teardown'ом нативного ядра; `appRunCatching` (`AppError.kt:17-23`) корректен и покрыт `CancellationTest.kt`.
- **Пакетная вставка корректна:** `upsertAll` — одна Room-транзакция `@Upsert(List)` (`Daos.kt:25-26`).
- **buildfix 2 и 3 реальны:** `LibboxVpnEngine.kt:327-340` действительно защищает 3-аргументный `requestNetwork` от API 26; `CHANGE_NETWORK_STATE` есть в манифесте; `values-v29/themes.xml` существует, `values/themes.xml` не содержит `forceDarkAllowed`; `CyrusWallpaper.kt:29-37` использует `remember` + `LaunchedEffect`; `app/build.gradle.kts:66-67` содержит `textReport`/`textOutput`.
- **Паinы из `memory/projects/cyrus.md` частично устарели:** WireGuard, AmneziaWG и SSH **реализованы**; per-subscription refresh (`refresh`/`refreshAll`) **существует**; `CommandServer` статистики **подключён** (`LibboxVpnEngine.kt:182-204`).

---

## Порядок работ

**Немедленно (блокеры):**
1. C5 — отозвать токен подписки и ключи из `scratch*.kts`, удалить файлы, дополнить `.gitignore`
2. C4 — убрать `connectionIdentity` из открытого хранения (HMAC вместо raw-ссылки)
3. C6 — `git init`, первый коммит, нормальный `.gitignore` (`bin/`, `scratch*.kts`, `validation/`, `*.aar`, `.DS_Store`)
4. C1/C2 — решить судьбу двух AAR: либо один ярус за раз, либо доработать `check_native.py` и добавить воспроизводимую сборку libXray

**Далее (функциональность):**
5. C3 — Xray: либо реализовать chained-схему (sing-box TUN + Xray на loopback), либо честно отклонять xray-only транспорты на connect и удалить мёртвый путь
6. H2 — починить DNS-правила (это утечка, а не косметика)
7. H5 — запретить публикацию `Connected` без подтверждения состояния туннеля
8. C7, H9 — починить `ImportKeysUseCaseTest`, добавить тесты на `SecretCipher`/`SecureStorage`/`SubscriptionRepositoryImpl`
9. H1, H14, H15 — устойчивость импорта и честные лимиты

**Гигиена:**
10. H10/H11, L1/L3/L5/L9 — release-сборка, ProGuard, мёртвый код, объём репозитория, версии в каталог

---

## Ограничения этого ревью

Не выполнялись: компиляция, R8, lint, JUnit, native-валидация, запуск на устройстве. Выводы о неработоспособности сборки основаны на чтении build-скриптов и гейтов, а не на прогоне. Не ревьюились бинарники внутри `libbox.aar`, `libXray.aar` и Amnezia AAR — возможны дополнительные риски в нативном коде. Проверка поведения `GoBackend.setState` в H5 выведена из отсутствия колбэка, а не из исходников библиотеки.
