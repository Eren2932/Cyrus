# Cyrus 0.5.0-dev — Оркестрированное техническое ревью

**Дата:** 19 сентября 2026
**Роль:** Оркестратор (не исполнитель по файлам)
**Метод:** 8 изолированных субагентов с непересекающимися зонами + личная верификация всех CRITICAL/HIGH находок
**Объём:** 16 Gradle-модулей, 117 `.kt`, 21 `.kts`, 11 `.py`, 39 `.md` — 7 475 строк Kotlin/Java в `src/`

---

## 1. Как проводилось ревью (методология оркестрации)

### 1.1 Декомпозиция на изолированные зоны

Единственный способ отревьюить проект такого размера без потери качества контекста — не читать 117 файлов в одном контексте, а раздать их восьми субагентам с **непересекающимися зонами ответственности** и жёстким read-only мандатом. Каждый субагент получил:

- точный список путей (без «посмотри вокруг»);
- запрет на `Edit`/`Write` — ревью, а не рефакторинг;
- требование ссылаться на `путь:строка` и указывать severity;
- явный чек-лист доменных рисков (для vpn/config — DoS/SSRF/инъекции; для vpn/service — Android lifecycle; для data — криптоаудит);
- требование «evidence-based, без выдумок; если не смог проверить — скажи прямо».

Правило «игнорируй `*/bin/*`» было критично: в проекте лежат **дубликаты скомпилированных исходников** (`core/common/bin/main/...`, `domain/bin/main/...`, `vpn/config/bin/main/...`), которые удвоили бы объём ревью без пользы.

| Агент | Зона | Файлов |
|---|---|---|
| **A** | `domain` + `core/{common,mvi,ui,database,datastore,network,designsystem}` | 25 |
| **B** | `vpn/link` + `vpn/config` (парсинг недоверенного ввода, генерация конфигов) | 13 |
| **C** | `vpn/service` (движки, VpnService, lifecycle) | 17 |
| **D** | `data` + `feature/{home,profiles,store}` (крипто, биллинг, Compose/MVI) | 24 |
| **E** | `app` + манифесты + ресурсы + нативные AAR/.so | ~20 |
| **F** | Gradle/CI/скрипты/FILES.sha256 | ~22 |
| **G1** | `tools/*.py` (guards) + `validation/` | 24 |
| **G2** | `docs/` + `memory/` + `scratch*.kts` | ~45 |

### 1.2 Верификация (trust but verify)

Отчёт субагента описывает **намерение**, а не факт. Поэтому все CRITICAL/HIGH прошли личную перепроверку оркестратором. Результаты — в §5. Ни одна из 11 проверенных критических находок не оказалась ложной; наоборот, три находки были **усилены** при перепроверке (см. §5.1, §5.5, §5.7).

### 1.3 Что НЕ делалось

- Сборка не запускалась (`gradle build`, `assembleRelease`) — вне рамок ревью.
- Проприетарные бинарные AAR (`libXray.aar`, `amneziawg-android`) не дизассемблировались на предмет бэкдоров — оценивалась только цепочка поставки и целостность.
- Рантайм-поведение на устройстве не воспроизводилось (использован существующий `docs/DEVICE_TEST_0.5.0.md`, подлинность которого подтверждена по SHA-256 APK).

---

## 2. Паспорт проекта

| Параметр | Значение |
|---|---|
| Назначение | Android VPN-клиент: sing-box v1.11.1 + Xray-core + AmneziaWG за единым `VpnEngine` |
| Стек | Kotlin 2.0.21, Compose BOM 2024.12.01, AGP 8.7.3, Koin 4.0, Ktor 3.0.2, Room 2.6.1 |
| Модули | 16 (app, domain, data, core×7, vpn×3, feature×3) |
| Архитектура | Заявлена Clean Architecture + MVI; фактически слои протекают (§4.3) |
| minSdk / targetSdk | 24 / 35 |
| Сборка | GitHub Actions (`android.yml`), Gradle 8.11.1, JDK 17, NDK 28 |
| VCS | **Отсутствует** — каталог не является git-репозиторием |
| Размер рабочего дерева | 2.1 ГБ (из них ~1.1 ГБ — `app/build`, ~893 МБ — `vpn/service/libs`) |

**Заявленная цель** (`CLAUDE.md:4`): «макс. поддержка VPN-протоколов, парсинг всех подписок, корректный VPN, перф парсинга/добавления ключей». По итогам ревью **два из четырёх пунктов не выполняются**: двухъядерность Xray неработоспособна (§5.4), а перф импорта упирается в лимит в 50× больше заявленного (§5.6).

---

## 3. Сводная оценка качества

| Область | Оценка | Обоснование |
|---|---|---|
| Архитектура и слои | **5 / 10** | 16 модулей, вменяемые порты (`domain/repository`), но `vpn/service → core/datastore`, `feature/profiles → vpn/config`, `core/datastore → vpn/config` — слои протекают |
| Домен (`domain`) | **7 / 10** | Чистый Kotlin, нет Android-зависимостей, но `requiredEngine` для неизвестного транспорта молча даёт SING_BOX (fail-open) |
| Core-инфраструктура | **5 / 10** | `DispatcherProvider` и `Logger` — **мёртвый код**; весь прод хардкодит `Dispatchers.IO` и пишет в `android.util.Log` напрямую |
| Парсинг (`vpn/link`) | **6 / 10** | Корректный base64, fail-closed `runCatching`, есть негативные тесты; но лимит в 50× больше заявленного и авто-декод всего payload |
| Генерация конфигов (`vpn/config`) | **4 / 10** | sing-box/Xray/ServerSetup строятся типизированно (JSON-инъекция невозможна) — но AWG-ветка собирается конкатенацией строк с обходом валидации |
| VPN-сервис (`vpn/service`) | **5 / 10** | Идемпотентный teardown, `NonCancellable`, FIFO-сериализация — сильная инженерная работа; но fail-open ветки, неатомарный счётчик здоровья, мёртвый `UnavailableVpnEngine` |
| Данные и крипто (`data`) | **5 / 10** | AES-256-GCM + Keystore + AAD + случайный IV — грамотно; но `connectionIdentity` полностью обходит шифрование (CRITICAL) |
| UI (`feature`, `app`) | **6 / 10** | `collectAsStateWithLifecycle`, `key` в списках, `FLAG_SECURE` на импорте; но 0% локализации и тяжёлая валидация на UI-потоке |
| Безопасность | **3 / 10** | Живые секреты в репозитории, plaintext-креды в БД, INI-инъекция, нет cert pinning, нет пиннинга бинарей |
| Сборка и CI | **4 / 10** | Компиляция/lint/тесты реально гоняются в CI — сильно; но нет wrapper, нет релизной подписи, actions по тегам, невоспроизводимая нативная сборка |
| Тесты | **4 / 10** | Есть сильные негативные тесты (глубина JSON, oversize outbound, shell-инъекции); но нет тестов на `XrayConfigFactory`, `SecretCipher`, `SubscriptionRepositoryImpl`; 3 из 5 мутационных наборов не проходят baseline |
| Документация | **3 / 10** | `DEVICE_TEST_0.5.0.md` подлинный и ценный; но README, SECURITY, ARCHITECTURE, IMPORT_FORMATS противоречат коду в 11 местах |
| Гигиена репозитория | **2 / 10** | Нет VCS, 2.1 ГБ мусора, 684 МБ байт-идентичных дублей, `.DS_Store`, `__pycache__` |

### **Итоговая интегральная оценка: 4.5 / 10**

Проект демонстрирует **высокую инженерную культуру в отдельных местах** (идемпотентный teardown туннеля, AAD-привязка шифротекста, bounded-парсинг JSON с лимитом вложенности, shell-инъекции закрыты в `ServerSetup`) при **системном провале в консистентности**: заявленные гарантии не совпадают с фактическим поведением, а самодельная система проверок сломана и не защищает ни от чего.

---

## 4. Системные проблемы (не по файлам, а по проекту)

### 4.1 Декларации противоречат коду

| Документ утверждает | Факт | Доказательство |
|---|---|---|
| `SECURITY.md:9` — Room шифруется `SecureStorage` | `connectionIdentity` хранит raw-ссылку с UUID/паролем открыто | `SecureStorage.kt:34-38`, `ProfileMapper.kt:85` |
| `IMPORT_FORMATS.md:9`, `CLAUDE.md:21` — лимит 1 МиБ | `MAX_INPUT = 52_428_800` (50 МиБ) | `DefaultLinkParser.kt:244` vs `:23` |
| `UPGRADE_0.5.0.md:51` — CommandServer не подключён | Подключён | `LibboxVpnEngine.kt:140,235` |
| `ARCHITECTURE.md:13` — в DI `UnavailableVpnEngine` | В DI только `CompositeVpnEngine` | `VpnModule.kt:12` |
| `README.md:3` — «компиляция и все unit-тесты 16 модулей проходят» | `README.md:10` — «здесь НЕ выполнялись» | Внутреннее противоречие README |
| `README.md:10` — «локально проходят source guards и их мутационные тесты» | 4 из 5 guard'ов и 3 из 5 тестов падают | §5.7 |
| `CLAUDE.md:29` — проект `:vpn:xray` | Модуля не существует | `settings.gradle.kts` |

### 4.2 Мёртвый код как системная привычка

`DispatcherProvider`, `Logger`/`redactSecrets`, `UnavailableVpnEngine`, `DummyTunVpnEngine`, `test-awg.gradle`, `awg-aar/`, `docs/LibboxVpnEngine.kt.template`, `ImportReport.duplicates`, `TunnelState.Failed.retryInMs`, `StoreContract` без интентов покупки. Абстракции создаются и не используются — это не косметика: `DispatcherProvider` и `Logger` были созданы **именно для** тестируемости и редактирования секретов, и их неиспользование даёт два реальных дефекта (нестабильные тесты + утечка конфига в `core.log` на debuggable-сборках).

### 4.3 Нарушение слоёв Clean Architecture

```
core/datastore  ──►  vpn/config      (SettingsStore знает TunnelOptions)
vpn/service     ──►  core/datastore
feature/profiles ──► vpn/config      (ProfileEditor зовёт ConfigFactory.validateProfile)
app             ──►  feature/* + vpn/config
```
`domain` чист, но всё, что выше, знает о слоях ниже «через голову». Это не сломает сборку, но делает `feature` нетestируемыми без VPN-стека.

---

## 5. Реестр рисков и ошибок

Severity: **CRITICAL** — эксплуатируемо или разрушает данные; **HIGH** — функциональный провал/утечка при определённых условиях; **MEDIUM** — деградация, гонки, плохая диагностика; **LOW** — гигиена.

### 5.1 CRITICAL

**C-1. Полный обход шифрования через `connectionIdentity`** *(верифицировано лично)*
`VpnProfile.connectionIdentity()` = `rawLink.substringBefore('#')` — то есть **полная share-ссылка, включая UUID и пароль** (`ImportReport.kt:11-12`). `ProfileMapper.toEntity` пишет её в колонку `connectionIdentity` (`ProfileMapper.kt:85`, `Entities.kt:26`), а `SecureStorage.transform` шифрует только `name/server/uuid/password/tlsJson/transportJson` (`SecureStorage.kt:34-38`) — `connectionIdentity` в список не входит.
**Итог:** AES-256-GCM шифрует пароль, а рядом, в той же строке SQLite, лежит он же в составе ссылки. Подтверждено выгрузкой БД на устройстве (`DEVICE_TEST_0.5.0.md:156-159`). Дополнительно `ProfileRepositoryImpl.getAllIdentities()` (`:51-53`) читает эти значения наружу.
**Дополнительно:** миграция `MIGRATION_1_2` заполняет колонку значением `id` (`CyrusDatabase.kt:26`), а не identity → после апгрейда повторный импорт того же ключа создаёт **дубликат профиля**.

**C-2. INI-инъекция в AmneziaWG через недоверенную ссылку** *(верифицировано лично)*
`ConfigFactory.build()` для `AMNEZIA_WG` (`ConfigFactory.kt:57-82`) собирает WireGuard-конфиг **конкатенацией строк**, полностью минуя `options.validate()` и `validateProfile()`:
```kotlin
appendLine("PrivateKey = ${profile.password}")
q["jc"]?.let { appendLine("Jc = $it") }
appendLine("PublicKey = ${q["public_key"]}")
```
Значения `q[...]` приходят из `query()` парсера, где они **URL-декодируются** (`DefaultLinkParser.kt:231`), то есть `%0A` превращается в перевод строки. Ссылка вида `...&public_key=x%0AEndpoint%20=%20attacker:51820` внедряет произвольные ключи и секции INI. Валидации Jc/Jmin/Jmax/S1/S2/H1–H4 как чисел **нет вообще**; при отсутствии `public_key` в конфиг уйдёт литерал `null`.

**C-3. Живые секреты в репозитории** *(верифицировано лично)*
- `scratch.kts:2` — реальный URL подписки с токеном: `https://mc.minecraft.webcam/sub/f3b23a84e818d73fb61c865265b1e33d5a5a?app=v2rayng`
- `scratch3.kts:23` — base64-блоб с UUID `4c7a0b95-1dcb-4044-b948-69e1b4881733`, Reality `pbk=9ngNG5S7MWDT7blqRQZix2-Ze24yRxj8nNNmEU8lTkg`, host `dbkv4jecap48.minecraft.webcam`

`.gitignore` их не покрывает. Считать скомпрометированными и ротировать.

**C-4. `FILES.sha256` недостоверен** *(верифицировано лично: 163 OK / 35 FAILED)*
Манифест целостности рассинхронизирован с деревом — в числе «провалившихся» `SecretCipher.kt`, `CyrusDatabase.kt`, `SettingsStore.kt`, `LibboxVpnEngine.kt`, `build-libbox.sh`. Заявленная проверяемость поставки не подтверждается.

**C-5. Система guards сломана и ложно-красная** *(верифицировано лично)*
Прогон сейчас: `check_merge` → `AssertionError: Tunnel owns cleanup in finally`; `check_upgrade` → `AssertionError: Failed is published after native teardown`; `check_native` → `ValueError: Expected exactly one libbox AAR; found 2`. Проходят только `check_buildfix` и `check_design`.
Причина — «иглы» из regex и позиционных сравнений, а не проверка инвариантов:
- `check_merge.py:28` требует **ровно два** комментария сразу после `finally {` и `runCatching` следующей строкой. В `TunnelServiceRunner.kt:114-122` теперь 5 комментариев и обёртка `withContext(NonCancellable)` → guard падает на **корректном** коде.
- `check_upgrade.py:21` берёт **первое** вхождение `bus.publish(TunnelState.Failed` (строка 52 — новая fail-closed ветка) вместо нужного (строка 123) → сравнение не того участка.
- `check_source.py:124` вызывает `check_merge` → **весь CI красный на чистом checkout**.

**C-6. Gradle Wrapper отсутствует полностью** *(верифицировано лично)*
В `gradle/` только `libs.versions.toml`; `gradlew`, `gradlew.bat`, `gradle-wrapper.jar`, `.properties` — нет. Сборка зависит от вручную установленного Gradle 8.11.1. Это осознанно (`docs/workflows/build-zip.yml:364`), но противоречит воспроизводимости.

**C-7. Документация выдаёт несуществующую защиту за существующую**
`SECURITY.md:9` перечисляет шифруемые поля и **не упоминает** `connectionIdentity`; `ARCHITECTURE.md:9` утверждает «`SecureStorage` шифрует строки до Room». Это не мелкая неточность — это ложь умолчанием о гарантии безопасности, подтверждённо опровергнутая на устройстве.

### 5.2 HIGH

| ID | Проблема | Доказательство |
|---|---|---|
| H-1 | **DoS: лимит импорта 50 МиБ вместо заявленного 1 МиБ** + авто-base64 всего payload до построчного лимита → пиковое потребление ~150 МБ, OOM на Android | `DefaultLinkParser.kt:23,25-26,244` |
| H-2 | **Фиктивный `Connected` для AmneziaWG.** `AmneziaVpnEngine.start` игнорирует результат `setState(UP)`; `CompositeVpnEngine` отдаёт `reportsDialFailures=false` → runner пропускает окно живости | `AmneziaVpnEngine.kt:29`, `CompositeVpnEngine.kt:80-81` |
| H-3 | **Двухъядерность Xray неработоспособна.** В VPN-режиме `XrayConfigFactory` бросает `error(...)`; в PROXY-режиме `proxyPort` биндится дважды и outbound ссылается сам на себя | `XrayConfigFactory.kt:16-21`, `TunnelControllerImpl.kt:66-72` |
| H-4 | **Неатомарный счётчик здоровья ядра.** `failures.value += 1` из нативных потоков Go теряет инкременты → вердикт `HEALTHY` на мёртвом ядре (ровно сценарий 0.5.0) | `CoreHealth.kt:51` |
| H-5 | **`UnavailableVpnEngine` не зарегистрирован.** При отсутствии AAR (`compileOnly`) Koin падает с `NoClassDefFoundError` вместо честного отказа; проверка `engine.id == "unavailable"` мертва | `VpnModule.kt:12`, `TunnelControllerImpl.kt:47,109` |
| H-6 | **SSRF при загрузке подписок.** Проверяется только схема https; localhost, приватные IP, metadata-эндпоинты и DNS-rebinding не блокируются | `SubscriptionRepositoryImpl.kt:123-128` |
| H-7 | **ProGuard keep-правило ссылается на несуществующий класс** `KentraVpnService` вместо `CyrusVpnService`; keep для libbox закомментирован | `proguard-rules.pro:26` *(верифицировано)* |
| H-8 | **`appRunCatching` глотает фатальные ошибки.** `catch (t: Throwable)` превращает `OutOfMemoryError`/`LinkageError` в `AppError.Unknown` | `AppError.kt:20` |
| H-9 | **`DispatcherProvider` и `Logger` — мёртвый код.** Прод хардкодит `Dispatchers.IO`, пишет в `android.util.Log` напрямую; `redactSecrets` не вызывается нигде → нативный лог ядра с конфигом попадает в `core.log` без маскирования | `Dispatchers.kt:10-20`, `Logger.kt:5`, `LibboxVpnEngine.kt:577-585` |
| H-10 | **Одна повреждённая строка убивает весь список профилей.** `json.decodeFromString` без try/catch → `SerializationException` валит `observeProfiles()` | `ProfileMapper.kt:90-91` |
| H-11 | **DataStore-потоки без `.catch`.** `activeProfileId` и `onboardingDone` не обрабатывают `IOException`, в отличие от соседних потоков | `SettingsStore.kt:65,94` |
| H-12 | **Биллинг без верификации.** Ни Play Billing, ни подписи, ни серверной валидации; entitlement только в памяти | `CatalogBillingRepository.kt:14,26-32` |
| H-13 | **Цепочка поставки бинарей не проверяема.** Ни один `.so`/`.aar` не имеет хеша в `FILES.sha256`; `libXray.aar` перепакован локально и содержит unstripped `debug_info` (50–67 МБ/ABI) | `FILES.sha256`, `vpn/service/libs/` |
| H-14 | **Невоспроизводимая нативная сборка.** `GOMOBILE_VERSION='latest'` в активном скрипте, тогда как docs-шаблон пиннит `v0.1.4` | `build-libbox.sh:6,30-31` |
| H-15 | **CI: actions пиннированы тегами, не SHA.** Риск подмены при компрометации апстрима | `android.yml:24,27,33,39,45,78,87` |
| H-16 | **Релизный пайплайн отсутствует.** `signingConfig` нет нигде, release собирается неподписанным, CI делает только debug APK | `app/build.gradle.kts:39` |

### 5.3 MEDIUM (выборка значимых)

- `TunnelBus.owner` — `var` без `@Volatile` при доступе с Main и из корутин (`TunnelBus.kt:26-28`).
- `TunnelServiceRunner` публикует `Connected` без generation-гарда, в отличие от `Failed` (`:82` vs `:123`).
- `LibboxVpnEngine.openTun` полагается на недокументированный `dup()` в libbox; `NetworkCallback`/`HandlerThread` не закрываются при провале `box.close()` (`:364-372, 399-400`).
- `CompositeVpnEngine` выбирает движок по подстроке в JSON вместо `VpnEngineKind` — расхождение с собственным планом (`CompositeVpnEngine.kt:27`).
- `XrayVpnEngine` не разбирает ответ `LibXray.invoke` → ошибка внутри JSON трактуется как успех (`:44-48`).
- Компиляция отсутствует: `connectionIdentity` в plaintext-колонке + миграция ломает дедупликацию (§C-1).
- `ProfilesViewModel.operation` — неатомарный check-then-set `busy` при конкурентном `dispatch` (`:108-110`).
- `HomeViewModel.init` — `catch` после `combine` завершает сбор навсегда (`:26-29`).
- Тяжёлая валидация ядром в `remember` на UI-потоке: `ProfileEditor.kt:42-44`, `ProfilesScreen.kt:55-57`.
- `CyrusWallpaper` — полный декод 1080×2160 без сэмплинга и `RGB_565` → ~9.3 МБ на битмап, без `recycle()` (`:32-34`).
- Локализация отсутствует: `strings.xml` содержит только `app_name`, весь UI захардкожен в Kotlin.
- `MviMachine.dispatch` — исключение в handler не перехватывается (нет `CoroutineExceptionHandler`), `Channel(16, DROP_OLDEST)` молча теряет эффекты (`Mvi.kt:41-49,57`).

### 5.4 LOW (гигиена, выборка)

`android.system.Os` неиспользуемый импорт (`LibboxVpnEngine.kt:8`); `.DS_Store` в 5 местах; `tools/__pycache__/` (не в `.gitignore`); `app/build` 1.1 ГБ и `vpn/service/libs` 893 МБ в рабочем дереве; `libxray_tmp/`, `tmp_xray2/`, `tmp_xray3/` — три байт-идентичные копии `libgojni.so` (684 МБ); `DummyTunVpnEngine` фабрикует `TrafficSample(1024,1024)`; `displayEndpoint` даёт `[[::1]]:443` для уже-скобочного IPv6; `formatBytes` возвращает отрицательное значение при отрицательном входе.

---

## 6. Приоритизированный план улучшений

### Волна 0 — немедленно (до любого коммита в публичный репозиторий)

| # | Действие | Обоснование |
|---|---|---|
| 0.1 | **Ротировать скомпрометированные ключи** из `scratch.kts`/`scratch3.kts` и удалить файлы | C-3 |
| 0.2 | **Инициализировать git-репозиторий** с корректным `.gitignore` (`__pycache__/`, `.kotlin/`, `awg-aar/`, `*.aar`, `scratch*.kts`, `docs/*.patch`) и закоммитить чистое дерево | C-6, гигиена |
| 0.3 | **Починить или пометить guards.** Минимум: убрать `check_merge`/`check_upgrade` из `check_source.py:124`, пока не переписаны на семантические проверки; иначе CI красный | C-5 |
| 0.4 | **Перегенерировать `FILES.sha256`** и включить в него AAR/`.so` | C-4, H-13 |
| 0.5 | **Обновить `SECURITY.md` и `ARCHITECTURE.md`** — честно описать, что `connectionIdentity` не шифруется | C-7 |

### Волна 1 — безопасность данных и парсинга (критический путь)

| # | Действие | Файл |
|---|---|---|
| 1.1 | **Исключить секреты из `connectionIdentity`.** Хешировать: `sha256(rawLink.substringBefore('#'))` или HMAC на ключе из Keystore. Плюс миграция 2→3, пересчитывающая существующие значения | `ImportReport.kt:11-12`, `ProfileMapper.kt:85`, `CyrusDatabase.kt` |
| 1.2 | **Устранить INI-инъекцию.** Прогонять AWG-ветку через `options.validate()` + отдельный `validateAwgProfile()`: числовые диапазоны для Jc/Jmin/Jmax/S1/S2/H1–H4, base64-формат для ключей, запрет `\r\n` в любом значении, обязательный `public_key` | `ConfigFactory.kt:57-82` |
| 1.3 | **Снизить `MAX_INPUT` до 1 МиБ** и перенести base64-декод **после** проверки построчного лимита; обновить сообщение | `DefaultLinkParser.kt:23,25-26,244` |
| 1.4 | **Закрыть SSRF.** Резолвить хост, блокировать private/loopback/link-local/metadata-диапазоны, ограничить порты 80/443/8080+ | `SubscriptionRepositoryImpl.kt:123-128` |
| 1.5 | **Fail-closed для AmneziaWG.** Проверять `setState(UP)` и возвращать ошибку; `reportsDialFailures=true` для AWG | `AmneziaVpnEngine.kt:29`, `CompositeVpnEngine.kt:80-81` |
| 1.6 | **Атомарный счётчик здоровья.** `failures.update { it + 1 }` | `CoreHealth.kt:51` |
| 1.7 | **Обернуть `decodeFromString` в try/catch** с per-row fallback вместо падения всего списка | `ProfileMapper.kt:90-91` |
| 1.8 | **Добавить `.catch` в DataStore-потоки** | `SettingsStore.kt:65,94` |
| 1.9 | **Починить ProGuard:** `CyrusVpnService`, раскомментировать keep для `io.nekohasekai.libbox.**` и `go.**` | `proguard-rules.pro:26` |

### Волна 2 — работоспособность заявленных функций

| # | Действие | Обоснование |
|---|---|---|
| 2.1 | Решить судьбу Xray-ядра: либо реализовать tun2socks, либо честно убрать из UI и `TransportCompat` | H-3 |
| 2.2 | Зарегистрировать `UnavailableVpnEngine` как fallback в `VpnModule` и убрать `compileOnly` | H-5 |
| 2.3 | Заменить выбор движка по подстроке на `TransportCompat.requiredEngine()` | MEDIUM |
| 2.4 | Разрешить коллизию `proxyPort` между Xray и chained sing-box | H-3 |
| 2.5 | Добавить watchdog + backoff-рестарт ядра; задействовать `TunnelState.Failed.retryInMs` | MEDIUM |
| 2.6 | `onTaskRemoved` / политика восстановления туннеля | MEDIUM |

### Волна 3 — тестируемость и качество

| # | Действие |
|---|---|
| 3.1 | Внедрить `DispatcherProvider` во все ViewModel/репозитории (или удалить абстракцию и перейти на `runTest` с `TestDispatcher`) |
| 3.2 | Написать тесты: `XrayConfigFactory`, `SecretCipher` (round-trip + подмена AAD), `SubscriptionRepositoryImpl` (SSRF-кейсы), AWG INI-инъекция, граница `MAX_LINES=2000`, `MAX_INPUT` |
| 3.3 | Переписать guards на AST/семантику (или заменить на detekt/ktlint + ArchUnit для проверки слоёв) |
| 3.4 | Изолировать мутационные тесты: копировать только `src/`, а не 2.1 ГБ дерева |
| 3.5 | Устранить `catch (Throwable)` в `appRunCatching` — не глотать `Error` |

### Волна 4 — сборка, поставка, гигиена

| # | Действие |
|---|---|
| 4.1 | Добавить Gradle Wrapper с пиннингом версии и проверкой `distributionSha256Sum` |
| 4.2 | Пиннировать `GOMOBILE_VERSION` и все GitHub Actions по SHA |
| 4.3 | Настроить `signingConfig` через CI-секреты; собирать подписанный release |
| 4.4 | Убрать `isUniversalApk = true` и лишний AAR из `fileTree`; вынести `libXray.aar` из APK |
| 4.5 | Удалить 684 МБ дублей (`libxray_tmp/`, `tmp_xray2/`, `tmp_xray3/`), `awg-aar/`, `test-awg.gradle`, `docs/LibboxVpnEngine.kt.template`, `scratch*.kts`, `.DS_Store` |
| 4.6 | Вынести все строки в `strings.xml` + создать `values-en/` |
| 4.7 | Добавить certificate pinning для домена подписок |
| 4.8 | Задействовать `Logger`/`redactSecrets` во всех точках логирования, убрать прямые `android.util.Log` |

---

## 7. Что сделано хорошо (не потерять при рефакторинге)

Это важно зафиксировать, чтобы волны улучшений не сломали работающее:

1. **Идемпотентный teardown туннеля.** `LibboxVpnEngine.teardownLocked` (`:172-207`) под `NonCancellable` + `Mutex` — закрывает ресурсы в правильном порядке, повторный вызов безопасен, ошибка `box.close()` не маскируется.
2. **FIFO-сериализация команд сервиса** через `Channel.UNLIMITED` + `cancelAndJoin` (`TunnelServiceRunner.kt:35-128`) — редкая и правильная работа с гонками жизненного цикла.
3. **AAD-привязка шифротекста** к `profile:{id}:{field}` (`SecureStorage.kt:35-43`) — блокирует перестановку шифротекстов между полями и записями.
4. **Fail-closed парсер.** `parse` → `runCatching{parseChecked}.getOrNull()`; `Base64Ext` использует `java.util.Base64` со строгим UTF-8 `REPORT`, без кастомного декодера.
5. **Bounded-парсинг Xray-JSON.** Ограничение вложенности ≤64, лимиты узлов/юзеров ≤100, allow-list'ы протоколов, отказ от выполнения routing/dns/inbounds (`XraySubscriptionReader.kt:40,57,68,82-96,129-139`).
6. **Shell-инъекции закрыты в `ServerSetup.kt`.** Regex-валидация версии/арх/sha256, `curl --proto '=https'`, sha256 **до** распаковки, `umask 077`, `install -m 600`, quoted-heredoc.
7. **Отсутствие опасных разрешений и exported-компонентов.** Полный аудит манифеста: нет `QUERY_ALL_PACKAGES`, `REQUEST_INSTALL_PACKAGES`, `SYSTEM_ALERT_WINDOW`, `ACCESS_FINE_LOCATION`; все сервисы `exported=false` с корректными foreground-типами; `allowBackup=false`.
8. **`FLAG_SECURE` на окнах импорта/ключа** (`ProfileEditor.kt:52`, `SecureCaptureActivity.kt:9-12`) и `IS_SENSITIVE` при копировании в клипборд.
9. **`DEVICE_TEST_0.5.0.md`** — подлинный отчёт: SHA-256 APK совпадает с артефактом, скриншоты существуют, методология воспроизводима. Это лучший артефакт в репозитории.
10. **CI реально собирает и тестирует.** `android.yml` выполняет компиляцию debug/release, `test` по 16 модулям, `lintDebug` с `abortOnError=true` и выводом в stdout — без массовых `disable`/baseline.

---

## 8. Резюме для принятия решений

**Три вопроса, требующих решения владельца:**

1. **Xray-ядро — оставляем или вырезаем?** Сейчас оно в APK (95 МБ), но не работает ни в одном режиме (H-3). Если оставлять — это отдельная волна работ (tun2socks + разрешение коллизии портов). Если вырезать — минус 95 МБ из артефакта и минус 4 критических пункта из бэклога.

2. **Двухъядерность через `Map<VpnEngineKind, VpnEngine>` — когда?** Собственный план (`XRAY_DUALCORE_PLAN.md:3`) помечен «design, not implemented». Текущий `CompositeVpnEngine` со выбором по подстроке — временное решение, которое уже дало два дефекта (H-2, H-5).

3. **Самодельные guards — чинить или заменять?** 48 проверок в `check_source.py` — это ~40 поисков подстрок, которые ломаются от любого рефакторинга и обходятся комментарием. Стандартный стек (detekt + ktlint + ArchUnit + Room schema export) даст больше при меньшей стоимости поддержки.

**Порядок работ:** Волна 0 (сегодня) → Волна 1 (безопасность данных, до публикации) → Волна 2 (работоспособность) → Волны 3–4 (качество и поставка).

**Оценка объёма:** Волны 0–1 — сфокусированная работа по 12 файлам. Волна 2 — архитектурное решение + 4–5 файлов. Волны 3–4 — регулярная работа, не блокирующая выпуск.

---

*Отчёт собран оркестратором из 8 изолированных ревью; все CRITICAL и HIGH верифицированы личным чтением кода и прогоном инструментов. Детальный разбор каждого файла — в Приложении A.*

---
---

# Приложение A — Пофайловый разбор

Легенда severity: **C** = CRITICAL, **H** = HIGH, **M** = MEDIUM, **L** = LOW.
Каталоги `*/bin/*` (дубликаты скомпилированных исходников) в разбор не включены — см. §8 п.4.5.

## A.1 Модуль `app` (точка входа)

| Файл | Назначение | Ключевая логика | Зависимости | Проблемы |
|---|---|---|---|---|
| `CyrusApp.kt` | `Application`, старт DI | `startKoin { androidContext; modules(dataModule, vpnModule, appModule) }` | Koin, все модули | **M** нет try/catch вокруг `startKoin` — неудовлетворённая зависимость = краш без диагностики (`:15`). **L** `DEBUG_DI` жёстко `false` (`:16`) |
| `MainActivity.kt` | Единственная Activity, edge-to-edge, reduced-motion | Собирает `appearance` из `SettingsStore`; пока `null` — чёрный `Surface`; `ContentObserver` на `ANIMATOR_DURATION_SCALE`; `CompositionLocalProvider(LocalReducedMotion)` | `SettingsStore`, `CyrusTheme`, `CyrusShell` | **M** при ошибке чтения DataStore экран навсегда чёрный, нет retry (`:35-38`). **M** входящие Intent (`vpn://`, `ss://`) не обрабатываются — нет intent-filter и `onNewIntent` (`launchMode=singleTask`), заявленный импорт по ссылкам не реализован. **L** `getFloat` в теле композиции на Main (`:52-55`) |
| `CyrusShell.kt` | Каркас навигации (3 таба + настройки) без Navigation-библиотеки | `rememberSaveable` для `tab/settingsOpen`, `SaveableStateProvider`, `AnimatedContent` push-переход, отключение семантики у уходящей страницы | `HomeRoute`, `ProfilesRoute`, `StoreRoute`, `SettingsScreen`, `CyrusWallpaper` | **M** все строки захардкожены (`:29-31,58,62-68`). **L** `tabs[tab]` без `coerceIn` — `IndexOutOfBounds` при рассинхроне `rememberSaveable` (`:62`) |
| `CyrusWallpaper.kt` | Фоновая камуфляжная картинка | `remember` + `LaunchedEffect(resource, preview)`; `BitmapFactory.decodeResource` в `Dispatchers.IO`; показ при `first == resource` | `wallpaper_camo(.webp)` | **M** `inSampleSize=1` всегда — 1080×2160 ARGB ≈ **9.3 МБ** на битмап, нет `RGB_565`, нет `recycle()` → пик ~18.6 МБ при смене темы (`:32-34`). **L** ветка `preview=true` никогда не вызывается |
| `AppModule.kt` | DI-граф use-case'ов и ViewModel'ей | `single { ImportKeysUseCase }`, `factory` для остальных, три `viewModel {}` | `dataModule`-порты | **M** `ImportKeysUseCase` — единственный `single` среди stateless use-case'ов; внутри есть `Mutex`-поле → скрытый общий стейт (`:18`) |
| `ServerWizardScreen.kt` | Генератор скрипта установки sing-box на VPS | `FLAG_SECURE` на время показа, генерация UUID/пароля через `SecureRandom`, результат в `AlertDialog(SecureOn)`, копирование с `IS_SENSITIVE` | `ServerSetup` | **M** секреты кладутся в клипборд и **не очищаются** после закрытия (`:82-85`). **M** строки захардкожены. **OK** инъекций в bash нет — `version`/`sha256`/`uuid` валидируются, heredoc в кавычках |
| `SettingsScreen.kt` | Настройки темы/сети/per-app | Собирает `TunnelOptions`, `updated.validate()` перед записью | `SettingsStore`, `TunnelOptions` | **M** локальный прокси без авторизации доступен другим приложениям устройства (`:80-81`) — осознанно, но задокументировать. **L** package-id не валидируются (`:106-108`). **M** строки захардкожены |
| `AndroidManifest.xml` | Корневой манифест | Только `INTERNET`, `MainActivity` (LAUNCHER, `singleTask`), `allowBackup=false`, `usesCleartextTraffic=false` | — | **M** иконка — вектор без adaptive-icon и `roundIcon`; на API 24–25 вектор как launcher-icon не поддержан (`:12`). **L** `fullBackupContent="false"` избыточно при `allowBackup=false` (`:11`). **OK** опасных разрешений нет |
| `res/values/`, `values-v29/`, `xml/`, `drawable-nodpi/` | Ресурсы | `values-v29/themes.xml:6` переносит `forceDarkAllowed` только на API 29+ — обход lint корректен, поведение не сломано | — | **M** `strings.xml` содержит **только `app_name`**, хотя `app/build.gradle.kts:17` объявляет `resourceConfigurations += ("ru","en")` — локализация отсутствует. **L** `values-v29` наследует `Theme.Material.NoActionBar`, не M3 (`:5`). **L** `device-transfer` не исключает `file/`, в отличие от `cloud-backup` |

## A.2 Модуль `domain` (чистый домен)

| Файл | Назначение | Ключевая логика | Зависимости | Проблемы |
|---|---|---|---|---|
| `model/ImportReport.kt` | Результат импорта + правило identity для дедупликации | `connectionIdentity()` = `rawLink.substringBefore('#')`, иначе `toString()` с обнулёнными презентационными полями | — | **C** identity содержит креды и уходит в незашифрованную колонку (`:11-12`). **M** fallback на `Map.toString()` нестабилен по порядку ключей. **L** `duplicates` никогда не заполняется |
| `model/Subscription.kt` | DTO подписки, `Entitlement`, `Plan` | `isValidAt(now) = expiresAtEpochMs > nowMs` — единственный инвариант | — | **M** `trafficLimitBytes`/`trafficUsedBytes`/`deviceLimit` не участвуют ни в одной проверке. **L** нет валидации `deviceLimit > 0`, `priceMinor >= 0`, `days > 0` |
| `model/TransportCompat.kt` | Канонизация транспортов + требуемое ядро | `normalize` через `ALIASES` + сжатие до букв/цифр, fallback `tcp`; `isSingBox`/`isXrayOnly`/`singBoxRejection` | — | **M** `requiredEngine` для **неизвестного** транспорта возвращает `SING_BOX` (`:62-63`) — fail-open; `isKnown` есть, но не используется. **L** `normalize(null)` → `"tcp"` маскирует ошибки парсера. **L** `EDITOR_CHOICES` дублирует `SING_BOX` |
| `model/TunnelState.kt` | Состояние туннеля, сэмпл трафика | sealed-иерархия; `isActive = Connected \|\| Preparing` | — | **M** `Stopping` не считается активным (`:11`) → UI может разрешить повторный connect во время остановки. **L** `Failed.retryInMs` нигде не потребляется |
| `model/VpnProfile.kt` | Транспорт-агностичное описание outbound | `displayEndpoint` оборачивает IPv6 в `[]` при наличии `:` | `TransportCompat` | **M** для уже-скобочного IPv6 даёт `[[::1]]:443` (`:66`). **L** нет инвариантов `port ∈ 1..65535`, непустой `server` |
| `repository/Repositories.kt` | Порты Clean Architecture | `LinkParser.export` → `requireNotNull(rawLink)`; `inspect` имеет дефолтную реализацию | coroutines `Flow/StateFlow` | **M** `export` бросает `IllegalArgumentException`, а не `AppError` (`:26`) — нарушение единой таксономии. **L** `inspect` не заполняет `issues`/`duplicates` |
| `usecase/UseCases.kt` | Импорт, connect, disconnect, delete профиля | `ImportKeysUseCase` под `Mutex`: parse → дедуп по identity → пачечная запись → выбор активного; `DeleteProfileUseCase` отключает туннель перед удалением | `LinkParser`, репозитории, `Mutex` | **H** хардкод `withContext(Dispatchers.Default)` (`:25`) — нарушение контракта `Dispatchers.kt`. **M** `Mutex` — поле экземпляра, TOCTOU при нескольких экземплярах (`:21,27-29`). **M** `ConnectUseCase`: туннель поднят, а `setActiveProfileId` упал → нет отката (`:42-43`). **M** `DeleteProfileUseCase` при `Preparing` отключает **любой** connect, включая чужой профиль (`:57`) |
| `test/TransportCompatTest.kt` | Юнит-тесты канонизации | Покрыты алиасы, отказы Xray-only, идемпотентность | JUnit4 | **M** не тестируется `requiredEngine` для неизвестного транспорта (текущий fail-open не зафиксирован тестом). **L** нет тестов на Unicode-вход |
| `test/ImportKeysUseCaseTest.kt` | Тесты импорта/удаления на fake-репозитории | 5 кейсов: первый/повторный импорт, сохранение выбора, пустой импорт, удаление чужого | `runTest`, fakes | **M** не покрыты: дубликаты внутри одного payload, падение парсера, падение `upsertAll`, конкурентные импорты, ветка `Preparing` |

## A.3 Модуль `core:common`

| Файл | Назначение | Ключевая логика | Зависимости | Проблемы |
|---|---|---|---|---|
| `AppError.kt` | Единая таксономия ошибок + `appRunCatching` | `from` кастует к `AppError` или оборачивает в `Unknown`; `appRunCatching` перебрасывает `CancellationException` | coroutines | **H** `catch (t: Throwable)` (`:20`) глотает `OutOfMemoryError`/`StackOverflowError`/`LinkageError` как `AppError.Unknown`. **L** `Network/Parse/Tunnel` не сохраняют `cause` |
| `Dispatchers.kt` | Заявленный инжектируемый провайдер диспетчеров | `interface DispatcherProvider` + `DefaultDispatcherProvider` | coroutines | **H** абстракция **полностью мертва** — grep находит только сам файл; весь прод хардкодит `Dispatchers.IO/Default` (`ProfileRepositoryImpl.kt:22-51`, `SecureStorage.kt:15`, `UseCases.kt:25`, `ProfilesViewModel.kt:52`) → тесты нестабильны |
| `Logger.kt` | Портал логирования + редакция секретов | `interface Logger`, `NoopLogger`, `redactSecrets()` (regex UUID и `scheme://`) | — | **H** в репозитории **нет ни одной реализации** `Logger` кроме `NoopLogger`; прод пишет через `android.util.Log` напрямую (`LibboxVpnEngine.kt:386,391`). **H** `redactSecrets` не вызывается нигде; regex не покрывает `http(s)://`, `ssr://`, `hy2://`, «голые» пароли/UUID |
| `test/CancellationTest.kt` | Проверка, что отмена не превращается в `AppError` | Один тест на `CancellationException` | JUnit4 | **M** нет тестов на `AppError.from` и на проглатывание `Error` — регрессия незаметна |

## A.4 Модуль `core:mvi` + `core:ui`

| Файл | Назначение | Ключевая логика | Зависимости | Проблемы |
|---|---|---|---|---|
| `mvi/Mvi.kt` | MVI-движок: `StateFlow` состояния + `Channel` эффектов | `dispatch` запускает handler **параллельно**; `reduce` — CAS через `update`; `Channel(16, DROP_OLDEST)` | coroutines | **H** исключение в `handler` не перехватывается (`viewModelScope` без `CoroutineExceptionHandler`) → краш (`:46-49`). **M** `DROP_OLDEST` на 16 молча теряет эффекты (навигация/snackbar), `trySend` не проверяется (`:41,57`). **M** конкурентные `dispatch` дают недетерминированный порядок. **L** `Channel` никогда не закрывается |
| `mvi/test/MviMachineTest.kt` | Тесты движка на счётчике | reduce двух интентов, однократность эффекта | Turbine | **M** не покрыты: переполнение буфера, конкурентные dispatch, исключение в handler, отмена scope |
| `ui/Effects.kt` | Сбор одноразовых эффектов, форматирование байт/скорости | `CollectEffects` через `repeatOnLifecycle(STARTED)`; `formatBytes` делит на 1024 | Compose, lifecycle | **M** `formatBytes` при отрицательном входе вернёт отрицательное «B» (`:28`). **L** `String.format` без `Locale.US` (`:32`). **L** исключение в `onEffect` отменяет `LaunchedEffect` без восстановления (`:19`) |
| `ui/MviViewModel.kt` | Android-хост MVI-машины поверх `viewModelScope` | Делегирует state/effects/reduce/effect в `MviMachine` | lifecycle-viewmodel | **H** наследует проблему `Mvi.kt`: нет `CoroutineExceptionHandler`/`SupervisorJob`. **L** `machine` создаётся в конструкторе и вызывает `handle` подкласса до инициализации его полей |

## A.5 Модуль `core:database`

| Файл | Назначение | Ключевая логика | Зависимости | Проблемы |
|---|---|---|---|---|
| `CyrusDatabase.kt` | Room-база (профили + подписки), версия 2 | `MIGRATION_1_2` добавляет `connectionIdentity` и заполняет её `id`; `exportSchema=false`; без destructive fallback | Room | **H** миграция пишет `connectionIdentity = id` (`:26`), тогда как новые строки получают identity из `rawLink` (`ProfileMapper.kt:85`) → после апгрейда повторный импорт создаёт **дубликат**. **M** `exportSchema=false` (`:14`) — нет схемной истории, миграции не валидируются. **L** имя БД `kentra.db` (`:21`) — остаток прежнего брендинга |
| `Daos.kt` | DAO профилей и подписок | observe/byId/bySource, upsert/upsertAll, deleteById/deleteBySource, getAllIdentities | Room | **L** `bySource`/`deleteBySource`/`getAllIdentities` без индексов → full scan. **L** дублирующиеся API: `insert(REPLACE)` и `upsert`, `delete(entity)` и `deleteById` |
| `Entities.kt` | Плоские Room-сущности | Сложные объекты — JSON-строками (`tlsJson`, `transportJson`); `connectionIdentity` — отдельная колонка | Room | **C** `connectionIdentity` (`:26`) хранится plaintext и содержит креды. **L** нет индекса по `originSourceId` |

## A.6 Модуль `core:datastore` + `core:network` + `core:designsystem`

| Файл | Назначение | Ключевая логика | Зависимости | Проблемы |
|---|---|---|---|---|
| `datastore/SettingsStore.kt` | Не-секретные настройки в Preferences DataStore | `appearance` и `tunnelOptions` с `.catch(IOException → emptyPreferences)`; `setTunnelOptions` валидирует перед записью | DataStore, `vpn/config.TunnelOptions` | **H** `activeProfileId` (`:65`) и `onboardingDone` (`:94`) **без** `.catch` → `IOException` валит коллектор. **M** класс держит переданный `Context`, а не `applicationContext` (`:34`). **M** дефолт `mtu = 9000` — jumbo-MTU на мобильном TUN сомнителен (`:85`). **M** нарушение слоёв: `core:datastore → vpn:config` |
| `network/HttpClientFactory.kt` | Фабрика Ktor-клиента | `expectSuccess=true`, `followRedirects=false`, таймауты 20/10/20с, retry×2 с экспоненциальной задержкой | Ktor (OkHttp) | **H** нет certificate pinning — MITM на домене подписок даёт подмену конфигов. **M** `ApiConfig.baseUrl` не используется в `create()` — мёртвая настройка (`:15,45-47`). **M** `HttpRequestRetry` ретраит неидемпотентные методы (`createCheckout`) → риск дублей заказов. **M** `ResponseException` не маппится в `AppError.Network` |
| `designsystem/Components.kt` | UI-кит: `TacticalCore`, навбар, сегмент-контрол, иконки, карточки | Анимации читаются внутри draw/layer-лямбд; sweep/пульс только при busy/active | Compose M3/Foundation | **M** `CyrusSegmented`: индикатор клампится (`:259`), а цвет текста сравнивает `i == selectedIndex` без клампа (`:263`) → при out-of-range ни одна метка не подсвечена. **L** `stateDescription` захардкожен по-русски (`:123-126`). **L** `Role.RadioButton` без `selectableGroup` у контейнера |
| `designsystem/Theme.kt` | Палитра, motion-токены, типографика | `CyrusTheme(darkTheme=true)`; `LocalReducedMotion` провайдится в `MainActivity.kt:67` | Compose M3 | **L** дефолт `darkTheme = true` (`:133`) — при забывчивости вызывающего тема не следует системе. **L** нет `isSystemInDarkTheme()` внутри |
| `designsystem/androidTest/DesignRegressionTest.kt` | Инструментальные рендер-тесты | 8 параметров (dark×4 статуса); проверка наследования foreground, сканирование пикселей с допуском `.02f` | `createComposeRule`, Parameterized | **M** допуск `.02f` чувствителен к анти-алиасингу/GPU → флейкость (`:71-72`). **M** нет проверки контраста (a11y), нет кейса `LocalReducedMotion=true` |

## A.7 Модуль `data`

| Файл | Назначение | Ключевая логика | Зависимости | Проблемы |
|---|---|---|---|---|
| `SecretCipher.kt` | Конверт AES-256-GCM: KEK в AndroidKeyStore, DEK в software, префикс `cyrus:enc:v2:` | KEK лениво создаётся в Keystore (`BLOCK_MODE_GCM`, 256 бит); DEK оборачивается KEK с AAD `"DEK"`, IV префиксом; `encrypt` — свежий `SecureRandom` IV на вызов, AAD = context; `decrypt` поддерживает V1/V2 и **fail-closed** бросает при ошибке | AndroidKeyStore, javax.crypto | **H** KEK без `setUserAuthenticationRequired`, `setIsStrongBoxBacked`, `setUnlockedDeviceRequired` (`:19-22`) — defense-in-depth. **H** DEK software-based, экспортируемый в память (`:36-38`) — root/компрометация процесса даёт plaintext всех ключей. **M** `decrypt` молча возвращает значение как есть, если оно не `isEncrypted` (`:65`) — legacy-строки не аутентифицированы. **L** нет различения `KeyPermanentlyInvalidatedException`/`AEADBadTagException` |
| `SecureStorage.kt` | Прозрачное шифрование колонок + миграция legacy → V2 | `prepare()` под `Mutex` в транзакции перечитывает таблицы и пере-запечатывает незашифрованные/V1-поля; `seal/open` с AAD `profile:{id}:{field}` | `CyrusDatabase`, `SecretCipher`, Room | **C** `transform` **не шифрует** `connectionIdentity` (`:34-38`). **M** миграция читает всю таблицу в память; при ошибке одной строки транзакция откатывается и `ready` навсегда `false` — нет частичного восстановления (`:19-27`). **L** при миграции подписок `lastError` затирается текстом ошибки (`:25`) |
| `ProfileMapper.kt` | `VpnProfile` ↔ `ProfileEntity`, сериализация TLS/Transport | `toEntity` пишет JSON-DTO с дефолтами + `connectionIdentity()`; `toDomain` декодирует JSON, `VpnProtocol.valueOf` под `runCatching → UNKNOWN` | Room entities, domain | **C** `connectionIdentity = profile.connectionIdentity()` (`:85`) → полная raw-ссылка в незашифрованную колонку. **H** `json.decodeFromString` без try/catch — битый JSON валит весь `observeProfiles()` (`:90-91`). **M** нет поля версии схемы в JSON — смена типа поля сделает старые записи нечитаемыми (`:42`). **L** неизвестный `originType` тихо → `Manual` (`:119-123`) |
| `CatalogBillingRepository.kt` | Локальный read-only каталог тарифов-заглушек | `plans()` отдаёт хардкод; `createCheckout`/`activateCode` всегда `failure`; `syncEntitlement` возвращает `entitlement.value` (всегда null) | `BillingRepository` | **H** реальной верификации покупок нет вообще — ни Play Billing, ни подписи, ни серверной валидации (`:11-32`). **M** `entitlement` только в памяти, не персистится (`:14,24`). **M** цены и лимиты заданы на клиенте (`:16-20`) |
| `SubscriptionRepositoryImpl.kt` | CRUD HTTPS-подписок, загрузка, парсинг, атомарная замена профилей | `add` валидирует URL и дедуплицирует; `refresh` при ошибке сохраняет `lastError`, не трогая ключи; `save` в транзакции удаляет старые и вставляет новые с UUID от `connectionIdentity`; `fetch` ограничивает 50 МиБ, требует 2xx | Room, Ktor, `LinkParser`, `SecureStorage` | **H** SSRF: только схема https, хост/IP не валидируются (`:123-128`). **M** сетевой `fetch` под глобальным `mutex` блокирует все источники (`:38-48`). **M** при `active == null` автоматически активируется первый профиль подписки (`:100`). **M** лимит ответа 50 МиБ вместо заявленного 1 МиБ. **L** любая ошибка (включая `AppError.Parse`) заворачивается в `Network` (`:58-62`) |
| `DataModule.kt` | Koin-граф data-слоя | Синглтоны БД, DAO, `SettingsStore`, `SecretCipher`, `SecureStorage`, `HttpClient`, парсер и три репозитория | Koin | **L** `SubscriptionRepositoryImpl` не получает `clock` — тесты таймингов невозможны через DI (`:15-31`) |
| `ProfileRepositoryImpl.kt` | Репозиторий профилей поверх DAO + шифрования | `observeProfiles` вызывает `prepare()` в `onStart`, decrypt в `map` на IO; `upsert/upsertAll` → `prepare()`+`seal`; `delete` сбрасывает «висящий» активный id | `ProfileDao`, `SettingsStore`, `SecureStorage` | **H** `getAllIdentities()` читает plaintext-ссылку из БД наружу (`:51-53`). **M** `secure.open` на каждый emission декодирует JSON и GCM всех профилей без кэша (`:22`). **L** сброс активного id не атомарен с удалением (`:41-45`) |
| `test/ProfileMapperTest.kt` | Единственный тест маппера | Happy-path round-trip: собрать профиль и сверить все поля | JUnit4 | **H** не покрыты: `null`-поля, битый JSON, неизвестный `originType`, `UNKNOWN`-фолбэк, forward-compat по неизвестным ключам, `rawLink == null` (`:14-41`) |

## A.8 Модуль `vpn:link` (парсинг недоверенного ввода)

| Файл | Назначение | Ключевая логика | Зависимости | Проблемы |
|---|---|---|---|---|
| `Base64Ext.kt` | Мягкое декодирование base64 (стандарт + URL-safe) | `filterNot{isWhitespace}`, отказ при `length%4==1`, досыпка padding, `getDecoder()` → fallback `getUrlDecoder()`, строгий UTF-8 `REPORT`; всё в `runCatching` | JDK `java.util.Base64` | **M** нет собственного лимита на размер — защита целиком на вызывающем; `runCatching` ловит `Throwable`, включая OOM → маскируется под «некорректный base64» (`:8,16-18`). **OK** паники нет, fail-closed, URL-safe обработан |
| `DefaultLinkParser.kt` | Единый парсер ссылок (`vless/vmess/ss/socks/http/wireguard/awg/ssh/naive/tor`) + `inspect` | `parse` → `runCatching{parseChecked}.getOrNull()`; `parseChecked` проверяет длину, запрет `\n\r`, диспетчеризует по схеме; `inspect` — лимит `MAX_INPUT`, авто-base64 при отсутствии `://`/`{`, JSON → `XraySubscriptionReader`, построчный цикл с `MAX_LINES`, дедуп по identity | domain, kotlinx.serialization, `Base64Ext`, `ProfileLinkWriter`, `XraySubscriptionReader` | **C** INI-инъекция: значения `wireguard()` берутся из `query()` с URL-декодированием, т.е. `%0A` → `\n` (`:168-185,231-232`). **H** `MAX_INPUT = 52_428_800 // 50 MiB` при сообщении «1 МиБ» (`:244` vs `:23`). **H** авто-base64 всего payload до построчного лимита → пик ~150 МБ (`:25-26`). **L** `lineSequence` не прерывается при превышении `MAX_LINES` (`:32-38`). **L** Reality `pbk` только `isNotBlank()`. **H** `vpn://` не обрабатывается вообще. **L** `tor()` хардкодит `server="tor.network"`, `password="tor"` |
| `ProfileLinkWriter.kt` | Канонический экспорт `VpnProfile` в ссылку | `enc` через URLEncoder (`+`→`%20`); VMESS через `JsonObject`+base64; удаление алиасов; сборка query и фрагмента | domain, kotlinx.serialization | **L** `requireNotNull(p.uuid/p.password)` без try/catch — некорректный in-memory профиль даст исключение наружу (`:47-51`). **OK** инъекций нет: JSON кодируется сериализатором, значения URL-энкодятся |
| `XraySubscriptionReader.kt` | Извлечение прокси-узлов из Xray-JSON, отказ от выполнения routing/dns/inbounds | DTO только с `outbounds`; `boundedNesting` — глубина ≤64 и баланс кавычек; лимиты узлов ≤100; allow-list'ы → пометка `cyrus-unsupported`; сохранение оригинала в base64 | `DefaultLinkParser`, `TransportCompat` | **M** `address` вставляется в URI **без `enc()`** (`:144-145`) — `?`, `#`, `@`, `:` из недоверенного JSON ломают структуру authority/query. **M** строка аллоцируется до проверки длины 32 КБ (`:61-62`). **L** общий мутабельный `q` загрязняет последующие узлы одного outbound (`:151,163`). **OK** SSRF-поверхности нет |
| `test/DefaultLinkParserTest.kt` | Тесты парсера | Позитивные/негативные кейсы схем | JUnit4 | **M** нет тестов границы `MAX_LINES`, allocation-bomb на большом base64, AWG-инъекции |
| `test/ImportRegressionTest.kt` | Регрессия импорта | Проверяет дедуп и отказ oversize | JUnit4 | **H** `:56` подаёт `1_048_577` символов, но реальный лимит 50 МиБ — тест проходит **по другой причине** (строка не парсится как base64 и как ссылка), а не из-за лимита. Ложная гарантия |
| `test/TransportAliasImportTest.kt` | Тесты алиасов транспортов | Проверка канонизации при импорте | JUnit4 | **L** покрытие узкое |
| `test/UpgradeImportTest.kt` | Регрессия upgrade | **Сильные** негативные кейсы: глубина 1000, oversize outbound, отсутствие секретов в issue | JUnit4 | **OK** — один из лучших тестовых файлов проекта |

## A.9 Модуль `vpn:config` (генерация конфигов ядра)

| Файл | Назначение | Ключевая логика | Зависимости | Проблемы |
|---|---|---|---|---|
| `ConfigFactory.kt` | Генерация sing-box JSON и AWG-INI из профиля | `build` при `AMNEZIA_WG` уходит в **строковую** сборку INI, иначе `json.encodeToString`; `config` вызывает `options.validate()` + `validateProfile()`, запрещает multiplex+Vision, строит DNS/route/outbounds | domain, kotlinx.serialization, `OptionsValidation`, `SingBoxModel` | **C** AWG-ветка (`:57-82`) **не вызывает** валидацию и конкатенирует URL-декодированные значения → INI-инъекция. **H** outbound `AMNEZIA_WG` = `type:"direct"` (`:338-341`) — при прямом вызове `config()` трафик мимо туннеля. **M** `validateProfile` пропускает формат UUID, `flow`, `fingerprint`, `alpn`, `scy`, `method`, `reserved`-диапазон. **M** `pluginOpts` уходит сырым (`:288`). **M** `utls.fingerprint` из недоверенного `fp` без whitelist (`:189-191`) |
| `OptionsValidation.kt` | Валидация пользовательских настроек | mtu 1280..9000, proxyPort 1024..65535, whitelist stack/logLevel, DNS непустой без пробелов, package-ID regex + ≤500, PROXY+perApp запрещён | `TunnelOptions` | **M** `dnsRemote/dnsLocal` проверяются лишь на «непусто/без пробелов» — произвольная строка уходит в `DnsServer.address` (`:8-9`). **L** нет валидации формата DNS-схемы и MTU под протокол. **OK** fail-closed: невалидное бросает исключение |
| `SingBoxModel.kt` | Типизированная схема sing-box | Только `@Serializable` data-классы + `@SerialName` | kotlinx.serialization | **L** `CacheFile.path="cache.db"` относительный, `enabled=true` по умолчанию (`:196-198`) |
| `XrayConfigFactory.kt` | Генерация Xray-JSON для xhttp/kcp/quic | `options.validate()`, VPN-режим → `error`, outbounds/routing через `buildJsonObject` | domain, kotlinx.serialization | **H** в VPN-режиме всегда `error(...)` (`:16-21`) — Xray не работает как VPN, что противоречит цели проекта. **M** нет `validateProfile`: `security`/`encryption`/`scy`/`headerType`/`quicSecurity`/`key`/`mode` идут без whitelist (`:12-13,149-211`). **L** `if (logLevel == "trace")` недостижимо (`:77`). **H** тестов на файл нет |
| `ServerSetup.kt` | Генерация серверного конфига + bash-скрипта установки | Порт, UUID regex, пароль 16..256 без control-символов, пути сертификатов без `..`; в скрипте — `curl --proto '=https'`, sha256 **до** tar, `check -c` **до** install, `umask 077`, `install -m 600`, quoted-heredoc | kotlinx.serialization | **OK** инъекций не найдено — образцовый файл по безопасности |
| `test/ConfigFactoryTest.kt` | Тесты генерации | Проверка структуры sing-box конфига | JUnit4 | **M** `:23` использует `uuid="uuid-1"` — тест подтверждает, что config-слой **не** валидирует UUID |
| `test/ServerSetupTest.kt` | Тесты серверной генерации | Включая негативные кейсы инъекций (`:30-33`) | JUnit4 | **OK** |
| `test/TransportCompatConfigTest.kt` | Тесты отказа Xray-only транспортов | `:30-36` проверяют корректный отказ | JUnit4 | **OK** |
| `test/UpgradeConfigTest.kt` | Регрессия upgrade-конфига | Проверка сохранения параметров | JUnit4 | **M** не покрыта AWG-ветка и INI-инъекция |

## A.10 Модуль `vpn:service` (движки, VpnService, lifecycle)

| Файл | Назначение | Ключевая логика | Зависимости | Проблемы |
|---|---|---|---|---|
| `VpnEngine.kt` | Контракт `VpnEngine` + DTO `TunnelSession` | `start` обязан вернуть управление только после реального TUN; `reportsDialFailures` (по умолчанию `false`) | `VpnService`, `Flow` | **M** контракт «return only after a real tunnel» ничем не проверяется — `DummyTunVpnEngine` и `XrayVpnEngine` его нарушают (`:21`). **OK** дефолт `false` корректен и fail-closed |
| `CyrusVpnService.kt` | Хост VPN-сервиса | `onStartCommand` → `runner.command`, `START_NOT_STICKY`; `onRevoke` → `runner.revoke()`; `onDestroy` → `runner.destroy()`; runner лениво | Koin, `VpnService`, `TunnelServiceRunner` | **M** `START_NOT_STICKY` — нет авто-восстановления после OOM/Doze, `onTaskRemoved` не переопределён (`:14`). **L** `onRevoke` только enqueue'ит stop — teardown зависит от обработки очереди (`:16`). **OK** foreground-тип `systemExempted` корректен |
| `CyrusProxyService.kt` | Хост loopback-прокси | Аналогично VPN-сервису, `START_NOT_STICKY` | Koin | **OK** foreground-тип `specialUse` + subtype-property корректен |
| `TunnelServiceRunner.kt` | Единственный владелец start/replace/stop; FIFO через `Channel.UNLIMITED` | `SupervisorJob + Dispatchers.Main.immediate`; на каждую команду — `cancelAndJoin` → `Preparing` → новый `tunnelJob` (сбор traffic, `engine.start`, вердикт `CoreHealth` с grace 2.5 с, `startForeground`, probation 12 с, `awaitCancellation`); `finally` — `engine.stop()` под `NonCancellable`, публикация `Failed` только при совпадении generation | Android Service/Notification, coroutines, `TunnelBus`, `CoreHealth` | **M** `bus.publish(Connected)` **без** generation-гарда, в отличие от `Failed` (`:82` vs `:123-124`) — единственная незащищённая публикация. **M** `destroy()` не вызывает `engine.stop()` сам — полагается на каскадную отмену (`:148-153`). **M** нет watchdog/backoff/restart после `Failed`. **L** `CORE_GRACE_MS=2500` оплачивается всегда — минимум 2.5 с в `Preparing` на каждое подключение (`:184`) |
| `TunnelBus.kt` | In-process source of truth | `claim` перезаписывает `owner`; `release(value)` сбрасывает только если `owner === value`, и при `Connected` публикует `Failed(FAILED_TEARDOWN)`; `_state`/`_traffic` — `MutableStateFlow` | coroutines | **M** `owner` — обычный `var` без `@Volatile`/synchronized; вызовы и с Main, и из корутин → гонка видимости (`:26-28`). **L** `publish(state)` безусловен, generation-гарда на уровне шины нет (`:49-51`) |
| `TunnelBusTest.kt` | Тест логики release | Проверка owner-identity | JUnit4 | **L** не тестируется конкурентность `owner` |
| `CoreHealth.kt` | Вердикт «ядро может носить трафик» по лог-маркерам | `onCoreMessage` инкрементит счётчик при `open outbound connection`, игнорируя `context canceled`; `awaitVerdict` держит grace-окно, `awaitInvalidation` — probation | coroutines | **H** `failures.value += 1` — неатомарный read-modify-write из нативных потоков Go → потерянные инкременты → **fail-open вердикт HEALTHY на мёртвом ядре** (`:51`). **M** вердикт строится на подстрочном матчинге нативных строк — brittle к апдейту ядра (`:48-52`). **M** нет watchdog после probation: падение ядра через 30 с не детектируется, UI остаётся `Connected` |
| `CoreLog.kt` | Приватный bounded-лог без logcat | Запись в приватный `filesDir`, bound 512K/keep 256K, `appendConfig` маскирует секреты | Android FS | **M** `writeLog` пишет нативную строку **без** `redact` — при ошибке конфигурации ядро эхо-выводит конфиг с ключами в `core.log` (`:52-57`). Release безопасен (`enabled()` по `FLAG_DEBUGGABLE`), debuggable-сборка течёт. **OK** `SimpleDateFormat` под `synchronized` |
| `LibboxVpnEngine.kt` | Реальный sing-box: `PlatformInterface`, `openTun`, `protect`, stats через `CommandServer` | `start` под `lifecycle.withLock` + IO: one-time `Libbox.setup`, `CoreLog.appendConfig`, teardown прошлой сессии, `health.reset()`, CAS-защита от двойного старта, `box.start()` + `resetNetwork()`, `CommandServer`, `startStats`. `stop` — `NonCancellable + IO` → `teardownLocked`. `teardownLocked` идемпотентен: stats-thread → client.disconnect → commandServer.close → box.close → tunFd.close | libbox AAR (Go JNI), `ParcelFileDescriptor`, `ConnectivityManager` | **H** fd-ownership держится на недокументированном `dup()` в libbox; при его отсутствии — двойное закрытие fd (`:364-372`). **M** `openTun` смешивает три ответственности, ~57 строк (`:317-373`). **M** `NetworkCallback`/`HandlerThread` не закрываются при провале `box.close()` → утечка на сессию (`:399-400,476-486`). **M** `writeLog` без редактирования (`:577-585`). **L** неиспользуемый импорт `android.system.Os` (`:8`). **OK** `System.loadLibrary` не нужен — AAR грузит `libbox` сам |
| `CompositeVpnEngine.kt` | Композит sing-box + Amnezia + Xray | Выбор ветки по `configJson.contains("[Interface]") && contains("PrivateKey")`; `activeEngine` регистрируется **до** старта; `stop` под `NonCancellable` сносит xray и активный движок независимо | `LibboxVpnEngine`, `AmneziaVpnEngine`, `XrayVpnEngine` | **H** `reportsDialFailures = activeEngine?.reportsDialFailures` — для AWG `false` → runner пропускает окно живости (`:80-81`). **M** выбор по подстроке вместо `VpnEngineKind` — расхождение с собственным планом, хрупко к смене формата (`:27`). **M** field-init создаёт нативные движки без try/catch — при отсутствии AAR (`compileOnly`) падает Koin-граф |
| `AmneziaVpnEngine.kt` | Движок AmneziaWG через `GoBackend` | `GoBackend(service, Noop...)` + `Config.parse`, `setState(UP)` | `com.zaneschepke:amneziawg-android` | **H** результат `setState(UP)` игнорируется (`:29`) → возможен фиктивный `Connected` без туннеля. **M** `backend`/`activeTunnel` без `@Volatile`/lock (`:15-16,25-28`). **M** `stop` ловит `Throwable` без логирования (`:39-47`). **H** в proxy-режиме `service` — не `VpnService`, а `ConfigFactory.build` всё равно вернёт WG-текст → попытка поднять TUN из прокси-сервиса |
| `XrayVpnEngine.kt` | Движок Xray | `System.loadLibrary("gojni")` в `init`; `LibXray.invoke(runXray)`; фейковый traffic-job | Xray AAR | **H** результат `invoke` не разбирается: `started = true` безусловно, ошибка внутри JSON трактуется как успех (`:44-48`). **M** `CoroutineScope(Dispatchers.IO)` вне жизненного цикла — повторный `start` без `stop` утечёт старый job (`:52-57`). **L** `loadLibrary` избыточен, `printStackTrace()` вместо лога (`:13-19`) |
| `DummyTunVpnEngine.kt` | Тестовый TUN + защищённый UDP-сокет | `start` блокируется в `while (isRunning && isActive)` | Android | **M** `start()` не возвращается до остановки — нарушает контракт `VpnEngine.kt:21`; runner завис бы в `Preparing` навсегда (`:75-77`). **L** фабрикует `TrafficSample(1024,1024)` (`:97-102`). Не подключён в Koin — латентный |
| `UnavailableVpnEngine.kt` | Заглушка, честно отказывающая в старте | `start` бросает `error(...)` | — | **H** **не зарегистрирован** в `VpnModule` — заявленный fallback отсутствует (`:14`) |
| `TunnelControllerImpl.kt` | Мост app↔service, единственная точка входа | `connect` под `Mutex`: запрет при `Preparing/Stopping`, выбор сервиса, `VpnService.prepare`, сборка конфигов, `bus.claim` + `Preparing` + `startForegroundService`, откат при исключении. `disconnect` — `Stopping` + `startService(STOP)` | Koin, `VpnService` | **H** в PROXY-режиме для xray-транспорта и Xray, и chained sing-box биндят один `proxyPort` → коллизия и петля «сам в себя» (`:66-72`). **M** `disconnect` без таймаута — при недоставке команды состояние навсегда `Stopping` (`:113-115`). **L** проверка `engine.id == "unavailable"` мертва — `engine` всегда `CompositeVpnEngine` (`:47,109`) |
| `VpnModule.kt` | Koin-граф vpn-слоя | `single TunnelBus/CoreHealth/ConfigFactory`; единственный `VpnEngine` = `CompositeVpnEngine` | Koin | **H** нет ни `UnavailableVpnEngine`, ни `Map<VpnEngineKind, VpnEngine>` из собственного плана; `XrayVpnEngine` не инжектится, а создаётся внутри Composite (`:8-25`) |

## A.11 Модуль `feature` (UI)

| Файл | Назначение | Ключевая логика | Зависимости | Проблемы |
|---|---|---|---|---|
| `home/HomeContract.kt` | Контракт Home | `HomeState.canConnect`, интенты, эффекты | core:mvi | **L** поле `message` никогда не устанавливается — мёртвый код (`:20`) |
| `home/HomeScreen.kt` | Экран подключения | `HomeRoute` собирает state через `collectAsStateWithLifecycle`, `CollectEffects`, launcher VPN-разрешения; гейтит анимацию по `pageActive && RESUMED` | Compose, core:ui, Koin | **M** лямбды `{ viewModel.dispatch(...) }` не в `remember` → `HomeContent` не skippable, рекомпозиция на каждый тик трафика (`:62-64`). **M** все строки захардкожены (`:87,101,105,110-111,115,131-137`). **L** `verticalScroll` на весь экран конфликтует с `BoxWithConstraints`-центрированием; магическая константа `-150.dp` (`:83`) |
| `home/HomeViewModel.kt` | MVI-логика Home | `init` комбинирует профили+activeId, слушает `tunnel.state`/`traffic`; `toggle` соединяет/разъединяет, маппит `AppError.Permission` → `RequestVpnPermission` | репозитории, `TunnelController`, use-cases | **M** `catch` после `combine` завершает сбор **навсегда** — одна ошибка расшифровки → список профилей больше не обновляется (`:26-29`). **M** `state` читается до `launch`, `busy` не атомарен — два быстрых тапа могут запустить два `connect` (`:59-62`). **M** строки ошибок в ViewModel (`:39,53,69,75`) |
| `home/test/HomeViewModelTest.kt` | 3 теста HomeViewModel | connect/disconnect по toggle; `Permission → RequestVpnPermission` | Turbine, coroutines-test | **M** не покрыты: двойной тап/`busy`, отсутствие профиля → `NavigateToProfiles`, `Failed → ShowMessage`, ошибка комбайна, обновление `traffic` |
| `profiles/ProfilesContract.kt` | Контракт Profiles | `ProfilesState`, 14 интентов, эффекты | core:mvi | **L** `ProfilesEffect.ImportSucceeded` объявлен, но нигде не эмитится (`:34`) |
| `profiles/ProfileEditor.kt` | Диалог редактирования ключа (поля/ссылка) с live-валидацией | Локальный `draft`, `verdict` через `ConfigFactory.validateProfile`, переключение режимов с ре-парсингом, сохранение с повторным `parse(export())` и защитой `id/createdAt/origin` | Compose, `LinkParser`, `ConfigFactory` | **M** валидация ядром в `remember` на каждый ввод символа в UI-потоке, без debounce (`:42-44`). **L** `indexOf` вернёт `-1` для WIREGUARD/AMNEZIA_WG/SSH/NAIVE/TOR — ни один чип не выбран, но сохранить можно (`:71`). **OK** `SecureFlagPolicy.SecureOn` и лимит 65536 символов — правильно |
| `profiles/ProfilesScreen.kt` | Список ключей и подписок, импорт (буфер/файл/QR), экспорт, share | Фильтрация в `remember`, LazyColumn с `key`, QR через `SecureCaptureActivity`, экспорт в файл и чтение с лимитом 1 МиБ, копирование с `IS_SENSITIVE`, share через chooser с предупреждением | Compose, zxing, `LinkParser`, `ConfigFactory` | **M** `validateProfile` для всех профилей в `remember` на UI-потоке при каждом изменении списка (`:55-57`). **M** `editTarget`/`detailId`/`deleteTarget`/`sourceTarget`/`pendingExport` без `rememberSaveable` → теряются при configuration change (`:58-64`). **M** `ACTION_SEND` с полным секретом в `EXTRA_TEXT` — любое приложение получает рабочий ключ, есть только предупреждение (`:245-247`). **L** для профилей без `rawLink` экспорт/share молча ничего не делают |
| `profiles/ProfilesViewModel.kt` | MVI-логика библиотеки ключей | `init` слушает туннель, профили, источники; `handle` обрабатывает импорт, сохранение, refresh, удаление; `operation` гейтит по `busy` | репозитории, use-cases | **M** check-then-set `currentState.busy` не атомарен — `MviMachine.dispatch` запускает корутины конкурентно (`:108-110`). **L** ошибка показывается сырым текстом `it.message` (`:55-68`). **L** один `ShowMessage` для успеха и ошибки |
| `profiles/SecureCaptureActivity.kt` | Обёртка zxing CaptureActivity | `FLAG_SECURE` до `super.onCreate` | zxing | **OK** корректно: `FLAG_SECURE`, `exported="false"`, локальный декодер без Play Services. **L** защита отдельной Surface zxing не проверена инструментально |
| `store/StoreContract.kt` | Контракт магазина | `StoreState(plans, busy)`, один интент `Load` | core:mvi | **L** нет интентов покупки/активации — соответствует заглушке биллинга (`:7`) |
| `store/StoreScreen.kt` | Список тарифов + CTA «Добавить свой ключ» | LazyColumn с `key`, цена через `NumberFormat("ru-RU")`, расчёт цены за месяц | Compose, Koin | **L** `months = if (plan.id == "m12") 12 else 3` — хрупкая привязка к строковому id (`:32-34`). **M** строки захардкожены. **OK** `collectAsStateWithLifecycle` + `key` в списке |
| `store/StoreViewModel.kt` | Загрузка каталога тарифов | `init` → `Load`; `handle` ставит `busy`, вызывает `billing.plans()` | `BillingRepository` | **L** при ошибке нет retry — состояние остаётся пустым (`:13-14`). **L** `plans()` идёт в `viewModelScope` (Main) — для реального биллинга недопустимо (`:6`) |

## A.12 Сборка, CI, скрипты

| Файл | Назначение | Ключевая логика | Проблемы |
|---|---|---|---|
| `settings.gradle.kts` | Репозитории + список модулей | `FAIL_ON_PROJECT_REPOS`; 16 модулей — заявленное количество **подтверждено** | **OK** |
| `build.gradle.kts` | Агрегатор плагинов | 7 плагинов через version catalog, все `apply false` | **OK** Compose Compiler подключён как плагин — корректно для Kotlin 2.x |
| `gradle.properties` | JVM-параметры, Android-флаги | `-Xmx4096m`, parallel/caching, `enableR8.fullMode=true`, `configuration-cache=false` | **L** отключённый configuration-cache снижает скорость CI. R8 применяется только к release, который в CI не собирается |
| `gradle/libs.versions.toml` | Единый version catalog | agp 8.7.3, kotlin 2.0.21, ksp 2.0.21-1.0.28, composeBom 2024.12.01 | **OK** версии согласованы, KSP строго соответствует Kotlin, смешения `composeOptions.kotlinCompilerExtensionVersion` нет. **L** неиспользуемые записи: `androidx-navigation-compose`, `androidx-appcompat`, `compose-material-icons` |
| `gradle/wrapper/*` | Gradle Wrapper | — | **C** **отсутствует полностью**: нет `gradle-wrapper.properties`, `.jar`, `gradlew*` — сборка зависит от вручную установленного Gradle 8.11.1 |
| `.github/workflows/android.yml` | Основной CI | Триггеры push на все ветки + PR + dispatch; `permissions: contents: read`; компиляция debug/release, `test` по 16 модулям, `check_generated_configs.sh`, `lintDebug`, `assembleDebug`, upload APK | **C** вызывает `check_source.py`, который через `:124` вызывает падающий `check_merge.py` → CI красный. **H** все actions по тегам, не SHA (`:24,27,33,39,45,78,87`). **H** вызывает `build-libbox.sh` с `GOMOBILE_VERSION='latest'` — невоспроизводимо. **M** нет верификации хеша собранного `libbox.aar`. **M** README описывает другой workflow (`build-zip.yml`), которого нет в `.github/workflows/` |
| `.github/workflows/build-libbox.yml` | Сборка нативного ядра | Только `workflow_dispatch`; `permissions: contents: read`; Go 1.23.6, NDK 28, `build-libbox.sh` + `check_native.py` | **OK** пиннинг sing-box реальный: `SING_BOX_REF='92d245ad040cbda2f84b21c2a847a470e532c179'` — полный 40-символьный SHA, версия 1.11.1 подтверждена. **H** `GOMOBILE_VERSION='latest'`. **M** нет верификации хешей |
| `build.sh` | Локальная сборка | `set -euo pipefail`, `cd` в каталог скрипта, проверка `gradle`, guards, `gradle --no-daemon test lintDebug assembleDebug` | **OK** корректный shebang/pipefail, нет хардкода путей. **L** использует системный `gradle`, версия не проверяется точно |
| `build-libbox.sh` | Сборка `libbox.aar` из sing-box | `set -euo pipefail`, `mktemp`+`trap`, защита от перезаписи AAR, `git fetch --depth 1` + `checkout --detach` + сверка SHA, `go install gomobile/gobind`, `go run ./cmd/internal/build_libbox` | **H** `GOMOBILE_VERSION='latest'` (`:6,30-31`) — невоспроизводимо, риск supply-chain. **L** NDK-версия упомянута в тексте, но не проверяется машинно. **OK** нет `curl \| sh`, секретов нет |
| `Build-Cyrus.ps1` | Windows-эквивалент `build.sh` | `$ErrorActionPreference="Stop"`, `Push-Location $PSScriptRoot` + `try/finally`, проверки `$LASTEXITCODE` | **L** вызывает `python`, тогда как bash-скрипты — `python3`. **L** `gradle` без wrapper. **OK** `Get-Command gradle` проверяется |
| `FILES.sha256` | Манифест контрольных сумм | 198 строк, формат `<64-hex>␠␠<path>` | **C** 163 OK / **35 FAILED** (верифицировано лично) — манифест старше правок. **H** AAR/`.so` не включены вообще — нет пиннинга бинарей. **M** `test-awg.gradle`, `scratch*.kts` не покрыты. **OK** все 198 путей существуют |
| `test-awg.gradle` | Резолв AAR amneziawg через конфигурацию `awg` | `repositories { mavenCentral() }`, `configurations { awg }`, задача `resolve` | **M** **мёртвый код** — нигде не подключён, не входит в `FILES.sha256`, дублирует реальную зависимость `vpn/service/build.gradle.kts:24` |
| `docs/workflows/build-zip.yml` | Неактивный шаблон ZIP-сборки | Пиннит `GRADLE_VERSION=8.11.1`, `GO_VERSION=1.23.6`, `GOMOBILE_VERSION=v0.1.4`; безопасная распаковка ZIP с защитой от path traversal/symlink; `persist-credentials: false` | **M** не исполняется (лежит вне `.github/workflows/`), но README ссылается на него как на «установленный workflow». `GOMOBILE_VERSION` здесь пиннится, а в активном скрипте — `latest` |

## A.13 `tools/` — самодельная система проверок

Фактический прогон (верифицировано лично):

| Скрипт | Exit | Результат |
|---|---|---|
| `check_source.py` | **1** | `AssertionError: No packaged APK accidentally included in source tree` |
| `check_design.py` | 0 | `PASS design gate: 10161 assertions, 71 contrast pairs` |
| `check_merge.py` | **1** | `AssertionError: Tunnel owns cleanup in finally` |
| `check_native.py` | **1** | `ValueError: Expected exactly one libbox AAR; found 2` |
| `check_upgrade.py` | **1** | `AssertionError: Failed is published after native teardown` |
| `check_buildfix.py` | 0 | `27 buildfix source checks passed` |
| `test_buildfix_guard.py` | 0 | `23 buildfix guard mutation cases passed` (278 с) |
| `test_native_guard.py` | 0 | `Ran 6 tests ... OK` (0.4 с) |
| `test_design_guard.py` | **1** | краш в `shutil.copytree` (`FileExistsError`) |
| `test_merge_guard.py` | **1** | падение на baseline `validate(root)` (257.8 с) |
| `test_upgrade_guard.py` | **1** | `AssertionError: Unmodified source guard failed` (201.8 с) |

| Файл | Назначение | Ключевая логика | Проблемы |
|---|---|---|---|
| `check_source.py` | «Оффлайн-инварианты»: 48 проверок + агрегатор | Смешанная: есть **реальный** самописный лексер Kotlin (`delimiters()`, `:16-49`) и `ET.parse` для XML; но ~40 проверок — поиск подстрок/regex | **H** вакуумные проверки: пустой `rglob` → цикл не исполняется, `all([])` = True — «всегда зелёная» проверка модулей (`:51-61`). **H** `rglob('*.apk')` не учитывает `.gitignore` → ложное падение после любой сборки (`:113`). **M** обход тривиален: переименовать класс, положить строку в комментарий (`:64-75`) |
| `check_buildfix.py` | 27 регресс-проверок buildfix | Преимущественно `in`/`not in` и точечные regex; сильные места — `values-v29` повторяет все base-items (`:85-90`) и regex API-24 fallback (`:61-66`) | **M** `zip_workflow.split(...)[1]` → `IndexError` вместо чистого fail при отсутствии маркера (`:73`). **L** смешение `find`/`index` (`:114-116`) |
| `check_design.py` | Дизайн-гейт: WCAG-контраст, палитры, геометрия | **Реальная логика**: парсит токены, вычисляет относительную яркость/контраст, сверяет SHA256 обоев с `wallpaper_audit.json`, прогоняет геометрический инвариант 1001 кадр × 5 ширин × 2 знака | **L** `scheme()` режет тело по `'\n)'` — хрупко к переформатированию `Theme.kt` (`:31-32`). **L** дублирует проверки `forceDarkAllowed` из `check_buildfix.py` |
| `check_merge.py` | 16 статических merge-guard'ов | regex/подстроки + позиционные сравнения | **C** `:28` требует **ровно два** комментария сразу после `finally {` и `runCatching` следующей строкой — падает на корректном коде (`TunnelServiceRunner.kt:114-122` теперь 5 комментариев + `NonCancellable`). Ломает весь CI через `check_source.py:124` |
| `check_native.py` | Проверка упаковки AAR libbox | **Реальная логика**: открывает zip, читает `classes.jar`, проверяет 5 классов и 3 ABI | **H** `len(files)!=1` требует ровно один AAR (`:11-12`) — сейчас их два, guard не обновлён под Xray-движок |
| `check_upgrade.py` | 89 source-проверок upgrade | Подстроки + `.index()`-порядок; поддерживает `CYRUS_CHECK_ROOT` | **C** `:21` берёт первое вхождение `bus.publish(TunnelState.Failed` (строка 52 — новая fail-closed ветка) вместо нужного (123) → ложное падение. **M** `count('prefs[Keys.'+key+']')>=2` — счётчик вхождений вместо семантики |
| `check_generated_configs.sh` | CI-проверка нативного синтаксиса | `set -euo pipefail`, `mktemp`+`trap`, `shopt -s nullglob`, корректные кавычки; проверяет ≥12 JSON и ровно 5 `.sh` | **L** `command -v go` под `set -e` даёт невнятный выход (`:5`). **OK** это чекер, а не генератор — ничего в проект не пишет |
| `test_buildfix_guard.py` | 23 мутации `check_buildfix` | Копирует дерево в temp, на каждую мутацию требует падения guard'а — **не тавтология** | **M** игнорирует только `__pycache__`, копируя **2.1 ГБ** дерева — прогон 278 с (`:43`). Мутации подобраны ровно под иглы guard'а |
| `test_design_guard.py` | 12 мутаций дизайн-гейта + подмена webp | Реальная логика (returncode != 0 + `'AssertionError' in stderr`) | **H** `shutil.copytree(ROOT, r)` **без ignore_patterns** — копирует 2.1 ГБ, падает с `FileExistsError` (`:24`) |
| `test_merge_guard.py` | 10 мутаций `check_merge` | — | **C** `:23` `validate(root)` падает на текущем исходнике → скрипт не доходит до mutation-кейсов |
| `test_upgrade_guard.py` | Мутации `check_upgrade` | — | **C** `:25` `assert run().returncode==0` — baseline уже падает, тест не доходит до мутаций |
| `test_native_guard.py` | 6 unittest-кейсов на синтетических AAR | Строит zip-фикстуры, проверяет `ValueError` на отсутствие/дубликат/пустой `.so` | **OK** единственный корректно изолированный тест (не копирует дерево, 0.384 с) |
| `wallpaper_audit.json` | SHA256 и границы яркости обоев | Используется `check_design.py` | **OK** содержателен, SHA256 совпадают |
| `__pycache__/` | Байткод `check_*.py` | — | **M** не указан в `.gitignore` → мусор |

**Вердикт по системе guards.** Частично настоящая, но выдаёт себя за большее. Реально работает: лексер Kotlin, WCAG-математика и SHA-256-аудит обоев, геометрический инвариант на 1001 кадре, zip-проверка AAR, `set -euo pipefail`-скрипт нативной валидации. Не работает: большинство из 48 source-проверок — «иглы» на конкретные подстроки, которые ломаются от любого рефакторинга и обходятся комментарием. Показательно, что **они сломались сами** при обычном рефакторинге `TunnelServiceRunner`. Мутационные тесты честные по замыслу, но 3 из 5 не проходят baseline.

## A.14 `validation/` — доказательная база

| Файл | Оценка |
|---|---|
| `buildfix3-change-map.json` | **Содержателен**: 15/15 SHA совпадают с текущими файлами. Единственная актуальная карта |
| `change-map.json` | **H** устарел: 45 совпало / **31 расхождение** из 81 |
| `buildfix-change-map.json`, `buildfix2-change-map.json` | Исторические (8/16 и 6/15) — формально ожидаемо, но лежат рядом с актуальной и создают впечатление действующих |
| `build-status.txt` | **C** `:11` «LOCAL buildfix3: source, design, merge, upgrade and native guards pass» — **сейчас не воспроизводится**. При этом честно разделяет «USER CI EVIDENCE» и «LOCAL ... NOT RUN» |
| `buildfix3-syntax-checks.txt` | **M** «75 Kotlin files» — фактически 117 `.kt`; «PASS» не перепроверяем из артефакта |
| `buildfix*-code.patch` (3 шт.) | Похожи на реальные unified diff'ы, не пустышки |
| `native-schema-source-audit.json` | **Содержателен**: 27 сверок полей Go-структур против pinned commit `92d245ad…`, с честной оговоркой о статичности |
| `fixture-structure-check.json` | **L** 10 строк — только счётчики узлов по 5 форматам, без хэшей |
| `privacy-check.txt` | **L** одна строка-утверждение без списка значений, метода и инструмента — неверифицируемое самозаявление |
| `buildfix1-ci-failure.txt` | Выдержка внешнего лога run `35346608067` — проверяемо лишь косвенно |
| `shell-syntax.txt`, `buildfix-syntax-checks.txt` | 2 строки без деталей |
| `build/reports/problems/problems-report.html` | **L** сгенерированный Gradle-отчёт, локальный мусор |

## A.15 Документация и память

| Файл | Оценка |
|---|---|
| `docs/DEVICE_TEST_0.5.0.md` | **Подлинный.** Устройство Xiaomi `2511FPC34G` (`klee_ru`), Android 16/SDK 36, SHA-256 APK совпадает с артефактом, скриншоты существуют, есть `/proc/maps`, dumpsys, egress-IP, бисекция Mali-маппингов. **H** внутреннее противоречие: `:180` «APK ✓ Собирается (8.11.1/JDK17)» vs `:31,:36,:847` (сборка остановлена, Gradle 9.5.1/JDK 24) |
| `docs/REVIEW_0.5.0.md` | **Честное** независимое ревью: 7 CRITICAL / 17 HIGH / 16 MEDIUM / 13 LOW, метод заявлен, ограничения оговорены. **Список незакрытых пунктов — в §A.16** |
| `docs/SECURITY.md` | **C** `:9` перечисляет шифруемые поля и **умалчивает** о `connectionIdentity` — ложь умолчанием. **H** `:11` «миграцию необходимо проверить на реальном APK» — не выполнено. **M** `:27` «AAR в исходном ZIP отсутствует» — в дереве два AAR |
| `docs/ARCHITECTURE.md` | **H** `:13` «в DI `UnavailableVpnEngine`» — неверно; `:9` «`SecureStorage` шифрует строки до Room» — опровергнуто. **M** заявленная слоистость нарушена. **OK** количество модулей (16) верно |
| `docs/UPGRADE_0.5.0.md` | **H** `:51` «CommandServer не подключён» — подключён; `:47` «WireGuard/OpenVPN/SSH не добавлены» — WG-аутбаунд есть. **OK** честные ограничения в `:3,:57` |
| `docs/IMPORT_FORMATS.md` | **H** `:9` «Лимиты: 1 МиБ» — код: 50 МиБ |
| `docs/PROVENANCE.md` | **M** все хеши ZIP/commit'ов проверить нечем (архивов нет, `.git` отсутствует). **L** `:35` расхождение 175 vs 198 записей |
| `docs/VALIDATION.md`, `BUILD_FIX_0.5.0_3.md` | **M** заявления о пройденных тестах относятся к внешнему прогону buildfix2, но в отрыве читаются как относящиеся к текущему дереву |
| `docs/LibboxVpnEngine.kt.template` | **H** противоречит текущему состоянию: `:35` требует «stop() на том же потоке», тогда как `MERGE_0.4.2.md:30` заменил это на Mutex; сам файл уже существует |
| `docs/history/` | **OK** полных побайтовых дубликатов корневых доков нет — осознанный архив |
| `docs/XRAY_DUALCORE_PLAN.md` | **L** `:3` «design, not implemented»; `:43-44` предполагает `UnavailableVpnEngine` как fallback — в коде его нет |
| `docs/FIX_0.5.0*.patch` (4 шт.) | **Все четыре ПРИМЕНЕНЫ** — это дубликаты-артефакты, а не неприменённые патчи. При этом есть код новее патчей (`TunnelBus.kt`, `TunnelServiceRunner.kt`) |
| `CLAUDE.md` | **H** `:21` «MAX_INPUT 1 МиБ» — противоречит коду. **H** `:29` упоминает проект `:vpn:xray`, которого нет в `settings.gradle.kts` |
| `README.md` | **H** внутреннее противоречие `:3` vs `:10`; `:10` «локально проходят source guards и их мутационные тесты» — 4 из 5 guard'ов падают |
| `memory/glossary.md` | **H** `:19` «wireguard, ssh НЕ поддержаны» — противоречит `cyrus.md:20` и `ConfigFactory.kt:327` |
| `memory/projects/cyrus.md` | **H** `:20` «WG/AWG/SSH реализованы» — противоречит `glossary.md:19` и `UPGRADE_0.5.0.md:47`. Три источника противоречат друг другу. **OK** раздел «грабли adb» (`:105-130`) — ценный |
| `scratch.kts` | **C** `:2` реальный URL подписки с токеном |
| `scratch3.kts` | **C** `:23` base64 с UUID, Reality pbk, host — живые секреты |
| `scratch2.kts` | Безопасный Base64-эксперимент, но мусор |
| `.DS_Store` | **L** 5 экземпляров; `.gitignore` их игнорирует, но `.git` нет |

## A.16 Незакрытые пункты из `docs/REVIEW_0.5.0.md`

Проверено против текущего кода:

| ID | Пункт | Статус |
|---|---|---|
| C1 | В `vpn/service/libs/` два AAR, `check_native.py` требует один | **НЕ ИСПРАВЛЕНО** |
| C2 | Нет скрипта сборки libXray; `libxray_tmp/`, `tmp_xray2/`, `tmp_xray3/` на месте | **НЕ ИСПРАВЛЕНО** |
| C3 | `XrayConfigFactory` бросает в VPN-режиме; `mixed` на `proxyPort` | **НЕ ИСПРАВЛЕНО** |
| C4 | `connectionIdentity` открытым текстом | **НЕ ИСПРАВЛЕНО** |
| C5 | Живые ключи в репозитории | **НЕ ИСПРАВЛЕНО** |
| C6 | `.git` отсутствует | **НЕ ИСПРАВЛЕНО** |
| C7 | `ImportKeysUseCaseTest` переопределяет `getAllIdentities()` | **ИСПРАВЛЕНО** |
| H1 | `profiles.isEmpty() \|\| issues.isNotEmpty()` — одна плохая строка убивает подписку | **НЕ ИСПРАВЛЕНО** |
| H3 | `CompositeVpnEngine` выбирает Amnezia по INI-маркеру, которого `ConfigFactory` не генерирует | **НЕ ИСПРАВЛЕНО** |
| H4 | `UnavailableVpnEngine` не инстанцируется | **НЕ ИСПРАВЛЕНО** |
| H11 | ProGuard keep `KentraVpnService` | **НЕ ИСПРАВЛЕНО** |
| H13 | Нет `gradlew`/wrapper | **НЕ ИСПРАВЛЕНО** |
| H14 | `MAX_INPUT` 50 МиБ vs сообщение «1 МиБ» | **НЕ ИСПРАВЛЕНО** |
| L1 | `DummyTunVpnEngine` на месте | **НЕ ИСПРАВЛЕНО** |
| L4 | `.DS_Store` в 5 местах | **НЕ ИСПРАВЛЕНО** |
| H2 | Утечки нет, DNS идёт через прокси | **ЗАКРЫТО** (переформулирован) |
| M13 | CommandServer подключён | **ЗАКРЫТО** |
| H5, H7 | liveness + маскирование лога Xray | **ЧАСТИЧНО ЗАКРЫТО** |

**Итог:** из 7 CRITICAL предыдущего ревью закрыт 1, из 17 HIGH — 2 частично. Ревью `REVIEW_0.5.0.md` остаётся актуальным документом, а не историческим.

---

*Приложение A покрывает 117 `.kt`, 21 `.kts`, 11 `.py`, 4 workflow/скрипта, 22 файла `validation/`, 20+ документов и 12 ресурсных файлов. Каталоги `*/bin/*` (дубликаты скомпилированных исходников) исключены как не являющиеся исходным кодом.*
