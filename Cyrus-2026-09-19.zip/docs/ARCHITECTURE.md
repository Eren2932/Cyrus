> Исторический документ основы 0.4.2. Актуальные изменения и ограничения: [UPGRADE_0.5.0.md](UPGRADE_0.5.0.md).

# Cyrus 0.2 — фактическая архитектура

Проект содержит 16 Gradle-модулей. `app` связывает DI/навигацию, `domain` содержит модели/контракты/use cases, `core` — common, mvi, ui, designsystem, database, datastore, network. `data` реализует хранение/подписки/каталог, `vpn` — link, config, service, `feature` — home, profiles, store.

`domain` остаётся JVM-модулем без Android API, но зависит от `core:common` и coroutines. Features не зависят друг от друга: переход из каталога в библиотеку передаётся callback через app. UI-платформа — Android Compose, не готовый KMP-проект.

`LinkParser.inspect()` выдаёт `ImportReport`. `ImportKeysUseCase` отвечает за локальное добавление/дедупликацию. `SubscriptionRepositoryImpl` выполняет ограниченный HTTPS-запрос (с проверкой резолва хоста на loopback/private/link-local — защита от SSRF) и атомарную замену источника. `ProfileMapper` сохраняет rawLink/parameters в transport DTO; `SecureStorage` шифрует секретные колонки до Room, а `connectionIdentity` пишется открытым текстом, потому что это уже SHA-256-отпечаток, а не ссылка.

MVI использует исходный небольшой `MviMachine`; длительные операции библиотеки блокируют повторные действия через busy-guard. Локальный импорт дополнительно защищён mutex на singleton use case. Отмена корутин не подавляется.

`VpnEngine` — только интерфейс. В DI находится `CompositeVpnEngine`, который по явному признаку `TunnelSession.tunOwner` выбирает движок владельца TUN: `AmneziaVpnEngine` (AmneziaWG) или `LibboxVpnEngine` (sing-box). `XrayVpnEngine` поднимается рядом как локальный SOCKS/mixed-вход на собственном порту, а sing-box получает TUN и цепочку на него; `UnavailableVpnEngine` остаётся типом-заглушкой для сборок без ядра и в DI не подставляется. `ConfigFactory` унаследован и не считается совместимым с непинненной актуальной схемой sing-box; часть расширений теперь явно отклоняется вместо потери параметров. Не существует готовых гарантий per-app routing, DNS leak protection, kill switch или reconnect.

`CatalogBillingRepository` предоставляет исходный локальный прайс. Платежи, активация и серверное entitlement не реализованы. Их кнопки убраны из UI, а не заменены fake-успехом.

Подробности, изменения и критерии следующих проверок: `ANALYSIS_AND_CHANGELOG.md`, `VALIDATION.md`, `SECURITY.md`. Документ предыдущей версии — `history/ARCHITECTURE.md`, только для истории.
