#!/usr/bin/env python3
"""Validate AAR packaging; compilation still has to validate the complete Java API."""
import argparse
import io
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]

# Every prebuilt core the app links against, and what must be inside it. Adding
# a core means adding one entry here; the gate then validates it automatically.
EXPECTED_AARS = {
    'libbox.aar': {
        # Java package emitted by `gomobile bind` for sing-box.
        'class_prefix': 'io/nekohasekai/libbox/',
        # JNI entry points the Kotlin engine calls directly.
        'bindings': ('Libbox', 'BoxService', 'PlatformInterface', 'CommandClient', 'SetupOptions'),
        'native_library': 'libbox.so',
    },
    'libXray.aar': {
        'class_prefix': 'libXray/',
        # XrayVpnEngine calls libXray.LibXray.invoke().
        'bindings': ('LibXray',),
        'native_library': 'libgojni.so',
    },
}

# ABIs the project ships. An AAR may carry extra ABIs; these three must be real.
REQUIRED_ABIS = ('arm64-v8a', 'armeabi-v7a', 'x86_64')


def verify_one(path, spec):
    """Check one AAR against its spec and return the path."""
    with zipfile.ZipFile(path) as aar:
        names = set(aar.namelist())
        if 'classes.jar' not in names:
            raise ValueError(f'{path.name}: missing classes.jar')
        with zipfile.ZipFile(io.BytesIO(aar.read('classes.jar'))) as jar:
            classes = set(jar.namelist())
            prefix = spec['class_prefix']
            if not any(name.startswith(prefix) for name in classes):
                raise ValueError(f'{path.name}: no classes under {prefix}')
            for binding in spec['bindings']:
                if f'{prefix}{binding}.class' not in classes:
                    raise ValueError(f'{path.name}: missing binding {prefix}{binding}.class')
        for abi in REQUIRED_ABIS:
            name = f'jni/{abi}/{spec["native_library"]}'
            if name not in names or aar.getinfo(name).file_size == 0:
                raise ValueError(f'{path.name}: missing or empty native library {name}')
    return path


def verify(folder, expected=None):
    """Validate every AAR in ``folder``.

    ``expected`` is the set of AAR file names that must be present; it defaults
    to every known core. Any AAR that is present but not known is rejected, so an
    unvalidated blob cannot be slipped into the native directory.
    """
    required = set(EXPECTED_AARS if expected is None else expected)
    files = sorted(folder.glob('*.aar'))
    if not files:
        raise ValueError(f'No AAR in {folder}; expected {", ".join(sorted(required))}')
    found = {path.name for path in files}
    missing = sorted(required - found)
    if missing:
        raise ValueError(f'Missing AAR in {folder}: {", ".join(missing)}')
    unknown = sorted(found - set(EXPECTED_AARS))
    if unknown:
        raise ValueError(f'Unrecognised AAR in {folder}: {", ".join(unknown)}; add it to EXPECTED_AARS or remove it')
    for path in files:
        verify_one(path, EXPECTED_AARS[path.name])
    return files


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        'require', nargs='*', default=None,
        help='AAR file names that must be present (default: all known cores)',
    )
    parser.add_argument('--folder', default=str(ROOT / 'vpn/service/libs'))
    args = parser.parse_args()
    verified = verify(Path(args.folder), args.require or None)
    print('PASS native AAR packaging:', ', '.join(path.name for path in verified))
    print('NOT VERIFIED: binary provenance, JNI/API compatibility, APK or runtime behaviour.')


if __name__ == '__main__':
    main()
