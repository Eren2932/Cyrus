#!/usr/bin/env python3
"""Source assertions only. Not a compiler, unit-test runner, native validator or Android test."""
from pathlib import Path
import re, os
from guard_support import finally_blocks
R=Path(os.environ.get("CYRUS_CHECK_ROOT", str(Path(__file__).resolve().parents[1])))
def text(p):return (R/p).read_text()
checks=[]
def check(name, condition):
    assert condition,name
    checks.append(name)
base='vpn/service/src/main/kotlin/dev/kentra/vpn/service/'
runner=text(base+'TunnelServiceRunner.kt');controller=text(base+'TunnelControllerImpl.kt')
factory=text('vpn/config/src/main/kotlin/dev/kentra/vpn/config/ConfigFactory.kt')
parser=text('vpn/link/src/main/kotlin/dev/kentra/vpn/link/DefaultLinkParser.kt')
writer=text('vpn/link/src/main/kotlin/dev/kentra/vpn/link/ProfileLinkWriter.kt')
reader=text('vpn/link/src/main/kotlin/dev/kentra/vpn/link/XraySubscriptionReader.kt')
settings=text('core/datastore/src/main/kotlin/dev/kentra/core/datastore/SettingsStore.kt')
check('Service commands serialized in one FIFO','for (command in commands)' in runner and 'Channel<Command>' in runner)
check('Replacement joins previous teardown before new job',runner.index('tunnelJob?.cancelAndJoin()')<runner.index('tunnelJob = scope.launch'))
check('Replacement cleanup cannot stop latest startId','if (startId != latestStartId) return' in runner and 'service.stopSelfResult(startId)' in runner)
def failed_after_native_teardown(source):
    """True when some finally block stops the engine and only then publishes Failed.

    The old check compared the first `bus.publish(TunnelState.Failed` in the file,
    which is the unrelated fail-closed branch for a failed teardown. Scanning the
    finally block ignores that occurrence and any future ones outside cleanup.
    """
    for block in finally_blocks(source):
        stop = block.find('engine.stop()')
        failed = block.find('bus.publish(TunnelState.Failed')
        if stop != -1 and failed != -1:
            return stop < failed
    return False


check('Failed is published after native teardown',failed_after_native_teardown(runner))
check('Connection errors do not echo native exception', 'error.message' not in runner and 'error.toString' not in runner)
check('Proxy is a distinct ordinary Service','class CyrusProxyService : Service()' in text(base+'CyrusProxyService.kt'))
check('VPN consent only in VPN mode','options.mode == ConnectionMode.VPN && VpnService.prepare(context)' in controller)
check('Proxy listener is loopback only','listen = "127.0.0.1"' in factory and 'Inbound(type = "mixed"' in factory)
check('Proxy service manifest specialUse','FOREGROUND_SERVICE_SPECIAL_USE' in text('vpn/service/src/main/AndroidManifest.xml'))
check('Editor protected from screenshots','SecureFlagPolicy.SecureOn' in text('feature/profiles/src/main/kotlin/dev/kentra/feature/profiles/ProfileEditor.kt'))
check('QR is bundled and secret capture protected','zxing-android-embedded:4.3.0' in text('feature/profiles/build.gradle.kts') and 'FLAG_SECURE' in text('feature/profiles/src/main/kotlin/dev/kentra/feature/profiles/SecureCaptureActivity.kt'))
check('QR decoder never exports captured image','setBarcodeImageEnabled(false)' in text('feature/profiles/src/main/kotlin/dev/kentra/feature/profiles/ProfilesScreen.kt'))
check('Subscription mode disambiguates HTTPS proxy', 'val asSubscription: Boolean' in text('feature/profiles/src/main/kotlin/dev/kentra/feature/profiles/ProfilesContract.kt'))
check('Xray nodes only, no remote policy execution','XraySubscriptionReader(this).inspect(text)' in parser and 'cyrus-unsupported' in reader and 'cyrus-xray' in reader)
check('Unsupported pin and multimode fail closed','require("pinSHA256" !in q)' in factory and 'gRPC multiMode' in factory)
check('Native socket protection fails closed','Не удалось защитить сокет' in text(base+'LibboxVpnEngine.kt'))
check('Canonical export from edited data','p.server' in writer and 'p.port' in writer and 'fun export(profile: VpnProfile)' in parser)
for key in ['connectionMode','proxyPort','dnsLocal','multiplex','logLevel','perAppMode','packages']:
 check('Persisted option '+key, settings.count('prefs[Keys.'+key+']')>=2)
check('Server installation checks before unpack','sha256sum --check' in text('vpn/config/src/main/kotlin/dev/kentra/vpn/config/ServerSetup.kt'))
check('Native schema CI is present','check_generated_configs.sh' in text('.github/workflows/android.yml'))
check('UI unavailable statistics shown as dash','active && state.traffic.available' in text('feature/home/src/main/kotlin/dev/kentra/feature/home/HomeScreen.kt'))
for p in R.rglob('*.kt'):
 if '/src/main/' not in str(p):continue
 s=p.read_text()
 check('No accidental when-branch constructor comma: '+p.name,not re.search(r'\),\s*\n\s*(?:VpnProtocol|ServerProtocol)\.',s))
for c in checks:print('PASS',c)
print(f'{len(checks)} upgrade source checks. Runtime and Kotlin tests NOT executed by this script.')
