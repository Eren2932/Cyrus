#!/usr/bin/env python3
"""Shared helpers for the source guards and their mutation tests.

Two concerns live here:

* ``copy_tree`` is the single copy routine used by every mutation test. The
  repository tree is ~2 GiB, almost all of it generated output, so the tests
  must never copy ``build/``, ``.gradle/``, AARs or APKs. Duplicating the ignore
  list in five files is how the tests drifted apart in the first place.

* ``finally_blocks`` extracts ``finally { ... }`` bodies with a brace matcher
  that skips comments and string literals. The merge/upgrade guards need to ask
  "does the teardown live inside a finally block?", not "is the text of the
  finally block formatted exactly like this?". The old regexes broke on correct
  code after a refactor added comments and a ``withContext(NonCancellable)``
  wrapper (docs/CODE_REVIEW_ORCHESTRATED_2026-09-19.md C-5).
"""
import re
import shutil

# Generated output, caches, vendored binaries and packaged artifacts. None of
# them are read by the guards, and copying them is what made the mutation tests
# take minutes and fail on the baseline.
COPY_IGNORE = shutil.ignore_patterns(
    'build', '.gradle', '.kotlin', '__pycache__', 'libs', 'awg-aar', '*.aar', '*.apk'
)


def copy_tree(src, dst):
    """Copy a repository tree for mutation testing, skipping heavy output."""
    shutil.copytree(src, dst, ignore=COPY_IGNORE)


def _matching_brace(source, open_index):
    """Index of the ``}`` matching the ``{`` at ``open_index``, or None.

    Comments and string literals are skipped so a brace inside a comment cannot
    unbalance the count.
    """
    depth = 0
    i = open_index
    n = len(source)
    while i < n:
        if source.startswith('//', i):
            j = source.find('\n', i)
            i = n if j < 0 else j + 1
            continue
        if source.startswith('/*', i):
            j = source.find('*/', i + 2)
            if j < 0:
                return None
            i = j + 2
            continue
        if source.startswith('"""', i):
            j = source.find('"""', i + 3)
            if j < 0:
                return None
            i = j + 3
            continue
        ch = source[i]
        if ch in '"\'':
            quote = ch
            i += 1
            while i < n:
                if source[i] == '\\':
                    i += 2
                    continue
                if source[i] == quote:
                    i += 1
                    break
                i += 1
            continue
        if ch == '{':
            depth += 1
        elif ch == '}':
            depth -= 1
            if depth == 0:
                return i
        i += 1
    return None


def finally_blocks(source):
    """Yield the body of every ``finally { ... }`` block in ``source``."""
    for match in re.finditer(r'\bfinally\b', source):
        brace = source.find('{', match.end())
        if brace == -1:
            continue
        end = _matching_brace(source, brace)
        if end is None:
            continue
        yield source[brace + 1:end]
