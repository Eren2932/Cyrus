#!/usr/bin/env python3
"""Check that source gates reject representative merge regressions; no Android execution."""
from pathlib import Path
import tempfile
from check_merge import validate, ROOT, ENGINE, SERVICE, CONFIG, TEST
from guard_support import copy_tree

mutations = [
    ('QUIC block restored', CONFIG, 'val rules = buildList {', 'val rules = buildList {\nadd(RouteRule(network = listOf("udp"), port = listOf(443), outbound = "block"))'),
    ('IPv6 regression test lost', TEST, 'udp443 is never blanket-blocked', 'removed regression'),
    ('lifecycle lock removed', ENGINE, 'lifecycle.withLock {', 'run {'),
    ('cancellable stop restored', ENGINE, 'NonCancellable + Dispatchers.IO', 'Dispatchers.IO'),
    ('TUN ownership lost', ENGINE, 'return fd.getFd()', 'return fd.detachFd()'),
    ('config log restored', ENGINE, '// Configuration contains credentials; never write it to logcat.', 'Log.d("sing-box", "Starting with config: ${session.configJson}")'),
    ('IPv4 default route lost', ENGINE, 'options.getInet4RouteRange()', 'options.getInet4RouteAddress()'),
    ('cleanup removed', SERVICE, 'runCatching { engine.stop() }', 'runCatching { Unit }'),
    ('unhandled start failure restored', SERVICE, 'if (error is kotlinx.coroutines.CancellationException) throw error', 'throw error'),
    ('scope leak restored', SERVICE, 'scope.cancel()', 'tunnelJob?.cancel()'),
]
with tempfile.TemporaryDirectory() as directory:
    root = Path(directory) / 'Cyrus'
    copy_tree(ROOT, root)
    validate(root)
    for name, path, old, new in mutations:
        p = root / path
        original = p.read_text()
        assert old in original, name
        p.write_text(original.replace(old, new))
        try:
            validate(root)
        except AssertionError:
            print('PASS rejected:', name)
        else:
            raise AssertionError('Undetected mutation: ' + name)
        finally:
            p.write_text(original)
print(f'PASS {len(mutations)} merge mutation cases; not Kotlin or runtime tests.')
