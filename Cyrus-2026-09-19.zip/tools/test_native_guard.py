#!/usr/bin/env python3
"""Synthetic ZIP fixture tests for check_native, not tests of a real libbox binary."""
import io
from pathlib import Path
import tempfile
import unittest
import zipfile
from check_native import verify

LIBBOX_BINDINGS = ('Libbox', 'BoxService', 'PlatformInterface', 'CommandClient', 'SetupOptions')
ABIS = ('arm64-v8a', 'armeabi-v7a', 'x86_64')


class NativePackagingTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def write_aar(self, name, classes, native, omit_class=None, omit_abi=None,
                  empty_abi=None, omit_native=False):
        jar_data = io.BytesIO()
        with zipfile.ZipFile(jar_data, 'w') as jar:
            for cls in classes:
                if cls != omit_class:
                    jar.writestr(f'{cls}.class', b'fixture-only')
        path = self.root / name
        with zipfile.ZipFile(path, 'w') as aar:
            aar.writestr('classes.jar', jar_data.getvalue())
            if not omit_native:
                for abi in ABIS:
                    if abi != omit_abi:
                        aar.writestr(f'jni/{abi}/{native}', b'' if abi == empty_abi else b'fixture-only')
        return path

    def libbox(self, **kwargs):
        classes = [f'io/nekohasekai/libbox/{binding}' for binding in LIBBOX_BINDINGS]
        return self.write_aar('libbox.aar', classes, 'libbox.so', **kwargs)

    def libxray(self, **kwargs):
        return self.write_aar('libXray.aar', ['libXray/LibXray'], 'libgojni.so', **kwargs)

    def test_complete_packaging(self):
        box = self.libbox()
        xray = self.libxray()
        self.assertEqual(verify(self.root), sorted([box, xray]))

    def test_absent(self):
        with self.assertRaises(ValueError): verify(self.root)

    def test_missing_libxray(self):
        self.libbox()
        with self.assertRaises(ValueError): verify(self.root)

    def test_single_core_can_be_required(self):
        box = self.libbox()
        self.assertEqual(verify(self.root, ['libbox.aar']), [box])

    def test_unrecognised_aar(self):
        box = self.libbox()
        self.libxray()
        (self.root / 'mystery.aar').write_bytes(box.read_bytes())
        with self.assertRaises(ValueError): verify(self.root)

    def test_missing_binding(self):
        self.libbox(omit_class='io/nekohasekai/libbox/BoxService')
        self.libxray()
        with self.assertRaises(ValueError): verify(self.root)

    def test_missing_abi(self):
        self.libbox(omit_abi='arm64-v8a')
        self.libxray()
        with self.assertRaises(ValueError): verify(self.root)

    def test_empty_native_library(self):
        self.libbox(empty_abi='x86_64')
        self.libxray()
        with self.assertRaises(ValueError): verify(self.root)

    def test_missing_libxray_entrypoint(self):
        self.libbox()
        self.libxray(omit_class='libXray/LibXray')
        with self.assertRaises(ValueError): verify(self.root)


if __name__ == '__main__':
    unittest.main(verbosity=2)
