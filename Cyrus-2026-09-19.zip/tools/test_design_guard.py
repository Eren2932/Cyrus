#!/usr/bin/env python3
"""Mutation tests: verify the design gate rejects known regressions (stdlib)."""
from pathlib import Path
import subprocess, sys, tempfile
from guard_support import copy_tree
ROOT=Path(__file__).resolve().parents[1]
T='core/designsystem/src/main/kotlin/dev/kentra/core/designsystem/Theme.kt'
C='core/designsystem/src/main/kotlin/dev/kentra/core/designsystem/Components.kt'
N='app/src/main/kotlin/dev/kentra/app/CyrusShell.kt'
W='app/src/main/kotlin/dev/kentra/app/CyrusWallpaper.kt'
mutations=[
 ('black dark-theme text',T,'0xFFEDEDEA','0xFF080808'),
 ('invisible secondary text',T,'0xFFB3B3AF','0xFF383838'),
 ('missing root foreground',T,'LocalContentColor provides MaterialTheme.colorScheme.onBackground','LocalContentColor provides Color.Black'),
 ('missing scaffold foreground',N,'contentColor = MaterialTheme.colorScheme.onBackground','contentColor = Color.Black'),
 ('idle ring alpha',C,'drawCircle(ring, radius','drawCircle(ring.copy(alpha = .16f), radius'),
 ('bar gradient',C,'.background(pill)','.background(Brush.verticalGradient(listOf(pill, Color.White)))'),
 ('wallpaper attenuation',W,'contentScale = ContentScale.Crop','contentScale = ContentScale.Crop, alpha = .58f'),
 ('missing outgoing push',N,'slideOutHorizontally','fadeOut'),
 ('invisible bar hit targets',N,'if (!settingsOpen) CyrusNavigationBar','CyrusNavigationBar'),
 ('idle continuous work',C,'active && animate && !reduced','!busy && animate && !reduced'),
 ('dark control border too dim',T,'0xFF9B9B9B','0xFF2A2A2A'),
]
with tempfile.TemporaryDirectory() as d:
    r=Path(d)/'Cyrus';copy_tree(ROOT,r)
    def run():return subprocess.run([sys.executable,str(r/'tools/check_design.py')],capture_output=True,text=True)
    assert run().returncode==0,'Baseline gate must pass'
    for label,path,old,new in mutations:
        p=r/path;original=p.read_text();assert old in original,label
        p.write_text(original.replace(old,new))
        result=run();p.write_text(original)
        assert result.returncode!=0,'Gate failed to catch: '+label
        assert 'AssertionError' in result.stderr,'Unexpected failure: '+result.stderr
        print('PASS rejected:',label)
    p=r/'app/src/main/res/drawable-nodpi/wallpaper_camo.webp';p.write_bytes(p.read_bytes()+b'changed')
    result=run();assert result.returncode!=0 and 'Changed wallpaper needs a new pixel audit' in result.stderr
    print('PASS rejected: unaudited wallpaper')
print('PASS 12 mutation cases; this is not Android runtime testing.')
