package dev.kentra.domain.model

import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * `displayEndpoint` is what the user copies into a bug report and what the profile
 * list shows. A malformed endpoint is worse than an ugly one: `[[::1]]:443` cannot be
 * reached or looked up by anyone.
 */
class DisplayEndpointTest {

    private fun profile(server: String) = VpnProfile(
        id = "p",
        name = "n",
        protocol = VpnProtocol.VLESS,
        server = server,
        port = 443,
    )

    @Test
    fun `a hostname is left alone`() {
        assertEquals("example.com:443", profile("example.com").displayEndpoint)
    }

    @Test
    fun `an ipv4 address is left alone`() {
        assertEquals("10.0.0.1:443", profile("10.0.0.1").displayEndpoint)
    }

    @Test
    fun `a bare ipv6 address is bracketed`() {
        assertEquals("[2001:db8::1]:443", profile("2001:db8::1").displayEndpoint)
        assertEquals("[::1]:443", profile("::1").displayEndpoint)
    }

    @Test
    fun `an already bracketed address is not bracketed twice`() {
        assertEquals("[::1]:443", profile("[::1]").displayEndpoint)
        assertEquals("[2001:db8::1]:443", profile("[2001:db8::1]").displayEndpoint)
    }

    @Test
    fun `brackets are balanced and never doubled`() {
        // IPv6 needs exactly one pair; anything else needs none. The bug this guards is
        // `[[::1]]:443` - doubled brackets on input that already carried them.
        for (server in listOf("::1", "[::1]", "2001:db8::1", "[2001:db8::1]")) {
            val endpoint = profile(server).displayEndpoint
            assertEquals("server=$server -> $endpoint", 1, endpoint.count { it == '[' })
            assertEquals("server=$server -> $endpoint", 1, endpoint.count { it == ']' })
        }
        for (server in listOf("example.com", "10.0.0.1")) {
            val endpoint = profile(server).displayEndpoint
            assertEquals("server=$server -> $endpoint", 0, endpoint.count { it == '[' })
            assertEquals("server=$server -> $endpoint", 0, endpoint.count { it == ']' })
        }
    }
}
