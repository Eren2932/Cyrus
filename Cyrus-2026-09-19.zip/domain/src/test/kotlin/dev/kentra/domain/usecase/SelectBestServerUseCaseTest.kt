package dev.kentra.domain.usecase

import dev.kentra.domain.model.BestServerResult
import dev.kentra.domain.model.ProbeOutcome
import dev.kentra.domain.model.SelectionStep
import dev.kentra.domain.model.TrafficSample
import dev.kentra.domain.model.TunnelState
import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.model.VpnProtocol
import dev.kentra.domain.model.connectionIdentity
import dev.kentra.domain.repository.LatencyProber
import dev.kentra.domain.repository.ProfileRepository
import dev.kentra.domain.repository.ProfileValidator
import dev.kentra.domain.repository.TunnelController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.filterIsInstance
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The search's whole value is in the ORDER it trusts evidence, so the tests are about
 * ranking decisions rather than about plumbing: a nearer key must lose to a working one,
 * and a key that answers a socket must lose to one that survives probation.
 */
class SelectBestServerUseCaseTest {

    private fun profile(id: String, protocol: VpnProtocol = VpnProtocol.VLESS) =
        VpnProfile(id, "Ключ $id", protocol, "$id.test", 443)

    private class Repo(initial: List<VpnProfile>) : ProfileRepository {
        val entries = MutableStateFlow(initial)
        val active = MutableStateFlow<String?>(null)
        override fun observeProfiles(): Flow<List<VpnProfile>> = entries
        override fun observeActiveProfileId(): Flow<String?> = active
        override suspend fun getProfile(id: String) = entries.value.firstOrNull { it.id == id }
        override suspend fun upsert(profile: VpnProfile) {
            entries.value = entries.value.filterNot { it.id == profile.id } + profile
        }
        override suspend fun upsertAll(profiles: List<VpnProfile>) { profiles.forEach { upsert(it) } }
        override suspend fun delete(id: String) { entries.value = entries.value.filterNot { it.id == id } }
        override suspend fun setActiveProfileId(id: String?) { active.value = id }
        override suspend fun getAllIdentities(): List<String> = entries.value.map { it.connectionIdentity() }
    }

    private class Prober(private val outcomes: Map<String, ProbeOutcome>) : LatencyProber {
        val measured = mutableListOf<String>()
        override suspend fun measure(profile: VpnProfile, timeoutMillis: Long): ProbeOutcome {
            measured += profile.id
            return outcomes[profile.id] ?: ProbeOutcome.Unreachable("нет ответа")
        }
    }

    private class Validator(private val broken: Set<String>) : ProfileValidator {
        override fun validate(profile: VpnProfile) {
            require(profile.id !in broken) { "не собирается ядром" }
        }
    }

    private sealed interface Script {
        data object Up : Script
        data object Dead : Script
        /** Comes up, then is invalidated inside the probation window. */
        data object UpThenInvalidated : Script
    }

    private class Tunnel(
        private val scope: CoroutineScope,
        private val scripts: Map<String, Script> = emptyMap(),
        private val invalidateAfterMs: Long = 30,
        /** How long the service takes to tear the tunnel down after `disconnect()` returns. */
        private val teardownMs: Long = 50,
    ) : TunnelController {
        private val mutable = MutableStateFlow<TunnelState>(TunnelState.Idle)
        override val state: StateFlow<TunnelState> = mutable
        override val traffic: Flow<TrafficSample> = flowOf(TrafficSample())
        val dialled = mutableListOf<String>()
        var disconnects = 0

        override suspend fun connect(profile: VpnProfile) {
            // The real controller refuses rather than waits: TunnelControllerImpl.kt:51
            // throws while the state is Preparing or Stopping. A fake that accepted the
            // call here would hide the whole class of "asked too early" failures.
            if (mutable.value is TunnelState.Preparing || mutable.value is TunnelState.Stopping)
                throw IllegalStateException("Дождитесь завершения предыдущего подключения")
            dialled += profile.id
            when (scripts[profile.id] ?: Script.Up) {
                Script.Up -> mutable.value = TunnelState.Connected(profile.id, 0)
                Script.Dead -> mutable.value = TunnelState.Failed("ядро не поднялось")
                Script.UpThenInvalidated -> {
                    mutable.value = TunnelState.Connected(profile.id, 0)
                    scope.launch {
                        delay(invalidateAfterMs)
                        mutable.value = TunnelState.Failed("invalidated after connect")
                    }
                }
            }
        }

        override suspend fun disconnect() {
            disconnects++
            // The real controller publishes Stopping and returns; the teardown happens
            // afterwards in the service (TunnelControllerImpl.kt:129). Modelling it as an
            // instant transition to Idle is what let the ordering bug through before.
            mutable.value = TunnelState.Stopping
            scope.launch {
                delay(teardownMs)
                if (mutable.value is TunnelState.Stopping) mutable.value = TunnelState.Idle
            }
        }
    }

    private fun useCase(repo: Repo, prober: Prober, validator: Validator, tunnel: Tunnel) =
        SelectBestServerUseCase(repo, prober, validator, tunnel, probationMs = 200)

    private suspend fun SelectBestServerUseCase.run(): BestServerResult =
        invoke().filterIsInstance<SelectionStep.Finished>().first().result

    @Test
    fun `nearest reachable key wins and is left connected`() = runTest {
        val near = profile("near"); val far = profile("far")
        val repo = Repo(listOf(far, near))
        val tunnel = Tunnel(backgroundScope)
        val result = useCase(
            repo,
            Prober(mapOf("near" to ProbeOutcome.Reachable(12), "far" to ProbeOutcome.Reachable(90))),
            Validator(emptySet()),
            tunnel,
        ).run()

        assertEquals(near.id, (result as BestServerResult.Found).profile.id)
        assertEquals(12L, result.rttMillis)
        assertEquals("near", repo.active.value)
        assertTrue(tunnel.state.value is TunnelState.Connected)
    }

    @Test
    fun `a key the core cannot build is never probed`() = runTest {
        val broken = profile("broken"); val good = profile("good")
        val prober = Prober(mapOf("good" to ProbeOutcome.Reachable(50)))
        val result = useCase(Repo(listOf(broken, good)), prober, Validator(setOf("broken")), Tunnel(backgroundScope)).run()

        assertEquals(good.id, (result as BestServerResult.Found).profile.id)
        assertEquals(1, result.report.rejectedByValidation)
        assertFalse("сломанный ключ не должен занимать сокет", "broken" in prober.measured)
    }

    @Test
    fun `a key that answers the probe but cannot carry traffic loses to a slower one`() = runTest {
        val fast = profile("fast"); val slow = profile("slow")
        val tunnel = Tunnel(backgroundScope, mapOf("fast" to Script.Dead, "slow" to Script.Up))
        val result = useCase(
            Repo(listOf(fast, slow)),
            Prober(mapOf("fast" to ProbeOutcome.Reachable(5), "slow" to ProbeOutcome.Reachable(200))),
            Validator(emptySet()),
            tunnel,
        ).run()

        assertEquals(slow.id, (result as BestServerResult.Found).profile.id)
        assertEquals(listOf("fast", "slow"), tunnel.dialled)
        assertEquals(1, result.report.failedVerification)
    }

    @Test
    fun `a tunnel that dies inside the probation window does not win`() = runTest {
        // The runner publishes Connected before the core has finished proving itself, and a
        // dead bootstrap surfaces about 6 s later. Ranking on Connected alone would crown
        // this key; waiting out the window is what stops it.
        val fast = profile("fast"); val slow = profile("slow")
        val tunnel = Tunnel(
            backgroundScope,
            mapOf("fast" to Script.UpThenInvalidated, "slow" to Script.Up),
        )
        val result = useCase(
            Repo(listOf(fast, slow)),
            Prober(mapOf("fast" to ProbeOutcome.Reachable(5), "slow" to ProbeOutcome.Reachable(200))),
            Validator(emptySet()),
            tunnel,
        ).run()

        assertEquals(slow.id, (result as BestServerResult.Found).profile.id)
        assertEquals(1, result.report.failedVerification)
    }

    @Test
    fun `an endpoint that refused the probe is not dialled`() = runTest {
        val dead = profile("dead"); val live = profile("live")
        val tunnel = Tunnel(backgroundScope)
        val result = useCase(
            Repo(listOf(dead, live)),
            Prober(mapOf("dead" to ProbeOutcome.Unreachable("connection refused"), "live" to ProbeOutcome.Reachable(80))),
            Validator(emptySet()),
            tunnel,
        ).run()

        assertEquals(live.id, (result as BestServerResult.Found).profile.id)
        assertEquals(1, result.report.unreachable)
        assertEquals(listOf("live"), tunnel.dialled)
    }

    @Test
    fun `a UDP-only key is still a candidate because nothing was measured`() = runTest {
        // hysteria2 has no TCP listener to measure. Skipping it would silently drop a
        // working key from the search on the strength of a probe that could not apply.
        val quic = profile("quic", VpnProtocol.HYSTERIA2)
        val tunnel = Tunnel(backgroundScope)
        val result = useCase(
            Repo(listOf(quic)),
            Prober(mapOf("quic" to ProbeOutcome.NotMeasurable)),
            Validator(emptySet()),
            tunnel,
        ).run()

        assertEquals(quic.id, (result as BestServerResult.Found).profile.id)
        assertNull("незамеренный ключ не имеет честного RTT", result.rttMillis)
        assertEquals(listOf("quic"), tunnel.dialled)
        assertEquals(1, result.report.notMeasurable)
    }

    @Test
    fun `distance decides among measured keys, whatever protocol they speak`() = runTest {
        // The ranking rule: a measured round trip orders candidates, and only keys nothing
        // could be measured on are held back. That a hysteria2 key can be measured at all -
        // the half that used to be missing - is proved where it lives, in
        // RoutingLatencyProberTest and UdpLatencyProberTest; what this pins down is that
        // nothing in the search reorders by protocol.
        val slowTcp = profile("slow")
        val nearQuic = profile("near", VpnProtocol.HYSTERIA2)
        val unmeasured = profile("unmeasured", VpnProtocol.WIREGUARD)
        val tunnel = Tunnel(
            backgroundScope,
            mapOf("near" to Script.Dead, "slow" to Script.Dead, "unmeasured" to Script.Up),
        )
        val result = useCase(
            Repo(listOf(slowTcp, nearQuic, unmeasured)),
            Prober(
                mapOf(
                    "slow" to ProbeOutcome.Reachable(300),
                    "near" to ProbeOutcome.Reachable(20),
                    "unmeasured" to ProbeOutcome.NotMeasurable,
                ),
            ),
            Validator(emptySet()),
            tunnel,
        ).run()

        assertEquals(unmeasured.id, (result as BestServerResult.Found).profile.id)
        assertEquals("сначала по замеру, незамеренные — последними", listOf("near", "slow", "unmeasured"), tunnel.dialled)
        assertEquals(1, result.report.notMeasurable)
    }

    @Test
    fun `no key survives verification reports not found with the count tried`() = runTest {
        val a = profile("a"); val b = profile("b")
        val result = useCase(
            Repo(listOf(a, b)),
            Prober(mapOf("a" to ProbeOutcome.Reachable(10), "b" to ProbeOutcome.Reachable(20))),
            Validator(emptySet()),
            Tunnel(backgroundScope, mapOf("a" to Script.Dead, "b" to Script.Dead)),
        ).run()

        assertEquals(BestServerResult.NotFound::class.java, result::class.java)
        assertEquals(2, (result as BestServerResult.NotFound).report.verified)
        assertEquals(2, result.report.failedVerification)
    }

    @Test
    fun `nothing routable reports no candidates and says how many were dropped`() = runTest {
        val result = useCase(
            Repo(listOf(profile("a"), profile("b"))),
            Prober(emptyMap()),
            Validator(setOf("a", "b")),
            Tunnel(backgroundScope),
        ).run()

        val noCandidates = result as BestServerResult.NoCandidates
        assertEquals(2, noCandidates.report.considered)
        assertEquals(2, noCandidates.report.rejectedByValidation)
    }

    @Test
    fun `an empty list is reported as nothing to search rather than as a failure`() = runTest {
        val result = useCase(Repo(emptyList()), Prober(emptyMap()), Validator(emptySet()), Tunnel(backgroundScope)).run()
        assertEquals(0, (result as BestServerResult.NoCandidates).report.considered)
    }

    @Test
    fun `an already connected tunnel is disconnected before candidates are dialled`() = runTest {
        // Candidates cannot be dialled while the TUN is held, and a user pressing "Авто"
        // while connected is asking to be moved off that server, not to be refused.
        val only = profile("only")
        val tunnel = Tunnel(backgroundScope)
        tunnel.connect(profile("previous"))
        val result = useCase(
            Repo(listOf(only)),
            Prober(mapOf("only" to ProbeOutcome.Reachable(30))),
            Validator(emptySet()),
            tunnel,
        ).run()

        assertEquals(only.id, (result as BestServerResult.Found).profile.id)
        assertTrue("туннель должен быть освобождён перед перебором", tunnel.disconnects >= 1)
    }

    @Test
    fun `a search started while connected does not throw away its best candidate`() = runTest {
        // `disconnect()` publishes Stopping and returns, and `connect()` refuses while the
        // state is Stopping rather than waiting for it. Asking to connect straight after a
        // disconnect therefore fails for a reason that has nothing to do with the candidate
        // being tested - and because the shortlist is ordered best-first, that failure lands
        // on the *best* candidate. The user would be moved to a worse server, or told that
        // nothing works immediately after their working tunnel was torn down.
        val only = profile("only")
        val tunnel = Tunnel(backgroundScope)
        tunnel.connect(profile("previous"))
        val result = useCase(
            Repo(listOf(only)),
            Prober(mapOf("only" to ProbeOutcome.Reachable(30))),
            Validator(emptySet()),
            tunnel,
        ).run()

        assertEquals(only.id, (result as BestServerResult.Found).profile.id)
        assertEquals(
            "кандидат потерян из-за незавершённого teardown, а не из-за себя",
            0,
            result.report.failedVerification,
        )
    }
}
