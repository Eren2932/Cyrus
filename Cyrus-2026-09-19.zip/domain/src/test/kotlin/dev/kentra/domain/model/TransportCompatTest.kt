package dev.kentra.domain.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TransportCompatTest {

    @Test fun `xray raw is plain tcp`() {
        for (alias in listOf("raw", "RAW", " raw ", "none", "original", "", "tcp")) assertEquals("tcp", TransportCompat.normalize(alias))
        assertEquals("tcp", TransportCompat.normalize(null))
    }

    @Test fun `http aliases collapse to the sing-box name`() {
        for (alias in listOf("h2", "h2c", "http2", "HTTP")) assertEquals("http", TransportCompat.normalize(alias))
    }

    @Test fun `grpc and ws aliases collapse`() {
        assertEquals("grpc", TransportCompat.normalize("gun"))
        assertEquals("ws", TransportCompat.normalize("WebSocket"))
        assertEquals("httpupgrade", TransportCompat.normalize("http-upgrade"))
    }

    @Test fun `unsupported transports keep their canonical name`() {
        assertEquals("xhttp", TransportCompat.normalize("splithttp"))
        assertEquals("kcp", TransportCompat.normalize("mKCP"))
        assertEquals("quic", TransportCompat.normalize("quic"))
    }

    @Test fun `every sing-box transport is accepted and every alias of it too`() {
        for (type in TransportCompat.SING_BOX) assertNull(TransportCompat.singBoxRejection(type))
        for (alias in listOf("raw", "h2", "gun", "websocket", "upgrade")) assertNull(TransportCompat.singBoxRejection(alias))
    }

    @Test fun `grpc multiMode selects Xray but ordinary grpc selects sing-box`() {
        val base = VpnProfile("id", "grpc", VpnProtocol.VLESS, "proxy.example", 443,
            uuid = "11111111-2222-3333-4444-555555555555",
            transport = TransportSettings("grpc"),
            parameters = mapOf("type" to "grpc", "mode" to "multi"))
        assertEquals(VpnEngineKind.XRAY, TransportCompat.requiredEngine(base))
        assertEquals(VpnEngineKind.SING_BOX, TransportCompat.requiredEngine(base.copy(parameters = mapOf("type" to "grpc"))))
    }

    @Test fun `xray only transports are refused by name, not silently accepted`() {
        for (type in TransportCompat.XRAY_ONLY) {
            val reason = TransportCompat.singBoxRejection(type)
            assertTrue("must name the transport: " + reason, reason != null && reason.contains(type))
            assertTrue("must name Xray: " + reason, reason!!.contains("Xray"))
            assertEquals(VpnEngineKind.XRAY, TransportCompat.requiredEngine(type))
        }
        assertEquals(VpnEngineKind.SING_BOX, TransportCompat.requiredEngine("raw"))
    }

    @Test fun `unknown transport is reported without echoing markup`() {
        val reason = TransportCompat.singBoxRejection("we<b>ird")
        assertTrue(reason != null && !reason.contains("<"))
    }

    @Test fun `normalization is idempotent`() {
        for (alias in listOf("raw", "h2", "gun", "websocket", "splithttp", "mkcp", "weird")) {
            val once = TransportCompat.normalize(alias)
            assertEquals(once, TransportCompat.normalize(once))
        }
    }

    private fun key(
        protocol: VpnProtocol,
        transport: String = "tcp",
        parameters: Map<String, String> = emptyMap(),
    ) = VpnProfile("id", "name", protocol, "proxy.example", 443,
        transport = TransportSettings(transport), parameters = parameters)

    @Test fun `QUIC protocols are measurable because a QUIC server answers a version probe`() {
        assertEquals(WireKind.QUIC, TransportCompat.wireKind(key(VpnProtocol.HYSTERIA2)))
        assertEquals(WireKind.QUIC, TransportCompat.wireKind(key(VpnProtocol.TUIC)))
    }

    @Test fun `an ordinary TCP key is measured with a connect`() {
        // The control: the taxonomy must not swallow the common case.
        assertEquals(WireKind.TCP, TransportCompat.wireKind(key(VpnProtocol.VLESS)))
        assertEquals(WireKind.TCP, TransportCompat.wireKind(key(VpnProtocol.TROJAN)))
        assertEquals(WireKind.TCP, TransportCompat.wireKind(key(VpnProtocol.SHADOWSOCKS)))
    }

    @Test fun `the transport decides the wire before the protocol does`() {
        // A vless key carried over kcp is UDP whatever its protocol says, and one carried
        // over the quic network is QUIC for the same reason.
        assertEquals(WireKind.OPAQUE_UDP, TransportCompat.wireKind(key(VpnProtocol.VLESS, transport = "kcp")))
        assertEquals(WireKind.OPAQUE_UDP, TransportCompat.wireKind(key(VpnProtocol.VLESS, transport = "mkcp")))
        assertEquals(WireKind.QUIC, TransportCompat.wireKind(key(VpnProtocol.VLESS, transport = "quic")))
    }

    @Test fun `salamander obfuscation makes a QUIC key unmeasurable`() {
        // Every datagram is XORed before the QUIC layer sees it, so a plain version probe is
        // deobfuscated to noise and dropped. Calling this QUIC would have the prober report a
        // working server as silent.
        assertEquals(
            WireKind.OPAQUE_UDP,
            TransportCompat.wireKind(
                key(VpnProtocol.HYSTERIA2, parameters = mapOf("obfs" to "salamander", "obfs-password" to "test-only")),
            ),
        )
    }

    @Test fun `WireGuard is UDP and is never measured with a TCP connect`() {
        // Both speak UDP on the wire, so a TCP connect to that port measures whatever else
        // the host runs there - a confident number about a service the user is not buying.
        assertEquals(WireKind.OPAQUE_UDP, TransportCompat.wireKind(key(VpnProtocol.WIREGUARD)))
        assertEquals(WireKind.OPAQUE_UDP, TransportCompat.wireKind(key(VpnProtocol.AMNEZIA_WG)))
    }
}
