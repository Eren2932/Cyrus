package dev.kentra.domain.model

import java.security.MessageDigest

data class ImportIssue(val line: Int, val reason: String)
data class ImportReport(
    val profiles: List<VpnProfile> = emptyList(),
    val issues: List<ImportIssue> = emptyList(),
    val duplicates: Int = 0,
)

/**
 * Stable, one-way fingerprint of a profile used for import de-duplication.
 *
 * The value is `"v3:"` followed by the lowercase hex SHA-256 digest of the original
 * credential source. It is written to `profiles.connectionIdentity` (ProfileMapper.toEntity),
 * a column that SecureStorage does NOT encrypt - so the returned string must never contain
 * credentials. Because the digest is irreversible, the column is safe to store in plaintext:
 * an attacker with the database file cannot recover the UUID, password or share link.
 *
 * Source of the digest:
 * - [VpnProfile.rawLink] present: the link without its `#fragment` (fragment is presentational);
 * - otherwise: a canonical string built only from the significant connection fields. The old
 *   fallback used `toString()` of a copy, which embedded `uuid`/`password` in plaintext and was
 *   not stable across map ordering.
 *
 * The algorithm and the `"v3:"` prefix are mirrored by `CyrusDatabase.MIGRATION_2_3`, which
 * re-hashes the values already stored by earlier app versions. Keep them in sync.
 */
fun VpnProfile.connectionIdentity(): String =
    IDENTITY_PREFIX + (rawLink?.substringBefore('#') ?: canonicalIdentitySource()).sha256Hex()

/**
 * Deterministic serialization of the fields that define a connection. Ordering is fixed and
 * parameters are sorted so the same logical profile always yields the same digest.
 */
private fun VpnProfile.canonicalIdentitySource(): String = buildString {
    append("protocol=").append(protocol.name).append(FIELD_SEPARATOR)
    append("server=").append(server).append(FIELD_SEPARATOR)
    append("port=").append(port).append(FIELD_SEPARATOR)
    append("uuid=").append(uuid.orEmpty()).append(FIELD_SEPARATOR)
    append("password=").append(password.orEmpty()).append(FIELD_SEPARATOR)
    append("method=").append(method.orEmpty()).append(FIELD_SEPARATOR)
    append("flow=").append(flow.orEmpty()).append(FIELD_SEPARATOR)
    append("alterId=").append(alterId?.toString().orEmpty()).append(FIELD_SEPARATOR)
    append("tls=")
        .append(tls.enabled).append(',')
        .append(tls.serverName.orEmpty()).append(',')
        .append(tls.allowInsecure).append(',')
        .append(tls.alpn.joinToString(",")).append(',')
        .append(tls.fingerprint.orEmpty()).append(',')
        .append(tls.reality?.publicKey.orEmpty()).append(',')
        .append(tls.reality?.shortId.orEmpty()).append(',')
        .append(tls.reality?.spiderX.orEmpty())
        .append(FIELD_SEPARATOR)
    append("transport=")
        .append(transport.type).append(',')
        .append(transport.path.orEmpty()).append(',')
        .append(transport.host.orEmpty()).append(',')
        .append(transport.serviceName.orEmpty())
        .append(FIELD_SEPARATOR)
    append("parameters=")
        .append(parameters.toSortedMap().entries.joinToString(",") { "${it.key}=${it.value}" })
}

private fun String.sha256Hex(): String {
    val digest = MessageDigest.getInstance("SHA-256").digest(toByteArray(Charsets.UTF_8))
    val out = StringBuilder(digest.size * 2)
    for (byte in digest) {
        val value = byte.toInt() and 0xFF
        out.append(HEX_DIGITS[value ushr 4]).append(HEX_DIGITS[value and 0x0F])
    }
    return out.toString()
}

private const val IDENTITY_PREFIX = "v3:"
private const val FIELD_SEPARATOR = '\u0000'
private const val HEX_DIGITS = "0123456789abcdef"
