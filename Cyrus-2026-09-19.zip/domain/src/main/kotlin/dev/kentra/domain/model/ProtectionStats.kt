package dev.kentra.domain.model

/**
 * The route categories that can be attributed to a blocked connection.
 * Threat and phishing protection is DNS-backed, so those counters may stay at zero
 * even while the resolver is actively protecting the tunnel.
 */
enum class ProtectionCategory {
    ADS,
    TRACKERS,
    ANNOYANCES,
    THREATS,
    FIREWALL,
    OTHER,
}

/** Persisted counters shown by the protection and statistics screens. */
data class ProtectionStats(
    val blockedRequests: Long = 0L,
    val uploadedBytes: Long = 0L,
    val downloadedBytes: Long = 0L,
    val adsBlocked: Long = 0L,
    val trackersBlocked: Long = 0L,
    val annoyancesBlocked: Long = 0L,
    val threatsBlocked: Long = 0L,
    val firewallBlocked: Long = 0L,
    val otherBlocked: Long = 0L,
    val lastBlockedAtEpochMs: Long? = null,
)
