package dev.kentra.domain.repository

import dev.kentra.domain.model.Entitlement
import dev.kentra.domain.model.Plan
import dev.kentra.domain.model.ProbeOutcome
import dev.kentra.domain.model.SubscriptionSource
import dev.kentra.domain.model.TrafficSample
import dev.kentra.domain.model.TunnelState
import dev.kentra.domain.model.VpnProfile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

interface ProfileRepository {
    fun observeProfiles(): Flow<List<VpnProfile>>
    fun observeActiveProfileId(): Flow<String?>
    suspend fun getProfile(id: String): VpnProfile?
    suspend fun upsert(profile: VpnProfile)
    suspend fun upsertAll(profiles: List<VpnProfile>)
    suspend fun delete(id: String)
    suspend fun setActiveProfileId(id: String?)
    suspend fun getAllIdentities(): List<String>
}

/** Parses user-pasted keys. Implemented in :vpn:link, pure Kotlin, heavily unit tested. */
interface LinkParser {
    fun parse(uri: String): VpnProfile?
    fun export(profile: VpnProfile): String = requireNotNull(profile.rawLink)

    /** Accepts a newline list, a base64 blob, or a single link. Returns everything it could read. */
    fun parseMany(payload: String): List<VpnProfile>

    fun inspect(payload: String): dev.kentra.domain.model.ImportReport =
        dev.kentra.domain.model.ImportReport(profiles = parseMany(payload))
}

interface SubscriptionRepository {
    fun observeSources(): Flow<List<SubscriptionSource>>
    suspend fun add(name: String, url: String): Result<SubscriptionSource>
    suspend fun refresh(sourceId: String): Result<Int>
    suspend fun refreshAll(): Result<Int>
    suspend fun remove(sourceId: String)
}

interface BillingRepository {
    suspend fun plans(): Result<List<Plan>>
    fun observeEntitlement(): Flow<Entitlement?>
    /** Returns the URL of the external checkout: in-app purchases are deliberately not used. */
    suspend fun createCheckout(planId: String): Result<String>
    suspend fun activateCode(code: String): Result<Entitlement>
    suspend fun syncEntitlement(): Result<Entitlement?>
}

/** Port to the VPN process. The UI talks to the tunnel ONLY through this. */
interface TunnelController {
    val state: StateFlow<TunnelState>
    val traffic: Flow<TrafficSample>
    suspend fun connect(profile: VpnProfile)
    suspend fun disconnect()
}

/**
 * Measures how far away a key's endpoint is.
 *
 * Deliberately one profile per call rather than a list: the caller decides how many to
 * run at once, so the concurrency limit lives with the policy instead of inside the
 * implementation. It also keeps the port honest for a future implementation that has to
 * serialise (anything sharing one socket would).
 *
 * This measures REACHABILITY AND ROUND TRIP, not throughput and not "does the proxy
 * work". A server can answer a TCP connect and still refuse to carry a byte - which is
 * exactly why the search does not stop here.
 *
 * What can be measured depends on the key's wire, which is [TransportCompat.wireKind]'s
 * answer and not this port's: a TCP listener is measured with a connect, a QUIC listener
 * with a version-negotiation round trip, and an endpoint whose handshake no prober can
 * cheaply reproduce is reported as [ProbeOutcome.NotMeasurable]. That last answer is not a
 * failure - it is the prober declining to invent a number, and the caller must keep such a
 * key a candidate.
 */
interface LatencyProber {
    suspend fun measure(profile: VpnProfile, timeoutMillis: Long): ProbeOutcome
}

/**
 * Rejects a key that the core which would carry it cannot build.
 *
 * Implemented by the config layer, because only it knows both cores' rules. The search
 * uses it to avoid spending a probe - and, worse, a 15-second verification slot - on a
 * key that was never going to connect.
 */
interface ProfileValidator {
    fun validate(profile: VpnProfile)
}
