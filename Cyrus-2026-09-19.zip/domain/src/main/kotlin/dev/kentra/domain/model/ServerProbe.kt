package dev.kentra.domain.model

/**
 * What a measurement of one key's endpoint actually established.
 *
 * The three cases are deliberately NOT collapsed into a number. A key whose wire nobody can
 * measure has no round trip to report, and inventing one - or reporting the timeout as
 * "slow" - would rank it against keys that were genuinely measured. Keeping the distinction
 * is what makes the ranking honest rather than merely plausible.
 */
sealed interface ProbeOutcome {

    /**
     * One round trip to the endpoint completed in [rttMillis].
     *
     * What the round trip consists of depends on the wire: a TCP handshake for a TCP
     * listener, a QUIC version-negotiation exchange for a QUIC listener. Both are one round
     * trip to the same endpoint over the same path, which is why the numbers may be compared
     * across protocols at all.
     */
    data class Reachable(val rttMillis: Long) : ProbeOutcome

    /**
     * Nothing could be measured on this endpoint: WireGuard's Noise initiation, mKCP's
     * session setup, or a QUIC connection whose every byte is obfuscated before the QUIC
     * layer sees it. Nothing is claimed about such a key - not that it is alive, and not that
     * it is dead.
     *
     * Measuring one with a probe that does not apply would be worse than not measuring at
     * all: on a host that happens to run some other service on that port a TCP connect would
     * succeed, and the key would be ranked on a number that describes a listener its proxy
     * never uses.
     *
     * Such keys stay candidates - they are simply ordered after the measured ones, because
     * there is evidence for those and none for these.
     */
    data object NotMeasurable : ProbeOutcome

    /** The endpoint refused, or its address could not be resolved. */
    data class Unreachable(val reason: String) : ProbeOutcome
}

/** One key and what measuring it established. */
data class ProbeResult(val profile: VpnProfile, val outcome: ProbeOutcome)

/**
 * Where the candidates were lost, stage by stage.
 *
 * Reported to the user instead of being hidden: "лучший из 57" and "лучший из 3" are
 * different claims, and the difference is usually the interesting part. A search that
 * silently discards 54 keys looks identical to one that never had them.
 */
data class SelectionReport(
    val considered: Int = 0,
    /** Keys the core that would carry them cannot even build - not worth a probe. */
    val rejectedByValidation: Int = 0,
    val reachable: Int = 0,
    val notMeasurable: Int = 0,
    val unreachable: Int = 0,
    /** Candidates actually dialled end-to-end. */
    val verified: Int = 0,
    val failedVerification: Int = 0,
)

sealed interface BestServerResult {

    /**
     * [rttMillis] is null when the winner was never measured: the connection is proven by the
     * verification stage, the round trip is simply unknown.
     */
    data class Found(
        val profile: VpnProfile,
        val rttMillis: Long?,
        val report: SelectionReport,
    ) : BestServerResult

    /** Every candidate failed; [report] says where they were lost. */
    data class NotFound(val report: SelectionReport) : BestServerResult

    /** Nothing to search: no keys, or none of them routable. */
    data class NoCandidates(val report: SelectionReport) : BestServerResult
}

/** Progress of a running search. Emitted so a 30-second wait is not a frozen screen. */
sealed interface SelectionStep {
    data class Measuring(val done: Int, val total: Int) : SelectionStep
    data class Verifying(val name: String, val index: Int, val total: Int) : SelectionStep
    data class Finished(val result: BestServerResult) : SelectionStep
}
