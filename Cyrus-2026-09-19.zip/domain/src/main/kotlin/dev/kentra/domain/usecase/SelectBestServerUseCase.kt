package dev.kentra.domain.usecase

import dev.kentra.domain.model.BestServerResult
import dev.kentra.domain.model.ProbeOutcome
import dev.kentra.domain.model.ProbeResult
import dev.kentra.domain.model.SelectionReport
import dev.kentra.domain.model.SelectionStep
import dev.kentra.domain.model.TunnelState
import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.repository.LatencyProber
import dev.kentra.domain.repository.ProfileRepository
import dev.kentra.domain.repository.ProfileValidator
import dev.kentra.domain.repository.TunnelController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.channels.ProducerScope
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.atomic.AtomicInteger

/**
 * Picks the key most likely to actually carry traffic, and leaves it connected.
 *
 * The search runs in three stages, each of which removes candidates for a *different*
 * reason, and the reasons are not interchangeable:
 *
 * 1. **Validation.** A key the core which would carry it cannot build is dropped before
 *    any network work. Probing it would spend a slot to learn something already known.
 * 2. **Measurement.** One round trip to `server:port`, all candidates at once, short
 *    timeout. What that round trip is depends on the key's wire
 *    ([dev.kentra.domain.model.TransportCompat.wireKind]): a TCP connect for a TCP listener,
 *    a QUIC version-negotiation exchange for a QUIC listener. Both are one round trip to the
 *    same endpoint, so the numbers are comparable across protocols - which is the point, and
 *    the reason hysteria2 and tuic keys are no longer pushed to the back of the queue by
 *    default. Endpoints whose handshake no prober can cheaply reproduce (WireGuard, mKCP,
 *    obfuscated QUIC) yield no number at all. Either way this is real evidence of
 *    reachability and distance - and nothing more. A server can answer and still refuse to
 *    carry a byte.
 * 3. **Verification.** The top candidates are dialled for real: the core is asked to
 *    bring the tunnel up, and the candidate must survive the whole probation window
 *    without the core reporting a failure. This is the only stage that tests the proxy
 *    rather than the socket - and it is only as good as what the core is able to report,
 *    which depends on the topology (see the honest limit below).
 *
 * Why the probation window matters: the runner publishes `Connected` *before* the core
 * has finished proving itself, and a hostname-addressed outbound whose bootstrap fails
 * surfaces that failure about 6 s after start - after the 2.5 s grace window has already
 * closed with zero dial failures (measured, DEVICE_TEST_0.5.0.md §7.7). Stopping at
 * `Connected` would therefore rank a dead tunnel above a working one whenever the dead
 * one was nearer. Waiting out the probation is what makes "best" mean "works", not
 * "answered fastest".
 *
 * Honest limit: `Connected` surviving probation proves the core came up, dialled and was
 * not invalidated. It does NOT prove a byte crossed - the app's own sockets are excluded
 * from the TUN ([dev.kentra.vpn.config.ConfigFactory] selfPackage), so the app cannot
 * fetch anything through its own tunnel to check. A proxy that accepts the connection and
 * then carries nothing (a revoked key, a server that answers TCP and drops the payload)
 * therefore still passes: with no traffic, the core's failure counter is trivially zero,
 * and a quiet tunnel and a healthy one look alike. This is the strongest signal the app
 * has without a second network path, and it is stated here rather than implied.
 *
 * What the window does watch, it watches in full. The counter is topology-aware
 * ([dev.kentra.vpn.service.CoreHealth]): a session whose outbound is the loopback hop into
 * the Xray helper cannot report a failed dial at all, so there the core's DNS collapse is
 * the signal - which is the difference between passing and rejecting a session that
 * resolved nothing for four minutes (device log, 2026-09-20 13:46:44).
 *
 * Side effect, deliberately: a search disconnects whatever was up. Candidates cannot be
 * dialled while the tunnel is held, and a user pressing "Авто" while connected is asking
 * to be moved off their current server, not to be told to disconnect first. Every dial is
 * preceded by [settle], which waits for the previous teardown to land - see there for why
 * that wait is not optional.
 */
class SelectBestServerUseCase(
    private val profiles: ProfileRepository,
    private val prober: LatencyProber,
    private val validator: ProfileValidator,
    private val tunnel: TunnelController,
    /**
     * Injectable so tests can exercise the "connected, then invalidated" path without
     * waiting the real window out. Production always uses [PROBATION_MS].
     */
    private val probationMs: Long = PROBATION_MS,
) {

    /** Serialised: two concurrent searches would fight over the single TUN. */
    private val mutex = Mutex()

    operator fun invoke(): Flow<SelectionStep> = channelFlow {
        mutex.withLock {
            search()
        }
    }

    private suspend fun ProducerScope<SelectionStep>.search() {
        val all = profiles.observeProfiles().first()
        if (all.isEmpty()) {
            send(SelectionStep.Finished(BestServerResult.NoCandidates(SelectionReport())))
            return
        }

        val candidates = all.filter { runCatching { validator.validate(it) }.isSuccess }
        var report = SelectionReport(
            considered = all.size,
            rejectedByValidation = all.size - candidates.size,
        )
        if (candidates.isEmpty()) {
            send(SelectionStep.Finished(BestServerResult.NoCandidates(report)))
            return
        }

        val measured = measure(candidates)
        val reachable = measured
            .filter { it.outcome is ProbeOutcome.Reachable }
            .sortedBy { (it.outcome as ProbeOutcome.Reachable).rttMillis }
        val unmeasurable = measured.filter { it.outcome is ProbeOutcome.NotMeasurable }
        report = report.copy(
            reachable = reachable.size,
            notMeasurable = unmeasurable.size,
            unreachable = measured.size - reachable.size - unmeasurable.size,
        )

        // Endpoints that refused the probe are not dialled: for a TCP transport that same
        // connect is a precondition for the proxy to work at all, so spending a verification
        // slot on one buys a slow "no". Keys nothing could be measured on are a different
        // case - nothing was measured, so nothing is concluded, and they are tried.
        //
        // Ordering is evidence first: a key with a measured round trip outranks one without,
        // whatever protocol either speaks. That is the ranking, and it is the reason a
        // hysteria2 key can now win: it is measured like any other, instead of being
        // appended to the end of the list as unmeasurable.
        val shortlist = (reachable + unmeasurable).take(SHORTLIST)
        if (shortlist.isEmpty()) {
            send(SelectionStep.Finished(BestServerResult.NotFound(report)))
            return
        }

        for ((index, candidate) in shortlist.withIndex()) {
            send(SelectionStep.Verifying(candidate.profile.name, index + 1, shortlist.size))
            report = report.copy(verified = report.verified + 1)
            if (verify(candidate.profile)) {
                profiles.setActiveProfileId(candidate.profile.id)
                val rtt = (candidate.outcome as? ProbeOutcome.Reachable)?.rttMillis
                send(SelectionStep.Finished(BestServerResult.Found(candidate.profile, rtt, report)))
                return
            }
            report = report.copy(failedVerification = report.failedVerification + 1)
            settle()
        }
        send(SelectionStep.Finished(BestServerResult.NotFound(report)))
    }

    /**
     * Measures every candidate at once, with a ceiling on how many sockets are open.
     *
     * Progress is sent as each one lands rather than at the end: the whole search can take
     * half a minute and a screen that says nothing for that long is indistinguishable from
     * a hung one.
     */
    private suspend fun ProducerScope<SelectionStep>.measure(
        candidates: List<VpnProfile>,
    ): List<ProbeResult> {
        val permits = Semaphore(MAX_CONCURRENT_PROBES)
        val done = AtomicInteger(0)
        return coroutineScope {
            candidates.map { profile ->
                async(Dispatchers.IO) {
                    val outcome = runCatching {
                        permits.withPermit { prober.measure(profile, PROBE_TIMEOUT_MS) }
                    }.getOrElse {
                        // A prober that throws is a prober that failed to measure, which is
                        // not the same as a server that refused. Say so instead of guessing.
                        ProbeOutcome.Unreachable(it.message ?: it::class.java.simpleName)
                    }
                    send(SelectionStep.Measuring(done.incrementAndGet(), candidates.size))
                    ProbeResult(profile, outcome)
                }
            }.awaitAll()
        }
    }

    /**
     * Brings the tunnel to a state [TunnelController.connect] will accept, and waits for it.
     *
     * This exists because `disconnect()` and `connect()` are not symmetric. `disconnect()`
     * publishes `Stopping` and returns; the service tears the tunnel down afterwards.
     * `connect()` does not wait for that - it *refuses* while the state is `Preparing` or
     * `Stopping`, and throws ([dev.kentra.vpn.service.TunnelControllerImpl], "Дождитесь
     * завершения предыдущего подключения"). Calling the two back to back therefore fails
     * for a reason that has nothing to do with the candidate being tested.
     *
     * That failure is not evenly distributed, which is what makes it dangerous: the
     * shortlist is ordered best-first, so it lands on the best candidate first, and after a
     * failed candidate it lands on the next one. Left alone, the search would quietly settle
     * for a worse server, or report that nothing works having just torn down a tunnel that
     * did. It is also the ordering that produces two TUNs on one address, because the new
     * interface is established while the old descriptor is still open.
     *
     * Returns false if the tunnel never settles; the caller treats that as a candidate that
     * could not be verified, which is what it is.
     */
    private suspend fun settle(): Boolean {
        if (tunnel.state.value.isActive) runCatching { tunnel.disconnect() }
        return withTimeoutOrNull(TEARDOWN_TIMEOUT_MS) {
            tunnel.state.first { it is TunnelState.Idle || it is TunnelState.Failed }
        } != null
    }

    /**
     * Brings [profile] up and waits out the probation window. True only if it is still up
     * when the window closes.
     */
    private suspend fun verify(profile: VpnProfile): Boolean {
        if (!settle()) return false
        if (runCatching { tunnel.connect(profile) }.isFailure) return false

        // `Connected` carries the id it belongs to, so a late state from a superseded
        // candidate cannot be mistaken for this one coming up.
        val reached = withTimeoutOrNull(CONNECT_TIMEOUT_MS) {
            tunnel.state.first {
                (it is TunnelState.Connected && it.profileId == profile.id) || it is TunnelState.Failed
            }
        }
        if (reached !is TunnelState.Connected) return false

        // Null here means the window closed with the tunnel still up, which is the pass.
        val dropped = withTimeoutOrNull(probationMs) {
            tunnel.state.first { it is TunnelState.Failed || it is TunnelState.Idle }
        }
        return dropped == null
    }

    companion object {
        /**
         * A bare TCP connect either lands quickly or the endpoint is not usable from here.
         * Long enough for a slow mobile link, short enough that 57 of them stay bearable.
         */
        const val PROBE_TIMEOUT_MS = 2_000L

        /** Open sockets at once. Enough to be quick, few enough not to look like a scan. */
        const val MAX_CONCURRENT_PROBES = 8

        /** Candidates dialled end-to-end. Each one can cost [CONNECT_TIMEOUT_MS] + [PROBATION_MS]. */
        const val SHORTLIST = 3

        const val CONNECT_TIMEOUT_MS = 20_000L

        /**
         * How long to wait for a disconnect to actually land. Generous, because the cost of
         * waiting is a few seconds once per candidate while the cost of not waiting is
         * losing the candidate altogether - and, on this codebase, of leaving two TUNs on
         * one address behind.
         */
        const val TEARDOWN_TIMEOUT_MS = 15_000L

        /**
         * Must cover `TunnelServiceRunner.CORE_PROBATION_MS` (12 s) - that is the window the
         * runner itself watches before it decides a connected core is a dead one. If the
         * runner's window grows and this does not, verification starts passing tunnels the
         * runner is about to tear down.
         */
        const val PROBATION_MS = 12_000L
    }
}
