package dev.kentra.domain.model

/** Which native core is able to carry a given transport. */
enum class VpnEngineKind { SING_BOX, XRAY }

/**
 * What a prober can honestly learn about a key's endpoint before the tunnel is dialled.
 *
 * Deliberately a different question from "which core carries this key" ([VpnEngineKind]).
 * A key can need Xray and still be measurable; a key sing-box carries natively can still be
 * unmeasurable. This enum answers one thing only, and it exists because the search ranks
 * candidates by a measurement: a candidate whose wire nobody can measure cannot be compared
 * with one whose wire somebody can, and pretending otherwise is how a ranking stops meaning
 * anything.
 */
enum class WireKind {
    /** A TCP listener. A bare connect is a real round trip and a real answer. */
    TCP,

    /**
     * A QUIC listener. QUIC has no TCP handshake to time, but a QUIC server that receives a
     * packet carrying a version it does not support answers with a Version Negotiation
     * packet (RFC 9000 §6) - a real round trip to the same endpoint on the same port, which
     * is what makes hysteria2 and tuic comparable with everything else.
     */
    QUIC,

    /**
     * UDP with no handshake a prober can cheaply reproduce: WireGuard's Noise initiation,
     * mKCP's session setup, or a QUIC connection whose every byte is obfuscated before it
     * reaches the QUIC layer. Nothing is claimed about these endpoints - not that they are
     * alive, and not that they are dead.
     */
    OPAQUE_UDP,
}

/**
 * The single source of truth for transport naming.
 *
 * Panels hand out the same wire transport under several names: Xray renamed
 * "tcp" to "raw" in 1.8.16, "splithttp" became "xhttp", HTTP/2 appears as "h2"
 * or "h2c", and gRPC is still written as "gun" by older generators. A raw value
 * taken from a key must therefore never be compared against core capabilities
 * directly - it has to be canonicalised first, otherwise a perfectly supported
 * key is rejected only because of its spelling.
 *
 * Canonical names are the ones the sing-box JSON schema uses.
 */
object TransportCompat {

    /** Implemented by the pinned sing-box core. */
    val SING_BOX: Set<String> = setOf("tcp", "ws", "grpc", "http", "httpupgrade")

    /**
     * Real transports that only Xray-core implements. Renaming cannot emulate
     * them: a sing-box outbound built from such a key would connect and then
     * stall, which is worse for the user than an explicit refusal.
     */
    val XRAY_ONLY: Set<String> = setOf("xhttp", "kcp", "quic")

    /** Canonical transports offered in the key editor, in order. */
    val EDITOR_CHOICES: List<String> = listOf("tcp", "ws", "grpc", "http", "httpupgrade")

    /** Protocols whose proxy itself speaks QUIC on the wire. */
    val QUIC_PROTOCOLS: Set<VpnProtocol> = setOf(VpnProtocol.HYSTERIA2, VpnProtocol.TUIC)

    /** UDP-only protocols whose handshake a prober cannot reproduce cheaply. */
    val OPAQUE_UDP_PROTOCOLS: Set<VpnProtocol> = setOf(VpnProtocol.WIREGUARD, VpnProtocol.AMNEZIA_WG)

    /** The only obfuscation this app's config layer accepts on hysteria2. */
    private const val SALAMANDER = "salamander"

    private val ALIASES: Map<String, String> = mapOf(
        // Xray 1.8.16+ calls plain TCP "raw"; some generators write nothing at all.
        "" to "tcp", "tcp" to "tcp", "raw" to "tcp", "none" to "tcp", "original" to "tcp",
        "ws" to "ws", "websocket" to "ws",
        "grpc" to "grpc", "gun" to "grpc",
        "http" to "http", "h2" to "http", "h2c" to "http", "http2" to "http",
        "httpupgrade" to "httpupgrade", "upgrade" to "httpupgrade",
        // Known-but-unsupported: canonicalised so the diagnostic can name them.
        "xhttp" to "xhttp", "splithttp" to "xhttp", "xhttps" to "xhttp",
        "kcp" to "kcp", "mkcp" to "kcp",
        "quic" to "quic",
    )

    /**
     * Canonical transport name. Unknown values are returned squashed and
     * lowercased so they can be shown back to the user without echoing markup.
     */
    fun normalize(type: String?): String {
        val cleaned = type?.trim()?.lowercase().orEmpty()
        ALIASES[cleaned]?.let { return it }
        val squashed = cleaned.filter { it.isLetterOrDigit() }
        return ALIASES[squashed] ?: squashed.ifEmpty { "tcp" }
    }

    fun isSingBox(type: String?): Boolean = normalize(type) in SING_BOX
    fun isXrayOnly(type: String?): Boolean = normalize(type) in XRAY_ONLY
    fun isKnown(type: String?): Boolean = isSingBox(type) || isXrayOnly(type)

    /** gRPC multiMode is an Xray feature even though ordinary gRPC is sing-box-native. */
    fun requiresXray(profile: VpnProfile): Boolean {
        val type = normalize(profile.transport.type)
        return isXrayOnly(type) || (type == "grpc" && profile.parameters["mode"]?.trim()?.lowercase() == "multi")
    }

    /**
     * Engine a key needs. Derived, never stored, so no database migration.
     *
     * Unrecognised transports are rejected instead of being routed to a default:
     * picking a core for a transport we cannot name would hide a parser gap
     * behind a connection that fails much later, inside a native core, with an
     * unreadable message. Callers must treat the throw as a refusal to connect.
     */
    fun requiredEngine(type: String?): VpnEngineKind = when {
        isXrayOnly(type) -> VpnEngineKind.XRAY
        isSingBox(type) -> VpnEngineKind.SING_BOX
        else -> throw IllegalArgumentException(
            "Unknown transport «${normalize(type)}»: refusing to pick a core for it.",
        )
    }

    fun requiredEngine(profile: VpnProfile): VpnEngineKind = when {
        requiresXray(profile) -> VpnEngineKind.XRAY
        isSingBox(profile.transport.type) -> VpnEngineKind.SING_BOX
        else -> throw IllegalArgumentException(
            "Unknown transport «${normalize(profile.transport.type)}»: refusing to pick a core for it.",
        )
    }

    /**
     * What a prober can measure on this key's endpoint, if anything.
     *
     * The transport field is consulted first and wins: a vless key carried over kcp is UDP
     * whatever its protocol says, and a vless key over the `quic` network is QUIC for the
     * same reason. Only when the transport says nothing about the wire does the protocol
     * decide.
     *
     * The one case that looks measurable and is not: hysteria2 with salamander obfuscation.
     * Salamander XORs every datagram before it reaches the QUIC layer, so a plain QUIC
     * packet is deobfuscated to noise and dropped - the version-negotiation probe would get
     * silence from a server that is working perfectly. Silence is not evidence, and a probe
     * that cannot reach the wire must not be allowed to conclude anything about it, so such
     * a key is classified opaque rather than QUIC.
     */
    fun wireKind(profile: VpnProfile): WireKind {
        when (normalize(profile.transport.type)) {
            "kcp" -> return WireKind.OPAQUE_UDP
            "quic" -> return WireKind.QUIC
        }
        if (profile.parameters["obfs"] == SALAMANDER) return WireKind.OPAQUE_UDP
        return when (profile.protocol) {
            in QUIC_PROTOCOLS -> WireKind.QUIC
            in OPAQUE_UDP_PROTOCOLS -> WireKind.OPAQUE_UDP
            else -> WireKind.TCP
        }
    }

    /**
     * Human-readable reason a transport cannot be used by the sing-box core, or
     * null when it can. Names the canonical transport and the way out; never
     * claims support that does not exist.
     */
    fun singBoxRejection(type: String?): String? {
        val canonical = normalize(type)
        return when {
            canonical in SING_BOX -> null
            canonical in XRAY_ONLY ->
                "Транспорт «$canonical» реализован только в Xray-ядре, sing-box его не умеет. " +
                    "Запросите у провайдера ключ на ws, grpc, httpupgrade или tcp/raw к тому же серверу."
            else ->
                "Неизвестный транспорт «$canonical». Поддерживаются: ${SING_BOX.joinToString(", ")} " +
                    "(синонимы raw, h2, gun, websocket распознаются автоматически)."
        }
    }
}
