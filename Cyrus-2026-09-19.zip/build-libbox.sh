#!/usr/bin/env bash
# Same pinned toolchain as Eren2932/Cyrus .github/workflows/build.yml.
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SING_BOX_REF='92d245ad040cbda2f84b21c2a847a470e532c179'
# Pinned like the sing-box ref below: the binding tool decides the generated
# Java/JNI glue, so letting it float ('latest') made the AAR unreproducible —
# the glue could change with no source diff at all.
#
# v0.1.4 is what docs/workflows/build-zip.yml used, and it no longer builds: it
# pins golang.org/x/tools@v0.16.0, which does not compile under the Go release
# this tree needs. v0.1.13 is the oldest release that does. The two generate
# byte-identical go/Seq classes, so the AAR stays compatible with libXray.aar
# in the same directory.
GOMOBILE_VERSION='v0.1.13'
NATIVE_PLATFORMS='android/arm,android/arm64,android/amd64'
for tool in go git java; do
  command -v "$tool" >/dev/null || { echo "Missing tool: $tool" >&2; exit 1; }
done
: "${ANDROID_HOME:?Set ANDROID_HOME to the Android SDK directory}"
: "${ANDROID_NDK_HOME:?Set ANDROID_NDK_HOME to NDK 27.0.12077973}"
WORK="$(mktemp -d "${TMPDIR:-/tmp}/cyrus-libbox.XXXXXXXX")"
trap 'rm -rf -- "$WORK"' EXIT
mkdir -p "$ROOT/vpn/service/libs"
# Check for libbox.aar specifically: vpn/service/libs also holds libXray.aar,
# and a sibling core must not block rebuilding sing-box.
if [ -e "$ROOT/vpn/service/libs/libbox.aar" ]; then
  echo 'vpn/service/libs/libbox.aar already exists. Back it up and remove it explicitly before rebuilding.' >&2
  exit 1
fi
git init -q "$WORK/source"
git -C "$WORK/source" remote add origin https://github.com/SagerNet/sing-box.git
git -C "$WORK/source" fetch --depth 1 origin "$SING_BOX_REF"
git -C "$WORK/source" checkout --detach FETCH_HEAD
test "$(git -C "$WORK/source" rev-parse HEAD)" = "$SING_BOX_REF"

# Cyrus carries one change against upstream: the mitm outbound. It lives as a
# patch rather than as a fork so upstream's commit stays visible in the log and
# the diff stays reviewable without cloning both repositories.
shopt -s nullglob
for patch in "$ROOT"/vpn/service/libbox/*.patch; do
  echo "applying $(basename "$patch")"
  git -C "$WORK/source" apply --verbose "$patch"
done
shopt -u nullglob
export GOBIN="$WORK/bin"
export PATH="$GOBIN:$PATH"
export GOMAXPROCS="${GOMAXPROCS:-2}"
export GOFLAGS="${GOFLAGS:--p=2}"
cd "$WORK/source"
go install "github.com/sagernet/gomobile/cmd/gomobile@$GOMOBILE_VERSION"
go install "github.com/sagernet/gomobile/cmd/gobind@$GOMOBILE_VERSION"
# v1.11.1 build_libbox does not accept -tags; it chooses its own native tags.
go run ./cmd/internal/build_libbox -target android -platform "$NATIVE_PLATFORMS"
test -s libbox.aar
cp libbox.aar "$ROOT/vpn/service/libs/libbox.aar"
echo 'Built vpn/service/libs/libbox.aar; run python3 tools/check_native.py next.'
