package dev.kentra.feature.profiles

import androidx.lifecycle.viewModelScope
import dev.kentra.core.common.AppError
import dev.kentra.core.ui.MviViewModel
import dev.kentra.domain.repository.*
import dev.kentra.domain.model.*
import dev.kentra.domain.usecase.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.withContext

class ProfilesViewModel(
    private val profiles: ProfileRepository,
    private val subscriptions: SubscriptionRepository,
    private val importKeys: ImportKeysUseCase,
    private val deleteProfile: DeleteProfileUseCase,
    private val parser: LinkParser,
    private val tunnel: TunnelController,
) : MviViewModel<ProfilesIntent, ProfilesState, ProfilesEffect>(ProfilesState()) {
    init {
        tunnel.state.onEach { reduce { copy(tunnel = it) } }.launchIn(viewModelScope)
        combine(profiles.observeProfiles(), profiles.observeActiveProfileId()) { list, active ->
            reduce { copy(profiles = list, activeProfileId = active) }
        }.catch { effect(ProfilesEffect.ShowMessage("Не удалось открыть хранилище ключей. Данные не удалены.")) }.launchIn(viewModelScope)
        subscriptions.observeSources().onEach { reduce { copy(sources = it) } }
            .catch { effect(ProfilesEffect.ShowMessage("Не удалось прочитать подписки")) }.launchIn(viewModelScope)
    }
    override suspend fun handle(intent: ProfilesIntent) {
        when (intent) {
            ProfilesIntent.OpenImport -> if (!currentState.busy) reduce { copy(importSheetVisible = true, importText = "", report = null) }
            ProfilesIntent.CloseImport -> if (!currentState.busy) reduce { copy(importSheetVisible = false, importText = "", report = null) }
            is ProfilesIntent.ImportTextChanged -> if (!currentState.busy) reduce { copy(importText = intent.text, report = null) }
            is ProfilesIntent.QueryChanged -> reduce { copy(query = intent.query) }
            is ProfilesIntent.Filter -> reduce { copy(protocol = intent.protocol) }
            is ProfilesIntent.SubscriptionMode -> if (!currentState.busy) reduce { copy(asSubscription = intent.enabled, report = null) }
            is ProfilesIntent.SaveProfile -> operation {
                val old = profiles.getProfile(intent.profile.id) ?: error("Нет профиля")
                val exported = parser.export(intent.profile)
                val parsed = parser.parse(exported) ?: error("Некорректные параметры")
                val updated = parsed.copy(id = old.id, name = intent.profile.name.trim().take(160), createdAt = old.createdAt, origin = old.origin)
                if (tunnel.state.value.isActive && (tunnel.state.value as? TunnelState.Connected)?.profileId == old.id) {
                    effect(ProfilesEffect.ShowMessage("Перед редактированием работающего ключа отключите соединение"))
                } else if (tunnel.state.value is TunnelState.Preparing || tunnel.state.value is TunnelState.Stopping) {
                    effect(ProfilesEffect.ShowMessage("Дождитесь завершения переключения"))
                } else {
                    profiles.upsert(updated)
                    effect(ProfilesEffect.ShowMessage("Параметры сохранены. Изменения ключа подписки могут быть заменены при обновлении."))
                }
            }
            ProfilesIntent.PreviewImport -> operation {
                val payload = currentState.importText
                val report = withContext(Dispatchers.Default) { parser.inspect(payload) }
                reduce { copy(report = report) }
            }
            ProfilesIntent.ConfirmImport -> operation {
                val payload = currentState.importText.trim()
                val result = if (currentState.asSubscription) {
                    check(!tunnel.state.value.isActive && tunnel.state.value !is TunnelState.Stopping)
                    subscriptions.add("", payload).map { it.profileCount }
                }
                else {
                    check(currentState.report != null)
                    importKeys(payload)
                }
                result.onSuccess { count ->
                    reduce { copy(importSheetVisible = false, importText = "", report = null) }
                    effect(ProfilesEffect.ShowMessage(if (count == 0) "Все ключи уже есть в библиотеке" else "Добавлено ключей: $count"))
                }.onFailure { effect(ProfilesEffect.ShowMessage(userMessage(it, "Импорт не выполнен"))) }
            }
            is ProfilesIntent.Select -> operation {
                val profile = profiles.getProfile(intent.profileId) ?: error("Нет профиля")
                if (tunnel.state.value is TunnelState.Preparing || tunnel.state.value is TunnelState.Stopping) {
                    effect(ProfilesEffect.ShowMessage("Дождитесь завершения подключения"))
                } else {
                    if (tunnel.state.value is TunnelState.Connected) tunnel.connect(profile)
                    profiles.setActiveProfileId(intent.profileId)
                }
            }
            is ProfilesIntent.Rename -> operation {
                val name = intent.name.trim().take(160)
                if (name.isNotEmpty()) profiles.getProfile(intent.id)?.let { profiles.upsert(it.copy(name = name)) }
            }
            is ProfilesIntent.Delete -> operation {
                deleteProfile(intent.profile).onFailure { effect(ProfilesEffect.ShowMessage("Не удалось удалить ключ")) }
            }
            is ProfilesIntent.RemoveSource -> operation {
                val connectedId = (tunnel.state.value as? TunnelState.Connected)?.profileId
                val affected = currentState.profiles.any { it.id == connectedId && (it.origin as? ProfileOrigin.Subscription)?.sourceId == intent.id }
                if (affected || tunnel.state.value is TunnelState.Preparing) tunnel.disconnect()
                subscriptions.remove(intent.id)
            }
            is ProfilesIntent.RefreshSource -> operation {
                if (tunnel.state.value.isActive || tunnel.state.value is TunnelState.Stopping)
                    effect(ProfilesEffect.ShowMessage("Перед обновлением подписки отключитесь: набор серверов может измениться"))
                else showRefresh(subscriptions.refresh(intent.id))
            }
            ProfilesIntent.RefreshSubscriptions -> operation {
                if (tunnel.state.value.isActive || tunnel.state.value is TunnelState.Stopping)
                    effect(ProfilesEffect.ShowMessage("Перед обновлением подписок отключитесь"))
                else showRefresh(subscriptions.refreshAll())
            }
        }
    }
    private fun showRefresh(result: Result<Int>) {
        result.onSuccess { effect(ProfilesEffect.ShowMessage("Обновлено ключей: $it")) }
            .onFailure { effect(ProfilesEffect.ShowMessage(userMessage(it, "Ошибка обновления"))) }
    }

    /** Keep implementation details such as `network:` and exception class names out of UI. */
    private fun userMessage(error: Throwable, fallback: String): String = when (val e = error) {
        is AppError.Network -> e.reason ?: fallback
        is AppError.Parse -> e.reason ?: fallback
        is AppError.Tunnel -> e.reason ?: fallback
        is AppError.Permission -> "Требуется разрешение: ${e.what}"
        is AppError.NotFound -> "Не найдено: ${e.what}"
        else -> fallback
    }

    /**
     * Runs one exclusive operation.
     *
     * The old `if (currentState.busy) return` was a check-then-act: intents are handled
     * concurrently (every dispatch launches its own coroutine), so two operations that
     * arrive together both read `busy == false` and both proceed. The mutex makes the
     * claim itself atomic, and the loser is told instead of being dropped silently.
     */
    private val operationLock = kotlinx.coroutines.sync.Mutex()

    private suspend fun operation(block: suspend () -> Unit) {
        if (!operationLock.tryLock()) {
            effect(ProfilesEffect.ShowMessage("Дождитесь завершения уже выполняемой операции"))
            return
        }
        try {
            reduce { copy(busy = true) }
            try { block() }
            catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                effect(ProfilesEffect.ShowMessage("Операция не выполнена. Проверьте данные и доступ к хранилищу."))
            } finally { reduce { copy(busy = false) } }
        } finally {
            operationLock.unlock()
        }
    }
}
