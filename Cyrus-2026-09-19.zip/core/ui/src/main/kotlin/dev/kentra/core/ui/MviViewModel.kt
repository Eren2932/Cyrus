package dev.kentra.core.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dev.kentra.core.mvi.MviEffect
import dev.kentra.core.mvi.MviIntent
import dev.kentra.core.mvi.MviMachine
import dev.kentra.core.mvi.MviState
import dev.kentra.core.mvi.Store
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

/**
 * Android host for [MviMachine]. Features extend this and implement [handle] only.
 * No Compose type may ever appear in a subclass of this class.
 */
abstract class MviViewModel<I : MviIntent, S : MviState, E : MviEffect>(
    initialState: S,
) : ViewModel(), Store<I, S, E> {

    private val machine = MviMachine<I, S, E>(
        initialState,
        viewModelScope,
        onError = { onHandlerError(it) },
    ) { intent -> handle(intent) }

    /**
     * Called when [handle] throws for one intent.
     *
     * The default keeps the failure inside that intent instead of letting it reach
     * `viewModelScope`, whose cancellation would take down every other in-flight intent
     * and every collection started in `init` — a screen that silently stops responding.
     * Only the class name is logged: an exception from a key or subscription operation
     * can carry the credential in its message, and logcat is world-readable.
     */
    protected open fun onHandlerError(t: Throwable) {
        // Fatal VM errors must not be contained; the app cannot continue after them.
        if (t is java.lang.Error) throw t
        android.util.Log.e("MviViewModel", "intent failed: ${t::class.java.simpleName}")
    }

    override val state: StateFlow<S> = machine.state
    override val effects: Flow<E> = machine.effects

    protected val currentState: S get() = machine.current

    override fun dispatch(intent: I) = machine.dispatch(intent)

    protected fun reduce(reducer: S.() -> S) = machine.reduce(reducer)

    protected fun effect(effect: E) = machine.effect(effect)

    protected abstract suspend fun handle(intent: I)
}
