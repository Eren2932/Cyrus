package dev.kentra.core.ui

import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * The traffic counters are user-facing and come from a native core through a JNI
 * boundary. A negative or wrapped long must never be rendered as if it were a
 * measurement - the UI would show the user a number that cannot be true.
 */
class FormatBytesTest {

    @Test
    fun `zero and small values stay in bytes`() {
        assertEquals("0 B", 0L.formatBytes())
        assertEquals("512 B", 512L.formatBytes())
        assertEquals("1023 B", 1023L.formatBytes())
    }

    @Test
    fun `units scale at 1024`() {
        assertEquals("1.0 KB", 1024L.formatBytes())
        assertEquals("1.0 MB", (1024L * 1024).formatBytes())
        assertEquals("1.0 GB", (1024L * 1024 * 1024).formatBytes())
    }

    @Test
    fun `a negative counter is clamped instead of printed as negative`() {
        // A byte count is unsigned in practice; -1 means "unset" or a wrapped long.
        assertEquals("0 B", (-1L).formatBytes())
        assertEquals("0 B", (Long.MIN_VALUE).formatBytes())
    }

    @Test
    fun `speed formatting reuses the byte formatting`() {
        assertEquals("1.0 KB/s", 1024L.formatSpeed())
    }
}
