package dev.kentra.core.common

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * H-9 regression: `writeLog` is the one place free-form native text reaches a log sink,
 * and on a config error sing-box echoes the outbound inline. Anything a user could
 * paste back into a client must not survive [redactSecrets].
 */
class RedactSecretsTest {

    private val uuid = "4c7a0b95-1dcb-4044-b948-69e1b4881733"
    private val password = "hunter2-not-real"

    @Test
    fun uuidIsRedacted() {
        assertTrue("uuid present before", uuid in "user id $uuid")
        assertFalse("uuid leaked", uuid in "user id $uuid".redactSecrets())
    }

    @Test
    fun shareLinkIsRedactedWhole() {
        val line = "dial failed: vless://$uuid:$password@db.example.com:443?type=ws#tag"
        val out = line.redactSecrets()
        assertFalse("uuid leaked: $out", uuid in out)
        assertFalse("password leaked: $out", password in out)
        assertFalse("host leaked: $out", "db.example.com" in out)
    }

    @Test
    fun queryParametersAreRedacted() {
        val out = "outbound { password=$password pbk=9ngNG5S7MWDT7blqRQZix2-Ze24yRxj8 host=db.example.com }".redactSecrets()
        assertFalse("password leaked: $out", password in out)
        assertFalse("reality pbk leaked: $out", "9ngNG5S7MWDT7blqRQZix2-Ze24yRxj8" in out)
        // The host is not a credential, and it is what a failed dial needs to name.
        assertTrue("host needed for diagnosis: $out", "db.example.com" in out)
    }

    @Test
    fun wireguardIniPrivateKeyIsRedacted() {
        val key = "sJPzZtUlYtG7AeIWuBUbCnEjrXvPRQjLPfKpBcJpQXY="
        val out = "config:\n[Interface]\nPrivateKey = $key\n".redactSecrets()
        assertFalse("private key leaked: $out", key in out)
        assertTrue("key name needed for diagnosis: $out", "PrivateKey" in out)
    }

    @Test
    fun ordinaryLogLinesSurviveRedaction() {
        // Over-redacting makes the log useless; a plain message must stay readable.
        val line = "sing-box started in 312 ms"
        assertEqualsIgnoringCase(line, line.redactSecrets())
    }

    private fun assertEqualsIgnoringCase(expected: String, actual: String) {
        assertTrue("expected <$expected> but was <$actual>", expected.equals(actual, ignoreCase = true))
    }
}
