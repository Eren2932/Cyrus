package dev.kentra.core.common

import java.math.BigInteger
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.ECGenParameterSpec
import java.util.Calendar
import java.util.Date
import java.util.TimeZone
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The encoder is hand-written DER, so the tests do the thing a library would
 * otherwise guarantee: hand the bytes to a real X.509 parser and let it judge.
 * A certificate that only our own code accepts is worthless.
 */
class X509CertificatesTest {

    private fun ecKeyPair(): KeyPair =
        KeyPairGenerator.getInstance("EC").apply { initialize(ECGenParameterSpec("secp256r1")) }.genKeyPair()

    private fun rsaKeyPair(): KeyPair =
        KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.genKeyPair()

    private fun parse(encoded: ByteArray): X509Certificate =
        CertificateFactory.getInstance("X.509").generateCertificate(encoded.inputStream()) as X509Certificate

    private fun date(year: Int, month: Int, day: Int): Date =
        Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
            clear()
            set(year, month - 1, day, 0, 0, 0)
        }.time

    private fun build(keyPair: KeyPair = ecKeyPair(), serial: BigInteger = BigInteger("1234567890")): ByteArray =
        X509Certificates.selfSignedCa(keyPair, "CN=Cyrus Protection CA, O=Cyrus", date(2026, 1, 1), date(2036, 1, 1), serial)

    @Test
    fun `a real X509 parser accepts the certificate`() {
        val certificate = parse(build())
        assertEquals("X.509", certificate.type)
        assertEquals(3, certificate.version)
    }

    @Test
    fun `signature verifies against the CA public key`() {
        val keyPair = ecKeyPair()
        val certificate = parse(build(keyPair))
        certificate.verify(keyPair.public)
    }

    @Test
    fun `signature rejects a different key`() {
        val certificate = parse(build(ecKeyPair()))
        assertThrows(Exception::class.java) { certificate.verify(ecKeyPair().public) }
    }

    @Test
    fun `it is a CA certificate limited to signing certificates`() {
        val certificate = parse(build())
        assertTrue("basicConstraints must mark a CA", certificate.basicConstraints == Int.MAX_VALUE)
        val usage = certificate.keyUsage
        assertTrue("keyCertSign", usage[5])
        assertTrue("cRLSign", usage[6])
        assertTrue("digitalSignature", usage[0])
        assertEquals("no other usages", 3, usage.count { it })
    }

    @Test
    fun `subject equals issuer and carries the requested name`() {
        val certificate = parse(build())
        assertEquals(certificate.subjectX500Principal, certificate.issuerX500Principal)
        // RFC 2253 prints the RDN sequence in reverse, so the expected string is
        // not the one that went in.
        assertEquals("O=Cyrus,CN=Cyrus Protection CA", certificate.subjectX500Principal.name)
    }

    @Test
    fun `serial and validity window are taken from the request`() {
        val certificate = parse(build(serial = BigInteger("1234567890")))
        assertEquals(BigInteger("1234567890"), certificate.serialNumber)
        assertEquals(date(2026, 1, 1).time / 1000, certificate.notBefore.time / 1000)
        assertEquals(date(2036, 1, 1).time / 1000, certificate.notAfter.time / 1000)
    }

    @Test
    fun `rsa keys produce a certificate that verifies`() {
        val keyPair = rsaKeyPair()
        val certificate = parse(build(keyPair))
        certificate.verify(keyPair.public)
        // An RSA-2048 certificate is larger than 127 bytes per field, so this also
        // covers the two-byte DER length form.
        assertTrue(certificate.encoded.size > 300)
    }

    @Test
    fun `dates past 2049 switch to GeneralizedTime and still parse`() {
        val keyPair = ecKeyPair()
        val encoded = X509Certificates.selfSignedCa(keyPair, "CN=Cyrus Protection CA", date(2049, 12, 1), date(2061, 1, 1))
        val certificate = parse(encoded)
        certificate.verify(keyPair.public)
        assertEquals(date(2061, 1, 1).time / 1000, certificate.notAfter.time / 1000)
    }

    @Test
    fun `leaf is signed by the CA and names the host in SAN`() {
        val ca = ecKeyPair()
        val caCertificate = parse(build(ca))
        val leafKey = ecKeyPair()
        val leaf = parse(
            X509Certificates.leaf(
                publicKey = leafKey.public,
                caPrivateKey = ca.private,
                caCertificate = caCertificate,
                host = "ads.example.com",
                notBefore = date(2026, 1, 1),
                notAfter = date(2027, 1, 1),
                serial = BigInteger("4242"),
            ),
        )
        leaf.verify(ca.public)
        assertEquals(caCertificate.subjectX500Principal, leaf.issuerX500Principal)
        // A chain is matched on the issuer's bytes, not on how the name reads.
        // X500Principal.name prints RDNs in the opposite order to the DER it was
        // parsed from, so an issuer rebuilt from that string matches nothing.
        assertTrue(
            "issuer must be byte-identical to the CA subject",
            leaf.issuerX500Principal.encoded.contentEquals(caCertificate.subjectX500Principal.encoded),
        )
        // Clients ignore CN; SAN is what actually names the host.
        assertEquals(listOf(listOf(2, "ads.example.com")), leaf.subjectAlternativeNames.map { it.toList() })
        assertEquals("CN=ads.example.com", leaf.subjectX500Principal.name)
    }

    @Test
    fun `leaf is a server certificate and signs nothing`() {
        val ca = ecKeyPair()
        val caCertificate = parse(build(ca))
        val leaf = parse(
            X509Certificates.leaf(
                publicKey = ecKeyPair().public,
                caPrivateKey = ca.private,
                caCertificate = caCertificate,
                host = "tracker.example.net",
                notBefore = date(2026, 1, 1),
                notAfter = date(2027, 1, 1),
            ),
        )
        assertEquals("a leaf must not be a CA", -1, leaf.basicConstraints)
        val usage = leaf.keyUsage
        assertTrue("digitalSignature", usage[0])
        assertTrue("keyEncipherment", usage[3])
        assertEquals("no other usages", 2, usage.count { it })
        assertEquals(listOf("1.3.6.1.5.5.7.3.1"), leaf.extendedKeyUsage.toList())
    }

    @Test
    fun `leaf signed by another CA does not verify`() {
        val certificate = parse(
            X509Certificates.leaf(
                publicKey = ecKeyPair().public,
                caPrivateKey = ecKeyPair().private,
                caCertificate = parse(build()),
                host = "example.com",
                notBefore = date(2026, 1, 1),
                notAfter = date(2027, 1, 1),
            ),
        )
        assertThrows(Exception::class.java) { certificate.verify(ecKeyPair().public) }
    }

    @Test
    fun `invalid arguments are rejected before any crypto runs`() {
        val keyPair = ecKeyPair()
        assertThrows(IllegalArgumentException::class.java) {
            X509Certificates.selfSignedCa(keyPair, "CN=Cyrus", date(2036, 1, 1), date(2026, 1, 1))
        }
        assertThrows(IllegalArgumentException::class.java) {
            X509Certificates.selfSignedCa(keyPair, "CN=Cyrus", date(2026, 1, 1), date(2036, 1, 1), BigInteger.ZERO)
        }
        assertThrows(IllegalArgumentException::class.java) {
            X509Certificates.selfSignedCa(keyPair, "email=someone@example.com", date(2026, 1, 1), date(2036, 1, 1))
        }
    }
}
