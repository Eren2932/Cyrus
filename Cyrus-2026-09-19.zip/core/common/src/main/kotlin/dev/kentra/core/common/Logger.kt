package dev.kentra.core.common

/**
 * Logging port. The implementation in :app writes to logcat + an in-memory ring buffer
 * that the diagnostics screen reads. NEVER log keys, UUIDs or subscription URLs.
 */
interface Logger {
    fun d(tag: String, message: String)
    fun i(tag: String, message: String)
    fun w(tag: String, message: String, t: Throwable? = null)
    fun e(tag: String, message: String, t: Throwable? = null)
}

object NoopLogger : Logger {
    override fun d(tag: String, message: String) = Unit
    override fun i(tag: String, message: String) = Unit
    override fun w(tag: String, message: String, t: Throwable?) = Unit
    override fun e(tag: String, message: String, t: Throwable?) = Unit
}

/**
 * Redacts secrets before they reach any log sink.
 *
 * Used on free-form text (native core messages), so it is deliberately broader than the
 * JSON-aware masking in `CoreLog`: it cannot know which key a value belongs to, so it
 * matches on shape as well as on `key=value` pairs. A miss here is a credential in a log,
 * so the patterns err on the side of over-redaction.
 */
fun String.redactSecrets(): String = this
    .replace(Regex("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"), "<uuid>")
    // Share links and subscription URLs carry the credential in the userinfo or the fragment.
    .replace(Regex("(?i)(vless|vmess|trojan|ss|ssr|hysteria2?|tuic|http|https|socks)://\\S+"), "<link>")
    // query/JSON style: password=..., pbk=..., uuid=...
    .replace(Regex("(?i)\\b(password|passwd|pwd|pbk|preshared_key|private_key|secret|token|api_key)\\s*[=:]\\s*\"?[^\\s,&\"}\\]]+"), "$1=<redacted>")
    // WireGuard INI form: `PrivateKey = <44-char base64>`.
    .replace(Regex("(?im)^\\s*(PrivateKey|PresharedKey)\\s*=\\s*\\S+"), "$1=<redacted>")
    // Bare base64 blobs long enough to be a key but not a word (WireGuard keys are 44 chars).
    .replace(Regex("\\b[A-Za-z0-9+/]{40,}={0,2}\\b"), "<b64>")
