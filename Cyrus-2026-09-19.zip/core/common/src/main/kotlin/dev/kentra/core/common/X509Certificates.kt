package dev.kentra.core.common

import java.io.ByteArrayOutputStream
import java.math.BigInteger
import java.nio.charset.StandardCharsets
import java.security.KeyPair
import java.security.PrivateKey
import java.security.PublicKey
import java.security.Signature
import java.security.cert.X509Certificate
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneOffset
import java.util.Date
import java.util.Locale

/**
 * Builds the two certificate shapes Cyrus needs: a self-signed CA root and a
 * leaf signed by it.
 *
 * Android ships an X.509 *parser* but no public builder, and the usual answer —
 * BouncyCastle — costs several megabytes of APK to produce a certificate. The
 * encoder below writes the DER by hand. It is deliberately narrow: version 3,
 * a subject name, and the handful of extensions either shape actually requires.
 * Narrowness is what makes it reviewable; every byte here is checkable against
 * RFC 5280 without a library in the loop.
 *
 * Callers verify what comes out (`certificate.verify(issuerPublicKey)`) before
 * it is persisted or handed to a TLS stack, so a mistake in this file fails
 * loudly instead of producing a certificate that nobody accepts.
 */
public object X509Certificates {

    private val EMPTY = ByteArray(0)

    // Name attribute types we accept; anything else is a bug in the caller,
    // not a case to handle silently.
    private val NAME_OIDS = mapOf(
        "CN" to "2.5.4.3",
        "O" to "2.5.4.10",
        "OU" to "2.5.4.11",
        "C" to "2.5.4.6",
    )

    @JvmOverloads
    public fun selfSignedCa(
        keyPair: KeyPair,
        subject: String,
        notBefore: Date,
        notAfter: Date,
        serial: BigInteger = BigInteger.ONE,
    ): ByteArray = selfSignedCa(keyPair.public, keyPair.private, subject, notBefore, notAfter, serial)

    /**
     * @param subject an RFC 4514-ish name, e.g. `CN=Cyrus Protection CA, O=Cyrus`.
     * @return DER-encoded certificate, ready for `CertificateFactory` or for
     *         `KeyChain.EXTRA_CERTIFICATE`.
     */
    public fun selfSignedCa(
        publicKey: PublicKey,
        privateKey: PrivateKey,
        subject: String,
        notBefore: Date,
        notAfter: Date,
        serial: BigInteger = BigInteger.ONE,
    ): ByteArray = name(subject).let { encoded ->
        build(
            publicKey = publicKey,
            privateKey = privateKey,
            issuerDer = encoded,
            subjectDer = encoded,
            notBefore = notBefore,
            notAfter = notAfter,
            serial = serial,
            extensions = listOf(caBasicConstraints(), caKeyUsage()),
        )
    }

    /**
     * A server certificate for one host, signed by the CA key.
     *
     * @param caPrivateKey the CA key. On Android this is a keystore key: it can
     *        sign but its material never leaves the keystore, which is why the
     *        signature is produced here rather than from exported bytes.
     * @param caCertificate the issuing root. Taking the certificate rather than
     *        a name string is deliberate: `X500Principal.name` prints RDNs in
     *        the opposite order to the DER it was parsed from, so round-tripping
     *        the issuer through a string produces bytes that differ from the
     *        root's own subject — and a chain is matched on those bytes, not on
     *        how the name reads.
     * @param host goes into CN and, crucially, into subjectAltName: modern
     *        clients ignore CN entirely.
     */
    public fun leaf(
        publicKey: PublicKey,
        caPrivateKey: PrivateKey,
        caCertificate: X509Certificate,
        host: String,
        notBefore: Date,
        notAfter: Date,
        serial: BigInteger = BigInteger.ONE,
    ): ByteArray = build(
        publicKey = publicKey,
        privateKey = caPrivateKey,
        issuerDer = caCertificate.subjectX500Principal.encoded,
        subjectDer = name("CN=$host"),
        notBefore = notBefore,
        notAfter = notAfter,
        serial = serial,
        extensions = listOf(leafBasicConstraints(), leafKeyUsage(), extendedKeyUsage(), subjectAltName(host)),
    )

    private fun build(
        publicKey: PublicKey,
        privateKey: PrivateKey,
        issuerDer: ByteArray,
        subjectDer: ByteArray,
        notBefore: Date,
        notAfter: Date,
        serial: BigInteger,
        extensions: List<ByteArray>,
    ): ByteArray {
        require(notAfter.after(notBefore)) { "notAfter should be later than notBefore" }
        require(serial.signum() > 0) { "serial must be positive" }

        val algorithm = signatureAlgorithm(privateKey)
        val tbs = sequence(
            context(0, integer(BigInteger.valueOf(2))),
            integer(serial),
            algorithmIdentifier(algorithm),
            issuerDer,
            sequence(time(notBefore.toInstant()), time(notAfter.toInstant())),
            subjectDer,
            // SubjectPublicKeyInfo is already DER-encoded by the provider;
            // re-encoding it by hand would only add a second place to be wrong.
            publicKey.encoded,
            context(3, sequence(*extensions.toTypedArray())),
        )

        val signer = Signature.getInstance(algorithm.jcaName)
        signer.initSign(privateKey)
        signer.update(tbs)
        return sequence(tbs, algorithmIdentifier(algorithm), bitString(signer.sign(), unusedBits = 0))
    }

    private class SignatureAlgorithm(val jcaName: String, val oid: String, val nullParameters: Boolean)

    private fun signatureAlgorithm(key: PrivateKey): SignatureAlgorithm = when (key.algorithm.uppercase(Locale.US)) {
        // RFC 5758: parameters MUST be absent for ECDSA.
        "EC", "ECDSA" -> SignatureAlgorithm("SHA256withECDSA", "1.2.840.10045.4.3.2", nullParameters = false)
        // RFC 4055: PKCS#1 v1.5 signature algorithms carry explicit NULL parameters.
        "RSA", "RSASSA-PKCS1-V1_5" -> SignatureAlgorithm("SHA256withRSA", "1.2.840.113549.1.1.11", nullParameters = true)
        else -> throw IllegalArgumentException("Unsupported key algorithm: ${key.algorithm}")
    }

    private fun algorithmIdentifier(algorithm: SignatureAlgorithm): ByteArray =
        if (algorithm.nullParameters) sequence(oid(algorithm.oid), tlv(0x05, EMPTY))
        else sequence(oid(algorithm.oid))

    // --- CA extensions ------------------------------------------------------

    /** cA = TRUE, critical: without it no client treats this as a root. */
    private fun caBasicConstraints(): ByteArray =
        extension("2.5.29.19", critical = true, sequence(boolean(true)))

    /** digitalSignature | keyCertSign | cRLSign — a CA that signs nothing else. */
    private fun caKeyUsage(): ByteArray =
        extension("2.5.29.15", critical = true, bitString(byteArrayOf(0x86.toByte()), unusedBits = 1))

    // --- Leaf extensions ----------------------------------------------------

    /** An empty SEQUENCE: this certificate signs nothing below it. */
    private fun leafBasicConstraints(): ByteArray =
        extension("2.5.29.19", critical = true, sequence())

    /** digitalSignature | keyEncipherment. */
    private fun leafKeyUsage(): ByteArray =
        extension("2.5.29.15", critical = true, bitString(byteArrayOf(0x90.toByte()), unusedBits = 4))

    /** id-kp-serverAuth only: a leaf that must not be used as a client cert. */
    private fun extendedKeyUsage(): ByteArray =
        extension("2.5.29.37", critical = false, sequence(oid("1.3.6.1.5.5.7.3.1")))

    private fun subjectAltName(host: String): ByteArray =
        extension("2.5.29.17", critical = false, sequence(contextTagged(2, host.toByteArray(StandardCharsets.US_ASCII))))

    private fun extension(oid: String, critical: Boolean, value: ByteArray): ByteArray = sequence(
        oid(oid),
        if (critical) boolean(true) else EMPTY,
        octetString(value),
    )

    private fun name(subject: String): ByteArray = sequence(*subject.split(',').map { part ->
        val separator = part.indexOf('=')
        require(separator > 0) { "Malformed name: $subject" }
        val type = part.substring(0, separator).trim()
        val oid = NAME_OIDS[type.uppercase(Locale.US)]
            ?: throw IllegalArgumentException("Unsupported name attribute: $type")
        set(sequence(oid(oid), utf8String(part.substring(separator + 1).trim())))
    }.toTypedArray())

    /**
     * UTCTime up to 2049, GeneralizedTime after. Both are fixed-form `…Z` (UTC),
     * which is what DER requires; a local-time encoding would be rejected.
     */
    private fun time(instant: Instant): ByteArray {
        val dateTime = LocalDateTime.ofInstant(instant, ZoneOffset.UTC)
        val year = dateTime.year
        val utc = year in 1950..2049
        val text = if (utc) {
            String.format(Locale.US, "%02d%02d%02d%02d%02d%02dZ",
                year % 100, dateTime.monthValue, dateTime.dayOfMonth,
                dateTime.hour, dateTime.minute, dateTime.second)
        } else {
            String.format(Locale.US, "%04d%02d%02d%02d%02d%02dZ",
                year, dateTime.monthValue, dateTime.dayOfMonth,
                dateTime.hour, dateTime.minute, dateTime.second)
        }
        return tlv(if (utc) 0x17 else 0x18, text.toByteArray(StandardCharsets.US_ASCII))
    }

    private fun concat(parts: Array<out ByteArray>): ByteArray {
        val out = ByteArrayOutputStream()
        parts.forEach { out.write(it) }
        return out.toByteArray()
    }

    private fun tlv(tag: Int, content: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(tag)
        writeLength(out, content.size)
        out.write(content)
        return out.toByteArray()
    }

    /** DER lengths: shortest form, long form only when actually needed. */
    private fun writeLength(out: ByteArrayOutputStream, length: Int) {
        when {
            length < 0x80 -> out.write(length)
            length <= 0xFF -> {
                out.write(0x81)
                out.write(length)
            }
            length <= 0xFFFF -> {
                out.write(0x82)
                out.write(length shr 8)
                out.write(length)
            }
            else -> {
                out.write(0x83)
                out.write(length shr 16)
                out.write(length shr 8)
                out.write(length)
            }
        }
    }

    private fun sequence(vararg parts: ByteArray): ByteArray = tlv(0x30, concat(parts))

    private fun set(vararg parts: ByteArray): ByteArray = tlv(0x31, concat(parts))

    private fun integer(value: BigInteger): ByteArray = tlv(0x02, value.toByteArray())

    private fun octetString(value: ByteArray): ByteArray = tlv(0x04, value)

    private fun bitString(value: ByteArray, unusedBits: Int): ByteArray =
        tlv(0x03, byteArrayOf(unusedBits.toByte()) + value)

    private fun boolean(value: Boolean): ByteArray =
        tlv(0x01, byteArrayOf(if (value) 0xFF.toByte() else 0x00))

    private fun utf8String(value: String): ByteArray = tlv(0x0C, value.toByteArray(StandardCharsets.UTF_8))

    /** Primitive context-specific tag, e.g. [2] dNSName inside subjectAltName. */
    private fun contextTagged(tag: Int, content: ByteArray): ByteArray = tlv(0x80 or tag, content)

    private fun oid(dotted: String): ByteArray {
        val parts = dotted.split('.').map { it.toInt() }
        require(parts.size >= 2) { "Malformed OID: $dotted" }
        val out = ByteArrayOutputStream()
        out.write(parts[0] * 40 + parts[1])
        parts.drop(2).forEach { part ->
            var value = part
            val stack = mutableListOf<Int>()
            do {
                stack.add(value and 0x7F)
                value = value shr 7
            } while (value > 0)
            for (index in stack.size - 1 downTo 0) {
                out.write(if (index > 0) stack[index] or 0x80 else stack[index])
            }
        }
        return tlv(0x06, out.toByteArray())
    }

    private fun context(tag: Int, content: ByteArray): ByteArray = tlv(0xA0 or tag, content)
}
