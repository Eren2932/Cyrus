package dev.kentra.core.common

/** Single error taxonomy for the whole app. UI maps these to strings, never the other way around. */
sealed class AppError(message: String? = null, cause: Throwable? = null) : Exception(message, cause) {
    data class Network(val reason: String? = null, override val cause: Throwable? = null) : AppError("network: $reason", cause)
    data class Parse(val reason: String? = null, override val cause: Throwable? = null) : AppError("parse: $reason", cause)
    data class Tunnel(val reason: String? = null, override val cause: Throwable? = null) : AppError("tunnel: $reason", cause)
    data class Permission(val what: String) : AppError("permission: $what")
    data class NotFound(val what: String) : AppError("not found: $what")
    data class Unknown(override val cause: Throwable?) : AppError("unknown", cause)

    companion object {
        fun from(t: Throwable): AppError = t as? AppError ?: Unknown(t)
    }
}

inline fun <T> appRunCatching(block: () -> T): Result<T> =
    try {
        Result.success(block())
    } catch (e: kotlinx.coroutines.CancellationException) {
        throw e
    } catch (e: java.lang.Error) {
        // Fatal VM errors (OutOfMemoryError, StackOverflowError, LinkageError, ...) must never be
        // converted into AppError.Unknown: the app cannot meaningfully continue after them, and
        // swallowing them hides real crashes behind a generic UI message.
        // NB: explicitly java.lang.Error - bare `Error` in Kotlin resolves to kotlin.Error.
        throw e
    } catch (t: Throwable) {
        Result.failure(AppError.from(t))
    }
