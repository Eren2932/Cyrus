package dev.kentra.core.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dev.kentra.vpn.config.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.catch
import java.io.IOException
import androidx.datastore.preferences.core.emptyPreferences

enum class ThemeMode { SYSTEM, DARK, LIGHT }

/**
 * Appearance is a single choice now: the theme. The wallpaper is a fixed
 * standard (camo) and motion follows the platform animator scale, so the
 * matching 0.3 preferences are gone. The `appearance_theme` key is unchanged,
 * so an existing install keeps the theme it was on.
 */
data class AppearanceSettings(val theme: ThemeMode = ThemeMode.DARK)

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "kentra_settings")

/**
 * Non-secret settings only. Auth tokens and subscription URLs belong in the encrypted store
 * (see data/SecretCipher and SecureStorage) — never here.
 */
class SettingsStore(private val context: Context) {

    private object Keys {
        val theme = stringPreferencesKey("appearance_theme")
        val activeProfileId = stringPreferencesKey("active_profile_id")
        val connectionMode = stringPreferencesKey("connection_mode")
        val proxyPort = intPreferencesKey("proxy_port")
        val dnsLocal = stringPreferencesKey("dns_local")
        val multiplex = booleanPreferencesKey("multiplex")
        val logLevel = stringPreferencesKey("log_level")
        val perAppMode = stringPreferencesKey("per_app_mode")
        val packages = stringPreferencesKey("per_app_packages")
        val mtu = intPreferencesKey("mtu")
        val stack = stringPreferencesKey("stack")
        val bypassLan = booleanPreferencesKey("bypass_lan")
        val blockAds = booleanPreferencesKey("block_ads")
        val protectionEnabled = booleanPreferencesKey("protection_enabled")
        val blockTrackers = booleanPreferencesKey("block_trackers")
        val blockAnnoyances = booleanPreferencesKey("block_annoyances")
        val blockThreats = booleanPreferencesKey("block_threats")
        val dnsProtection = booleanPreferencesKey("dns_protection")
        val inspectHttps = booleanPreferencesKey("inspect_https")
        val firewallEnabled = booleanPreferencesKey("firewall_enabled")
        val blockedPackages = stringPreferencesKey("firewall_packages")
        val ipv6 = booleanPreferencesKey("ipv6")
        val dnsRemote = stringPreferencesKey("dns_remote")
        val onboardingDone = booleanPreferencesKey("onboarding_done")
    }

    val appearance: Flow<AppearanceSettings> = context.dataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { prefs ->
            AppearanceSettings(
                theme = ThemeMode.entries.firstOrNull { it.name == prefs[Keys.theme] } ?: ThemeMode.DARK,
            )
        }

    suspend fun setTheme(value: ThemeMode) = context.dataStore.edit { it[Keys.theme] = value.name }

    val activeProfileId: Flow<String?> = context.dataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { it[Keys.activeProfileId] }

    val tunnelOptions: Flow<TunnelOptions> = context.dataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }.map { prefs ->
        TunnelOptions(
            mode = ConnectionMode.entries.firstOrNull { it.name == prefs[Keys.connectionMode] } ?: ConnectionMode.VPN,
            proxyPort = prefs[Keys.proxyPort] ?: 2080,
            // Must match TunnelOptions.dnsLocal. "local" deadlocks the bootstrap: inside the
            // TUN the system resolver points back into the tunnel, so the proxy's own server
            // address can never be resolved. See ConfigFactory.dnsLocal.
            dnsLocal = prefs[Keys.dnsLocal] ?: "1.1.1.1",
            enableMultiplex = prefs[Keys.multiplex] ?: false,
            logLevel = prefs[Keys.logLevel] ?: "warn",
            perAppMode = (prefs[Keys.packages] ?: "").lines().filter { it.isNotBlank() }.let { packages ->
                when (prefs[Keys.perAppMode]) {
                    "include" -> PerAppMode.Include(packages)
                    "exclude" -> PerAppMode.Exclude(packages)
                    else -> PerAppMode.Off
                }
            },
            mtu = prefs[Keys.mtu] ?: 9000,
            stack = prefs[Keys.stack] ?: "system",
            bypassLan = prefs[Keys.bypassLan] ?: true,
            blockAds = prefs[Keys.blockAds] ?: false,
            protectionEnabled = prefs[Keys.protectionEnabled] ?: (prefs[Keys.blockAds] ?: false),
            blockTrackers = prefs[Keys.blockTrackers] ?: false,
            blockAnnoyances = prefs[Keys.blockAnnoyances] ?: false,
            blockThreats = prefs[Keys.blockThreats] ?: false,
            dnsProtection = prefs[Keys.dnsProtection] ?: false,
            // Off by default and independently of the root's existence: turning
            // traffic decryption on is a decision the user makes, not a side
            // effect of having created a certificate.
            inspectHttps = prefs[Keys.inspectHttps] ?: false,
            firewallEnabled = prefs[Keys.firewallEnabled] ?: false,
            blockedPackages = (prefs[Keys.blockedPackages] ?: "").lines().filter { it.isNotBlank() }.distinct(),
            ipv6 = prefs[Keys.ipv6] ?: false,
            dnsRemote = prefs[Keys.dnsRemote] ?: "tls://1.1.1.1",
        )
    }

    val onboardingDone: Flow<Boolean> = context.dataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { it[Keys.onboardingDone] ?: false }

    suspend fun setActiveProfileId(id: String?) = context.dataStore.edit { prefs ->
        if (id == null) prefs.remove(Keys.activeProfileId) else prefs[Keys.activeProfileId] = id
    }

    suspend fun setTunnelOptions(options: TunnelOptions) = context.dataStore.edit { prefs ->
        options.validate()
        prefs[Keys.connectionMode] = options.mode.name
        prefs[Keys.proxyPort] = options.proxyPort
        prefs[Keys.dnsLocal] = options.dnsLocal
        prefs[Keys.multiplex] = options.enableMultiplex
        prefs[Keys.logLevel] = options.logLevel
        prefs[Keys.perAppMode] = when (options.perAppMode) { is PerAppMode.Include -> "include"; is PerAppMode.Exclude -> "exclude"; else -> "off" }
        prefs[Keys.packages] = when (val p = options.perAppMode) { is PerAppMode.Include -> p.packages; is PerAppMode.Exclude -> p.packages; else -> emptyList() }.joinToString("\n")
        prefs[Keys.mtu] = options.mtu
        prefs[Keys.stack] = options.stack
        prefs[Keys.bypassLan] = options.bypassLan
        prefs[Keys.blockAds] = options.blockAds
        prefs[Keys.protectionEnabled] = options.protectionEnabled
        prefs[Keys.blockTrackers] = options.blockTrackers
        prefs[Keys.blockAnnoyances] = options.blockAnnoyances
        prefs[Keys.blockThreats] = options.blockThreats
        prefs[Keys.dnsProtection] = options.dnsProtection
        prefs[Keys.inspectHttps] = options.inspectHttps
        prefs[Keys.firewallEnabled] = options.firewallEnabled
        prefs[Keys.blockedPackages] = options.blockedPackages.distinct().joinToString("\n")
        prefs[Keys.ipv6] = options.ipv6
        prefs[Keys.dnsRemote] = options.dnsRemote
    }

    suspend fun setOnboardingDone(done: Boolean) = context.dataStore.edit { it[Keys.onboardingDone] = done }
}
