package dev.kentra.core.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dev.kentra.domain.model.ProtectionCategory
import dev.kentra.domain.model.ProtectionStats
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.io.IOException

private val Context.protectionStatsDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "cyrus_protection_stats",
)

/**
 * Durable protection telemetry. It contains counters only; no domains, URLs or
 * application payloads are persisted.
 *
 * The VPN engine calls the non-suspending record methods from native callback threads.
 * DataStore serializes the edits, so increments cannot be lost when several blocked
 * connections arrive in the same status batch.
 */
class ProtectionStatsStore(private val context: Context) {
    private object Keys {
        val blockedRequests = longPreferencesKey("blocked_requests")
        val uploadedBytes = longPreferencesKey("uploaded_bytes")
        val downloadedBytes = longPreferencesKey("downloaded_bytes")
        val ads = longPreferencesKey("blocked_ads")
        val trackers = longPreferencesKey("blocked_trackers")
        val annoyances = longPreferencesKey("blocked_annoyances")
        val threats = longPreferencesKey("blocked_threats")
        val firewall = longPreferencesKey("blocked_firewall")
        val other = longPreferencesKey("blocked_other")
        val lastBlockedAt = longPreferencesKey("last_blocked_at")
    }

    private val writerScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val stats: Flow<ProtectionStats> = context.protectionStatsDataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { prefs ->
            ProtectionStats(
                blockedRequests = prefs[Keys.blockedRequests] ?: 0L,
                uploadedBytes = prefs[Keys.uploadedBytes] ?: 0L,
                downloadedBytes = prefs[Keys.downloadedBytes] ?: 0L,
                adsBlocked = prefs[Keys.ads] ?: 0L,
                trackersBlocked = prefs[Keys.trackers] ?: 0L,
                annoyancesBlocked = prefs[Keys.annoyances] ?: 0L,
                threatsBlocked = prefs[Keys.threats] ?: 0L,
                firewallBlocked = prefs[Keys.firewall] ?: 0L,
                otherBlocked = prefs[Keys.other] ?: 0L,
                lastBlockedAtEpochMs = prefs[Keys.lastBlockedAt],
            )
        }

    /**
     * Counts one blocked connection. There is no byte count to add: a connection the
     * core rejected never moves the payload it was refused, so any "traffic saved"
     * figure would be invented rather than measured.
     */
    fun recordBlocked(category: ProtectionCategory) {
        writerScope.launch {
            context.protectionStatsDataStore.edit { prefs ->
                prefs[Keys.blockedRequests] = increment(prefs[Keys.blockedRequests] ?: 0L)
                val key = when (category) {
                    ProtectionCategory.ADS -> Keys.ads
                    ProtectionCategory.TRACKERS -> Keys.trackers
                    ProtectionCategory.ANNOYANCES -> Keys.annoyances
                    ProtectionCategory.THREATS -> Keys.threats
                    ProtectionCategory.FIREWALL -> Keys.firewall
                    ProtectionCategory.OTHER -> Keys.other
                }
                prefs[key] = increment(prefs[key] ?: 0L)
                prefs[Keys.lastBlockedAt] = System.currentTimeMillis()
            }
        }
    }

    /** Store the cumulative totals reported by sing-box, never a per-second delta. */
    fun recordTraffic(uplinkBytes: Long, downlinkBytes: Long) {
        writerScope.launch {
            context.protectionStatsDataStore.edit { prefs ->
                prefs[Keys.uploadedBytes] = maxOf(prefs[Keys.uploadedBytes] ?: 0L, uplinkBytes.coerceAtLeast(0L))
                prefs[Keys.downloadedBytes] = maxOf(prefs[Keys.downloadedBytes] ?: 0L, downlinkBytes.coerceAtLeast(0L))
            }
        }
    }

    suspend fun reset() {
        context.protectionStatsDataStore.edit { prefs ->
            prefs.clear()
        }
    }

    private fun increment(value: Long): Long =
        if (value == Long.MAX_VALUE) value else value + 1L

}
