package dev.kentra.core.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import java.security.MessageDigest

@Database(
    entities = [ProfileEntity::class, SubscriptionEntity::class],
    version = 3,
    exportSchema = false,
)
abstract class CyrusDatabase : RoomDatabase() {
    abstract fun profileDao(): ProfileDao
    abstract fun subscriptionDao(): SubscriptionDao

    companion object {
        private const val NAME = "kentra.db"

        // Must match ImportReport.connectionIdentity(): "v3:" + lowercase hex SHA-256.
        private const val IDENTITY_PREFIX = "v3:"

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE profiles ADD COLUMN connectionIdentity TEXT NOT NULL DEFAULT ''")
                // Placeholder only: the id is not a connection identity, so MIGRATION_2_3
                // re-hashes this value. De-duplication for these rows is best-effort until
                // the profile is re-imported (see MIGRATION_2_3).
                db.execSQL("UPDATE profiles SET connectionIdentity = id")
            }
        }

        /**
         * Replaces the plaintext `connectionIdentity` values written by app versions <= 2 with
         * irreversible fingerprints. Before this migration the column held the full share link
         * (UUID + password), which SecureStorage never encrypts, so secrets leaked in the clear.
         *
         * The stored value is hashed as-is: the column is not encrypted, so no SecretCipher is
         * involved (and none is available at Room-migration time). For rows created after
         * v2 the stored value is exactly `rawLink.substringBefore('#')`, which is what
         * ImportReport.connectionIdentity() hashes, so those rows keep matching de-duplication.
         *
         * Known limitation: the hash can only match the new identity when the stored value was
         * the raw link. Rows written by MIGRATION_1_2 stored the profile `id`, and rows created
         * from a profile without a rawLink stored a `VpnProfile.toString()` dump; neither equals
         * the new canonical fingerprint, so a re-import of the same key may create a duplicate.
         * Re-importing profiles after upgrading is recommended.
         */
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                val updates = ArrayList<Pair<String, String>>()
                db.query("SELECT id, connectionIdentity FROM profiles").use { cursor ->
                    val idIndex = cursor.getColumnIndexOrThrow("id")
                    val identityIndex = cursor.getColumnIndexOrThrow("connectionIdentity")
                    while (cursor.moveToNext()) {
                        val id = cursor.getString(idIndex) ?: continue
                        val stored = cursor.getString(identityIndex) ?: continue
                        // Idempotency guard: never hash an already-migrated value.
                        if (stored.startsWith(IDENTITY_PREFIX)) continue
                        updates += id to IDENTITY_PREFIX + sha256Hex(stored)
                    }
                }
                for ((id, hashed) in updates) {
                    db.execSQL("UPDATE profiles SET connectionIdentity = ? WHERE id = ?", arrayOf(hashed, id))
                }
            }
        }

        private fun sha256Hex(value: String): String {
            val digest = MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8))
            val out = StringBuilder(digest.size * 2)
            for (byte in digest) {
                val v = byte.toInt() and 0xFF
                out.append(HEX_DIGITS[v ushr 4]).append(HEX_DIGITS[v and 0x0F])
            }
            return out.toString()
        }

        private const val HEX_DIGITS = "0123456789abcdef"

        fun build(context: Context): CyrusDatabase =
            Room.databaseBuilder(context, CyrusDatabase::class.java, NAME)
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                .build()
    }
}
