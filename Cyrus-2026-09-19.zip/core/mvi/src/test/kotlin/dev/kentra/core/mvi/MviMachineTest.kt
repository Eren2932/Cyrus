package dev.kentra.core.mvi

import app.cash.turbine.test
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

private data class CounterState(val value: Int = 0) : MviState
private sealed interface CounterIntent : MviIntent {
    data object Increment : CounterIntent
    data object Fail : CounterIntent
    data object Cancel : CounterIntent
}
private sealed interface CounterEffect : MviEffect {
    data class Toast(val text: String) : CounterEffect
}

@OptIn(ExperimentalCoroutinesApi::class)
class MviMachineTest {

    @Test
    fun `increment reduces state`() = runTest {
        val machine = machine(this)

        machine.dispatch(CounterIntent.Increment)
        machine.dispatch(CounterIntent.Increment)
        testScheduler.advanceUntilIdle()

        assertEquals(2, machine.current.value)
    }

    @Test
    fun `effects are emitted once`() = runTest {
        val machine = machine(this)

        machine.effects.test {
            machine.dispatch(CounterIntent.Fail)
            testScheduler.advanceUntilIdle()
            assertEquals(CounterEffect.Toast("boom"), awaitItem())
            cancelAndIgnoreRemainingEvents()
        }
    }

    /**
     * With the default `onError` an escaping exception cancels the scope, so every
     * later dispatch silently does nothing — the screen stops responding with no
     * error anywhere. This pins the behaviour the Android host relies on.
     */
    @Test
    fun `a failing intent does not kill the scope when a handler is installed`() = runTest {
        val errors = mutableListOf<Throwable>()
        val machine = MviMachine<CounterIntent, CounterState, CounterEffect>(
            CounterState(),
            this,
            onError = { errors += it },
        ) { intent ->
            when (intent) {
                CounterIntent.Increment -> reduce { copy(value = value + 1) }
                CounterIntent.Fail -> error("boom")
                CounterIntent.Cancel -> throw CancellationException("cancelled")
            }
        }

        machine.dispatch(CounterIntent.Fail)
        testScheduler.advanceUntilIdle()
        assertEquals("the failure must reach onError", 1, errors.size)

        // The scope survived: this increment must still land.
        machine.dispatch(CounterIntent.Increment)
        testScheduler.advanceUntilIdle()
        assertEquals(1, machine.current.value)
    }

    @Test
    fun `cancellation still propagates instead of being reported as an error`() = runTest {
        val errors = mutableListOf<Throwable>()
        val machine = MviMachine<CounterIntent, CounterState, CounterEffect>(
            CounterState(),
            this,
            onError = { errors += it },
        ) { throw CancellationException("cancelled") }

        machine.dispatch(CounterIntent.Cancel)
        testScheduler.advanceUntilIdle()

        assertTrue("cancellation is not an error: $errors", errors.isEmpty())
    }

    @Test
    fun `effects below the channel capacity are never dropped`() = runTest {
        val machine = machine(this)

        machine.effects.test {
            repeat(16) { machine.dispatch(CounterIntent.Fail) }
            testScheduler.advanceUntilIdle()
            repeat(16) { awaitItem() }
            cancelAndIgnoreRemainingEvents()
        }

        assertEquals(0, machine.droppedEffects)
    }

    private fun machine(scope: kotlinx.coroutines.CoroutineScope) =
        MviMachine<CounterIntent, CounterState, CounterEffect>(CounterState(), scope) { intent ->
            when (intent) {
                CounterIntent.Increment -> reduce { copy(value = value + 1) }
                CounterIntent.Fail -> effect(CounterEffect.Toast("boom"))
                CounterIntent.Cancel -> Unit
            }
        }
}
