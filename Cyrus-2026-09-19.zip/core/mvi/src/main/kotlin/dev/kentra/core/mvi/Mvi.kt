package dev.kentra.core.mvi

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** Marker types keep the contract of every screen explicit and greppable. */
interface MviState
interface MviIntent
interface MviEffect

interface Store<I : MviIntent, S : MviState, E : MviEffect> {
    val state: StateFlow<S>
    val effects: Flow<E>
    fun dispatch(intent: I)
}

/**
 * The whole MVI engine, 40 lines, zero magic.
 *
 * - [state] is the single source of truth for a screen.
 * - [effects] are one-shot, non-replayable (navigate, show snackbar, ask permission).
 * - Intents are handled concurrently on [scope]; ordering guarantees must live in the handler.
 */
class MviMachine<I : MviIntent, S : MviState, E : MviEffect>(
    initialState: S,
    private val scope: CoroutineScope,
    /**
     * What to do with a [handler] that throws.
     *
     * The default rethrows into [scope]. That is only safe for a scope that owns nothing
     * else: `viewModelScope` has no CoroutineExceptionHandler, so an escaping exception
     * cancels it — killing every other in-flight intent and every collection started in
     * `init`. The screen then stops reacting to input entirely, with no error anywhere.
     * Android hosts therefore pass a handler; see `MviViewModel.onHandlerError`.
     */
    private val onError: (Throwable) -> Unit = { throw it },
    private val handler: suspend MviMachine<I, S, E>.(I) -> Unit,
) : Store<I, S, E> {

    private val _state = MutableStateFlow(initialState)
    override val state: StateFlow<S> = _state.asStateFlow()

    // DROP_OLDEST is deliberate: an effect is a one-shot UI instruction, and a stale
    // "navigate" or "show message" is worse than none. It is not silent, though - see
    // [droppedEffects], which exists so a test can assert it stays at zero.
    private val _effects = Channel<E>(capacity = 16, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    override val effects: Flow<E> = _effects.receiveAsFlow()

    private val dropped = java.util.concurrent.atomic.AtomicLong()

    /** Effects discarded because [effects] had no room. Always zero unless 16 pile up. */
    val droppedEffects: Long get() = dropped.get()

    val current: S get() = _state.value

    override fun dispatch(intent: I) {
        // Explicit invoke: `handler` is an extension function type, so the receiver is passed directly.
        scope.launch {
            try {
                handler.invoke(this@MviMachine, intent)
            } catch (t: Throwable) {
                // Cancellation always propagates: swallowing it would leave a cancelled
                // screen believing its work is still in flight.
                if (t is CancellationException) throw t
                onError(t)
            }
        }
    }

    /** Pure state transition. Keep it free of side effects so it stays unit-testable. */
    fun reduce(reducer: S.() -> S) {
        _state.update { it.reducer() }
    }

    fun effect(effect: E) {
        // trySend never fails under DROP_OLDEST, so the only way to learn about a drop
        // is to watch for one. Recorded rather than logged: the value is a signal for
        // tests and diagnostics, not something to print per event.
        if (_effects.trySend(effect).isFailure) dropped.incrementAndGet()
    }
}
