#!/usr/bin/env bash
# Builds vpn/service/libs/libXray.aar from a pinned XTLS/libXray commit.
#
# The AAR is a prebuilt binary that the Kotlin engine links against, so it must
# come from a reviewed source revision rather than a hand-repacked local blob
# (docs/CODE_REVIEW_ORCHESTRATED_2026-09-19.md H-13). The build mirrors upstream
# build/main.py: it resolves Xray-core, downloads geo data, installs the pinned
# gomobile and runs `gomobile bind -target android`.
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
# XTLS/libXray, resolved through the GitHub API on 2026-09-19.
# Verified: the commit exists (GET /repos/XTLS/libXray/commits/<ref> -> 200,
# committed 2026-09-09). What is NOT verified is that the Java API it emits still
# matches what XrayVpnEngine.kt calls — that needs one real `gomobile bind` run.
# To move to a newer release:
#   curl -sS https://api.github.com/repos/XTLS/libXray/tags
# then re-run this script and `python3 tools/check_native.py --require libXray.aar`.
LIBXRAY_REF='50b95979f5db551bd273165cf469e5daaf791341'
# Pinned from libXray go.mod (golang.org/x/mobile). Upstream defaults to
# 'latest', which is exactly the non-reproducibility this script removes.
LIBXRAY_GOMOBILE_VERSION='v0.0.0-20260908204917-8b95e45f8d3e'
# libXray go.mod declares `go 1.27.1`; GOTOOLCHAIN makes the runner fetch that
# exact toolchain instead of relying on whatever Go happens to be installed.
LIBXRAY_GO_TOOLCHAIN='go1.27.1'
for tool in go git python3 java; do
  command -v "$tool" >/dev/null || { echo "Missing tool: $tool" >&2; exit 1; }
done
: "${ANDROID_HOME:?Set ANDROID_HOME to the Android SDK directory}"
: "${ANDROID_NDK_HOME:?Set ANDROID_NDK_HOME to the NDK used for gomobile bind}"
WORK="$(mktemp -d "${TMPDIR:-/tmp}/cyrus-libxray.XXXXXXXX")"
trap 'rm -rf -- "$WORK"' EXIT
mkdir -p "$ROOT/vpn/service/libs"
# Check for libXray.aar specifically: libbox.aar may already be present.
if [ -e "$ROOT/vpn/service/libs/libXray.aar" ]; then
  echo 'vpn/service/libs/libXray.aar already exists. Back it up and remove it explicitly before rebuilding.' >&2
  exit 1
fi
git init -q "$WORK/source"
git -C "$WORK/source" remote add origin https://github.com/XTLS/libXray.git
git -C "$WORK/source" fetch --depth 1 origin "$LIBXRAY_REF"
git -C "$WORK/source" checkout --detach FETCH_HEAD
test "$(git -C "$WORK/source" rev-parse HEAD)" = "$LIBXRAY_REF"
export GOTOOLCHAIN="$LIBXRAY_GO_TOOLCHAIN"
export LIBXRAY_GOMOBILE_VERSION
export GOMAXPROCS="${GOMAXPROCS:-2}"
export GOFLAGS="${GOFLAGS:--p=2}"
cd "$WORK/source"
python3 build/main.py android
test -s libXray.aar
cp libXray.aar "$ROOT/vpn/service/libs/libXray.aar"
echo 'Built vpn/service/libs/libXray.aar; run python3 tools/check_native.py next.'
