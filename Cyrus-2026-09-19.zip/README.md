# Cyrus 0.5.0-dev — buildfix3

**Исходники, не готовый APK.** Статус **текущего** дерева (проверено локально
2026-09-19, JDK 17 + Gradle wrapper 8.11.1 + Android SDK):

- `:app:compileDebugKotlin` — **BUILD SUCCESSFUL**;
- `./gradlew test` — **249 тестов, 0 падений, 0 ошибок** во всех модулях;
- `:app:lintDebug` — **BUILD SUCCESSFUL**;
- 6 guard-скриптов (`source`, `design`, `merge`, `upgrade`, `native`, `buildfix`) — **PASS**.

Не выполнялись: сборка APK, native Go validation, установка и реальное
соединение на устройстве. Ниже по тексту всё, что относится к buildfix2/3 —
исторический контекст, а не состояние этого дерева.

Присланный внешний CI-лог относится к **предыдущему** архиву (buildfix2), а не к
текущему дереву: в нём компиляция debug/release и unit-тесты всех 16 модулей
прошли, а сборку остановили две lint-ошибки при `abortOnError = true`. Обе
ошибки исправлены в этом архиве:

1. `NewApi` — `android:forceDarkAllowed` (API 29) в `values/themes.xml` при `minSdk 24`. Атрибут перенесён в новый `values-v29/themes.xml` без подавления lint и без потери поведения.
2. `ProduceStateDoesNotAssignValue` — `CyrusWallpaper.kt`. Декодирование обоев переведено на `remember` + `LaunchedEffect` с той же семантикой; декодирование осталось вне UI-потока.

Дополнительно lint теперь печатает полный отчёт в консоль CI (`textReport`, `textOutput = stdout`), поэтому следующий сбой, если он будет, покажет сразу все ошибки.

**Ни один из этих результатов не является гарантией для текущего дерева** — он
относится к архиву buildfix2. Проверяйте текущее состояние самостоятельно.

Отчёт: [docs/BUILD_FIX_0.5.0_3.md](docs/BUILD_FIX_0.5.0_3.md). Подпись релизной
сборки: [docs/RELEASE_SIGNING.md](docs/RELEASE_SIGNING.md).

Загрузите `Cyrus-0.5.0-dev-buildfix3-source.zip` в корень Eren2932/Cyrus без распаковки. Установленный workflow менять не требуется. Для ручного запуска укажите новое имя ZIP в поле archive; не нажимайте Re-run старого запуска.

О клиенте и ограничениях: [docs/UPGRADE_0.5.0.md](docs/UPGRADE_0.5.0.md). Предыдущие исправления: [docs/BUILD_FIX_0.5.0_2.md](docs/BUILD_FIX_0.5.0_2.md), [docs/BUILD_FIX_0.5.0.md](docs/BUILD_FIX_0.5.0.md).

Версия Android сохранена: 0.5.0-dev / code 7; applicationId dev.kentra.app. Не удаляйте установленный клиент без экспорта ключей при несовпадении подписи.
