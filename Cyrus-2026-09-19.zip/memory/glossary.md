# Glossary — Cyrus decoder ring

## Acronyms
| Term | Meaning | Context |
|------|---------|---------|
| MVI | MviMachine, busy-guard + mutex | feature/home, profiles |
| TUN | tun0 172.19.0.1/28, gvisor/system stack | LibboxVpnEngine.kt |
| SIP003 | obfs-local/v2ray-plugin для SS | ConfigFactory |
| SIP008 | Shadowsocks online config (ss:// + json) | подписки |
| XHTTP | ex-splithttp, modes auto/packet-up/stream-up/stream-one | Xray-only |
| Reality | pbk/sid/spx, uTLS chrome | VLESS |
| pinSHA256 | pinnedPeerCertSha256; ни одно из закреплённых ядер не умеет проверять pin | HY2, pin ⇒ `insecure` (DEVICE_TEST_0.5.0 §14) |

## Протоколы URI
| Scheme | Протокол |
|--------|----------|
| vless, vmess, trojan, ss, hy2/hysteria2, tuic | основные |
| socks/socks5/socks4/socks4a, http/https | прокси |
| wireguard, amneziawg (awg), ssh | ПОДДЕРЖАНЫ (AWG — только через `ConfigFactory.build()` + AmneziaVpnEngine) |
| ssr, hysteria1, openvpn | НЕ поддержаны — цель Stage |
| clash://, sing-box json, clash yaml/json | НЕ поддержаны — цель Stage |

## Подписки
| Формат | Статус |
|--------|--------|
| base64 ссылок, plain list, Xray JSON array | OK |
| Clash YAML/JSON, sing-box JSON, SSD, SIP008, v2rayN subscription | цель |
| redirect/http-подписки | запрещены сейчас |

## Транспорты
| Canonical | Aliases |
|-----------|---------|
| tcp | raw, none, original, "" |
| ws | websocket |
| grpc | gun |
| http | h2, h2c, http2 |
| httpupgrade | upgrade |
| xhttp | splithttp (Xray-only) |
| kcp | mkcp (Xray-only) |
| quic | V2Ray quic (Xray-only) |
