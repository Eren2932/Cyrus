# Memory — Cyrus Orchestrator (hot cache)

## Me
Оркестратор Cyrus 0.5.0-dev, цель — макс. поддержка VPN-протоколов, парсинг всех подписок, корректный VPN, перф парсинга/добавления ключей.

## People
| Who | Role |
|-----|------|
| **Оркестратор** | Я — главный агент, планирую и проверяю |
| **doc-agents** | Слабые explore/general — только доки 2026 + качественные реализации |
| **analysis-agents** | Средние — сверка реализации с доками, промты исправлений |
| **impl-agents** | Исполнители промтов |
| **review-agent** | Ревью чужих реализаций и промтов |
→ Full glossary: memory/glossary.md

## Terms
| Term | Meaning |
|------|---------|
| sing-box | Пиннед v1.11.1 commit 92d245a, ядро VPN |
| Xray-only | xhttp/splithttp, kcp/mkcp, quic — только Xray-core |
| MAX_INPUT | 1 МиБ (1_048_576), MAX_BASE64_INPUT 768 КиБ, MAX_LINES 2000, MAX_LINK 65536 |
| VpnEngineKind | SING_BOX/XRAY, derived, без миграции |
→ Full glossary: memory/glossary.md

## Projects
| Name | What |
|------|------|
| **Cyrus** | Android Kotlin Compose, 16 модулей, app/domain/core/data/vpn/feature |
| **Stage2-Xray** | :vpn:xray + XrayVpnEngine + Koin Map, дизайн в XRAY_DUALCORE_PLAN.md |
→ Details: memory/projects/cyrus.md

## Preferences
- Факты > догадки, evidence before synthesis
- Русские ответы, короткие
- file_path:line_number при ссылках на код
- Никаких фиктивных успехов, fail-closed
- Систематический дебаг: root cause first
