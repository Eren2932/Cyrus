package dev.kentra.vpn.link

import dev.kentra.domain.model.*
import kotlinx.serialization.json.*
import java.util.Base64
import java.net.URLEncoder
import kotlinx.serialization.Serializable

@Serializable
private data class XrayConfigDto(val outbounds: List<JsonObject>? = null)

/** Extract proxy nodes only. Never execute downloaded routing, DNS, local inbounds or policy. */
internal class XraySubscriptionReader(private val parser: DefaultLinkParser) {
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }
    
    companion object {
        private val ALLOWED_STREAM = setOf("network", "security", "tlsSettings", "realitySettings", "wsSettings", "grpcSettings", "xhttpSettings", "httpupgradeSettings", "tcpSettings", "rawSettings", "httpSettings", "hysteriaSettings")
        // `show` is an Xray-UI display flag; it never reaches the wire.
        private val ALLOWED_TLS = setOf("serverName", "allowInsecure", "fingerprint", "alpn", "publicKey", "shortId", "spiderX", "pinnedPeerCertSha256", "show")
        // `heartbeatPeriod` is the WebSocket ping interval; the core keeps its own keepalive.
        private val ALLOWED_TRANSPORT = setOf("host", "path", "headers", "serviceName", "multiMode", "mode", "heartbeatPeriod")
        // `mux` is multiplexing -- a first-class app setting (`enableMultiplex`). Its presence
        // says "this node may be multiplexed", not "this node needs behaviour we lack".
        private val ALLOWED_ROOT = setOf("protocol", "settings", "streamSettings", "tag", "mux")
        private val ALLOWED_VLESS_SETTINGS = setOf("vnext")
        private val ALLOWED_VMESS_SETTINGS = setOf("vnext")
        private val ALLOWED_SS_TROJAN_SETTINGS = setOf("servers")
        private val ALLOWED_HYSTERIA_SETTINGS = setOf("address", "port", "version")
        private val ALLOWED_VLESS_SERVER = setOf("address", "port", "users")
        private val ALLOWED_VMESS_SERVER = setOf("address", "port", "users")
        private val ALLOWED_VLESS_USER = setOf("id", "flow", "encryption", "level", "email")
        private val ALLOWED_VMESS_USER = setOf("id", "alterId", "security", "level", "email")
        private val ALLOWED_SS_TROJAN_SERVER = setOf("address", "port", "password", "method", "level", "email")
        private val SKIP_PROTOCOLS = setOf("freedom", "blackhole", "dns", "loopback")
        // Full IPv6 literal matcher (compressed forms included); rejects `?`, `#`, `@`.
        private val IPV6 = Regex(
            "(([0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4})|" +
                "(([0-9A-Fa-f]{1,4}:){1,7}:)|" +
                "(([0-9A-Fa-f]{1,4}:){1,6}:[0-9A-Fa-f]{1,4})|" +
                "(([0-9A-Fa-f]{1,4}:){1,5}(:[0-9A-Fa-f]{1,4}){1,2})|" +
                "(([0-9A-Fa-f]{1,4}:){1,4}(:[0-9A-Fa-f]{1,4}){1,3})|" +
                "(([0-9A-Fa-f]{1,4}:){1,3}(:[0-9A-Fa-f]{1,4}){1,4})|" +
                "(([0-9A-Fa-f]{1,4}:){1,2}(:[0-9A-Fa-f]{1,4}){1,5})|" +
                "([0-9A-Fa-f]{1,4}:)((:[0-9A-Fa-f]{1,4}){1,6})|" +
                "(:((:[0-9A-Fa-f]{1,4}){1,7}|:))",
        )
    }

    private fun JsonObject.str(key: String) = (get(key) as? JsonPrimitive)?.contentOrNull
    private fun JsonObject.obj(key: String) = get(key) as? JsonObject ?: JsonObject(emptyMap())
    private fun JsonObject.array(key: String) = get(key) as? JsonArray ?: JsonArray(emptyList())
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")
    fun inspect(text: String): ImportReport {
        val profiles = mutableListOf<VpnProfile>()
        val issues = mutableListOf<ImportIssue>()
        val seen = mutableSetOf<String>()
        var duplicates = 0
        try {
            require(boundedNesting(text))
            var generatedChars = 0
            
            // By parsing into a DTO, kotlinx.serialization skips generating a DOM 
            // for routing, dns, and inbounds, heavily reducing memory usage.
            val firstChar = text.find { !it.isWhitespace() }
            val configs = if (firstChar == '[') {
                json.decodeFromString<List<XrayConfigDto>>(text)
            } else {
                listOf(json.decodeFromString<XrayConfigDto>(text))
            }
            
            var index = 0
            for (config in configs) {
                val outbounds = config.outbounds ?: continue
                for (entry in outbounds) {
                    index++
                    if (index > DefaultLinkParser.MAX_LINES) { issues += ImportIssue(index, "Слишком много JSON-узлов"); break }
                    val o = entry
                    if (o.str("protocol") in SKIP_PROTOCOLS) continue
                    val converted = runCatching {
                        val oStr = o.toString()
                        require(oStr.length <= 32_768)
                        links(o, oStr)
                    }.getOrNull()
                    if (converted == null || converted.isEmpty()) { issues += ImportIssue(index, "Неподдерживаемый или повреждённый JSON outbound"); continue }
                    for (uri in converted) {
                        generatedChars += uri.length
                        require(generatedChars <= 4_194_304 && profiles.size < DefaultLinkParser.MAX_LINES)
                        val p = parser.parse(uri)
                        if (p == null) issues += ImportIssue(index, "Некорректные параметры JSON-узла")
                        else if (seen.add(p.connectionIdentity())) profiles += p else duplicates++
                    }
                }
            }
            if (profiles.isEmpty() && issues.isEmpty()) issues += ImportIssue(0, "В JSON нет поддерживаемых прокси-узлов")
        } catch (e: Exception) {
            // No source JSON, UUID, server or tokens in exception text.
            return ImportReport(issues = listOf(ImportIssue(0, "Нужен Xray JSON с массивом outbounds; sing-box/Clash JSON и YAML пока не поддерживаются")))
        }
        return ImportReport(profiles, issues, duplicates)
    }
    private fun boundedNesting(text: String): Boolean {
        var depth = 0
        var quoted = false
        var escaped = false
        for (ch in text) {
            if (quoted) {
                if (escaped) escaped = false else if (ch == '\\') escaped = true else if (ch == '"') quoted = false
            } else when (ch) {
                '"' -> quoted = true
                '{', '[' -> { depth++; if (depth > 64) return false }
                '}', ']' -> { depth--; if (depth < 0) return false }
            }
        }
        return depth == 0 && !quoted
    }
    private fun links(o: JsonObject, oStr: String): List<String> {
        val protocol = o.str("protocol") ?: error("protocol")
        val s = o.obj("settings")
        val stream = o.obj("streamSettings")
        val declaredNet = stream.str("network") ?: "tcp"
        val net = TransportCompat.normalize(declaredNet)
        val security = stream.str("security") ?: "none"
        val tls = stream.obj(if (security == "reality") "realitySettings" else "tlsSettings")
        val q = linkedMapOf<String, String>()
        fun put(key: String, value: String?) { if (value != null) q[key] = value }
        put("type", if (declaredNet == "hysteria") "tcp" else net)
        put("security", security); put("sni", tls.str("serverName")); put("fp", tls.str("fingerprint"))
        put("pbk", tls.str("publicKey")); put("sid", tls.str("shortId")); put("spx", tls.str("spiderX"))
        put("pinSHA256", tls.str("pinnedPeerCertSha256"))
        if (tls.str("allowInsecure") == "true") put("insecure", "1")
        val alpn = tls.array("alpn").mapNotNull { (it as? JsonPrimitive)?.contentOrNull }
        if (alpn.isNotEmpty()) put("alpn", alpn.joinToString(","))
        // "rawSettings" is the Xray 1.8.16+ name of "tcpSettings"; read whichever is present.
        val tr = when (net) {
            "ws" -> stream.obj("wsSettings")
            "grpc" -> stream.obj("grpcSettings")
            "xhttp" -> stream.obj("xhttpSettings")
            "httpupgrade" -> stream.obj("httpupgradeSettings")
            "http" -> stream.obj("httpSettings")
            else -> stream.obj("rawSettings").takeIf { it.isNotEmpty() } ?: stream.obj("tcpSettings")
        }
        put("host", tr.str("host") ?: tr.obj("headers").str("Host")); put("path", tr.str("path"))
        put("serviceName", tr.str("serviceName")); put("mode", tr.str("mode"))
        if (tr.str("multiMode") == "true") put("mode", "multi")
        // Preserve original outbound (encrypted by storage). Unknown behavior blocks connection,
        // not the entire subscription. Users can still inspect/export the node.
        put("cyrus-xray", Base64.getUrlEncoder().withoutPadding().encodeToString(oStr.toByteArray(Charsets.UTF_8)))
        // `header` is written by Xray even when there is no camouflage at all
        // (`{"type":"none"}`), and "no camouflage" is exactly what ConfigFactory accepts
        // (`headerType` in null/""/"none"). Keying on the name alone blocked 13 of 46
        // provider nodes that carry no obfuscation; only a real type is unsupported.
        val headerType = tr.obj("header").str("type")
        val headerSupported = "header" !in tr || headerType.isNullOrBlank() || headerType == "none"
        if (stream.keys.any { it !in ALLOWED_STREAM } || tls.keys.any { it !in ALLOWED_TLS } ||
            tr.keys.any { it != "header" && it !in ALLOWED_TRANSPORT } || !headerSupported ||
            tr.obj("headers").keys.any { it != "Host" } ||
            o.keys.any { it !in ALLOWED_ROOT })
            put("cyrus-unsupported", "xray-options")
        val knownSettings = when (protocol) {
            "vless" -> ALLOWED_VLESS_SETTINGS
            "vmess" -> ALLOWED_VMESS_SETTINGS
            "trojan", "shadowsocks" -> ALLOWED_SS_TROJAN_SETTINGS
            "hysteria" -> ALLOWED_HYSTERIA_SETTINGS
            else -> emptySet()
        }
        if (s.keys.any { it !in knownSettings }) put("cyrus-unsupported", "settings-options")
        require(s.array("vnext").size <= 100 && s.array("servers").size <= 100)
        val name = o.str("tag") ?: protocol
        fun uri(scheme: String, auth: String, address: String, port: Int, options: Map<String, String>): String {
            require(port in 1..65535)
            // Untrusted `address` must never inject `?`, `#`, `@` or `/` into the URI
            // authority. IPv6 literals keep their colons inside brackets; anything else
            // is percent-encoded.
            val host = if (':' in address) {
                require(IPV6.matches(address)) { "Некорректный IPv6-адрес" }
                "[$address]"
            } else {
                enc(address)
            }
            return "$scheme://$auth@$host:$port?" + options.entries.joinToString("&") { enc(it.key) + "=" + enc(it.value) } + "#" + enc(name)
        }
        return when (protocol) {
            "vless" -> s.array("vnext").flatMap { endpoint ->
                val server = endpoint.jsonObject
                require(server.array("users").size <= 100)
                val serverUnsupported = server.keys.any { it !in ALLOWED_VLESS_SERVER }
                server.array("users").map { item ->
                    val user = item.jsonObject
                    // Per-node copy: mutating a shared map leaks one node's flags into
                    // every later node of the same outbound.
                    val params = q.toMutableMap()
                    if (serverUnsupported) params["cyrus-unsupported"] = "server-options"
                    user.str("flow")?.let { params["flow"] = it }
                    user.str("encryption")?.let { params["encryption"] = it }
                    if (user.keys.any { it !in ALLOWED_VLESS_USER }) params["cyrus-unsupported"] = "user-options"
                    uri("vless", enc(requireNotNull(user.str("id"))), requireNotNull(server.str("address")), server.str("port")!!.toInt(), params)
                }
            }
            "vmess" -> s.array("vnext").flatMap { endpoint ->
                val server = endpoint.jsonObject
                require(server.array("users").size <= 100)
                val serverUnsupported = server.keys.any { it !in ALLOWED_VMESS_SERVER }
                server.array("users").map { item ->
                    val user = item.jsonObject
                    val params = q.toMutableMap()
                    if (serverUnsupported) params["cyrus-unsupported"] = "server-options"
                    if (user.keys.any { it !in ALLOWED_VMESS_USER }) params["cyrus-unsupported"] = "user-options"
                    val address = requireNotNull(server.str("address"))
                    val port = requireNotNull(server.str("port")).toInt()
                    // A vmess:// link is a base64 JSON body, not a query URI: nothing from
                    // `q` survives it. Every field the parser reads back -- and the two
                    // Cyrus markers -- must be written into the body explicitly, or the
                    // node silently degrades to plain TCP with no way to rebuild the
                    // original outbound.
                    //
                    // Built as Map<String, JsonElement> on purpose: `buildJsonObject`
                    // shares the name `put` with the query helper above, and the local
                    // function wins overload resolution -- it silently swallowed every
                    // field and produced `vmess://e30=` (an empty `{}`).
                    val host = tr.str("host") ?: tr.obj("headers").str("Host")
                    val mode = if (tr.str("multiMode") == "true") "multi" else tr.str("mode")
                    val vmess = JsonObject(buildMap<String, JsonElement> {
                        put("v", JsonPrimitive("2"))
                        put("ps", JsonPrimitive(name))
                        put("add", JsonPrimitive(address))
                        put("port", JsonPrimitive(port.toString()))
                        put("id", JsonPrimitive(requireNotNull(user.str("id"))))
                        put("aid", JsonPrimitive(user.str("alterId") ?: "0"))
                        put("scy", JsonPrimitive(user.str("security") ?: "auto"))
                        put("net", JsonPrimitive(net))
                        put("type", JsonPrimitive("none"))
                        host?.let { put("host", JsonPrimitive(it)) }
                        tr.str("path")?.let { put("path", JsonPrimitive(it)) }
                        tr.str("serviceName")?.let { put("path", JsonPrimitive(it)) }
                        mode?.let { put("mode", JsonPrimitive(it)) }
                        if (security == "tls" || security == "reality") {
                            put("tls", JsonPrimitive("tls"))
                            tls.str("serverName")?.let { put("sni", JsonPrimitive(it)) }
                        }
                        tls.str("fingerprint")?.let { put("fp", JsonPrimitive(it)) }
                        q["alpn"]?.let { put("alpn", JsonPrimitive(it)) }
                        // Same per-node markers as vless: without them a vmess node would
                        // keep neither its original outbound nor its "unsupported" flag.
                        params["cyrus-xray"]?.let { put("cyrus-xray", JsonPrimitive(it)) }
                        params["cyrus-unsupported"]?.let { put("cyrus-unsupported", JsonPrimitive(it)) }
                    })
                    val encoded = Base64.getEncoder().encodeToString(vmess.toString().toByteArray(Charsets.UTF_8))
                    "vmess://$encoded"
                }
            }
            "trojan", "shadowsocks" -> s.array("servers").map { item ->
                val server = item.jsonObject
                val params = q.toMutableMap()
                if (server.keys.any { it !in ALLOWED_SS_TROJAN_SERVER }) params["cyrus-unsupported"] = "server-options"
                val password = requireNotNull(server.str("password"))
                val auth = if (protocol == "trojan") enc(password) else Base64.getUrlEncoder().withoutPadding()
                    .encodeToString("${requireNotNull(server.str("method"))}:$password".toByteArray(Charsets.UTF_8))
                uri(if (protocol == "trojan") "trojan" else "ss", auth, requireNotNull(server.str("address")), server.str("port")!!.toInt(), params)
            }
            "hysteria" -> {
                require(s.str("version") == "2" || stream.obj("hysteriaSettings").str("version") == "2")
                // `fp` is kept, but it no longer marks the node unsupported. A uTLS
                // fingerprint is inert on QUIC in both cores this app can build for -
                // sing-box's uTLS config has no QUIC path, and Xray's hysteria2 ignores
                // the field too - so the parameter describes nothing that the connection
                // needs. Blocking the node for it rejected a working key over a decorative
                // field: measured on the device pool of 2026-09-20, it was the single
                // hysteria2 node out of three that never reached the prober.
                //
                // It is NOT applied either: sing-box's uTLS config has no QUIC entry
                // point, so the value never reaches the QUIC handshake - and emitting it
                // anyway was measured on device to be a harmless no-op rather than the
                // improvement it looks like. See ConfigFactory's `utls` handling.
                listOf(uri("hy2", enc(requireNotNull(stream.obj("hysteriaSettings").str("auth"))), requireNotNull(s.str("address")), s.str("port")!!.toInt(), q))
            }
            else -> error("unsupported")
        }
    }
}
