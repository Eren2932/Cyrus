package dev.kentra.vpn.link

import java.util.Base64
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.CodingErrorAction

internal fun String.decodeBase64OrNull(): String? {
    val cleaned = filterNot { it.isWhitespace() }
    if (cleaned.isEmpty() || cleaned.length % 4 == 1) return null
    val pad = when (cleaned.length % 4) {
        2 -> "=="
        3 -> "="
        else -> ""
    }
    val padded = cleaned + pad
    // Catch only recoverable decode failures. Error (OOM, LinkageError) must propagate
    // instead of being masked as "not base64" by a blanket runCatching.
    val bytes = try {
        Base64.getDecoder().decode(padded)
    } catch (_: IllegalArgumentException) {
        try {
            Base64.getUrlDecoder().decode(padded)
        } catch (_: IllegalArgumentException) {
            return null
        }
    }
    return try {
        Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString()
    } catch (_: CharacterCodingException) {
        null
    }
}
