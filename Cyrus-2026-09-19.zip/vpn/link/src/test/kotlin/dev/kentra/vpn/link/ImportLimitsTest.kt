package dev.kentra.vpn.link

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Boundary tests for the import DoS limits (H-1). They assert the limit is actually
 * the reason for rejection, not an incidental parse failure.
 */
class ImportLimitsTest {
    private val parser = DefaultLinkParser(idFactory = { "fixed-id" }, clock = { 0L })

    /** A payload that cannot be mistaken for base64 (`://` present) and has no whitespace. */
    private fun payloadOfLength(length: Int): String {
        val prefix = "vless://x"
        return prefix + "a".repeat(length - prefix.length)
    }

    @Test
    fun `payload exactly at MAX_INPUT passes the size gate`() {
        val report = parser.inspect(payloadOfLength(DefaultLinkParser.MAX_INPUT))
        assertFalse(report.issues.any { it.reason.contains("Лимит импорта") })
    }

    @Test
    fun `payload one char over MAX_INPUT is rejected by the size limit`() {
        val report = parser.inspect(payloadOfLength(DefaultLinkParser.MAX_INPUT + 1))
        assertEquals(1, report.issues.size)
        assertTrue(report.issues.single().reason.contains("Лимит импорта"))
        assertTrue(report.profiles.isEmpty())
    }

    @Test
    fun `base64 payload over its own stricter limit is rejected`() {
        val blob = "A".repeat(DefaultLinkParser.MAX_BASE64_INPUT + 1)
        val report = parser.inspect(blob)
        assertTrue(report.issues.any { it.reason.contains("base64") })
        assertTrue(report.profiles.isEmpty())
    }

    @Test
    fun `line limit is reported exactly once at line 2001`() {
        val lines = (1..DefaultLinkParser.MAX_LINES + 1).joinToString("\n") { "bad://node$it" }
        val report = parser.inspect(lines)
        val limitIssues = report.issues.filter { it.reason.contains("2000 строк") }
        assertEquals(1, limitIssues.size)
        assertEquals(DefaultLinkParser.MAX_LINES + 1, limitIssues.single().line)
        assertTrue(report.profiles.isEmpty())
    }
}
