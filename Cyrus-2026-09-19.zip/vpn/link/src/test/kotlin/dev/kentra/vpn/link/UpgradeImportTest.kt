package dev.kentra.vpn.link

import dev.kentra.domain.model.*
import org.junit.Assert.*
import org.junit.Test

class UpgradeImportTest {
    private val parser = DefaultLinkParser(clock={0})
    private val uuid = "11111111-2222-4333-8444-555555555555"
    @Test fun `sanitized real provider format variants preserve all nodes`() {
        val expected=mapOf("happ.json" to 4,"v2raytun.json" to 3,"v2rayng.txt" to 4,"nekobox.txt" to 2,"hiddify.txt" to 1)
        for((name,count) in expected) {
            val content=requireNotNull(javaClass.getResource("/subscriptions/$name")).readText()
            val report=parser.inspect(content)
            assertTrue("$name: ${report.issues}",report.issues.isEmpty())
            assertEquals(name,count,report.profiles.size)
        }
    }
    @Test fun `deeply nested JSON fails without parsing recursion`() {
        val r=parser.inspect("[".repeat(1000)+"0"+"]".repeat(1000))
        assertTrue(r.profiles.isEmpty());assertTrue(r.issues.isNotEmpty())
    }
    @Test fun `oversize JSON outbound is rejected not expanded`() {
        val r=parser.inspect("""{"outbounds":[{"protocol":"vless","tag":"${"x".repeat(40_000)}"}]}""")
        assertTrue(r.profiles.isEmpty());assertTrue(r.issues.isNotEmpty())
    }
    @Test fun `anonymous SOCKS5`() { val p=parser.parse("socks5://proxy.example:1080")!!;assertEquals(VpnProtocol.SOCKS,p.protocol);assertNull(p.password);assertEquals("5",p.parameters["version"]) }
    @Test fun `SOCKS4a username and IPv6`() { val p=parser.parse("socks4a://name@[2001:db8::1]:1081")!!;assertEquals("4a",p.parameters["version"]);assertEquals("name",p.parameters["username"]) }
    @Test fun `HTTP proxy auth survives escaped separators`() { val p=parser.parse("http://us%3Aer:p%40ss+word@proxy.example:3128")!!;assertEquals("us:er",p.parameters["username"]);assertEquals("p@ss+word",p.password);assertFalse(p.tls.enabled) }
    @Test fun `HTTPS proxy TLS default`() { val p=parser.parse("https://user:password@proxy.example")!!;assertTrue(p.tls.enabled);assertEquals(443,p.port) }
    @Test fun `anonymous HTTPS endpoint is a TLS proxy not garbage`() {
        val p = requireNotNull(parser.parse("https://example.com"))
        assertEquals(VpnProtocol.HTTP, p.protocol)
        assertEquals("example.com", p.server)
        assertEquals(443, p.port)
        assertTrue(p.tls.enabled)
        assertNull(p.password)
        assertNull(p.parameters["username"])
    }
    @Test fun `anonymous HTTP endpoint keeps the documented default proxy port`() {
        val p = requireNotNull(parser.parse("http://proxy.example"))
        assertEquals(VpnProtocol.HTTP, p.protocol)
        assertEquals(8080, p.port)
        assertFalse(p.tls.enabled)
        assertNull(p.password)
        assertNull(p.parameters["username"])
    }
    @Test fun `HTTPS proxy explicit port and root path remain valid`() {
        val p = requireNotNull(parser.parse("https://proxy.example:8443/"))
        assertEquals(8443, p.port)
        assertTrue(p.tls.enabled)
    }
    @Test fun `subscription URL is rejected by single proxy parser and reported by key importer`() {
        val url = "https://sub.example/sub/test-only-token?app=hiddify"
        assertNull(parser.parse(url))
        val report = parser.inspect(url)
        assertTrue(report.profiles.isEmpty())
        assertEquals(1, report.issues.size)
    }
    @Test fun `HTTPS proxy malformed authority and credentials are rejected`() {
        for (link in listOf("https://", "https://:443", "https://user@proxy.example",
            "https://proxy.example:", "https://proxy.example:0", "https://proxy.example:65536")) {
            assertNull("Malformed synthetic proxy must be rejected: $link", parser.parse(link))
        }
    }
    @Test fun `HTTPS proxy survives canonical export without credentials`() {
        val p = requireNotNull(parser.parse("https://proxy.example:8443"))
        val restored = requireNotNull(parser.parse(parser.export(p)))
        assertEquals(p.protocol, restored.protocol)
        assertEquals(p.server, restored.server)
        assertEquals(p.port, restored.port)
        assertTrue(restored.tls.enabled)
        assertNull(restored.password)
        assertNull(restored.parameters["username"])
    }
    @Test fun `subscription path is not a proxy`() { assertNull(parser.parse("https://sub.example/sub/test-only-token?app=happ")) }
    @Test fun `proxy malformed port fails`() { assertNull(parser.parse("socks5://proxy.example:0"));assertNull(parser.parse("http://u:p@proxy.example:65536")) }
    @Test fun `editing fields changes exported Reality connection without dropping extra fields`() {
        val p=parser.parse("vless://$uuid@old.example:443?security=reality&pbk=test-public-key&sid=ab&flow=xtls-rprx-vision&vendor=test-only#Old")!!
        val exported=parser.export(p.copy(server="new.example",port=8443,name="Новый + узел",tls=p.tls.copy(serverName="cdn.example")))
        val result=parser.parse(exported)!!
        assertEquals("new.example",result.server);assertEquals(8443,result.port);assertEquals("Новый + узел",result.name)
        assertEquals("cdn.example",result.tls.serverName);assertEquals("test-only",result.parameters["vendor"]);assertEquals("ab",result.tls.reality?.shortId)
    }
    @Test fun `export clear SNI does not resurrect peer alias`() {
        val p=parser.parse("trojan://test-only-secret@proxy.example?peer=old.example")!!
        assertNull(parser.parse(parser.export(p.copy(tls=p.tls.copy(serverName=null))))!!.tls.serverName)
    }
    @Test fun `all canonical formats roundtrip secrets`() {
        val links=listOf("vless://$uuid@proxy.example?security=tls&sni=cdn.example&type=ws&path=%2Fedge&host=cdn.example",
            "trojan://p%3A%40%2B%25@proxy.example", "tuic://$uuid:p%3A%40%2B%25@proxy.example?congestion_control=bbr&alpn=h3",
            "hy2://p%3A%40%2B%25@proxy.example?obfs=salamander&obfs-password=test-only", "ss://aes-256-gcm:p%3A%40%2B%25@proxy.example:8388",
            "socks5://u:p%3A%40%2B%25@proxy.example:1080", "https://u:p%3A%40%2B%25@proxy.example:443",
            "ssh://user:p%3A%40%2B%25@proxy.example:22", "naive+https://user:p%3A%40%2B%25@proxy.example:443?sni=cdn.example")
        for(link in links) { val p=parser.parse(link)!!;val q=parser.parse(parser.export(p))!!
            assertEquals(p.protocol,q.protocol);assertEquals(p.server,q.server);assertEquals(p.port,q.port);assertEquals(p.password,q.password);assertEquals(p.uuid,q.uuid)
        }
    }

    @Test fun `wireguard URI roundtrips percent-encoded private key`() {
        val privateKey = "AbCdEfGhIjKlMnOpQrStUvWxYz0123456789+/=="
        val publicKey = "0123456789abcdefghijklmnopqrstuvABCDEFGHijk="
        val encodedKey = java.net.URLEncoder.encode(privateKey, "UTF-8")
        val p = requireNotNull(parser.parse(
            "wireguard://${encodedKey}@10.0.0.2/32?endpoint=wg.example:51820&public_key=$publicKey",
        ))
        val restored = requireNotNull(parser.parse(parser.export(p)))
        assertEquals(VpnProtocol.WIREGUARD, restored.protocol)
        assertEquals(privateKey, restored.password)
        assertEquals("10.0.0.2/32", restored.parameters["local_address"])
        assertEquals("wg.example", restored.server)
    }
    @Test fun `Xray list imports nodes but never DNS inbound or routing policy`() {
        val text="""[{"inbounds":[{"protocol":"socks","port":9999}],"dns":{"servers":["localhost"]},"routing":{"domainStrategy":"AsIs"},"outbounds":[
          {"tag":"WS region label","protocol":"vless","settings":{"vnext":[{"address":"ws.example","port":8443,"users":[{"id":"$uuid","encryption":"none"}]}]},"streamSettings":{"network":"ws","security":"tls","tlsSettings":{"serverName":"cdn.example","fingerprint":"firefox"},"wsSettings":{"host":"cdn.example","path":"/edge"}}},
          {"tag":"XHTTP preserved","protocol":"vless","settings":{"vnext":[{"address":"xh.example","port":443,"users":[{"id":"$uuid"}]}]},"streamSettings":{"network":"xhttp","security":"tls","xhttpSettings":{"host":"cdn.example","path":"/x","mode":"auto"}}},
          {"protocol":"freedom"},{"protocol":"blackhole"}]}]"""
        val report=parser.inspect(text);assertTrue(report.issues.toString(),report.issues.isEmpty());assertEquals(2,report.profiles.size)
        assertEquals("ws",report.profiles[0].transport.type);assertEquals("xhttp",report.profiles[1].transport.type)
        assertNotNull(report.profiles[0].parameters["cyrus-xray"]);assertFalse(report.profiles[0].parameters.containsKey("routing"))
    }
    @Test fun `direct VMess xhttp URI parses`() {
        val link = "vmess://eyJ2IjoiMiIsInBzIjoidm1lc3MteGh0dHAiLCJhZGQiOiJ2bWVzcy5leGFtcGxlIiwicG9ydCI6IjQ0MyIsImlkIjoiMTExMTExMTEtMjIyMi00MzMzLTg0NDQtNTU1NTU1NTU1NTU1IiwiYWlkIjoiMCIsInNjeSI6ImF1dG8iLCJuZXQiOiJ4aHR0cCIsInR5cGUiOiJub25lIiwicGF0aCI6Ii94IiwidGxzIjoidGxzIiwic25pIjoiY2RuLmV4YW1wbGUifQ=="
        val p = requireNotNull(parser.parse(link))
        assertEquals(VpnProtocol.VMESS, p.protocol)
        assertEquals("xhttp", p.transport.type)
    }

    @Test fun `Xray JSON VMess is imported and keeps its Xray-only transport`() {
        val text = """{"outbounds":[{"tag":"vmess-xhttp","protocol":"vmess","settings":{"vnext":[{"address":"vmess.example","port":443,"users":[{"id":"$uuid","alterId":0,"security":"auto"}]}]},"streamSettings":{"network":"xhttp","security":"tls","tlsSettings":{"serverName":"cdn.example"},"xhttpSettings":{"path":"/x","mode":"auto"}}}]}"""
        val report = parser.inspect(text)
        assertTrue(report.issues.toString(), report.issues.isEmpty())
        val p = report.profiles.single()
        assertEquals(VpnProtocol.VMESS, p.protocol)
        assertEquals("xhttp", p.transport.type)
        assertEquals("auto", p.parameters["mode"])
        assertEquals("/x", p.parameters["path"])
        assertEquals("cdn.example", p.parameters["sni"])
        // A vmess:// body is not a query URI: without this the node loses its
        // original outbound and there is no way back to the Xray-only transport.
        assertNotNull("cyrus-xray must survive the JSON->vmess round trip", p.parameters["cyrus-xray"])
    }

    @Test fun `unknown Xray behavioral fields remain marked unsupported`() {
        val text="""{"outbounds":[{"protocol":"vless","settings":{"vnext":[{"address":"proxy.example","port":443,"users":[{"id":"$uuid"}]}]},"streamSettings":{"network":"tcp","sockopt":{"dialerProxy":"other"}}}]}"""
        val p=parser.inspect(text).profiles.single();assertNotNull(p.parameters["cyrus-unsupported"])
    }
    // Real provider nodes (43 of 46 in the 2026-09-19 device pool) carried `mux`, a
    // cosmetic `show` flag, `heartbeatPeriod` and `header.type=none`. None of those is
    // unsupported behaviour, but every one of them tripped the allowlists and blocked
    // the node -- see DEVICE_TEST_0.5.0.md §13.2б.
    @Test fun `multiplex is a known field and does not block the node`() {
        val text="""{"outbounds":[{"protocol":"vless","mux":{"enabled":true,"concurrency":8},"settings":{"vnext":[{"address":"proxy.example","port":443,"users":[{"id":"$uuid"}]}]},"streamSettings":{"network":"tcp","security":"reality","realitySettings":{"serverName":"cdn.example","publicKey":"pk","shortId":"sid","show":false},"tcpSettings":{"header":{"type":"none"}}}}]}"""
        val p=parser.inspect(text).profiles.single()
        assertNull("mux/show/header-none must not mark a node unsupported: ${p.parameters}",
            p.parameters["cyrus-unsupported"])
    }
    @Test fun `websocket heartbeat interval is a known field`() {
        val text="""{"outbounds":[{"protocol":"vless","settings":{"vnext":[{"address":"proxy.example","port":443,"users":[{"id":"$uuid"}]}]},"streamSettings":{"network":"ws","security":"tls","tlsSettings":{"serverName":"cdn.example"},"wsSettings":{"path":"/edge","headers":{"Host":"cdn.example"},"heartbeatPeriod":30}}}]}"""
        val p=parser.inspect(text).profiles.single()
        assertNull("heartbeatPeriod must not mark a node unsupported: ${p.parameters}",
            p.parameters["cyrus-unsupported"])
    }
    // `fp` on a hysteria2 node is a uTLS fingerprint. It cannot be applied to a QUIC
    // handshake by either core, so it is inert rather than unrepresentable - marking the
    // node unsupported for it threw away a working key over a decorative field.
    @Test fun `hysteria fingerprint is retained but does not mark the node unsupported`() {
        val text="""{"outbounds":[{"protocol":"hysteria","settings":{"address":"proxy.example","port":443,"version":2},"streamSettings":{"network":"hysteria","security":"tls","hysteriaSettings":{"auth":"test-only-not-a-real-password","version":2},"tlsSettings":{"alpn":["h3"],"fingerprint":"firefox","serverName":"proxy.example"}}}]}"""
        val p=parser.inspect(text).profiles.single()
        assertNull("fp must not mark a hysteria2 node unsupported: ${p.parameters}",
            p.parameters["cyrus-unsupported"])
        assertEquals("the fingerprint stays on the key", "firefox", p.tls.fingerprint)
        assertEquals("h3", p.tls.alpn.single())
    }
    @Test fun `tcp header camouflage other than none is still unsupported`() {
        val text="""{"outbounds":[{"protocol":"vless","settings":{"vnext":[{"address":"proxy.example","port":443,"users":[{"id":"$uuid"}]}]},"streamSettings":{"network":"tcp","tcpSettings":{"header":{"type":"http","request":{"path":["/"]}}}}}]}"""
        val p=parser.inspect(text).profiles.single()
        assertNotNull("real TCP camouflage must stay blocked", p.parameters["cyrus-unsupported"])
    }
    @Test fun `malformed JSON issue does not contain secrets`() { val r=parser.inspect("{\"outbounds\": SECRET-TEST-ONLY}");assertTrue(r.profiles.isEmpty());assertFalse(r.issues.toString().contains("SECRET-TEST-ONLY")) }
    @Test fun `unknown JSON protocol is explicit not silently dropped`() { val r=parser.inspect("""{"outbounds":[{"protocol":"unsupported-vendor"}]}""");assertEquals(1,r.issues.size) }
}
