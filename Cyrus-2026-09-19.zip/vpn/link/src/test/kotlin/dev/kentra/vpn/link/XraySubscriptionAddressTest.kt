package dev.kentra.vpn.link

import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * An untrusted `address` in Xray JSON must not be able to inject `?`, `#`, `@` or `:`
 * into the generated URI authority (M in `XraySubscriptionReader`).
 */
class XraySubscriptionAddressTest {
    private val parser = DefaultLinkParser(idFactory = { "fixed-id" }, clock = { 0L })
    private val uuid = "11111111-2222-3333-4444-555555555555"

    private fun node(tag: String, address: String) =
        """{"protocol":"vless","tag":"$tag","settings":{"vnext":[{"address":"$address","port":443,"users":[{"id":"$uuid","encryption":"none"}]}]}}"""

    @Test
    fun `address metacharacters do not leak into the parsed server host`() {
        val json = "{\"outbounds\":[" +
            node("frag", "1.2.3.4#frag") + "," +
            node("query", "1.2.3.4?x=1") + "," +
            node("userinfo", "a@b.c") + "," +
            node("ok", "1.2.3.4") +
            "]}"
        val report = parser.inspect(json)

        // The benign node still imports, so the reader is exercised end to end.
        assertTrue("benign node must import", report.profiles.any { it.name == "ok" })
        // Whatever survived must not contain a structural URI character in the host.
        assertTrue(
            "no structural character may reach the server host",
            report.profiles.none { p -> p.server.any { it == '?' || it == '#' || it == '@' } },
        )
    }
}
