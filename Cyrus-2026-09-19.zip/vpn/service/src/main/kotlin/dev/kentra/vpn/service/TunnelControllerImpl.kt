package dev.kentra.vpn.service

import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import dev.kentra.core.common.AppError
import dev.kentra.core.datastore.SettingsStore
import dev.kentra.domain.model.TrafficSample
import dev.kentra.domain.model.TransportSettings
import dev.kentra.domain.model.TunnelState
import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.repository.TunnelController
import dev.kentra.vpn.config.ConfigFactory
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import dev.kentra.domain.model.TransportCompat
import dev.kentra.domain.model.VpnEngineKind
import dev.kentra.domain.model.VpnProtocol
import dev.kentra.vpn.config.ConnectionMode
import dev.kentra.vpn.config.XrayConfigFactory
import dev.kentra.vpn.config.xrayInboundPort

/**
 * The only bridge between the app and the VPN process.
 *
 * Note the permission contract: this class does NOT show UI. If the VPN consent dialog is
 * required it fails with [AppError.Permission] and the feature layer turns that into an
 * MVI effect. Keeping Android dialogs out of the data layer is what makes this testable.
 */
class TunnelControllerImpl(
    private val context: Context,
    private val bus: TunnelBus,
    private val settings: SettingsStore,
    private val configFactory: ConfigFactory,
    private val engine: VpnEngine,
    private val ruleSets: ProtectionRuleSets = ProtectionRuleSets(context),
) : TunnelController {

    override val state: StateFlow<TunnelState> = bus.state
    override val traffic: Flow<TrafficSample> = bus.traffic

    private val commands = Mutex()
    private var runningService: Class<out android.app.Service>? = null

    override suspend fun connect(profile: VpnProfile) = commands.withLock {
        if (engine.id == "unavailable") throw AppError.Tunnel("VPN-ядро не установлено. Ключ сохранён, но трафик не защищён.")

        if (bus.state.value is TunnelState.Preparing || bus.state.value is TunnelState.Stopping)
            throw AppError.Tunnel("Дождитесь завершения предыдущего подключения")
        val options = settings.tunnelOptions.first()
        // AmneziaWG builds its own TUN through GoBackend, which needs a real
        // VpnService. Starting it from the plain proxy service would fail deep
        // inside the Go backend, so refuse here where the message is useful.
        if (profile.protocol == VpnProtocol.AMNEZIA_WG && options.mode == ConnectionMode.PROXY)
            throw AppError.Tunnel("AmneziaWG работает только в VPN-режиме; локальный прокси для него не поддерживается.")
        val target = if (options.mode == ConnectionMode.PROXY) CyrusProxyService::class.java else CyrusVpnService::class.java
        if (runningService != null && runningService != target && bus.state.value !is TunnelState.Idle && bus.state.value !is TunnelState.Failed)
            throw AppError.Tunnel("Перед сменой режима отключите текущее соединение")
        if (options.mode == ConnectionMode.VPN && VpnService.prepare(context) != null) throw AppError.Permission("vpn-consent")
        // requiredEngine() refuses unknown transports outright; surface that as a
        // user-visible tunnel error rather than letting the exception escape.
        val requiresXray = runCatching {
            TransportCompat.requiredEngine(profile) == VpnEngineKind.XRAY
        }.getOrElse { throw AppError.Tunnel(it.message ?: "Unsupported transport") }
        var configJson: String
        var xrayJson: String? = null
        // Installed, never downloaded: the core must not need the network to build a
        // tunnel it is about to become the device's only network.
        val ruleSetPaths = ruleSets.installed()

        if (requiresXray) {
            // Xray listens on its own loopback port and Sing-box chains into it.
            // Reusing options.proxyPort here previously bound both cores to the
            // same port and pointed the chain at itself.
            val xrayPort = xrayInboundPort(options)
            xrayJson = runCatching { XrayConfigFactory().config(profile, options, xrayPort) }
                .getOrElse { throw AppError.Tunnel("Xray config build failed: ${it.message}") }

            // Sing-box owns the TUN (VPN mode) or the local port (PROXY mode)
            // and forwards everything to the Xray listener.
            // transport is cleared too: leaving the original "xhttp" on a SOCKS
            // hop made the sing-box validator refuse the chain it was asked to
            // build, with the very message meant for a key sing-box must run alone.
            val chainedProfile = profile.copy(
                protocol = VpnProtocol.SOCKS,
                server = "127.0.0.1",
                port = xrayPort,
                transport = TransportSettings(type = "tcp"),
                parameters = emptyMap()
            )
            configJson = runCatching { configFactory.build(chainedProfile, options, ruleSetPaths) }
                .getOrElse { throw AppError.Tunnel("Chained config build failed: ${it.message}") }
        } else {
            configJson = runCatching { configFactory.build(profile, options, ruleSetPaths) }
                .getOrElse { throw AppError.Tunnel("config build failed: ${it.message}") }
        }

        val owner = if (profile.protocol == VpnProtocol.AMNEZIA_WG) TunnelOwner.AMNEZIA else TunnelOwner.SING_BOX
        val intent = Intent(context, target).apply {
            action = CyrusVpnService.ACTION_START
            putExtra(CyrusVpnService.EXTRA_PROFILE_ID, profile.id)
            putExtra(CyrusVpnService.EXTRA_PROFILE_NAME, profile.name)
            putExtra(CyrusVpnService.EXTRA_CONFIG, configJson)
            putExtra(CyrusVpnService.EXTRA_TUNNEL_OWNER, owner.name)
            xrayJson?.let { putExtra(CyrusVpnService.EXTRA_XRAY_CONFIG, it) }
        }
        val previousState = bus.state.value
        val previousOwner = bus.owner
        val previousService = runningService
        runningService = target
        bus.claim(this)
        bus.publish(TunnelState.Preparing)
        try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
        } catch (error: Exception) {
            runningService = previousService
            previousOwner?.let { bus.claim(it) }
            if (previousState is TunnelState.Connected) bus.publish(previousState)
            else bus.publish(TunnelState.Failed("Android не разрешил запустить службу подключения"))
            throw AppError.Tunnel("Android не разрешил запустить службу подключения")
        }
        Unit
    }

    override suspend fun disconnect() = commands.withLock {
        if (engine.id == "unavailable") { bus.reset(); return@withLock }
        val previous = bus.state.value
        bus.publish(TunnelState.Stopping)
        try {
            context.startService(
                Intent(context, runningService ?: CyrusVpnService::class.java).setAction(CyrusVpnService.ACTION_STOP),
            )
        } catch (error: Exception) {
            bus.publish(previous)
            throw AppError.Tunnel("Android не разрешил отправить команду остановки; используйте уведомление или системные настройки VPN")
        }
        Unit
    }
}
