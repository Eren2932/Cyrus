package dev.kentra.vpn.service

import android.net.IpPrefix
import android.app.Service
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.system.Os
import android.util.Log
import dev.kentra.core.common.redactSecrets
import dev.kentra.core.datastore.ProtectionStatsStore
import dev.kentra.domain.model.ProtectionCategory
import dev.kentra.domain.model.TrafficSample
import io.nekohasekai.libbox.BoxService
import io.nekohasekai.libbox.CommandClient
import io.nekohasekai.libbox.CommandClientHandler
import io.nekohasekai.libbox.CommandClientOptions
import io.nekohasekai.libbox.Connection
import io.nekohasekai.libbox.Connections
import io.nekohasekai.libbox.CommandServer
import io.nekohasekai.libbox.CommandServerHandler
import io.nekohasekai.libbox.SystemProxyStatus
import io.nekohasekai.libbox.InterfaceUpdateListener
import io.nekohasekai.libbox.Libbox
import io.nekohasekai.libbox.NetworkInterface
import io.nekohasekai.libbox.NetworkInterfaceIterator
import io.nekohasekai.libbox.PlatformInterface
import io.nekohasekai.libbox.SetupOptions
import io.nekohasekai.libbox.StatusMessage
import io.nekohasekai.libbox.StringIterator
import io.nekohasekai.libbox.TunOptions
import io.nekohasekai.libbox.WIFIState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.net.InetAddress
import java.util.Collections
import java.util.concurrent.atomic.AtomicReference
import java.net.NetworkInterface as JavaNetworkInterface

/**
 * Real sing-box core (Phase 2). Wires libbox [PlatformInterface] to the Android VPN service:
 * TUN establishment, socket protection (routing-loop prevention) and traffic statistics.
 *
 * Integration checklist from docs/LibboxVpnEngine.kt.template:
 *   1. Libbox.setup(...)                 — once per process
 *   2. PlatformInterface implementation  — openTun / autoDetectInterfaceControl / monitor
 *   3. Libbox.newService(config, pi)     — start() throws if the core fails to come up
 *   4. stats via CommandClient(Libbox.CommandStatus) -> TrafficSample
 *   5. stop(): serialized, non-cancellable service.close(), then close our original fd
 */
internal class LibboxVpnEngine(
    private val health: CoreHealth,
    private val protectionStats: ProtectionStatsStore,
    private val inspection: MitmInspection,
) : VpnEngine {

    override val id = "libbox"

    /** writeLog below feeds CoreHealth, so the runner can ask this core for a verdict. */
    override val reportsDialFailures: Boolean get() = true

    private val serviceRef = AtomicReference<BoxService?>(null)
    private val tunFd = AtomicReference<ParcelFileDescriptor?>(null)
    private val statsHandler = AtomicReference<StatsHandler?>(null)
    private val statsThread = AtomicReference<Thread?>(null)
    private val connectionsClientRef = AtomicReference<CommandClient?>(null)
    private val connectionsThread = AtomicReference<Thread?>(null)
    private val connectionsHandler = AtomicReference<ConnectionsHandler?>(null)
    private val commandServerRef = AtomicReference<CommandServer?>(null)

    /**
     * Kept so teardown can release the network monitor. The core normally calls
     * `closeDefaultInterfaceMonitor` itself while closing, but when `box.close()` throws
     * that never happens — and the registered NetworkCallback plus its HandlerThread then
     * outlive the session, one more pair per failed disconnect.
     */
    private val platformRef = AtomicReference<AndroidPlatformInterface?>(null)

    /**
     * Serializes the start/stop lifecycle. A START intent racing an in-flight stop
     * would otherwise let stop() close the freshly created service (or vice versa),
     * leaving a dead tunnel and a stale TUN fd behind.
     */
    private val lifecycle = Mutex()

    @Volatile
    private var setupDone = false

    override suspend fun start(service: Service, session: TunnelSession) {
        withContext(Dispatchers.IO) {
            lifecycle.withLock {
                require(session.configJson.isNotBlank()) { "empty sing-box config" }

                if (!setupDone) {
                    val filesDir = service.filesDir.absolutePath
                    java.io.File(filesDir, "files").mkdirs()
                    Libbox.setup(
                        SetupOptions().apply {
                            basePath = filesDir
                            workingPath = "$filesDir/files"
                            tempPath = service.cacheDir.absolutePath
                            fixAndroidStack = true
                        },
                    )
                    setupDone = true
                }

                // Configuration contains credentials; never write it to logcat.
                // Debug builds keep a redacted copy in private storage so a failed dial
                // can be diagnosed — without it the core's own errors are invisible.
                CoreLog.append(service, "=== session start: profile=\"${session.profileName}\" configChars=${session.configJson.length} ===")
                CoreLog.appendConfig(service, session.configJson)

                // A previous session may have leaked its core and TUN (e.g. a teardown
                // that a cancelled caller skipped). Release that state first: otherwise
                // newService() below fails with "engine already running" and the user can
                // never reconnect without killing the app.
                teardownLocked()

                // This session's verdict starts from zero. Reset only after the previous
                // core is gone, so a dying core's complaints are not charged to this one.
                //
                // The topology goes with it: when a helper config is present this core's
                // only outbound is the loopback hop into Xray, so the dial markers cannot
                // fire and the monitor has to watch something else - see CoreHealth.
                health.reset(expectsLocalHop = session.xrayJson != null)

                // The core asks for a certificate only where the route sends it to
                // the mitm outbound, so this is safe to leave installed: with
                // inspection off, nothing ever asks.
                inspection.install()

                val platform = AndroidPlatformInterface(service)
                platformRef.set(platform)
                val box = Libbox.newService(session.configJson, platform)
                if (!serviceRef.compareAndSet(null, box)) {
                    runCatching { box.close() }
                    platformRef.compareAndSet(platform, null)
                    platform.closeDefaultInterfaceMonitor(null)
                    error("engine already running")
                }
                try {
                    // Returns only after the core is up; openTun() has been called by then.
                    box.start()
                    // Force the core to rebind all sockets to the physical network.
                    // Without this, it doesn't know about wlan0/rmnet despite the monitor.
                    box.resetNetwork()
                } catch (t: Throwable) {
                    serviceRef.set(null)
                    runCatching { box.close() }
                    throw t
                }
                // libbox's NewService does NOT create a command server — it only creates the
                // core. CommandClient.connect() then dials a unix socket at
                // <basePath>/command.sock, which only CommandServer.start() creates. Without
                // the server below the client's connect() fails, the core's status never
                // arrives, and the UI shows "—" for traffic forever while packets are flowing
                // (docs/DEVICE_TEST_0.5.0.md §3.4).
                //
                // setService() is what makes a status readable at all: readStatus() reads the
                // Clash server's TrafficManager and reports TrafficAvailable=false without a
                // service. The Clash server itself always exists here, because libbox passes a
                // non-nil PlatformLogWriter, which forces sing-box to build one even with no
                // `experimental.clash_api`; with no external_controller it opens no port, so
                // this adds no listening socket to the device.
                val commandServer = Libbox.newCommandServer(AndroidCommandServerHandler(), COMMAND_LOG_LINES)
                // Registered before start(): a throw from setService/start must stay reachable
                // by teardown, or the socket outlives the session.
                commandServerRef.set(commandServer)
                commandServer.setService(box)
                commandServer.start()

                // Only now: the clients must dial a socket that already exists.
                startStats(service)
                startConnections(service)
            }
        }
    }

    override suspend fun stop() {
        android.util.Log.d("LibboxVpnEngine", "stop: starting")
        // NonCancellable: stop() must complete even when the calling tunnelJob was
        // cancelled (a cancelled coroutine's withContext throws before running the
        // block, which would leak the BoxService and the TUN fd — and the system
        // VPN would keep routing after the user pressed disconnect).
        withContext(NonCancellable + Dispatchers.IO) {
            lifecycle.withLock { teardownLocked() }
        }
        android.util.Log.d("LibboxVpnEngine", "stop: done")
    }

    /**
     * Releases the BoxService and the TUN descriptor. Must be called with [lifecycle] held.
     * Idempotent: safe on a never-started engine and safe to call twice.
     *
     * Throws if the TUN descriptor could not be closed — that is the one failure that
     * leaves the device routing every packet into a dead tunnel, so the caller must know.
     */
    private fun teardownLocked() {
        var failure: Throwable? = null

        // Before the box: no connection may still be asking for a certificate
        // when the core that would use it is gone.
        inspection.uninstall()

        android.util.Log.d("LibboxVpnEngine", "stop: waiting for command clients")
        connectionsThread.getAndSet(null)?.let { t ->
            runCatching { connectionsClientRef.getAndSet(null)?.disconnect() }
            runCatching { t.interrupt() }
            runCatching { t.join(2_000) }
        }
        connectionsHandler.getAndSet(null)
        statsThread.getAndSet(null)?.let { t ->
            runCatching { clientRef.getAndSet(null)?.disconnect() }
            runCatching { t.interrupt() }
            runCatching { t.join(2_000) }
        }
        statsHandler.getAndSet(null)
        // Closed before the box: the client must lose its endpoint while the service that
        // answers it is still alive, otherwise a late status lands on a dead session.
        commandServerRef.getAndSet(null)?.let { server ->
            android.util.Log.d("LibboxVpnEngine", "stop: closing command server")
            // Not routed into `failure`: the command server holds no TUN, so failing to close
            // it cannot strand traffic and must not trigger the fail-closed path.
            runCatching { server.close() }
                .onFailure { android.util.Log.e("LibboxVpnEngine", "stop: command server close failed: ${it::class.java.simpleName}") }
        }
        serviceRef.getAndSet(null)?.let { box ->
            android.util.Log.d("LibboxVpnEngine", "stop: closing libbox")
            // The pinned core closes its instance in a Go goroutine; serialize lifecycle here.
            runCatching { box.close() }.onFailure { failure = it }
            android.util.Log.d("LibboxVpnEngine", "stop: libbox closed")
        }
        tunFd.getAndSet(null)?.let { fd ->
            android.util.Log.d("LibboxVpnEngine", "stop: closing tunFd")
            // The ORIGINAL established descriptor (we kept ownership).
            // Closing it is what makes the kernel drop the TUN and the system
            // unregister the VPN network.
            runCatching { fd.close() }.onFailure { failure = it } // never leak a stale tunnel fd
            android.util.Log.d("LibboxVpnEngine", "stop: tunFd closed")
        }

        // Released unconditionally and before the throw below: the core would normally
        // do this while closing, but a box.close() that threw never got there. Neither a
        // registered NetworkCallback nor a live HandlerThread holds the TUN, so a failure
        // here must not join `failure` — but leaking them would keep the process
        // subscribed to network changes forever.
        platformRef.getAndSet(null)?.let { platform ->
            android.util.Log.d("LibboxVpnEngine", "stop: releasing network monitor")
            runCatching { platform.closeDefaultInterfaceMonitor(null) }
                .onFailure { android.util.Log.e("LibboxVpnEngine", "stop: monitor release failed: ${it::class.java.simpleName}") }
        }

        failure?.let { throw it }
    }

    private val clientRef = AtomicReference<CommandClient?>(null)

    /** Cumulative counters + instantaneous speeds reported by the core, polled once per second. */
    override val traffic: Flow<TrafficSample> = flow {
        while (true) {
            emit(statsHandler.get()?.latestSample ?: TrafficSample())
            delay(1_000)
        }
    }.flowOn(Dispatchers.IO)

    private inner class StatsHandler(private val vpn: Service) : CommandClientHandler {
        @Volatile
        var latestSample: TrafficSample = TrafficSample()

        /** Logged once, so a silent no-op can be told apart from "no traffic yet". */
        private var firstStatusLogged = false

        override fun writeStatus(message: StatusMessage?) {
            if (message != null) {
                if (!firstStatusLogged) {
                    firstStatusLogged = true
                    CoreLog.append(vpn, "stats: first status received (uplink=${message.getUplinkTotal()} downlink=${message.getDownlinkTotal()})")
                }
                val uplink = message.getUplinkTotal()
                val downlink = message.getDownlinkTotal()
                latestSample = TrafficSample(
                    // The core reports whether it actually has traffic to report; hardcoding
                    // `true` here is what let the UI claim data it never had.
                    available = message.getTrafficAvailable(),
                    uplinkBytes = uplink,
                    downlinkBytes = downlink,
                    uplinkSpeedBps = message.getUplink(),
                    downlinkSpeedBps = message.getDownlink(),
                )
                protectionStats.recordTraffic(uplink, downlink)
            }
        }

        override fun connected() { CoreLog.append(vpn, "stats: command client connected") }
        override fun disconnected(message: String?) {
            CoreLog.append(vpn, "stats: command client disconnected (message=${if (message.isNullOrBlank()) "none" else "present"})")
            latestSample = TrafficSample()
        }
        override fun clearLogs() {}
        override fun writeLogs(messageList: StringIterator?) {}
        override fun writeGroups(message: io.nekohasekai.libbox.OutboundGroupIterator?) {}
        override fun initializeClashMode(modeList: StringIterator?, currentMode: String?) {}
        override fun updateClashMode(newMode: String?) {}
        override fun writeConnections(message: io.nekohasekai.libbox.Connections?) {}
    }

    /**
     * The status command only exposes aggregate traffic. A second command stream gives us
     * the connection rule and outbound, which is enough to count a blocked request without
     * storing domains or payloads. The ID de-duplicates repeated snapshots of one connection.
     */
    private inner class ConnectionsHandler(private val vpn: Service) : CommandClientHandler {
        private val seenBlocked = LinkedHashSet<String>()
        private var snapshots = 0L
        private var blockedTotal = 0L

        override fun writeConnections(message: Connections?) {
            if (message == null) return
            runCatching {
                // iterator() walks the *filtered* slice, which stays empty until a
                // filter is applied. Without this the snapshot looks like a tunnel with
                // no connections at all, and every counter stays at zero.
                message.filterState(Libbox.ConnectionStateAll.toInt())
                val iterator = message.iterator()
                val sample = StringBuilder()
                var seen = 0
                while (iterator.hasNext()) {
                    val connection = iterator.next()
                    seen++
                    // One snapshot per session is enough to see whether blocked
                    // connections reach us at all and what a matched rule looks like.
                    if (sample.length < 400) sample.append(
                        "[out=${connection.getOutbound()}/${connection.getOutboundType()} " +
                            "rule=${connection.getRule()} dom=${connection.getDomain()}] ",
                    )
                    val outbound = connection.getOutbound().orEmpty()
                    val outboundType = connection.getOutboundType().orEmpty()
                    if (!outbound.equals("block", ignoreCase = true) &&
                        !outboundType.equals("block", ignoreCase = true)
                    ) continue

                    val id = connection.getID().orEmpty()
                    val key = if (id.isNotBlank()) id else listOf(
                        connection.getDomain().orEmpty(),
                        connection.getSource().orEmpty(),
                        connection.getCreatedAt().toString(),
                    ).joinToString("|")
                    if (seenBlocked.add(key)) {
                        val category = categoryOf(connection)
                        protectionStats.recordBlocked(category = category)
                        // Counted, never described: no domain reaches the log even in a
                        // debug build, because "which sites you opened" is exactly what a
                        // statistics screen must not leave behind.
                        if (++blockedTotal % 25 == 1L) CoreLog.append(vpn, "blocked: total=$blockedTotal last=${category.name}")
                    }
                }
                // A long-running tunnel can produce many short-lived IDs. Keep the
                // de-duplication window bounded while retaining enough history for a burst.
                while (seenBlocked.size > 4096) seenBlocked.remove(seenBlocked.first())
                // The first snapshot after start is always empty, so a one-shot log proves
                // nothing. Sample periodically instead: enough to see whether the core
                // tracks connections at all, rare enough not to flood the log.
                snapshots++
                if (snapshots % 60L == 1L) {
                    CoreLog.append(vpn, "connections: snapshot #$snapshots n=$seen blocked=$blockedTotal $sample")
                }
            }.onFailure {
                CoreLog.append(vpn, "stats: connection snapshot could not be read")
            }
        }

        private fun categoryOf(connection: Connection): ProtectionCategory {
            val rule = connection.getRule().orEmpty().lowercase()
            return when {
                "package" in rule || "firewall" in rule -> ProtectionCategory.FIREWALL
                "cyrus-trackers" in rule -> ProtectionCategory.TRACKERS
                "cyrus-annoyances" in rule -> ProtectionCategory.ANNOYANCES
                "cyrus-ads" in rule -> ProtectionCategory.ADS
                else -> ProtectionCategory.OTHER
            }
        }

        override fun connected() = Unit
        override fun disconnected(message: String?) = Unit
        override fun clearLogs() = Unit
        override fun writeLogs(messageList: StringIterator?) = Unit
        override fun writeGroups(message: io.nekohasekai.libbox.OutboundGroupIterator?) = Unit
        override fun initializeClashMode(modeList: StringIterator?, currentMode: String?) = Unit
        override fun updateClashMode(newMode: String?) = Unit
        override fun writeStatus(message: StatusMessage?) = Unit
    }

    /**
     * Answers the four questions the core's command server asks its host. All four concern
     * system-proxy and reload features this app does not offer, so every one of them is a
     * deliberate no-op with an explicit "not available" answer.
     *
     * This must never lie about the system proxy: claiming `available = true` would make the
     * core believe a proxy is set up and it would try to drive one that does not exist.
     */
    private inner class AndroidCommandServerHandler : CommandServerHandler {
        override fun getSystemProxyStatus(): SystemProxyStatus = SystemProxyStatus().apply {
            setAvailable(false)
            setEnabled(false)
        }

        override fun postServiceClose() = Unit

        override fun serviceReload() = Unit

        override fun setSystemProxyEnabled(isEnabled: Boolean) = Unit
    }

    private fun startStats(vpn: Service) {
        val handler = StatsHandler(vpn)
        val client = CommandClient(handler, CommandClientOptions().apply {
            setCommand(Libbox.CommandStatus)
            // Go side does time.Duration(interval), i.e. nanoseconds.
            setStatusInterval(STATUS_INTERVAL_NS)
        })
        statsHandler.set(handler)
        clientRef.set(client)
        // Pinned Connect() already retries dialing and starts a Go reader; it does NOT
        // block for the lifetime of the stream. Do not connect five times on success.
        val thread = Thread({
            if (clientRef.get() === client && !Thread.currentThread().isInterrupted) {
                // Never swallow this. A command client that cannot connect is exactly why
                // the UI shows "—" for traffic while packets are flowing, and swallowing the
                // failure made that indistinguishable from "no traffic yet" — the reason
                // this defect survived a whole review cycle. Only the failure class is
                // logged; the message can name a destination.
                runCatching { client.connect() }.onFailure {
                    CoreLog.append(vpn, "stats: CommandClient.connect failed: ${it::class.java.simpleName}")
                }
                // A stopped session must not retain a late connection to a new session.
                if (clientRef.get() !== client || Thread.currentThread().isInterrupted)
                    runCatching { client.disconnect() }
            }
        }, "libbox-stats")
        statsThread.set(thread)
        thread.isDaemon = true
        thread.start()
    }

    private fun startConnections(vpn: Service) {
        val handler = ConnectionsHandler(vpn)
        val client = CommandClient(handler, CommandClientOptions().apply {
            setCommand(Libbox.CommandConnections)
            // The same field drives the status and the connections commands: the client
            // writes it to the server, which starts `time.NewTicker(interval)` on it.
            // Left at zero the Go runtime panics with
            // "non-positive interval for NewTicker" and takes the whole process with it,
            // which is how a statistics feature managed to kill the tunnel it measures.
            setStatusInterval(CONNECTIONS_INTERVAL_NS)
        })
        connectionsHandler.set(handler)
        connectionsClientRef.set(client)
        val thread = Thread({
            if (connectionsClientRef.get() === client && !Thread.currentThread().isInterrupted) {
                runCatching { client.connect() }.onFailure {
                    CoreLog.append(vpn, "stats: connections client failed: ${it::class.java.simpleName}")
                }
                if (connectionsClientRef.get() !== client || Thread.currentThread().isInterrupted)
                    runCatching { client.disconnect() }
            }
        }, "libbox-connections")
        connectionsThread.set(thread)
        thread.isDaemon = true
        thread.start()
    }

    /**
     * Bridge from the sing-box core to Android VPN plumbing. Method semantics follow
     * sing-box-for-android — skipping protect() here is the only way to create a routing loop.
     */
    private inner class AndroidPlatformInterface(
        private val vpn: Service,
    ) : PlatformInterface {

        override fun openTun(options: TunOptions): Int {
            val builder = (vpn as? VpnService ?: error("TUN запрещён в режиме прокси")).Builder()
                .setSession("Cyrus")
                .setMtu(options.getMTU())
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                builder.setBlocking(true)
            }

            for (prefix in iterate(options.getInet4Address())) {
                builder.addAddress(prefix.address(), prefix.prefix())
            }
            for (prefix in iterate(options.getInet6Address())) {
                builder.addAddress(prefix.address(), prefix.prefix())
            }
            // DNS-hijack address: first tun address + 1, provided by the core.
            runCatching { options.getDNSServerAddress() }.getOrNull()?.let { dnsBox ->
                val dns = dnsBox.getValue()
                if (dns.isNotBlank()) builder.addDnsServer(dns)
            }
            for (prefix in iterate(options.getInet4RouteAddress())) {
                builder.addRoute(prefix.address(), prefix.prefix())
            }
            for (prefix in iterate(options.getInet6RouteAddress())) {
                builder.addRoute(prefix.address(), prefix.prefix())
            }
            // CRITICAL: RouteRange is the computed auto-route set (0.0.0.0/0 by default).
            // Without it the VPN gets NO default route and Android routes all traffic
            // around the tunnel — this was the cause of "no traffic through VPN".
            for (prefix in iterate(options.getInet4RouteRange())) {
                builder.addRoute(prefix.address(), prefix.prefix())
            }
            for (prefix in iterate(options.getInet6RouteRange())) {
                builder.addRoute(prefix.address(), prefix.prefix())
            }
            for (prefix in iterate(options.getInet4RouteExcludeAddress())) {
                excludeRoute(builder, prefix.address(), prefix.prefix())
            }
            for (prefix in iterate(options.getInet6RouteExcludeAddress())) {
                excludeRoute(builder, prefix.address(), prefix.prefix())
            }
            for (pkg in iterate(options.getIncludePackage())) {
                builder.addAllowedApplication(pkg)
            }
            for (pkg in iterate(options.getExcludePackage())) {
                builder.addDisallowedApplication(pkg)
            }

            val fd = runCatching { builder.establish() }.getOrNull()
                ?: return -1

            // libbox v1.11.1 service.go/OpenTun duplicates this descriptor with dup().
            // Keep ownership of the original: the core closes its duplicate, and
            // stop() closes our ParcelFileDescriptor. detachFd() would leak the original.
            val previous = tunFd.getAndSet(fd)
            previous?.let { runCatching { it.close() } }
            return fd.getFd()
        }

        private fun excludeRoute(builder: VpnService.Builder, address: String, prefix: Int) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                runCatching {
                    builder.excludeRoute(IpPrefix(InetAddress.getByName(address), prefix))
                }
            }
            // < API 33: route exclusions are not supported; auto-route ranges handle it.
        }

        /** CRITICAL: without protect() every core socket loops back into the TUN we just built. */
        override fun autoDetectInterfaceControl(fd: Int) {
            Log.d("sing-box", "autoDetectInterfaceControl called for fd=$fd")
            // The host is a plain Service in proxy mode. Capture the VPN-only API
            // in a typed local before entering the lambda; do not rely on a member smart cast.
            val vpnService: VpnService = vpn as? VpnService ?: return
            val protected: Boolean = runCatching { vpnService.protect(fd) }.getOrDefault(false)
            Log.d("sing-box", "protect(fd=$fd) result=$protected")
            if (!protected) {
                error("Не удалось защитить сокет VPN от петли маршрутизации")
            }
        }

        override fun usePlatformAutoDetectInterfaceControl(): Boolean = true

        private var defaultNetworkCallback: android.net.ConnectivityManager.NetworkCallback? = null
        private var monitorThread: android.os.HandlerThread? = null

        override fun startDefaultInterfaceMonitor(listener: InterfaceUpdateListener?) {
            if (listener == null) return
            val cm = vpn.getSystemService(android.net.ConnectivityManager::class.java) ?: return

            // Request only physical (non-VPN) networks — we must NOT report the TUN
            // interface back to the core, or it will try to route through itself.
            val request = android.net.NetworkRequest.Builder()
                .addCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .addCapability(android.net.NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
                .build()

            defaultNetworkCallback = object : android.net.ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: android.net.Network) {
                    notifyListener(cm, network, listener)
                }
                override fun onLinkPropertiesChanged(network: android.net.Network, linkProperties: android.net.LinkProperties) {
                    notifyListener(cm, network, listener)
                }
                override fun onCapabilitiesChanged(network: android.net.Network, caps: android.net.NetworkCapabilities) {
                    notifyListener(cm, network, listener)
                }
                override fun onLost(network: android.net.Network) {
                    runCatching {
                        listener.updateDefaultInterface("", 0, false, false)
                    }
                }
            }
            // The Handler overload was added in API 26; minSdk is 24.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val handlerThread = android.os.HandlerThread("net-monitor")
                handlerThread.start()
                monitorThread = handlerThread
                val handler = android.os.Handler(handlerThread.looper)
                runCatching {
                    cm.requestNetwork(request, defaultNetworkCallback!!, handler)
                }
            } else {
                // Android 7 delivers callbacks on its connectivity callback thread.
                runCatching {
                    cm.requestNetwork(request, defaultNetworkCallback!!)
                }
            }
            // Proactively find the current physical (non-VPN) network.
            for (network in cm.allNetworks) {
                val caps = cm.getNetworkCapabilities(network) ?: continue
                if (caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    && caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
                ) {
                    notifyListener(cm, network, listener)
                    break
                }
            }
        }

        private fun notifyListener(
            cm: android.net.ConnectivityManager,
            network: android.net.Network,
            listener: InterfaceUpdateListener,
        ) {
            val linkProperties = cm.getLinkProperties(network) ?: return
            val capabilities = cm.getNetworkCapabilities(network)
            val ifaceName = linkProperties.interfaceName ?: ""
            // Skip VPN/TUN interfaces that slipped through
            if (ifaceName.startsWith("tun")) return
            val ifaceIndex = runCatching { JavaNetworkInterface.getByName(ifaceName)?.index ?: 0 }.getOrDefault(0)
            val metered = capabilities?.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_NOT_METERED) == false
            Log.d("sing-box", "Default interface updated: $ifaceName idx=$ifaceIndex metered=$metered")
            runCatching {
                listener.updateDefaultInterface(ifaceName, ifaceIndex, metered, false)
            }.onFailure { Log.e("sing-box", "Failed to update default interface", it) }
            // Kick the core to rebind all sockets through the updated interface.
            runCatching { serviceRef.get()?.resetNetwork() }
        }

        override fun closeDefaultInterfaceMonitor(listener: InterfaceUpdateListener?) {
            defaultNetworkCallback?.let { callback ->
                runCatching {
                    val cm = vpn.getSystemService(android.net.ConnectivityManager::class.java)
                    cm?.unregisterNetworkCallback(callback)
                }
            }
            defaultNetworkCallback = null
            monitorThread?.quitSafely()
            monitorThread = null
        }

        override fun getInterfaces(): NetworkInterfaceIterator {
            val list = runCatching {
                Collections.list(JavaNetworkInterface.getNetworkInterfaces())
            }.getOrDefault(emptyList())
            Log.d("sing-box", "getInterfaces() returning ${list.size} interfaces")
            return object : NetworkInterfaceIterator {
                private var cursor = 0
                override fun hasNext(): Boolean = cursor < list.size
                override fun next(): NetworkInterface {
                    val nif = list[cursor++]
                    // Collect addresses as CIDR prefixes (e.g. "10.0.0.1/24").
                    // Go's netip.ParsePrefix panics on bare IPs or zone IDs like "%dummy0".
                    val prefixes = mutableListOf<String>()
                    for (ifAddr in nif.interfaceAddresses) {
                        val addr = ifAddr.address ?: continue
                        var host = addr.hostAddress ?: continue
                        // Strip IPv6 zone ID (e.g. "%dummy0") — Go doesn't accept it.
                        val pctIdx = host.indexOf('%')
                        if (pctIdx >= 0) host = host.substring(0, pctIdx)
                        val prefixLen = ifAddr.networkPrefixLength.toInt()
                        prefixes.add("$host/$prefixLen")
                    }
                    // The core filters interfaces by Flags&IFF_UP (route/network.go) and
                    // uses Type for network strategy. Java's getFlags() returns the raw
                    // IFF_* bits, but we must at least ensure UP is visible. Without flags
                    // the interface list is empty and every dial fails with
                    // "no available network interface".
                    val type = when {
                        nif.name.startsWith("wlan") || nif.name.startsWith("ap") -> TYPE_WIFI
                        nif.name.startsWith("rmnet") || nif.name.startsWith("ccmni") ||
                            nif.name.startsWith("swlan") || nif.name.startsWith("usb") -> TYPE_CELLULAR
                        nif.name.startsWith("eth") -> TYPE_ETHERNET
                        else -> TYPE_OTHER
                    }
                    val networkInterface = NetworkInterface().apply {
                        setName(nif.name)
                        setIndex(nif.index)
                        setMTU(runCatching { nif.mtu }.getOrDefault(0))
                        setFlags(computeFlags(nif)) // core keeps only Flags&IFF_UP != 0
                        setType(type)
                        setMetered(false)
                        setAddresses(
                            object : StringIterator {
                                private var idx = 0
                                override fun hasNext(): Boolean = idx < prefixes.size
                                override fun next(): String = prefixes[idx++]
                                override fun len(): Int = prefixes.size - idx
                            },
                        )
                        setDNSServer(emptyStringIterator())
                    }
                    Log.d("sing-box", "getInterfaces() yielding: ${nif.name} (idx=${nif.index}, type=$type, up=${nif.isUp}) with ${prefixes.size} prefixes")
                    return networkInterface
                }
            }
        }

        override fun underNetworkExtension(): Boolean = false
        override fun includeAllNetworks(): Boolean = false
        override fun useProcFS(): Boolean = false

        override fun findConnectionOwner(
            ipProtocol: Int,
            sourceAddress: String?,
            sourcePort: Int,
            destinationAddress: String?,
            destinationPort: Int,
        ): Int {
            val cm = vpn.getSystemService(android.net.ConnectivityManager::class.java) ?: return -1
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return -1
            val local = java.net.InetSocketAddress(runCatching { InetAddress.getByName(sourceAddress) }.getOrNull() ?: return -1, sourcePort)
            val remote = java.net.InetSocketAddress(runCatching { InetAddress.getByName(destinationAddress) }.getOrNull() ?: return -1, destinationPort)
            return runCatching { cm.getConnectionOwnerUid(ipProtocol, local, remote) }.getOrDefault(-1)
        }

        override fun packageNameByUid(uid: Int): String =
            runCatching { vpn.packageManager.getNameForUid(uid) ?: "unknown" }
                .getOrDefault("unknown")

        override fun uidByPackageName(packageName: String?): Int =
            runCatching { vpn.packageManager.getPackageUid(requireNotNull(packageName), 0) }
                .getOrDefault(-1)

        override fun readWIFIState(): WIFIState? = null

        override fun sendNotification(notification: io.nekohasekai.libbox.Notification?) = Unit

        override fun clearDNSCache() = Unit

        override fun writeLog(message: String?) {
            if (message == null) return
            // Native messages may contain credentials or destination URLs, so they never
            // reach logcat. They are kept in the app's private storage instead — see CoreLog.
            //
            // CoreLog.appendConfig() masks a *structured* config by JSON key, but a free-form
            // core line has no keys to consult: on a config error sing-box echoes the
            // outbound inline, UUID and password included. Redact by shape before anything
            // is written, and hand the redacted text to the health counter too, so no
            // un-redacted copy is ever held in memory longer than this stack frame.
            val safe = message.redactSecrets()
            CoreLog.append(vpn, safe)
            // The same line is the only honest evidence of whether this core can dial at
            // all: at `warn` level a working core is silent. See CoreHealth.
            health.onCoreMessage(safe)
        }
    }

    private companion object {
        /**
         * Log lines the command server buffers for the log command. This app does not use
         * that command — the core's output goes to [CoreLog] instead — so the buffer is
         * deliberately small: it exists only because the constructor requires a value.
         */
        const val COMMAND_LOG_LINES = 64

        /**
         * Command-client intervals, in nanoseconds: the Go side converts them with
         * time.Duration(interval). Neither may be zero — the server feeds the value to
         * time.NewTicker, and a non-positive interval panics the whole process.
         */
        const val STATUS_INTERVAL_NS = 1_000_000_000L
        const val CONNECTIONS_INTERVAL_NS = 1_000_000_000L

        // Must match io.nekohasekai.libbox constants (constant/network.go:
        // WIFI=0, Cellular=1, Ethernet=2, Other=3).
        const val TYPE_WIFI = 0
        const val TYPE_CELLULAR = 1
        const val TYPE_ETHERNET = 2
        const val TYPE_OTHER = 3

        // Linux IFF_* bits (see Go syscall/zerrors_linux_arm64.go); the core maps
        // rawFlags -> net.Flags via libbox linkFlags() and keeps UP interfaces only.
        const val IFF_UP = 0x1
        const val IFF_BROADCAST = 0x2
        const val IFF_LOOPBACK = 0x8
        const val IFF_POINTOPOINT = 0x10
        const val IFF_RUNNING = 0x40
        const val IFF_MULTICAST = 0x8000

        /** Android's java.net.NetworkInterface has no getFlags(); rebuild from predicates. */
        fun computeFlags(nif: JavaNetworkInterface): Int {
            var flags = 0
            if (runCatching { nif.isUp }.getOrDefault(false)) flags = flags or IFF_UP
            if (runCatching { nif.isLoopback }.getOrDefault(false)) flags = flags or IFF_LOOPBACK
            if (runCatching { nif.isPointToPoint }.getOrDefault(false)) flags = flags or IFF_POINTOPOINT
            if (runCatching { nif.supportsMulticast() }.getOrDefault(false)) flags = flags or IFF_MULTICAST
            if (!nif.isLoopback && !nif.isPointToPoint) flags = flags or IFF_BROADCAST
            if (runCatching { nif.isUp }.getOrDefault(false)) {
                // Most physical interfaces report RUNNING; core treats it as a bonus.
                flags = flags or IFF_RUNNING
            }
            return flags
        }

        fun emptyStringIterator(): StringIterator = object : StringIterator {
            override fun hasNext(): Boolean = false
            override fun next(): String = ""
            override fun len(): Int = 0
        }

        fun iterate(iterator: io.nekohasekai.libbox.RoutePrefixIterator?): List<io.nekohasekai.libbox.RoutePrefix> =
            buildList {
                if (iterator != null) {
                    while (iterator.hasNext()) add(iterator.next())
                }
            }

        fun iterate(iterator: StringIterator?): List<String> = buildList {
            if (iterator != null) {
                while (iterator.hasNext()) add(iterator.next())
            }
        }
    }
}
