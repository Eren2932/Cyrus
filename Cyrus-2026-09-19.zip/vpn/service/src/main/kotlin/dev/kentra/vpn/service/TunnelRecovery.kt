package dev.kentra.vpn.service

/**
 * Notices that a network the tunnel could dial through has come back.
 *
 * This seam exists for one reason: the decision it feeds is worth testing, and a
 * [android.net.ConnectivityManager] cannot be constructed in a JVM unit test. The policy
 * below can, so the interesting part - *when* a dropped tunnel deserves another dial -
 * is testable, and the untestable part stays a thin wrapper.
 */
internal interface NetworkWatcher {

    /**
     * Watches for a usable network and calls [onNetwork] when one appears.
     *
     * May fire more than once and on any thread. What a firing means is not this
     * interface's business; [TunnelRecovery] decides that.
     */
    fun watch(onNetwork: () -> Unit)

    /** Stops watching. Safe to call when nothing is being watched. */
    fun stop()

    /**
     * Whether a physical network exists right now.
     *
     * The VPN this app builds is itself a network, so "is there a network" cannot be
     * answered from the default network alone - while the tunnel is up that is the tunnel.
     */
    fun hasNetworkNow(): Boolean
}

/**
 * Decides whether a tunnel that died should be dialled again once the network returns.
 *
 * The gap this fills: a tunnel started while the device has no network fails its
 * probation and is torn down, and nothing ever tries again - the connection is dead until
 * the user notices and presses the button. The network coming back is the one event that
 * makes another dial worth attempting, and nothing else in the app listens for it.
 *
 * Three rules keep it from becoming a retry loop, and each is here for a reason:
 *
 * - **Only what the user still wants.** [stoppedByUser] forgets the session, so a tunnel
 *   the user switched off is never brought back. Reconnecting something that was
 *   deliberately disconnected is worse than staying down.
 * - **One attempt per failure.** A firing clears [dropped], so the next network event does
 *   nothing until another failure arms the watcher again. A key that is genuinely dead
 *   therefore costs two dials per network change, not one per callback - and a device
 *   flapping between Wi-Fi and cellular does not turn into a dial loop.
 * - **Armed only after a failure.** A healthy tunnel is not watched at all. The core has
 *   its own interface monitor and rebinds its sockets when the physical network changes,
 *   so the only case nothing handles is the one that never came up.
 *
 * [retry] is called on whatever thread the watcher uses. It must therefore do nothing but
 * hand the session to a queue - here, the runner's command channel.
 */
internal class TunnelRecovery(
    private val watcher: NetworkWatcher?,
    private val retry: (TunnelSession) -> Unit,
) {
    private val lock = Any()

    /** What the user last asked for and has not withdrawn. */
    private var wanted: TunnelSession? = null

    /**
     * Whether the watcher is armed. Doubles as the one-attempt guarantee: it is read and
     * cleared in the same critical section, so two networks announced at once - Wi-Fi and
     * cellular coming back together, on two callback threads - still dial once.
     */
    private var watching = false

    /** The user asked for [session]. Any pending recovery is now stale. */
    fun started(session: TunnelSession) {
        disarm()
        synchronized(lock) { wanted = session }
    }

    /** The user asked for no tunnel. Nothing is recovered after this. */
    fun stoppedByUser() {
        disarm()
        synchronized(lock) { wanted = null }
    }

    /** The tunnel is up, so there is nothing to recover from. */
    fun connected() = disarm()

    /**
     * A tunnel the user still wants has died. Arm the watcher - but only if the device has
     * no network to dial through, which is the one failure the network returning can fix.
     *
     * That condition is what keeps this bounded. A key that is refused with the network
     * up will be refused again, so arming there would hold a foreground service waiting for
     * an event that changes nothing: the tunnel would be retried on every Wi-Fi handover
     * and never succeed. Offline, the same failure has an obvious cause and an obvious
     * cure, and that is the case worth waiting for.
     *
     * A failure with no session wanted - the user disconnected while it was failing - arms
     * nothing either: there is nothing to bring back.
     */
    fun failed() {
        val armable = synchronized(lock) { wanted != null && !watching }
        // With no network there is nothing to dial through, so waiting costs nothing and
        // fixes everything. With one, the failure has another cause and this is not it.
        if (!armable || watcher?.hasNetworkNow() != false) return
        synchronized(lock) { watching = true }
        watcher?.watch(::onNetwork)
    }

    /** Whether a redial is pending. The service must not stop itself while this is true. */
    fun armed(): Boolean = synchronized(lock) { watching }

    fun destroy() {
        disarm()
        synchronized(lock) { wanted = null }
    }

    /**
     * Fires on every network event; only one of them is acted on. Note that the watcher is
     * always released here, even when nothing is retried: otherwise a later failure would
     * find [watching] already true and never arm again.
     */
    private fun onNetwork() {
        val redial = synchronized(lock) {
            val session = wanted.takeIf { watching }
            watching = false
            session
        }
        watcher?.stop()
        if (redial != null) retry(redial)
    }

    private fun disarm() {
        val stop = synchronized(lock) {
            val was = watching
            watching = false
            was
        }
        if (stop) watcher?.stop()
    }
}
