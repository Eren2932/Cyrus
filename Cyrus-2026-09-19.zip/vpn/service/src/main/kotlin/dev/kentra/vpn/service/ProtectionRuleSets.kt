package dev.kentra.vpn.service

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Installs the shipped filter lists and keeps them fresh.
 *
 * The lists travel in the APK (`assets/rulesets/`) and are copied into private
 * storage on first use. That is what keeps the network off the start path: with
 * a remote rule-set sing-box downloads it inside `start()`, while the TUN is
 * already up and no physical interface is bound, fails with "no available network
 * interface", and refuses to start — so enabling protection broke every key
 * instead of just the filtering.
 *
 * Freshness is therefore a background concern: [refreshIfStale] tries the
 * upstream URLs at most once a day and only replaces a file it has verified. A
 * failed download leaves the installed copy untouched, so a device without
 * access to the upstream still filters with what it shipped with.
 */
class ProtectionRuleSets(private val context: Context) {

    private data class Spec(val tag: String, val asset: String, val url: String)

    private val specs = listOf(
        Spec(
            tag = "cyrus-ads",
            asset = "rulesets/cyrus-ads.srs",
            url = "https://raw.githubusercontent.com/SagerNet/sing-geosite/rule-set/geosite-category-ads-all.srs",
        ),
        Spec(
            tag = "cyrus-trackers",
            asset = "rulesets/cyrus-trackers.srs",
            url = "https://github.com/x15rte/adguard2singbox/releases/download/rules/adguarddnsfilter.srs",
        ),
        Spec(
            tag = "cyrus-annoyances",
            asset = "rulesets/cyrus-annoyances.srs",
            url = "https://raw.githubusercontent.com/SagerNet/sing-geosite/rule-set/geosite-category-consent-management.srs",
        ),
    )

    /**
     * tag → absolute path, for every list that is actually on disk. Called on the
     * connect path, so it only ever reads or copies from the APK: never network.
     */
    suspend fun installed(): Map<String, String> = withContext(Dispatchers.IO) {
        val dir = directory() ?: return@withContext emptyMap()
        specs.mapNotNull { spec ->
            val file = File(dir, "${spec.tag}.srs")
            if (!isUsable(file) && !installFromAsset(spec, file)) return@mapNotNull null
            spec.tag to file.absolutePath
        }.toMap()
    }

    /** Best-effort refresh. Safe to call from app start; never throws. */
    suspend fun refreshIfStale(maxAgeMillis: Long = REFRESH_INTERVAL_MS) {
        withContext(Dispatchers.IO) {
            val dir = directory() ?: return@withContext
            val now = System.currentTimeMillis()
            for (spec in specs) {
                val file = File(dir, "${spec.tag}.srs")
                if (isUsable(file) && now - file.lastModified() < maxAgeMillis) continue
                if (!isUsable(file)) installFromAsset(spec, file)
                runCatching { download(spec, file) }
            }
        }
    }

    private fun directory(): File? = runCatching {
        File(context.filesDir, "rulesets").apply { mkdirs() }
    }.getOrNull()

    private fun installFromAsset(spec: Spec, target: File): Boolean = runCatching {
        val tmp = File(target.parentFile, "${target.name}.tmp")
        context.assets.open(spec.asset).use { input ->
            FileOutputStream(tmp).use { output -> input.copyTo(output) }
        }
        if (!isUsable(tmp)) {
            tmp.delete()
            return false
        }
        tmp.renameTo(target)
        true
    }.getOrDefault(false)

    private fun download(spec: Spec, target: File) {
        val tmp = File(target.parentFile, "${target.name}.tmp")
        try {
            val connection = URL(spec.url).openConnection() as HttpURLConnection
            try {
                connection.instanceFollowRedirects = true
                connection.connectTimeout = 15_000
                connection.readTimeout = 30_000
                if (connection.responseCode != HttpURLConnection.HTTP_OK) return
                connection.inputStream.use { input ->
                    FileOutputStream(tmp).use { output -> input.copyTo(output) }
                }
            } finally {
                connection.disconnect()
            }
            // Only a file the core can parse may replace the one it is using.
            if (!isUsable(tmp)) {
                tmp.delete()
                return
            }
            tmp.renameTo(target)
        } finally {
            if (tmp.exists() && !tmp.renameTo(target)) tmp.delete()
        }
    }

    /** Magic `SRS` plus a version the bundled core understands (it supports 1..3). */
    private fun isUsable(file: File): Boolean = runCatching {
        if (!file.isFile || file.length() < 4) return false
        file.inputStream().use { input ->
            val header = ByteArray(4)
            if (input.read(header) != 4) return false
            header[0] == 'S'.code.toByte() &&
                header[1] == 'R'.code.toByte() &&
                header[2] == 'S'.code.toByte() &&
                header[3] in 1..3
        }
    }.getOrDefault(false)

    private companion object {
        const val REFRESH_INTERVAL_MS = 24L * 60 * 60 * 1000
    }
}
