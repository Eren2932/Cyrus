package dev.kentra.vpn.service

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest

/**
 * Watches physical networks through [ConnectivityManager].
 *
 * Two details matter and both are easy to get wrong:
 *
 * The VPN this app builds is itself a network with `INTERNET`, and it is the *default*
 * network for everything on the device while the tunnel is up. Reporting it back would
 * have the tunnel dial through itself. Every candidate is therefore filtered on
 * [NetworkCapabilities.TRANSPORT_VPN], which is available on every supported API level,
 * rather than on `NET_CAPABILITY_NOT_VPN`, which needs API 28 while minSdk is 24.
 *
 * "Available" is not the same as usable: a captive portal is available and black-holes
 * every packet. Both [onAvailable] and a validated [onCapabilitiesChanged] are reported,
 * and [TunnelRecovery] makes one attempt per failure - so an early, unvalidated firing
 * costs one dial, and the validated one that follows gets a real second chance.
 */
internal class ConnectivityNetworkWatcher(
    private val context: Context,
) : NetworkWatcher {

    private val lock = Any()
    private var manager: ConnectivityManager? = null
    private var callback: ConnectivityManager.NetworkCallback? = null

    override fun watch(onNetwork: () -> Unit) {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                if (isPhysical(cm, network)) onNetwork()
            }

            override fun onCapabilitiesChanged(network: Network, capabilities: NetworkCapabilities) {
                if (capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) &&
                    isPhysical(cm, network)
                ) onNetwork()
            }
        }
        synchronized(lock) {
            manager = cm
            this.callback = callback
        }
        runCatching { cm.registerNetworkCallback(request, callback) }
            .onFailure { release()?.let { (m, c) -> runCatching { m.unregisterNetworkCallback(c) } } }
    }

    override fun stop() {
        release()?.let { (cm, callback) -> runCatching { cm.unregisterNetworkCallback(callback) } }
    }

    override fun hasNetworkNow(): Boolean {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return false
        return cm.allNetworks.any { network ->
            val capabilities = cm.getNetworkCapabilities(network) ?: return@any false
            capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                !capabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
        }
    }

    private fun isPhysical(cm: ConnectivityManager, network: Network): Boolean {
        val capabilities = cm.getNetworkCapabilities(network) ?: return false
        return !capabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
    }

    private fun release(): Pair<ConnectivityManager, ConnectivityManager.NetworkCallback>? {
        val (cm, callback) = synchronized(lock) {
            val cm = manager
            val callback = this.callback
            manager = null
            this.callback = null
            cm to callback
        }
        return if (cm != null && callback != null) cm to callback else null
    }
}
