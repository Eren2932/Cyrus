package dev.kentra.vpn.service

import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.security.KeyChain
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.util.Log
import dev.kentra.core.common.X509Certificates
import java.io.File
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.X509EncodedKeySpec
import java.util.Date
import java.util.Locale
import javax.net.ssl.TrustManagerFactory
import javax.net.ssl.X509TrustManager

/**
 * The local certificate authority behind HTTPS inspection.
 *
 * Scope of this class is deliberately narrow: create the root, keep its private
 * key in the Android keystore, hand the user a way to install the certificate,
 * and report honestly whether the system trusts it. It does **not** intercept
 * anything — interception needs the TLS engine in the core, and until that
 * exists a root here buys the user nothing except a decision they should make
 * knowingly.
 *
 * Two properties matter more than convenience:
 *
 * - the private key never leaves the keystore (it is generated inside it and is
 *   not exportable), so a compromised backup or a rooted app cannot replay it;
 * - nothing is persisted before it verifies. A root that no parser accepts
 *   would be installed into the system trust store and silently trusted by
 *   nobody — the worst possible failure mode for this feature.
 */
class ProtectionCa(private val context: Context) {

    data class State(
        /** Null when no root has been created yet. */
        val certificate: X509Certificate? = null,
        /**
         * True when the certificate is present in the trust store Android gives
         * apps by default. Note the asymmetry: the *store* accepts user roots,
         * but an app targeting API 24+ only honours them if its own network
         * security config says so. So `installed` is necessary, never sufficient.
         */
        val installed: Boolean = false,
    )

    fun state(): State {
        val certificate = readCertificate()
        return State(certificate = certificate, installed = certificate != null && isTrusted(certificate))
    }

    /** Creates a new root, replacing any previous one. Throws on keystore failure. */
    fun create(): X509Certificate {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        if (keyStore.containsAlias(ALIAS)) keyStore.deleteEntry(ALIAS)

        val generator = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, ANDROID_KEYSTORE)
        generator.initialize(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_SIGN)
                .setKeySize(256)
                .setDigests(KeyProperties.DIGEST_SHA256)
                .build(),
        )
        val keyPair = generator.generateKeyPair()

        val now = System.currentTimeMillis()
        val encoded = X509Certificates.selfSignedCa(
            keyPair = keyPair,
            subject = SUBJECT,
            // A device with a clock behind the real time would otherwise hold a
            // root that is "not yet valid"; one day of slack costs nothing.
            notBefore = Date(now - CLOCK_SKEW_MS),
            notAfter = Date(now + VALIDITY_MS),
            serial = BigInteger(SERIAL_BITS, SecureRandom()).takeIf { it.signum() > 0 } ?: BigInteger.ONE,
        )
        val certificate = parse(encoded)
        certificate.verify(keyPair.public)
        file().writeBytes(encoded)
        return certificate
    }

    /**
     * System dialog that installs the root. Returns null when there is nothing to
     * install yet, or when the platform no longer allows it.
     *
     * Since Android 13 (API 33) a root can only be installed through Settings:
     * `createInstallIntent` still opens, but only shows a notice pointing there.
     * That is why [exportToDownloads] exists — the user needs the file in hand,
     * and the app cannot put it in the credential store for them.
     */
    @Suppress("DEPRECATION")
    fun installIntent(): Intent? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) return null
        val certificate = readCertificate() ?: return null
        return KeyChain.createInstallIntent().apply {
            putExtra(KeyChain.EXTRA_CERTIFICATE, certificate.encoded)
            putExtra(KeyChain.EXTRA_NAME, INSTALL_NAME)
        }
    }

    /** Where the user has to go to install the root on API 33+. */
    fun settingsIntent(): Intent = Intent(Settings.ACTION_SECURITY_SETTINGS)

    /**
     * The root in PEM form, or null when there is none yet.
     *
     * PEM rather than raw DER: it is what the Settings installer's file picker
     * expects on API 33+, and a certificate the user can open and read is one
     * they can check instead of taking on faith.
     */
    fun pem(): String? {
        val certificate = readCertificate() ?: return null
        return buildString {
            append("-----BEGIN CERTIFICATE-----\n")
            append(Base64.encodeToString(certificate.encoded, Base64.DEFAULT))
            append("-----END CERTIFICATE-----\n")
        }
    }

    /** Drops the certificate and destroys the key. Reversible only by creating a new root. */
    fun delete() {
        if (!file().delete() && file().exists()) {
            Log.w(TAG, "CA certificate file could not be deleted")
        }
        runCatching {
            KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }.deleteEntry(ALIAS)
        }.onFailure { Log.w(TAG, "CA key could not be removed: ${it::class.java.simpleName}") }
    }

    /**
     * A server certificate for one host, signed by the CA key, for a key the
     * caller already holds.
     *
     * Only the public half crosses this boundary. The TLS engine minting the
     * leaf keeps its private key in its own memory, so nothing able to
     * impersonate the host is ever handed over; the CA key still only signs.
     *
     * Nothing is cached here on purpose. The caller caches per host, and a
     * second cache keyed by host alone would answer a *different* key pair with
     * an old certificate — a mismatch the TLS stack reports as a broken
     * connection, on a host the user did nothing to break.
     *
     * @param publicKeyDer DER-encoded SubjectPublicKeyInfo, i.e. what
     *        `X509EncodedKeySpec` and `PublicKey.getEncoded` speak.
     * @return DER-encoded certificate, or null when there is no usable CA. The
     *         caller must then pass the connection through untouched rather than
     *         fail it: a feature that decrypts traffic may never break it.
     */
    fun issueLeaf(host: String, publicKeyDer: ByteArray): ByteArray? {
        val name = host.trim().lowercase(Locale.US)
        if (name.isEmpty() || name.length > MAX_HOST_LENGTH || !HOST_PATTERN.matches(name)) return null

        val caCertificate = readCertificate() ?: return null
        val caPrivateKey = caPrivateKey() ?: return null
        val publicKey = runCatching {
            KeyFactory.getInstance(LEAF_KEY_ALGORITHM).generatePublic(X509EncodedKeySpec(publicKeyDer))
        }.onFailure { Log.w(TAG, "leaf public key rejected for $name: ${it::class.java.simpleName}") }
            .getOrNull() ?: return null

        val now = System.currentTimeMillis()
        val encoded = X509Certificates.leaf(
            publicKey = publicKey,
            caPrivateKey = caPrivateKey,
            caCertificate = caCertificate,
            host = name,
            notBefore = Date(now - CLOCK_SKEW_MS),
            notAfter = Date(now + LEAF_VALIDITY_MS),
            serial = BigInteger(SERIAL_BITS, SecureRandom()).takeIf { it.signum() > 0 } ?: BigInteger.ONE,
        )
        val leaf = parse(encoded)
        // Same rule as for the root: never hand out a certificate we have not verified.
        leaf.verify(caCertificate.publicKey)
        return encoded
    }

    private fun caPrivateKey(): PrivateKey? = runCatching {
        KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }.getKey(ALIAS, null) as? PrivateKey
    }.onFailure { Log.w(TAG, "CA key unavailable: ${it::class.java.simpleName}") }
        .getOrNull()

    private fun file(): File = File(context.filesDir, FILE_NAME)

    private fun readCertificate(): X509Certificate? {
        val file = file()
        if (!file.isFile) return null
        return runCatching {
            file.inputStream().use { parse(it.readBytes()) }
        }.onFailure { Log.w(TAG, "CA certificate unreadable: ${it::class.java.simpleName}") }
            .getOrNull()
    }

    private fun parse(encoded: ByteArray): X509Certificate =
        CertificateFactory.getInstance("X.509").generateCertificate(encoded.inputStream()) as X509Certificate

    private fun isTrusted(certificate: X509Certificate): Boolean = runCatching {
        val factory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
        factory.init(null as KeyStore?)
        factory.trustManagers.filterIsInstance<X509TrustManager>().any { manager ->
            manager.acceptedIssuers.any { anchor ->
                anchor.subjectX500Principal == certificate.subjectX500Principal &&
                    anchor.publicKey.encoded.contentEquals(certificate.publicKey.encoded)
            }
        }
    }.onFailure { Log.w(TAG, "trust store check failed: ${it::class.java.simpleName}") }
        .getOrDefault(false)

    private companion object {
        const val TAG = "ProtectionCa"
        const val ANDROID_KEYSTORE = "AndroidKeyStore"
        const val ALIAS = "cyrus_protection_ca_v1"
        const val FILE_NAME = "protection-ca.crt"
        const val EXPORT_FILE_NAME = "cyrus-protection-ca.crt"
        const val SUBJECT = "CN=Cyrus Protection CA, O=Cyrus"
        const val INSTALL_NAME = "Cyrus HTTPS inspection"
        const val SERIAL_BITS = 64
        const val CLOCK_SKEW_MS = 24L * 60 * 60 * 1000
        const val VALIDITY_MS = 10L * 365 * 24 * 60 * 60 * 1000
        /** The core mints an EC P-256 leaf key and sends only its public half. */
        const val LEAF_KEY_ALGORITHM = "EC"
        const val LEAF_VALIDITY_MS = 30L * 24 * 60 * 60 * 1000
        /** Longest name a DNS label chain can reach (RFC 1035), SNI included. */
        const val MAX_HOST_LENGTH = 253
        val HOST_PATTERN = Regex("[a-z0-9]([a-z0-9._-]*[a-z0-9])?")
    }
}
