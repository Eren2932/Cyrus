package dev.kentra.vpn.service

import android.app.Service
import android.net.VpnService
import org.amnezia.awg.backend.GoBackend
import org.amnezia.awg.config.Config
import dev.kentra.domain.model.TrafficSample
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emptyFlow
import java.io.ByteArrayInputStream
import org.amnezia.awg.backend.Tunnel

class AmneziaVpnEngine(private val context: android.content.Context) : VpnEngine {
    override val id: String = "amnezia"

    @Volatile private var backend: GoBackend? = null
    @Volatile private var activeTunnel: AwgTunnel? = null

    private class AwgTunnel(private val name: String) : Tunnel {
        override fun getName() = name

        @Volatile var last: Tunnel.State? = null
        override fun onStateChange(newState: Tunnel.State) { last = newState }
    }

    override suspend fun start(service: Service, session: TunnelSession) {
        val b = GoBackend(service, org.amnezia.awg.backend.NoopTunnelActionHandler())
        backend = b
        // Config.parse() throws on a malformed config, which is the main failure
        // mode here; the exception is deliberately not swallowed so the runner can
        // mark the session failed instead of showing a green icon over nothing.
        val config = Config.parse(ByteArrayInputStream(session.configJson.toByteArray()))
        val t = AwgTunnel(session.profileName.ifBlank { "Amnezia" })
        activeTunnel = t
        b.setState(t, Tunnel.State.UP, config)
        awaitUp(t)
    }

    /**
     * Waits for the Go backend to report the tunnel state.
     *
     * `setState` returns before the tunnel is actually up, so without this the UI
     * could go green over a session the backend never accepted. An explicitly
     * reported DOWN is treated as a failure. A backend that never calls back is
     * allowed through with a warning: some versions only invoke `onStateChange`
     * on error, and blocking those out would break working tunnels — which is
     * worse than the gap this check closes.
     */
    private suspend fun awaitUp(t: AwgTunnel) {
        val deadline = System.currentTimeMillis() + AWG_UP_TIMEOUT_MS
        while (System.currentTimeMillis() < deadline) {
            when (t.last) {
                Tunnel.State.UP -> return
                Tunnel.State.DOWN ->
                    error("AmneziaWG backend refused to bring the tunnel up.")
                else -> kotlinx.coroutines.delay(AWG_POLL_MS)
            }
        }
        android.util.Log.w(
            "AmneziaVpnEngine",
            "AmneziaWG backend did not report state within ${AWG_UP_TIMEOUT_MS}ms; assuming up.",
        )
    }

    private companion object {
        const val AWG_UP_TIMEOUT_MS = 3_000L
        const val AWG_POLL_MS = 50L
    }

    override suspend fun stop() {
        try {
            val b = backend
            val t = activeTunnel
            if (b != null && t != null) {
                b.setState(t, Tunnel.State.DOWN, null)
            }
        } catch (e: Throwable) {
            // Catch Throwable, not Exception: the Go backend can raise Error subclasses,
            // and one escaping here would abort the composite teardown. Never log the
            // throwable itself — it can embed the tunnel config.
            android.util.Log.e("AmneziaVpnEngine", "Failed to tear down AWG tunnel: ${e::class.java.simpleName}")
        } finally {
            backend = null
            activeTunnel = null
        }
    }

    // AmneziaWG Go backend does not provide real-time traffic statistics natively without polling
    // For now, we return emptyFlow.
    override val traffic: Flow<TrafficSample> = emptyFlow()
}
