package dev.kentra.vpn.service

import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import android.os.RemoteException
import android.util.Log
import dev.kentra.domain.model.TrafficSample
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * Drives the Xray helper core, which runs in a process of its own — [XrayCoreService]
 * explains why that is a hard requirement rather than a preference.
 *
 * This class holds no `libXray` import and never calls `System.loadLibrary("gojni")`.
 * Loading `libgojni.so` here is exactly what used to kill the process, so the two cores
 * are kept from ever meeting: everything this engine needs crosses Binder.
 *
 * ## Self-exclusion
 *
 * Xray dials the proxy server from inside the helper process, and those sockets must not
 * be captured by the TUN sing-box owns — a captured dial goes back into the SOCKS hop that
 * leads into Xray, and every CONNECT then fails with "connection refused" while the config
 * loads and the inbound accepts normally. `registerDialerController` would be the direct
 * answer, but the helper's `go.Seq` glue is only correct once it is alone in a process, and
 * the exemption is already expressed in the generated config: sing-box keeps this app's
 * own package out of the TUN (see `ConfigFactory.selfPackage`), which covers every process
 * of the package — including `:xray` — and needs no JNI callback.
 */
internal class XrayVpnEngine(
    private val context: Context,
    private val health: CoreHealth,
) : VpnEngine {

    override val id: String = "xray"

    private val _traffic = MutableStateFlow(TrafficSample(0, 0))
    override val traffic: Flow<TrafficSample> = _traffic.asStateFlow()

    private var host: XrayCoreHost? = null

    /** True between an accepted start() and a stop(). Keeps stop() off a never-started core. */
    @Volatile
    private var started = false

    override suspend fun start(service: Service, session: TunnelSession) {
        // A profile that sing-box can carry on its own has no Xray config at all.
        val config = session.xrayJson ?: return

        withContext(Dispatchers.IO) {
            val host = XrayCoreHost(context.applicationContext, health)
            this@XrayVpnEngine.host = host
            try {
                val error = host.run(config)
                if (error != null) {
                    // The error text can echo the config payload. Report the fact, never the text.
                    Log.e(TAG, "Xray rejected the config (${error.length} chars)")
                    throw IllegalStateException("Xray core refused the configuration")
                }
                // The native side reports failures *inside* the JSON rather than by
                // throwing, so "the call returned" is not evidence that Xray started.
                // Reading the reply here is what keeps a rejected config from being
                // reported to the user as a working tunnel.
                Log.d(TAG, "Xray helper accepted the configuration")
                started = true
            } catch (e: Throwable) {
                // Native code also throws Error subclasses (e.g. UnsatisfiedLinkError).
                // Never log the throwable: it can embed the request payload.
                Log.e(TAG, "Failed to start Xray: ${e::class.java.simpleName}")
                this@XrayVpnEngine.host = null
                runCatching { host.close() }
                throw e
            }
        }
    }

    override suspend fun stop() {
        // NonCancellable is mandatory. stop() is reached from the finally block of the
        // already-cancelled tunnel job; a plain withContext() throws CancellationException
        // BEFORE running the block, which aborted CompositeVpnEngine.stop() before it ever
        // reached the sing-box engine — leaving the kernel TUN (and the whole system VPN
        // network) alive after the user pressed "Отключить".
        withContext(NonCancellable + Dispatchers.IO) {
            val host = this@XrayVpnEngine.host
            this@XrayVpnEngine.host = null
            try {
                // Sent even when start() never completed: the helper ignores a stop it has
                // no core for, and a helper that outlived its session would otherwise
                // answer the next one with a stale core.
                host?.stop()
            } catch (e: Throwable) {
                // Teardown must never throw out of here: it would abort the composite
                // teardown and strand the sing-box engine.
                Log.e(TAG, "Failed to stop Xray: ${e::class.java.simpleName}")
            } finally {
                started = false
                runCatching { host?.close() }
                _traffic.value = TrafficSample(0, 0)
            }
        }
    }

    private companion object {
        const val TAG = "XrayVpnEngine"
    }
}

/**
 * Binder client for [XrayCoreService]. One host per session, released in [close].
 *
 * Requests are serialized by construction: [XrayVpnEngine] awaits each reply, and the
 * composite runs start before stop, so only one request is ever in flight.
 */
private class XrayCoreHost(
    private val context: Context,
    private val health: CoreHealth,
) {

    private val connected = CompletableDeferred<Unit>()
    private val messenger = AtomicReference<Messenger?>(null)
    private val bound = AtomicBoolean(false)
    private val pending = AtomicReference<CompletableDeferred<Bundle>?>(null)

    /**
     * Replies are delivered on the main looper, which exists in every process regardless
     * of the thread that started the request.
     */
    private val replies = object : Handler(Looper.getMainLooper()) {
        override fun handleMessage(message: Message) {
            val slot = pending.getAndSet(null) ?: return
            slot.complete(message.data ?: Bundle())
        }
    }
    private val replyMessenger = Messenger(replies)

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            if (service == null) {
                connected.completeExceptionally(IllegalStateException("Xray helper has no binder"))
                return
            }
            messenger.set(Messenger(service))
            connected.complete(Unit)
        }

        /**
         * Called when the process hosting the helper has crashed or been killed. That is
         * the one failure the request/reply path cannot see: the reply never comes, so
         * without this the tunnel would keep running with nothing behind its SOCKS hop.
         */
        override fun onServiceDisconnected(name: ComponentName?) {
            messenger.set(null)
            pending.getAndSet(null)?.completeExceptionally(IllegalStateException("Xray helper died"))
            connected.completeExceptionally(IllegalStateException("Xray helper died"))
            health.noteHelperLost()
        }
    }

    /** Returns the failure text reported by the helper, or null when Xray is up. */
    suspend fun run(config: String): String? {
        require(config.length <= MAX_CONFIG_CHARS) { "Xray config too large to hand to the helper" }
        val target = awaitMessenger()
        return request(target, XrayCoreProtocol.MSG_RUN, Bundle().apply {
            putString(XrayCoreProtocol.KEY_CONFIG, config)
        })
    }

    suspend fun stop() {
        val target = messenger.get() ?: return
        runCatching { request(target, XrayCoreProtocol.MSG_STOP, null) }
    }

    fun close() {
        if (!bound.getAndSet(false)) return
        messenger.set(null)
        pending.getAndSet(null)?.completeExceptionally(IllegalStateException("Xray helper released"))
        runCatching { context.unbindService(connection) }
    }

    private suspend fun awaitMessenger(): Messenger {
        if (bound.compareAndSet(false, true)) {
            val intent = Intent(context, XrayCoreService::class.java)
            if (!context.bindService(intent, connection, Context.BIND_AUTO_CREATE)) {
                bound.set(false)
                throw IllegalStateException("Xray helper is not available")
            }
        }
        withTimeout(XrayCoreProtocol.BIND_TIMEOUT_MS) { connected.await() }
        return messenger.get() ?: throw IllegalStateException("Xray helper is not available")
    }

    private suspend fun request(target: Messenger, what: Int, data: Bundle?): String? {
        val slot = CompletableDeferred<Bundle>()
        check(pending.compareAndSet(null, slot)) { "Xray helper request already in flight" }
        val message = Message.obtain(null, what).apply {
            if (data != null) this.data = data
            replyTo = replyMessenger
        }
        try {
            target.send(message)
        } catch (e: RemoteException) {
            pending.compareAndSet(slot, null)
            throw IllegalStateException("Xray helper is gone")
        }
        val reply = try {
            withTimeout(XrayCoreProtocol.REPLY_TIMEOUT_MS) { slot.await() }
        } finally {
            pending.compareAndSet(slot, null)
        }
        return reply.getString(XrayCoreProtocol.KEY_ERROR)?.takeIf { it.isNotBlank() }
    }

    private companion object {
        /**
         * Binder transactions are capped at 1 MB and the limit counts UTF-16 units, so this
         * is half of it. A config above this is malformed input, not a configuration: fail
         * with a name for the problem instead of a TransactionTooLargeException that the
         * user would read as "server unreachable".
         */
        const val MAX_CONFIG_CHARS = 512 * 1024
    }
}
