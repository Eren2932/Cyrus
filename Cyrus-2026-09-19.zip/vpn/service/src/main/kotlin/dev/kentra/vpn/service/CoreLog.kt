package dev.kentra.vpn.service

import android.content.Context
import android.content.pm.ApplicationInfo
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Diagnostics for the native core.
 *
 * sing-box messages routinely name the destination host and, on a configuration error,
 * echo the whole config — including the key. They therefore never go to logcat, where
 * every app on the device can read them. Instead they land in a bounded file inside the
 * app's private storage, readable only by this app (and by `run-as` on a debuggable build).
 *
 * Debug builds only: a release APK writes no core log at all.
 */
internal object CoreLog {

    private const val FILE_NAME = "core.log"
    private const val MAX_BYTES = 512L * 1024
    private const val KEEP_BYTES = 256L * 1024
    private const val TAG = "CyrusCoreLog"

    /**
     * JSON keys whose values must never be written, even to private storage.
     * `public_key` / `short_id` are deliberately absent: Reality's public key and short id
     * are public by design (they ship inside the share link) and are needed to verify a
     * handshake configuration.
     */
    private val SECRET_KEYS = setOf(
        "uuid", "password", "private_key", "preshared_key", "user", "username", "plugin_opts",
    )

    private val stamp = SimpleDateFormat("MM-dd HH:mm:ss.SSS", Locale.US)
    private val lock = Any()

    fun enabled(context: Context): Boolean =
        (context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0

    fun append(context: Context, message: String) {
        if (!enabled(context)) return
        write(context, message)
    }

    /**
     * Appends why the core refused to start, with credential-shaped substrings masked.
     *
     * A native failure is the only evidence that separates a rejected config from an
     * unreachable server, and the user-visible message deliberately says neither. It can
     * echo the config back, so it goes to this private file and never to logcat — and only
     * the message is kept: a stack trace would carry the same payload several times over.
     */
    fun appendFailure(context: Context, error: Throwable) {
        if (!enabled(context)) return
        val cause = generateSequence(error) { it.cause }.take(3).joinToString(" ← ") { it::class.java.simpleName }
        val message = generateSequence(error) { it.cause }
            .mapNotNull { it.message }
            .firstOrNull()
            .orEmpty()
        write(context, "start failed: $cause: ${mask(message).take(800)}")
    }

    private val TOKEN = Regex("[A-Za-z0-9+/_=-]{32,}")

    /** Masks anything long enough to be a key or a password. */
    private fun mask(message: String): String =
        TOKEN.replace(message) { "«masked: ${it.value.length} chars»" }

    /** Appends the config with credential values masked, so a failed dial can be inspected. */
    fun appendConfig(context: Context, configJson: String) {
        if (!enabled(context)) return
        val redacted = runCatching { (redact(JSONObject(configJson)) as JSONObject).toString(2) }
            .getOrElse { "«config не является JSON или не разобран»" }
        write(context, "--- sing-box config (секреты замаскированы) ---\n$redacted\n--- end config ---")
    }

    fun clear(context: Context) {
        runCatching { File(context.filesDir, FILE_NAME).delete() }
    }

    private fun write(context: Context, message: String) {
        synchronized(lock) {
            runCatching {
                val file = File(context.filesDir, FILE_NAME)
                if (file.length() > MAX_BYTES) truncate(file)
                file.appendText("${stamp.format(Date())} $message\n")
            }.onFailure { Log.w(TAG, "core log write failed: ${it::class.java.simpleName}") }
        }
    }

    private fun redact(value: Any?): Any? = when (value) {
        is JSONObject -> JSONObject().apply {
            for (key in value.keys()) {
                val raw = value.opt(key)
                if (key in SECRET_KEYS) {
                    val chars = raw?.toString()?.length ?: 0
                    put(key, "«masked: $chars chars»")
                } else {
                    put(key, redact(raw))
                }
            }
        }
        is JSONArray -> JSONArray().apply { for (i in 0 until value.length()) put(redact(value.opt(i))) }
        else -> value
    }

    /** Drops the oldest half so the file keeps the most recent activity. */
    private fun truncate(file: File) {
        val bytes = file.readBytes()
        val from = (bytes.size - KEEP_BYTES).coerceAtLeast(0).toInt()
        file.writeBytes(bytes.copyOfRange(from, bytes.size))
    }
}
