package dev.kentra.vpn.service

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withTimeoutOrNull

/** Raised when the core is running but cannot open a connection through any outbound. */
internal class CoreUnreachableException : IllegalStateException("core cannot reach its outbound")

/** Whether the core proved it can carry traffic, or is merely alive. */
internal enum class CoreVerdict { HEALTHY, UNREACHABLE }

/**
 * Verdict on whether the native core can actually carry traffic.
 *
 * 0.5.0 shipped a build that reported `Connected` while the core sat in a DNS bootstrap
 * deadlock: the proxy could never resolve its own server address, every dial failed, and
 * the device had no connectivity behind a green icon (docs/DEVICE_TEST_0.5.0.md §3.2).
 * `start()` returning proves only that the core came up — not that it can carry a single
 * packet — so the runner asks this monitor before it tells the user the tunnel is up.
 *
 * The evidence is the core's own verdict, not a probe. An external prober was rejected on
 * purpose: it would make "connected" depend on some third-party endpoint staying
 * reachable, and would report a slow server as broken. The configured log level is `warn`,
 * so a healthy core writes nothing at all — silence is the success signal.
 *
 * The markers below are read out of the pinned core binary itself
 * (`strings libbox.so`), not taken from documentation or from guesswork about its source.
 *
 * Which markers apply depends on the session's topology, because the core's own output
 * does: a session whose outbound is a loopback hop into the Xray helper has no dial that
 * can fail. [reset] is told, once per session, and [localHop] carries that for the life of
 * the session. A monitor that read one fixed set of markers was blind to that whole
 * topology - see [DNS_FAILURE_MARKER] for the device log that proves it.
 */
internal class CoreHealth {

    private val failures = MutableStateFlow(0)

    /** Outbound dial failures observed in the current session. */
    val dialFailures: StateFlow<Int> = failures.asStateFlow()

    /**
     * Whether this session's sing-box outbound is the loopback hop into the Xray helper
     * rather than the proxy itself.
     *
     * It decides which core output counts as a failure, and it is the difference between a
     * check that works and one that cannot work at all. A dial to `127.0.0.1` either lands
     * on a live listener or the helper is gone; the helper is started and answered before
     * the TUN exists, so in this topology the dial markers below are *structurally* unable
     * to fire, whatever the proxy behind them does. See [DNS_FAILURE_MARKER].
     */
    @Volatile
    private var localHop = false

    /** A new session must not inherit the previous session's verdict - nor its topology. */
    fun reset(expectsLocalHop: Boolean = false) {
        failures.value = 0
        localHop = expectsLocalHop
    }

    /**
     * Feeds one line of native output. The line is never logged: it names the destination
     * host, and not leaking that is the whole reason `writeLog` stays out of logcat.
     */
    fun onCoreMessage(message: String) {
        val markers = if (localHop) LOCAL_HOP_FAILURE_MARKERS else DIAL_FAILURE_MARKERS
        if (markers.none(message::contains)) return
        if (CANCELLATION_CAUSES.any(message::contains)) return
        // `writeLog` is invoked from several Go threads. `value += 1` is a
        // read-modify-write: concurrent calls lose increments, the threshold is never
        // reached and a core that cannot dial at all is reported HEALTHY. `update`
        // is the atomic form and must be used here.
        failures.update { it + 1 }
    }

    /**
     * The Xray helper process is gone — see [XrayCoreService] for why it is a separate
     * process at all.
     *
     * Its loopback listener is the hop sing-box chains into, so losing it black-holes
     * every packet the tunnel carries while the icon stays green. That is not a flake to
     * be averaged out, so the counter is driven past any threshold a caller can pass
     * rather than incremented: one lost helper is already a dead tunnel.
     */
    fun noteHelperLost() {
        failures.update { HELPER_LOST }
    }

    /**
     * Holds the session in `Preparing` for at most [graceMs] and reports what the core
     * managed to prove. Silence counts as proof: at `warn` level a core that can dial
     * writes nothing, and a core that cannot says so immediately.
     */
    suspend fun awaitVerdict(graceMs: Long, threshold: Int): CoreVerdict {
        if (failures.value >= threshold) return CoreVerdict.UNREACHABLE
        withTimeoutOrNull(graceMs) { failures.first { it >= threshold } }
        return if (failures.value >= threshold) CoreVerdict.UNREACHABLE else CoreVerdict.HEALTHY
    }

    /**
     * Suspends until a later failure invalidates an already published `Connected`.
     * The caller bounds this with its own window: a stray failure hours into a session is
     * a different problem (a network change) and must not tear a working tunnel down.
     */
    suspend fun awaitInvalidation(threshold: Int) {
        failures.first { it >= threshold }
    }

    private companion object {
        /**
         * How the pinned core wraps a failed outbound dial. Both variants are real and
         * both are needed: the stream one and the UDP/packet one.
         *
         * Deliberately NOT included: `exchange failed for`. A DNS exchange can fail for a
         * single destination without the tunnel being broken, and the proxy's own name
         * resolution already fails the dial below it, so the dial markers cover that case
         * without the extra noise.
         *
         * "the dial below it" is the load-bearing phrase, and [LOCAL_HOP_FAILURE_MARKERS]
         * is what happens when there is no such dial.
         */
        val DIAL_FAILURE_MARKERS = listOf(
            "open outbound connection",
            "open outbound packet connection",
        )

        /**
         * How the pinned core reports a name lookup it could not complete.
         *
         * Excluded from the default markers on purpose - see [DIAL_FAILURE_MARKERS] - and
         * counted only in a [localHop] session, where the exclusion's premise does not
         * hold. A device log shows what the premise costs.
         *
         * Session `proxy-4` at 2026-09-20 13:46:44 carries a transport only Xray can
         * carry, so its sing-box config had a single outbound - `socks 127.0.0.1:2081`,
         * the helper's loopback listener - and reported
         *
         *     core verdict: HEALTHY after 2500ms, dialFailures=0
         *     core probation passed: dialFailures=0
         *
         * over a session in which *every* lookup died: 108 x
         * `dns: exchange failed for <host>. IN A: context deadline exceeded`, and 29
         * connections left hanging for up to 4m4s before the core closed them. Nothing on
         * the device resolved for four and a half minutes while the icon said connected.
         * The counter was zero because the dial it watches was to a socket that was
         * listening.
         *
         * `context canceled` lookups are still not counted here - they are filtered by
         * [CANCELLATION_CAUSES] before either marker set is consulted.
         */
        const val DNS_FAILURE_MARKER = "dns: exchange failed for"

        /** What counts as a failure when the front core's outbound is a loopback hop. */
        val LOCAL_HOP_FAILURE_MARKERS = DIAL_FAILURE_MARKERS + DNS_FAILURE_MARKER

        /**
         * Causes that mean the caller gave up, not that the core could not dial: an app
         * aborting a request, a connectivity probe timing out, a superseded request.
         *
         * Measured on a working VLESS session: two of these in a 50 s window while the
         * tunnel carried 1.4 MB in each direction and the egress IP was the server's. A
         * cancellation is categorically not evidence of unreachability, so it must not
         * count towards the threshold — otherwise the check fires on healthy tunnels.
         */
        val CANCELLATION_CAUSES = listOf(
            "context canceled",
            "operation was canceled",
        )

        /**
         * Above every threshold a caller passes. A lost helper is never "not enough
         * failures yet", so it must not be expressed as an increment.
         */
        const val HELPER_LOST = 1_000
    }
}
