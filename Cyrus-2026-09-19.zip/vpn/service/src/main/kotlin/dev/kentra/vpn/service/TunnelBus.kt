package dev.kentra.vpn.service

import dev.kentra.domain.model.TrafficSample
import dev.kentra.domain.model.TunnelState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Shown when a tunnel may still be up that we can no longer control. Kept next to the bus
 * because the bus is the last line of defence against claiming a state we cannot prove.
 */
internal const val FAILED_TEARDOWN =
    "Не удалось снять туннель: соединение может остаться активным. " +
        "Отключите VPN в системных настройках или перезапустите приложение."

/**
 * Single source of truth for tunnel state inside the app process.
 *
 * PHASE 1: the service runs in the main process, so a shared object is enough.
 * PHASE 2: the service moves to `android:process=":vpn"` and this class becomes
 * the client side of an AIDL/Messenger channel. The rest of the app will not notice,
 * because nothing outside this package reads the tunnel state directly.
 */
class TunnelBus {
    // Read from the main thread (UI) and written from the tunnel coroutine. Without
    // @Volatile the UI can keep seeing a stale owner after release(), which is exactly
    // the window in which it would offer "Подключить" over a TUN that is still up.
    @Volatile
    var owner: Any? = null
        private set
    fun claim(value: Any) { owner = value }
    fun release(value: Any) {
        if (owner === value) {
            owner = null
            // Fail-closed, same rule the runner applies after a teardown (DEVICE_TEST_0.5.0.md
            // §3.5): an owner that disappears while the state is `Connected` never proved the
            // TUN was released, so claiming `Idle` would be a lie the user pays for — the UI
            // would offer "Подключить" over a registered VPN network that black-holes every
            // packet. Preparing/Stopping still reset: the tunnel never came up, so there is
            // nothing to warn about, and the connect was simply abandoned.
            if (state.value is TunnelState.Connected) publish(TunnelState.Failed(FAILED_TEARDOWN))
            else if (state.value !is TunnelState.Failed) reset()
        }
    }

    private val _state = MutableStateFlow<TunnelState>(TunnelState.Idle)
    val state: StateFlow<TunnelState> = _state.asStateFlow()

    private val _traffic = MutableStateFlow(TrafficSample())
    val traffic: StateFlow<TrafficSample> = _traffic.asStateFlow()

    fun publish(state: TunnelState) {
        _state.value = state
    }

    fun publish(sample: TrafficSample) {
        _traffic.value = sample
    }

    fun reset() {
        _state.value = TunnelState.Idle
        _traffic.value = TrafficSample()
    }
}
