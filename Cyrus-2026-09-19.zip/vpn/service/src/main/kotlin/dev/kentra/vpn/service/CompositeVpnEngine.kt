package dev.kentra.vpn.service

import android.app.Service
import android.content.Context
import dev.kentra.core.datastore.ProtectionStatsStore
import dev.kentra.domain.model.TrafficSample
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext

internal class CompositeVpnEngine(
    private val context: Context,
    private val health: CoreHealth,
    private val protectionStats: ProtectionStatsStore,
    private val protectionCa: ProtectionCa,
) : VpnEngine {
    override val id: String = "composite"

    private val libbox = LibboxVpnEngine(health, protectionStats, MitmInspection(protectionCa))
    private val amnezia = AmneziaVpnEngine(context)
    private val xray = XrayVpnEngine(context, health)

    private var activeEngine: VpnEngine? = null
    private val _traffic = MutableStateFlow<Flow<TrafficSample>>(emptyFlow())

    override suspend fun start(service: Service, session: TunnelSession) {
        // The owner is decided by the controller, not sniffed out of the config.
        // Xray is never the owner: it terminates a transport sing-box cannot carry
        // and exposes it on loopback, while sing-box keeps owning the TUN.
        val engine = when (session.owner) {
            TunnelOwner.AMNEZIA -> amnezia
            TunnelOwner.SING_BOX -> libbox
        }

        // Register the engine BEFORE starting it. A start() that throws must stay
        // reachable by stop(), otherwise the half-started core is never torn down.
        activeEngine = engine
        _traffic.value = engine.traffic

        // Start Xray first so the loopback target exists by the time the TUN comes
        // up and the chained sing-box outbound tries to reach it. The Xray core lives in
        // its own process (XrayCoreService): two Go runtimes in one process abort it.
        if (session.xrayJson != null) {
            xray.start(service, session)
        }

        engine.start(service, session)
    }

    override suspend fun stop() {
        // NonCancellable is mandatory: stop() is invoked from the finally block of the
        // cancelled tunnel job. Without it, the first suspension point throws
        // CancellationException and the whole teardown is abandoned — the native TUN
        // stays up, the system keeps the VPN network registered, and the device loses
        // all connectivity. (This is exactly what "Отключить" used to do.)
        withContext(NonCancellable) {
            var failure: Throwable? = null

            // Tear the engines down independently: a failure in one must not strand
            // the other, and the active engine is the one holding the TUN.
            runCatching { xray.stop() }.onFailure { failure = it }

            val engine = activeEngine
            activeEngine = null
            if (engine != null) {
                // The active engine owns the TUN, so its failure outranks the other's.
                runCatching { engine.stop() }.onFailure { failure = it }
            }

            _traffic.value = emptyFlow()

            // Surface the failure so the runner can stay fail-closed instead of telling
            // the user the tunnel is down while it may still be routing traffic.
            failure?.let { throw it }
        }
    }

    override val traffic: Flow<TrafficSample> = _traffic.flatMapLatest { it }

    /**
     * Reflects the session that is actually up. The composite is what Koin hands the
     * runner, but only the sing-box branch can produce a dial verdict — a WireGuard
     * session must not be held in Preparing waiting for a signal it cannot emit.
     */
    override val reportsDialFailures: Boolean
        get() = activeEngine?.reportsDialFailures == true
}
