package dev.kentra.vpn.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import dev.kentra.domain.model.TunnelState
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel

/** FIFO owns start/replace/stop; cancellation always joins native teardown before the next start. */
internal class TunnelServiceRunner(
    private val service: Service,
    private val bus: TunnelBus,
    private val engine: VpnEngine,
    private val health: CoreHealth,
    private val proxy: Boolean,
    private val networkWatcher: NetworkWatcher? = null,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private data class Command(val session: TunnelSession?, val startId: Int)
    private val commands = Channel<Command>(Channel.UNLIMITED)
    private var tunnelJob: Job? = null
    private var latestStartId = 0
    private var generation = 0L

    /**
     * Brings the tunnel back when the network does. The retry only re-queues: every
     * re-dial goes through the same FIFO as a user's connect, so it cannot race a teardown
     * or build a second TUN alongside a live one.
     */
    private val recovery = TunnelRecovery(networkWatcher) { session ->
        CoreLog.append(service, "network back: dialling «${session.profileName}» again")
        commands.trySend(Command(session, latestStartId))
    }

    /**
     * Result of the most recent native teardown. Non-null means the engine could not
     * confirm it released the TUN, so the UI must not claim the tunnel is down.
     */
    private var teardownError: Throwable? = null
    private val notificationId = if (proxy) 0x4B46 else 0x4B45

    init {
        scope.launch {
            for (command in commands) {
                generation++
                val token = generation
                bus.publish(TunnelState.Stopping)
                tunnelJob?.cancelAndJoin()
                tunnelJob = null
                val session = command.session
                if (session == null) {
                    // The user asked for no tunnel, so a later network event must not
                    // bring one back. Forgetting the session is what makes that true.
                    recovery.stoppedByUser()
                    val error = teardownError
                    teardownError = null
                    if (error == null) {
                        bus.reset()
                    } else {
                        // Fail-closed. A teardown that did not release the TUN leaves the
                        // system VPN network registered and every packet black-holed, so
                        // reporting Idle here would be a lie the user pays for.
                        bus.publish(TunnelState.Failed(FAILED_TEARDOWN))
                    }
                    finish(command.startId)
                    continue
                }
                bus.publish(TunnelState.Preparing)
                recovery.started(session)
                tunnelJob = scope.launch {
                    var failure: String? = null
                    try {
                        coroutineScope {
                            launch { engine.traffic.collect { bus.publish(it) } }
                            engine.start(service, session)

                            // start() proves the core came up, not that it can dial. A core
                            // stuck in a DNS bootstrap deadlock returns from start() happily
                            // and then black-holes every packet, which is how 0.5.0 showed a
                            // green icon over a device with no connectivity at all
                            // (docs/DEVICE_TEST_0.5.0.md §3.2). Hold the UI in Preparing
                            // until the core has had its chance to prove itself. An engine
                            // that cannot report a verdict is not held at all — waiting for
                            // evidence that will never come is not a check, it is a delay.
                            val verdict = if (engine.reportsDialFailures) {
                                val v = health.awaitVerdict(CORE_GRACE_MS, CORE_FAILURE_THRESHOLD)
                                CoreLog.append(service, "core verdict: $v after ${CORE_GRACE_MS}ms, dialFailures=${health.dialFailures.value}")
                                v
                            } else {
                                CoreVerdict.HEALTHY
                            }
                            if (verdict == CoreVerdict.UNREACHABLE) throw CoreUnreachableException()

                            // Guarded like `Failed` below. Publishing `Connected` from a
                            // superseded session is the exact failure that made 0.5.0 show a
                            // green icon over a device with no connectivity: the state is the
                            // one thing the user trusts, and a stale token has no right to set
                            // it. The probation window therefore also belongs inside the guard
                            // — watching a session that will never be shown is just a delay.
                            if (token == generation) {
                                recovery.connected()
                                bus.publish(TunnelState.Connected(session.profileId, System.currentTimeMillis(), proxy))
                                // Update the existing foreground-service notification through
                                // the FGS API, which remains valid if POST_NOTIFICATIONS is denied.
                                service.startForeground(notificationId, notification(true))

                                // A clean verdict window is not evidence that the core will
                                // stay healthy, because the dial that matters is the slow one.
                                // Measured on device: the bootstrap failure of a
                                // hostname-addressed outbound surfaces 6.1 s after start —
                                // 3.6 s AFTER a 2.5 s window closed with zero failures, because
                                // DNS times out rather than refusing. Stay on probation long
                                // enough to cover that, and tear down instead of leaving a green
                                // icon over a tunnel that black-holes every packet: a dead
                                // tunnel is worse for the user than no tunnel.
                                if (engine.reportsDialFailures) {
                                    val invalidated = withTimeoutOrNull(CORE_PROBATION_MS) {
                                        health.awaitInvalidation(CORE_FAILURE_THRESHOLD)
                                        true
                                    }
                                    CoreLog.append(
                                        service,
                                        if (invalidated == true) "core invalidated after connect: dialFailures=${health.dialFailures.value}"
                                        else "core probation passed: dialFailures=${health.dialFailures.value}",
                                    )
                                    if (invalidated == true) throw CoreUnreachableException()
                                }
                            }
                            awaitCancellation()
                        }
                    } catch (error: Throwable) {
                        if (error is kotlinx.coroutines.CancellationException) throw error
                        // Native exceptions may embed a key/config. Do not expose the exception verbatim.
                        // The cause still has to survive somewhere: without it a rejected
                        // config and an unreachable server are indistinguishable, and the
                        // only way to tell them apart is to guess.
                        CoreLog.appendFailure(service, error)
                        failure = if (error is CoreUnreachableException) FAILED_CORE_UNREACHABLE else FAILED_CORE_START
                        bus.publish(TunnelState.Stopping)
                    } finally {
                        // Cancellation cannot interrupt the engine's serialized teardown.
                        // Replacement commands must wait for this cleanup to finish.
                        // NonCancellable is mandatory: this block runs for an already
                        // cancelled job, and any suspension point inside would otherwise
                        // throw before the native teardown executes, stranding the TUN.
                        teardownError = withContext(NonCancellable) {
                            runCatching { engine.stop() }.exceptionOrNull()
                        }
                        if (failure != null && token == generation) {
                            // Whether the cause was the network is decided by the policy,
                            // not here: it arms only when the device has nothing to dial
                            // through, which is the one failure a returning network fixes.
                            recovery.failed()
                            if (recovery.armed()) {
                                CoreLog.append(service, "recovery armed: «${session.profileName}» will be redialled when a network returns")
                                service.startForeground(notificationId, notification(connected = false, waitingForNetwork = true))
                            }
                            bus.publish(TunnelState.Failed(failure))
                        }
                        // A tunnel kept waiting is not released. The service owns the
                        // watcher, so stopping here would unregister the very callback
                        // meant to bring the tunnel back - which is what happened on the
                        // first attempt at this: the watcher armed, the service stopped,
                        // and nothing ever fired. The user still sees the failure, and
                        // disconnecting still releases the service at once.
                        if (token == generation && !recovery.armed()) finish(command.startId)
                    }
                }
            }
        }
    }

    fun command(intent: Intent?, startId: Int) {
        latestStartId = startId
        bus.claim(this)
        if (intent?.action == CyrusVpnService.ACTION_START) {
            // Must happen synchronously, before awaiting an older session's teardown.
            service.startForeground(notificationId, notification(false))
            val owner = if (intent.getStringExtra(CyrusVpnService.EXTRA_TUNNEL_OWNER) == TunnelOwner.AMNEZIA.name)
                TunnelOwner.AMNEZIA else TunnelOwner.SING_BOX
            val session = TunnelSession(
                intent.getStringExtra(CyrusVpnService.EXTRA_PROFILE_ID).orEmpty(),
                intent.getStringExtra(CyrusVpnService.EXTRA_PROFILE_NAME).orEmpty(),
                intent.getStringExtra(CyrusVpnService.EXTRA_CONFIG).orEmpty(),
                intent.getStringExtra(CyrusVpnService.EXTRA_XRAY_CONFIG),
                owner,
            )
            commands.trySend(Command(session, startId))
        } else commands.trySend(Command(null, startId))
    }

    fun revoke() { commands.trySend(Command(null, latestStartId)) }
    fun destroy() {
        generation++
        recovery.destroy()
        commands.close()
        scope.cancel()
        bus.release(this)
    }
    private fun finish(startId: Int) {
        if (startId != latestStartId) return
        service.stopForeground(Service.STOP_FOREGROUND_REMOVE)
        service.stopSelfResult(startId)
    }
    private fun notification(connected: Boolean, waitingForNetwork: Boolean = false): Notification {
        val channel = "cyrus_connection"
        val manager = service.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26 && manager.getNotificationChannel(channel) == null)
            manager.createNotificationChannel(NotificationChannel(channel, "Подключение Cyrus", NotificationManager.IMPORTANCE_LOW).apply {
                lockscreenVisibility = Notification.VISIBILITY_SECRET
                setShowBadge(false)
            })
        val intent = Intent(service, service.javaClass).setAction(CyrusVpnService.ACTION_STOP)
        val stop = PendingIntent.getService(service, notificationId, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(service, channel).setSmallIcon(R.drawable.ic_stat_vpn)
            .setContentTitle(
                when {
                    connected -> if (proxy) "Локальный прокси запущен" else "VPN-интерфейс запущен"
                    waitingForNetwork -> "Ожидание сети"
                    else -> "Подключение…"
                },
            )
            .setContentText(
                when {
                    waitingForNetwork -> "Cyrus подключится, когда сеть появится"
                    proxy -> "Только приложения с настроенным прокси"
                    else -> "Cyrus · сетевое ядро активно"
                },
            )
            .setVisibility(NotificationCompat.VISIBILITY_SECRET).setOngoing(true).setOnlyAlertOnce(true)
            .addAction(0, "Отключить", stop).build()
    }

    private companion object {
        /**
         * How long the session stays in `Preparing` before `Connected` is published.
         * The core dials its own outbound within milliseconds of `start()` returning, so a
         * bootstrap failure lands inside this window and the user never sees a green icon
         * over a dead tunnel. A healthy core is silent at `warn` level, so the window is
         * always paid in full — this is the price of not lying about the tunnel.
         */
        const val CORE_GRACE_MS = 2_500L

        /** One dial failure is a flake; three is a pattern. */
        const val CORE_FAILURE_THRESHOLD = 3

        /**
         * How long a freshly published `Connected` stays on probation. Must exceed the
         * slowest first dial — measured at 6.1 s for a hostname-addressed outbound whose
         * bootstrap DNS times out — with margin for a slower resolver.
         */
        const val CORE_PROBATION_MS = 12_000L

        const val FAILED_CORE_START =
            "Ядро не запустилось. Проверьте параметры, доступность порта и поддержку ключа."

        const val FAILED_CORE_UNREACHABLE =
            "Ядро запустилось, но не может открыть соединение. Проверьте адрес сервера, " +
                "ключ и доступность сети."
    }
}
