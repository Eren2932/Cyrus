package dev.kentra.vpn.service

import android.util.Log
import io.nekohasekai.libbox.Libbox
import io.nekohasekai.libbox.MitmCertificateProvider

/**
 * The bridge between the core's TLS engine and the CA key in the keystore.
 *
 * The core asks for a leaf certificate every time it wants to terminate a
 * connection, and it cannot mint one itself: signing needs the CA key, and that
 * key lives in the Android keystore, where it can sign but cannot be exported.
 * So the question crosses into Kotlin and the answer crosses back as DER.
 *
 * What crosses is only what has to. The leaf key pair is generated inside the
 * core, whose private half never leaves its own memory; this side sees a public
 * key and returns a certificate for it. The CA key never leaves the keystore
 * either — it only signs.
 *
 * The core caches per host and only calls back for hosts it has not issued for
 * recently, so this is not on the hot path of every connection.
 */
internal class MitmInspection(private val ca: ProtectionCa) {

    /**
     * Makes certificate issuance available to the core. Interception still only
     * happens where the route sends traffic to the mitm outbound, so installing
     * this while the user has inspection switched off intercepts nothing.
     */
    fun install() {
        runCatching { Libbox.setMitmCertificateProvider(Issuer(ca)) }
            .onFailure { Log.e(TAG, "MITM provider not installed: ${it::class.java.simpleName}") }
    }

    /** Withdraws issuance. Connections then pass through the core untouched. */
    fun uninstall() {
        runCatching { Libbox.setMitmCertificateProvider(null) }
            .onFailure { Log.w(TAG, "MITM provider not withdrawn: ${it::class.java.simpleName}") }
    }

    private class Issuer(private val ca: ProtectionCa) : MitmCertificateProvider {
        /**
         * @return the DER certificate, or null when there is no root (or the host
         *         is not one we will sign for): the core then forwards the
         *         connection untouched instead of failing it.
         */
        override fun issue(serverName: String, publicKey: ByteArray): ByteArray? =
            runCatching { ca.issueLeaf(serverName, publicKey) }
                .onFailure { Log.w(TAG, "leaf for $serverName failed: ${it::class.java.simpleName}") }
                .getOrNull()
    }

    private companion object {
        const val TAG = "MitmInspection"
    }
}
