package dev.kentra.vpn.service

import dev.kentra.domain.repository.TunnelController
import dev.kentra.vpn.config.ConfigFactory
import org.koin.android.ext.koin.androidContext
import org.koin.dsl.module

val vpnModule = module {
    single { TunnelBus() }
    single { CoreHealth() }
    single { ConfigFactory(selfPackage = androidContext().packageName) }
    // Root CA for HTTPS inspection. Created only when the user asks for it.
    single { ProtectionCa(androidContext()) }

    // Composite core (Sing-box + AmneziaWG + Xray helper).
    //
    // Built defensively: the native cores are `compileOnly` here and are bundled by
    // :app. If an artifact is missing, a bare NoClassDefFoundError from the Koin
    // graph tells the user nothing — the fallback refuses every connection with a
    // readable message and makes the "unavailable" check in TunnelControllerImpl live.
    single<VpnEngine> {
        val health: CoreHealth = get()
        runCatching { CompositeVpnEngine(androidContext(), health, get(), get()) }
            .onFailure { android.util.Log.e("VpnModule", "Composite engine unavailable: ${it::class.java.simpleName}") }
            .getOrElse { UnavailableVpnEngine() }
    }

    single<TunnelController> {
        TunnelControllerImpl(
            context = androidContext(),
            bus = get(),
            settings = get(),
            configFactory = get(),
            engine = get(),
        )
    }
}
