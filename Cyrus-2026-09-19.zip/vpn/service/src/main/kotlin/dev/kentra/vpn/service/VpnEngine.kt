package dev.kentra.vpn.service

import android.app.Service
import android.net.VpnService
import dev.kentra.domain.model.TrafficSample
import kotlinx.coroutines.flow.Flow

/**
 * Which core owns the TUN interface for a session.
 *
 * Decided by the controller from the profile's protocol and passed explicitly. It
 * must never be inferred from the config text: when the composite used to sniff
 * for "[Interface]" in the JSON, a change in the WireGuard config format silently
 * routed WireGuard into the sing-box core.
 */
enum class TunnelOwner { SING_BOX, AMNEZIA }

/** Everything the engine needs to bring a tunnel up. Generated in :vpn:config, never hand-written. */
data class TunnelSession(
    val profileId: String,
    val profileName: String,
    val configJson: String,
    val xrayJson: String? = null,
    /** Core that owns the TUN. Xray, when present, is always a helper behind sing-box. */
    val owner: TunnelOwner = TunnelOwner.SING_BOX,
)

/** Android engine boundary. Native integration must also implement protect(), DNS and lifecycle handling. */
interface VpnEngine {
    val id: String

    /** Must establish the TUN interface through [service] and return only after a real tunnel is established. */
    suspend fun start(service: Service, session: TunnelSession)

    suspend fun stop()

    val traffic: Flow<TrafficSample>

    /**
     * Whether this engine can report the core's own verdict on outbound dials.
     *
     * Only the sing-box engine can: `writeLog` is the one place a core failure surfaces.
     * Where this is false the runner skips the liveness window instead of making every
     * connect wait for evidence that will never arrive. Defaults to false so a new engine
     * is honest about the gap rather than silently inheriting a check it cannot satisfy.
     */
    val reportsDialFailures: Boolean get() = false
}
