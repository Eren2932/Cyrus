package dev.kentra.vpn.service

import dev.kentra.domain.model.*
import org.junit.Assert.*
import org.junit.Test

class TunnelBusTest {
    @Test fun `obsolete service cannot reset new connection`() {
        val bus=TunnelBus();val old=Any();val new=Any()
        bus.claim(old);bus.publish(TunnelState.Connected("old",0));bus.claim(new);bus.publish(TunnelState.Preparing)
        bus.release(old);assertEquals(TunnelState.Preparing,bus.state.value)
        bus.release(new);assertEquals(TunnelState.Idle,bus.state.value)
    }
    @Test fun `release retains a useful failure`() { val b=TunnelBus();val owner=Any();b.claim(owner);b.publish(TunnelState.Failed("test-only"));b.release(owner);assertTrue(b.state.value is TunnelState.Failed) }

    /**
     * §3.5: the UI must never say "Подключить" while the TUN may still be up. The runner's
     * teardown path is already fail-closed, but an owner that disappears while the state is
     * `Connected` (service destroyed without a confirmed teardown) used to reset to `Idle`,
     * which is the same lie in a different place.
     */
    @Test fun `release must not claim idle over a live tunnel`() {
        val bus = TunnelBus(); val owner = Any()
        bus.claim(owner); bus.publish(TunnelState.Connected("live", 0))
        bus.release(owner)
        assertTrue("release from Connected reset to ${bus.state.value}: the TUN may still be up",
            bus.state.value is TunnelState.Failed)
    }
    @Test fun `missing statistics are distinguishable from zero`() { assertFalse(TrafficSample().available);assertTrue(TrafficSample(available=true).available) }
    @Test fun `proxy mode is explicit in connection state`() { assertTrue(TunnelState.Connected("test",0,proxyOnly=true).proxyOnly) }
}
