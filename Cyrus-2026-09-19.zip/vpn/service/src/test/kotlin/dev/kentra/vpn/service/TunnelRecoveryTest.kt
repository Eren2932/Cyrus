package dev.kentra.vpn.service

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * A tunnel started while the device has no network fails its probation and stays dead:
 * nothing in the app listens for the network coming back. These cover the policy that
 * decides when another dial is deserved - not the ConnectivityManager, which cannot be
 * constructed here and is wrapped by a seam precisely so that this can be.
 */
class TunnelRecoveryTest {

    @Test
    fun `a tunnel the user still wants is redialled when the network returns`() {
        val watcher = FakeWatcher()
        val (recovery, redials) = recovery(watcher)
        val session = session("a")

        recovery.started(session)
        recovery.failed()
        watcher.fire()

        assertEquals(listOf(session), redials)
    }

    @Test
    fun `a healthy tunnel is not watched at all`() {
        val watcher = FakeWatcher()
        val (recovery, redials) = recovery(watcher)

        recovery.started(session("a"))
        recovery.connected()

        // The core rebinds its own sockets when the physical network changes, so watching a
        // tunnel that is already up would only add a second, competing recovery path.
        assertFalse(watcher.watching)
        assertTrue(redials.isEmpty())
    }

    @Test
    fun `a tunnel the user switched off is never brought back`() {
        val watcher = FakeWatcher()
        val (recovery, redials) = recovery(watcher)

        recovery.started(session("a"))
        recovery.stoppedByUser()
        recovery.failed()
        watcher.fire()

        assertFalse(watcher.watching)
        assertTrue(redials.isEmpty())
    }

    @Test
    fun `several network events are still one attempt`() {
        val watcher = FakeWatcher()
        val (recovery, redials) = recovery(watcher)
        val session = session("a")

        recovery.started(session)
        recovery.failed()
        watcher.fire()
        watcher.fire()
        watcher.fire()

        // A device flapping between Wi-Fi and cellular must not become a dial loop.
        assertEquals(listOf(session), redials)
    }

    @Test
    fun `a later failure arms the watcher again`() {
        val watcher = FakeWatcher()
        val (recovery, redials) = recovery(watcher)
        val session = session("a")

        recovery.started(session)
        recovery.failed()
        watcher.fire()

        // The first attempt failed too - the network was announced before it validated.
        recovery.failed()
        assertTrue("вторая неудача должна снова вооружить наблюдателя", watcher.watching)
        watcher.fire()

        assertEquals(listOf(session, session), redials)
    }

    @Test
    fun `the watcher is released once an attempt has been made`() {
        val watcher = FakeWatcher()
        val (recovery, _) = recovery(watcher)

        recovery.started(session("a"))
        recovery.failed()
        watcher.fire()

        assertEquals(1, watcher.stopped)
    }

    @Test
    fun `a failure with a network present is not waited out`() {
        val watcher = FakeWatcher().apply { hasNetwork = true }
        val (recovery, redials) = recovery(watcher)

        recovery.started(session("a"))
        recovery.failed()

        // The network is there and the tunnel still failed, so the cause is the key or the
        // server. Waiting would hold a foreground service for an event that changes nothing.
        assertFalse(watcher.watching)
        watcher.fire()
        assertTrue(redials.isEmpty())
    }

    @Test
    fun `a failure with no network is waited out`() {
        val watcher = FakeWatcher().apply { hasNetwork = false }
        val (recovery, _) = recovery(watcher)

        recovery.started(session("a"))
        recovery.failed()

        assertTrue(watcher.watching)
        assertTrue(recovery.armed())
    }

    @Test
    fun `a failure with nothing wanted arms nothing`() {
        val watcher = FakeWatcher()
        val (recovery, _) = recovery(watcher)

        // Disconnected while the session was still failing.
        recovery.failed()

        assertFalse(watcher.watching)
    }

    @Test
    fun `destroy forgets the session`() {
        val watcher = FakeWatcher()
        val (recovery, redials) = recovery(watcher)

        recovery.started(session("a"))
        recovery.failed()
        recovery.destroy()
        watcher.fire()

        assertTrue(redials.isEmpty())
        assertFalse(watcher.watching)
    }

    @Test
    fun `recovery is armed only once while already watching`() {
        val watcher = FakeWatcher()
        val (recovery, _) = recovery(watcher)

        recovery.started(session("a"))
        recovery.failed()
        recovery.failed()

        // Two failures, one watcher: a second registration would leak the first callback.
        assertEquals(1, watcher.registrations)
    }

    private fun recovery(watcher: NetworkWatcher): Pair<TunnelRecovery, List<TunnelSession>> {
        val redials = mutableListOf<TunnelSession>()
        return TunnelRecovery(watcher) { redials += it } to redials
    }

    private fun session(id: String) = TunnelSession(id, "name $id", "{}")

    /**
     * Keeps the listener after [stop], which is what ConnectivityManager does:
     * unregistering stops *new* callbacks but does not recall one already in flight. That
     * is what makes `fire()` twice meaningful - two networks announced at once arrive as
     * two calls on two threads, and only one of them may dial.
     */
    private class FakeWatcher : NetworkWatcher {
        private var listener: (() -> Unit)? = null
        var registrations = 0
        var stopped = 0
        var hasNetwork = false
        private var armed = false
        val watching get() = armed

        override fun watch(onNetwork: () -> Unit) {
            registrations++
            armed = true
            listener = onNetwork
        }

        override fun stop() {
            stopped++
            armed = false
        }

        override fun hasNetworkNow(): Boolean = hasNetwork

        fun fire() { listener?.invoke() }
    }
}
