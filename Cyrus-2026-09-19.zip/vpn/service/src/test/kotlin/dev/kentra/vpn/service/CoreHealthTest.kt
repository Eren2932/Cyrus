package dev.kentra.vpn.service

import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * H-4 regression: the counter used to be `failures.value += 1`. `writeLog` is called
 * from several Go threads at once, so that read-modify-write lost increments, the
 * threshold was never reached, and a core that could not dial at all was reported
 * HEALTHY - the exact 0.5.0 failure of a green icon over a device with no connectivity.
 */
class CoreHealthTest {

    private fun dialFailure() = "2026/09/19 12:00:00 [warn] inbound: open outbound connection: dial tcp: i/o timeout"

    @Test
    fun `concurrent dial failures are all counted`() {
        val health = CoreHealth()
        val threads = 8
        val perThread = 500
        val start = CountDownLatch(1)
        val done = CountDownLatch(threads)
        val errors = ConcurrentLinkedQueue<Throwable>()

        repeat(threads) { index ->
            // Plain threads, not coroutines: this is how the Go runtime calls back.
            thread(name = "go-$index", isDaemon = true) {
                try {
                    start.await()
                    repeat(perThread) { health.onCoreMessage(dialFailure()) }
                } catch (t: Throwable) {
                    errors += t
                } finally {
                    done.countDown()
                }
            }
        }

        start.countDown()
        assertTrue("workers did not finish", done.await(30, TimeUnit.SECONDS))
        assertTrue("worker errors: $errors", errors.isEmpty())

        // A lost increment anywhere means the threshold can be missed, i.e. a dead core
        // reported as healthy. There is no tolerance here - the count must be exact.
        assertEquals(
            "lost increments: ${threads * perThread - health.dialFailures.value} of ${threads * perThread}",
            threads * perThread,
            health.dialFailures.value,
        )
    }

    @Test
    fun `only real dial failures count`() {
        val health = CoreHealth()
        health.onCoreMessage("[info] sing-box started")
        health.onCoreMessage("[warn] something else entirely")
        assertEquals(0, health.dialFailures.value)

        health.onCoreMessage(dialFailure())
        health.onCoreMessage("[warn] open outbound packet connection: no route to host")
        assertEquals(2, health.dialFailures.value)
    }

    @Test
    fun `a cancelled request is not evidence of unreachability`() {
        // Measured on a working session: two of these in 50 s with 1.4 MB flowing.
        // Counting them would tear down healthy tunnels.
        val health = CoreHealth()
        health.onCoreMessage("[warn] open outbound connection: context canceled")
        health.onCoreMessage("[warn] open outbound connection: operation was canceled")
        assertEquals(0, health.dialFailures.value)
    }

    @Test
    fun `a new session does not inherit the previous verdict`() {
        val health = CoreHealth()
        repeat(5) { health.onCoreMessage(dialFailure()) }
        health.reset()
        assertEquals(0, health.dialFailures.value)
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun `silence is proof of health`() = runTest {
        // At `warn` a core that can dial writes nothing at all.
        val health = CoreHealth()
        assertEquals(CoreVerdict.HEALTHY, health.awaitVerdict(2_500, 3))
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun `a threshold of failures is reported as unreachable`() = runTest {
        val health = CoreHealth()
        repeat(3) { health.onCoreMessage(dialFailure()) }
        assertEquals(CoreVerdict.UNREACHABLE, health.awaitVerdict(2_500, 3))
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun `a late failure invalidates an already published connection`() = runTest {
        val health = CoreHealth()
        val reached = kotlinx.coroutines.CompletableDeferred<Unit>()
        val job = launch {
            health.awaitInvalidation(3)
            reached.complete(Unit)
        }
        advanceTimeBy(1_000)
        assertTrue("invalidation fired before the threshold was reached", !reached.isCompleted)

        repeat(3) { health.onCoreMessage(dialFailure()) }
        advanceTimeBy(1)
        assertTrue("a dead core must invalidate a published Connected", reached.isCompleted)
        job.cancel()
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun `one failure is a flake and does not decide the verdict`() = runTest {
        val health = CoreHealth()
        health.onCoreMessage(dialFailure())
        assertEquals(CoreVerdict.HEALTHY, health.awaitVerdict(2_500, 3))
    }

    private fun dnsFailure(host: String = "dns.google.com") =
        "2026/09/20 13:46:54 [error] [2068267080 10.0s] dns: exchange failed for $host. IN A: context deadline exceeded"

    /**
     * Device log, session `proxy-4`, 2026-09-20 13:46:44. The key needed a transport only
     * Xray carries, so the sing-box config had one outbound - `socks 127.0.0.1:2081`, the
     * helper's loopback listener - and the session reported
     * `core probation passed: dialFailures=0` while 108 lookups died and 29 connections
     * hung for up to 4m4s. The dial markers cannot fire against a listening socket, so
     * without this the core is pronounced HEALTHY over a device that resolves nothing.
     */
    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun `a helper-backed session counts the DNS collapse its dial markers cannot see`() = runTest {
        val health = CoreHealth()
        health.reset(expectsLocalHop = true)
        val reached = kotlinx.coroutines.CompletableDeferred<Unit>()
        val job = launch {
            health.awaitInvalidation(3)
            reached.complete(Unit)
        }

        repeat(3) { health.onCoreMessage(dnsFailure()) }
        advanceTimeBy(1)
        assertTrue("a tunnel that resolves nothing must not keep its Connected", reached.isCompleted)
        job.cancel()
    }

    /**
     * The other direction, and the reason the marker was excluded in the first place: one
     * destination's lookup can fail without the tunnel being broken, and where sing-box
     * dials the proxy itself a real failure surfaces as a failed dial instead. Counting
     * these here would tear down healthy sessions.
     */
    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun `the same lookups are ignored when sing-box dials the proxy itself`() = runTest {
        val health = CoreHealth()
        health.reset(expectsLocalHop = false)
        repeat(3) { health.onCoreMessage(dnsFailure("z-m-gateway.facebook.com")) }
        assertEquals(CoreVerdict.HEALTHY, health.awaitVerdict(2_500, 3))
    }

    @Test
    fun `a cancelled lookup is not a failure in a helper-backed session either`() {
        // The device log carries both shapes in the same window: 108 `context deadline
        // exceeded` and ~50 `context canceled`. Only the first is evidence.
        val health = CoreHealth()
        health.reset(expectsLocalHop = true)
        health.onCoreMessage("dns: exchange failed for mtalk.google.com. IN A: context canceled")
        health.onCoreMessage("dns: exchange failed for g.whatsapp.net. IN A: context canceled")
        assertEquals(0, health.dialFailures.value)
    }

    @Test
    fun `the topology does not leak into the next session`() {
        val health = CoreHealth()
        health.reset(expectsLocalHop = true)
        health.onCoreMessage(dnsFailure())
        assertEquals(1, health.dialFailures.value)

        health.reset()
        health.onCoreMessage(dnsFailure())
        assertEquals("a plain session must not inherit the helper's marker set", 0, health.dialFailures.value)
    }
}
