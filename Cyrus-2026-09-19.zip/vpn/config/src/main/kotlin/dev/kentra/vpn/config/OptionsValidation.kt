package dev.kentra.vpn.config

/** IPv4 literal, full-match. */
internal val IPV4_REGEX = Regex("((25[0-5]|2[0-4]\\d|1?\\d?\\d)\\.){3}(25[0-5]|2[0-4]\\d|1?\\d?\\d)")

/** IPv6 literal (compressed forms included), full-match. */
internal val IPV6_REGEX = Regex(
    "(([0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4})|" +
        "(([0-9A-Fa-f]{1,4}:){1,7}:)|" +
        "(([0-9A-Fa-f]{1,4}:){1,6}:[0-9A-Fa-f]{1,4})|" +
        "(([0-9A-Fa-f]{1,4}:){1,5}(:[0-9A-Fa-f]{1,4}){1,2})|" +
        "(([0-9A-Fa-f]{1,4}:){1,4}(:[0-9A-Fa-f]{1,4}){1,3})|" +
        "(([0-9A-Fa-f]{1,4}:){1,3}(:[0-9A-Fa-f]{1,4}){1,4})|" +
        "(([0-9A-Fa-f]{1,4}:){1,2}(:[0-9A-Fa-f]{1,4}){1,5})|" +
        "([0-9A-Fa-f]{1,4}:)((:[0-9A-Fa-f]{1,4}){1,6})|" +
        "(:((:[0-9A-Fa-f]{1,4}){1,7}|:))",
)

internal fun isIpLiteral(value: String): Boolean = IPV4_REGEX.matches(value) || IPV6_REGEX.matches(value)

private val DNS_SCHEMES = setOf("tls", "https", "h3", "quic", "udp", "tcp")
private val IPV4_WITH_PORT = Regex("${IPV4_REGEX.pattern}:(\\d{1,5})")
private val IPV6_WITH_PORT = Regex("\\[(?:${IPV6_REGEX.pattern})\\]:\\d{1,5}")

/**
 * A sing-box DNS server address must be an IP, an IP:port pair or `scheme://host`.
 * Anything else (free text, credentials, fragments) is refused instead of being
 * forwarded verbatim into `DnsServer.address`.
 */
internal fun isValidDnsAddress(value: String): Boolean {
    if (value.isBlank() || value.any { it.isWhitespace() }) return false
    if ("://" in value) {
        val scheme = value.substringBefore("://").lowercase()
        val rest = value.substringAfter("://")
        return scheme in DNS_SCHEMES && rest.isNotEmpty() && rest.none { it == '@' || it == '#' }
    }
    if (isIpLiteral(value)) return true
    if (IPV4_WITH_PORT.matches(value)) return value.substringAfterLast(':').toInt() in 1..65535
    if (IPV6_WITH_PORT.matches(value)) return value.substringAfterLast(':').toInt() in 1..65535
    return false
}

fun TunnelOptions.validate() {
    require(mtu in 1280..9000) { "MTU: 1280–9000" }
    require(proxyPort in 1024..65535) { "Порт прокси: 1024–65535" }
    require(stack in setOf("system", "gvisor", "mixed")) { "Неизвестный TUN stack" }
    require(logLevel in setOf("warn", "error", "fatal")) { "Разрешены только warn/error/fatal" }
    require(isValidDnsAddress(dnsRemote)) { "Некорректный DNS" }
    require(dnsLocal == "local" || isValidDnsAddress(dnsLocal)) { "Некорректный локальный DNS" }
    val packages = when (val p = perAppMode) { is PerAppMode.Include -> p.packages; is PerAppMode.Exclude -> p.packages; else -> emptyList() }
    val packageId = Regex("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+")
    require(packages.size <= 500 && packages.all { packageId.matches(it) }) { "Некорректные package IDs" }
    require(blockedPackages.size <= 500 && blockedPackages.distinct().all { packageId.matches(it) }) { "Некорректные package IDs firewall" }
    require(perAppMode !is PerAppMode.Include || packages.isNotEmpty()) { "Укажите приложения для режима включения" }
    require(mode != ConnectionMode.PROXY || perAppMode == PerAppMode.Off) { "Фильтр приложений доступен только в VPN" }
}
