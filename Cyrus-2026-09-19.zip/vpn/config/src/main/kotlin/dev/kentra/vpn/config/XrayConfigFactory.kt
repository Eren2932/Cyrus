package dev.kentra.vpn.config

import dev.kentra.domain.model.VpnProtocol
import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.model.TransportCompat
import dev.kentra.vpn.config.ConnectionMode
import dev.kentra.vpn.config.TunnelOptions
import kotlinx.serialization.json.*

class XrayConfigFactory {

    private companion object {
        val XRAY_PROTOCOLS = setOf(VpnProtocol.VLESS, VpnProtocol.VMESS, VpnProtocol.TROJAN)
        val SECURITY_VALUES = setOf("none", "tls", "reality")
        val UUID_RE =
            Regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")

        /**
         * The two cores do not share a log vocabulary, and getting this wrong is
         * silent: Xray accepts an unknown `loglevel` by falling back rather than
         * complaining, so a wrong value costs the diagnostics without telling anyone.
         *
         * sing-box: debug | info | warn | error | fatal
         * Xray:     debug | info | warning | error | none
         *
         * [TunnelOptions.validate] only lets warn/error/fatal through, so those are
         * the three that need translating - and note that `warn` and `fatal` do not
         * exist in Xray at all.
         */
        val LOG_LEVEL_TO_XRAY = mapOf("warn" to "warning", "error" to "error", "fatal" to "error")

        /** Header camouflage types the pinned Xray's mKCP transport accepts. */
        val KCP_HEADERS = setOf("", "none", "srtp", "utp", "wechat-video", "dtls", "wireguard")

        /** QUIC obfuscation modes the pinned Xray accepts. `key` is required by any non-none value. */
        val QUIC_SECURITY = setOf("", "none", "aes-128-gcm", "chacha20-poly1305")

        /**
         * The private ranges the LAN-bypass rule matches, written out instead of
         * `geoip:private`.
         *
         * The pinned Xray ships **no** `geoip.dat`/`geosite.dat`: `libXray.aar`
         * carries only `classes.jar` and `jni/`, and the core resolves its asset
         * directory to `/system/bin`, which holds no geo files. A single
         * `geoip:`/`geosite:` reference therefore fails the *whole* config at load
         * time —
         *
         *     infra/conf/serial: failed to parse json config > failed to build
         *     routing configuration > invalid field rule > common/geodata:
         *     illegal ip rule: geoip:private > failed to open geoip.dat
         *
         * — which the user sees as "Ядро не запустилось" for every xhttp/kcp/quic
         * key, no matter how valid the key itself is. Plain CIDRs need no data
         * file, so the rule loads unconditionally.
         *
         * These are Go's `netip.Addr.IsPrivate()` ranges (what sing-box's
         * `ip_is_private` matches) plus loopback, link-local and CGNAT, which are
         * just as certainly not remote traffic.
         */
        val PRIVATE_CIDRS = listOf(
            "10.0.0.0/8",
            "172.16.0.0/12",
            "192.168.0.0/16",
            "127.0.0.0/8",
            "169.254.0.0/16",
            "100.64.0.0/10",
            "fc00::/7",
            "fe80::/10",
            "::1/128",
        )
    }

    /**
     * Fail-closed validation of a key before it reaches the Xray core.
     *
     * Every rejection explains itself instead of letting the core fail later with
     * an unreadable native error. Values that arrive straight from an untrusted
     * link are checked against whitelists rather than passed through.
     */
    /** Validate a profile that is going through the Xray helper core. */
    fun validateProfile(profile: VpnProfile) {
        require(profile.protocol in XRAY_PROTOCOLS) {
            "Xray-ядро не поддерживает протокол ${profile.protocol}"
        }
        val q = effectiveParameters(profile)
        val net = TransportCompat.normalize(profile.transport.type)
        require(TransportCompat.requiresXray(profile)) {
            TransportCompat.singBoxRejection(net)
                ?: "Транспорт «$net» обслуживается ядром sing-box; Xray для него не требуется."
        }
        if (profile.protocol == VpnProtocol.TROJAN) {
            require(!profile.password.isNullOrBlank()) { "Отсутствует пароль trojan-ключа." }
        } else {
            val uuid = profile.uuid
            require(uuid != null && UUID_RE.matches(uuid)) {
                "Некорректный UUID в ключе: ядро Xray откажется его принять."
            }
        }
        require(q["security"] in SECURITY_VALUES) {
            "Неподдерживаемый параметр security: ${q["security"]}"
        }
        when (net) {
            "xhttp" -> require(q["mode"].orEmpty() in setOf("", "auto", "packet-up", "stream-up", "stream-one")) {
                "Неподдерживаемый режим XHTTP: ${q["mode"]}"
            }
            "grpc" -> require(q["mode"].orEmpty() in setOf("", "multi", "gun")) {
                "Неподдерживаемый режим gRPC: ${q["mode"]}"
            }
            "kcp" -> require(q["headerType"].orEmpty() in KCP_HEADERS) {
                "Неподдерживаемый тип заголовка mKCP: ${q["headerType"]}"
            }
            "quic" -> {
                val quicSecurity = q["quicSecurity"].orEmpty()
                require(quicSecurity in QUIC_SECURITY) {
                    "Неподдерживаемая защита QUIC: ${q["quicSecurity"]}"
                }
                // The core refuses a secured QUIC transport without a key, and it
                // refuses it at load time - which the user sees as "Ядро не
                // запустилось" rather than as a problem with the key.
                if (quicSecurity.isNotEmpty() && quicSecurity != "none") {
                    require(!q["key"].isNullOrEmpty()) { "Для защищённого QUIC-транспорта нужен ключ (key)." }
                }
            }
        }
        q["flow"]?.takeIf { it.isNotBlank() }?.let { flow ->
            require(profile.protocol == VpnProtocol.VLESS && flow in setOf("xtls-rprx-vision", "xtls-rprx-vision-udp443")) {
                "Некорректный flow"
            }
        }
        require(profile.server.isNotBlank()) { "Отсутствует адрес сервера." }
        require(profile.port in 1..65535) { "Некорректный порт сервера: ${profile.port}" }
    }

    /**
     * Merge the typed model back over query parameters. VMess stores its original
     * transport under `net`, while VLESS/Trojan links use `type`; the typed
     * TransportSettings field is the canonical source for both.
     *
     * Every write goes through [setOrRemove] rather than the shorter
     * `put(k, v) ?: remove(k)`. `MutableMap.put` returns the *previous* value, not
     * the one just written, so that idiom ran its `remove` branch precisely when the
     * key was absent - the one case where the typed field is the only source - and
     * deleted the value a line after writing it. A profile whose typed transport
     * carried the path/host but whose raw parameters did not therefore reached the
     * core with the path and host missing, and the same applied to sni, fp, flow and
     * the Reality fields.
     */
    private fun effectiveParameters(profile: VpnProfile): Map<String, String> =
        profile.parameters.toMutableMap().apply {
            put("type", TransportCompat.normalize(profile.transport.type))
            setOrRemove("path", profile.transport.path)
            setOrRemove("host", profile.transport.host)
            setOrRemove("serviceName", profile.transport.serviceName)
            put("security", when {
                profile.tls.reality != null -> "reality"
                profile.tls.enabled -> "tls"
                else -> "none"
            })
            setOrRemove("sni", profile.tls.serverName)
            // `peer` is the same quantity under the name older links used.
            if (profile.tls.serverName == null) remove("peer")
            // A pin says "not CA-vouched" and the pinned Xray has no
            // `pinnedPeerCertificateChainSha256` to check it with either (verified by
            // grepping the shipped libgojni.so), so it is honoured the same way sing-box
            // honours it: by not asking a trust store about a certificate that was never
            // in it. Dropping the pin while still verifying is a guaranteed
            // `x509: certificate signed by unknown authority`. See
            // ConfigFactory.validateProfile.
            val pinned = profile.parameters["pinSHA256"]?.isNotBlank() == true
            if (profile.tls.allowInsecure || pinned) put("insecure", "1") else run { remove("insecure"); remove("allowInsecure") }
            if (profile.tls.alpn.isNotEmpty()) put("alpn", profile.tls.alpn.joinToString(",")) else remove("alpn")
            setOrRemove("fp", profile.tls.fingerprint)
            val reality = profile.tls.reality
            if (reality == null) {
                remove("pbk"); remove("sid"); remove("spx")
            } else {
                put("pbk", reality.publicKey)
                setOrRemove("sid", reality.shortId)
                setOrRemove("spx", reality.spiderX)
            }
            setOrRemove("flow", profile.flow?.takeIf { it.isNotBlank() })
        }

    /** Writes [value] under [key], or drops the key when there is nothing to write. */
    private fun MutableMap<String, String>.setOrRemove(key: String, value: String?) {
        if (value == null) remove(key) else put(key, value)
    }


    /**
     * Builds the Xray-core JSON for a transport that only Xray can carry.
     *
     * Xray has no native Android TUN. In VPN mode Sing-box owns the TUN and
     * forwards to this local inbound; in PROXY mode the user's apps connect to
     * it directly. Either way the inbound is the same loopback listener, so the
     * caller passes the port explicitly and both modes share one code path.
     */
    fun config(profile: VpnProfile, options: TunnelOptions, localPort: Int): String {
        options.validate()
        validateProfile(profile)
        require(localPort in 1024..65535) { "Local Xray port must be in 1024..65535, was $localPort" }

        val inbounds = buildJsonArray {
            add(buildJsonObject {
                put("tag", "proxy-in")
                put("port", localPort)
                put("protocol", "mixed")
                put("settings", buildJsonObject {
                    put("udp", true)
                })
                put("listen", "127.0.0.1")
                put("sniffing", buildJsonObject {
                    put("enabled", true)
                    put("destOverride", buildJsonArray { add("http"); add("tls") })
                })
            })
        }

        val outbounds = buildJsonArray {
            add(outbound(profile, "proxy"))
            add(buildJsonObject {
                put("protocol", "freedom")
                put("tag", "direct")
            })
            add(buildJsonObject {
                put("protocol", "blackhole")
                put("tag", "block")
            })
        }

        val routing = buildJsonObject {
            put("domainStrategy", if (options.ipv6) "AsIs" else "IPIfNonMatch")
            put("rules", buildJsonArray {
                if (options.bypassLan) {
                    add(buildJsonObject {
                        put("type", "field")
                        put("ip", buildJsonArray { PRIVATE_CIDRS.forEach { add(it) } })
                        put("outboundTag", "direct")
                    })
                }
                // Ad blocking is deliberately NOT mirrored here. Xray can only
                // express `category-ads-all` through `geosite:`, and no geosite
                // data ships with the core (see PRIVATE_CIDRS), so the rule would
                // make the entire config unloadable. Nothing is lost: sing-box
                // always fronts Xray - it owns the TUN (VPN mode) or the local
                // port (proxy mode) and applies `options.blockAds` through a
                // downloaded rule-set *before* handing traffic to the loopback
                // hop, so the block happens upstream of this config.
            })
        }

        val root = buildJsonObject {
            put("log", buildJsonObject {
                put("loglevel", LOG_LEVEL_TO_XRAY[options.logLevel] ?: "warning")
            })
            put("inbounds", inbounds)
            put("outbounds", outbounds)
            put("routing", routing)
        }

        return root.toString()
    }

    private fun outbound(profile: VpnProfile, tag: String): JsonObject {
        val q = effectiveParameters(profile)
        val net = TransportCompat.normalize(profile.transport.type)
        
        return buildJsonObject {
            put("tag", tag)
            
            when (profile.protocol) {
                VpnProtocol.VLESS -> {
                    put("protocol", "vless")
                    put("settings", buildJsonObject {
                        put("vnext", buildJsonArray {
                            add(buildJsonObject {
                                put("address", profile.server)
                                put("port", profile.port)
                                put("users", buildJsonArray {
                                    add(buildJsonObject {
                                        put("id", profile.uuid ?: "")
                                        profile.flow?.takeIf { it.isNotBlank() }?.let { put("flow", it) }
                                        put("encryption", q["encryption"] ?: "none")
                                    })
                                })
                            })
                        })
                    })
                }
                VpnProtocol.VMESS -> {
                    put("protocol", "vmess")
                    put("settings", buildJsonObject {
                        put("vnext", buildJsonArray {
                            add(buildJsonObject {
                                put("address", profile.server)
                                put("port", profile.port)
                                put("users", buildJsonArray {
                                    add(buildJsonObject {
                                        put("id", profile.uuid ?: "")
                                        put("alterId", profile.alterId ?: 0)
                                        put("security", q["scy"] ?: "auto")
                                    })
                                })
                            })
                        })
                    })
                }
                VpnProtocol.TROJAN -> {
                    put("protocol", "trojan")
                    put("settings", buildJsonObject {
                        put("servers", buildJsonArray {
                            add(buildJsonObject {
                                put("address", profile.server)
                                put("port", profile.port)
                                put("password", profile.password ?: "")
                            })
                        })
                    })
                }
                else -> error("Unsupported Xray protocol: ${profile.protocol}")
            }

            val streamSettings = buildJsonObject {
                put("network", net)
                
                val security = q["security"] ?: "none"
                if (security != "none") {
                    put("security", security)
                    if (security == "tls" || security == "reality") {
                        val tlsSettings = buildJsonObject {
                            q["sni"]?.let { put("serverName", it) }
                            if (q["insecure"] == "1" || q["allowInsecure"] == "1" || q["allowInsecure"] == "true") {
                                put("allowInsecure", true)
                            }
                            q["alpn"]?.let { 
                                put("alpn", buildJsonArray { 
                                    it.split(",").forEach { add(it) } 
                                }) 
                            }
                            q["fp"]?.let { put("fingerprint", it) }
                            
                            if (security == "reality") {
                                q["pbk"]?.let { put("publicKey", it) }
                                q["sid"]?.let { put("shortId", it) }
                                q["spx"]?.let { put("spiderX", it) }
                            }
                        }
                        put(if (security == "reality") "realitySettings" else "tlsSettings", tlsSettings)
                    }
                }

                when (net) {
                    "ws" -> {
                        put("wsSettings", buildJsonObject {
                            q["path"]?.let { put("path", it) }
                            q["host"]?.let { 
                                put("headers", buildJsonObject { put("Host", it) }) 
                            }
                        })
                    }
                    "grpc" -> {
                        put("grpcSettings", buildJsonObject {
                            q["serviceName"]?.let { put("serviceName", it) }
                            if (q["mode"] == "multi") put("multiMode", true)
                        })
                    }
                    "xhttp" -> {
                        put("xhttpSettings", buildJsonObject {
                            // XHTTP takes its Host as a dedicated field. Putting it in
                            // `headers` is not merely ignored - the core refuses the
                            // whole config with `"headers" can't contain "host"`, so
                            // every xhttp key failed to start.
                            q["host"]?.let { put("host", it) }
                            q["path"]?.let { put("path", it) }
                            q["mode"]?.takeIf { it.isNotBlank() }?.let { put("mode", it) }
                        })
                    }
                    "kcp" -> {
                        put("kcpSettings", buildJsonObject {
                            q["headerType"]?.let { put("header", buildJsonObject { put("type", it) }) }
                        })
                    }
                    "quic" -> {
                        put("quicSettings", buildJsonObject {
                            q["headerType"]?.let { put("header", buildJsonObject { put("type", it) }) }
                            q["quicSecurity"]?.let { put("security", it) }
                            q["key"]?.let { put("key", it) }
                        })
                    }
                }
            }
            put("streamSettings", streamSettings)
        }
    }
}

/**
 * Port the Xray core listens on inside the process.
 *
 * It must differ from [TunnelOptions.proxyPort]. In PROXY mode Sing-box binds
 * `proxyPort` itself and forwards to Xray, so a shared port would collide; using
 * a derived port in both modes keeps a single code path and avoids the collision
 * that previously made the chained configuration unusable. The value wraps at the
 * top of the range so the derived port is always inside 1024..65535.
 */
fun xrayInboundPort(options: TunnelOptions): Int =
    if (options.proxyPort < 65535) options.proxyPort + 1 else options.proxyPort - 1
