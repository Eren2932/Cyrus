package dev.kentra.vpn.config

import dev.kentra.domain.model.TransportCompat
import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.model.VpnProtocol
import kotlinx.serialization.json.*

enum class ConnectionMode { VPN, PROXY }

/** User-tunable knobs that must never leak into the UI layer as raw JSON. */
data class TunnelOptions(
    val mode: ConnectionMode = ConnectionMode.VPN,
    val proxyPort: Int = 2080,
    val mtu: Int = 9000,
    /** "system" is lighter on battery, "gvisor" is more compatible. */
    val stack: String = "system",
    val bypassLan: Boolean = true,
    /** Legacy switch retained for existing installs; it also acts as the old master switch. */
    val blockAds: Boolean = false,
    /** Master switch for the AdGuard-like protection page. */
    val protectionEnabled: Boolean = false,
    val blockTrackers: Boolean = false,
    val blockAnnoyances: Boolean = false,
    /** Uses a threat-blocking DNS resolver instead of the user-selected resolver. */
    val blockThreats: Boolean = false,
    /** Uses AdGuard DNS for DNS-level ad and tracker protection. */
    val dnsProtection: Boolean = false,
    /**
     * Terminates TLS on port 443 so requests can be inspected.
     *
     * Only meaningful together with an installed root: with no certificate the
     * core forwards every connection untouched, so enabling this without a
     * root changes nothing rather than breaking HTTPS.
     */
    val inspectHttps: Boolean = false,
    /** Blocks network access for the selected package IDs. */
    val firewallEnabled: Boolean = false,
    val blockedPackages: List<String> = emptyList(),
    val ipv6: Boolean = false,
    val perAppMode: PerAppMode = PerAppMode.Off,
    val dnsRemote: String = "tls://1.1.1.1",
    /**
     * Resolver used for the `dns-direct` server, i.e. for resolving the *outbound's own*
     * server address. It must be reachable WITHOUT the tunnel.
     *
     * "local" is wrong here in VPN mode: the system resolver points at the VPN network's
     * DNS (the TUN address), so the query goes back into the tunnel, falls through to
     * `final = dns-remote`, and that detours through the proxy — which cannot be dialled
     * until its own address is resolved. A hostname-based server (e.g. VLESS Reality)
     * then never comes up, and every name lookup on the device fails with `name error`.
     * An IP-literal resolver over the `direct` outbound breaks that cycle.
     */
    val dnsLocal: String = "1.1.1.1",
    val enableMultiplex: Boolean = false,
    val logLevel: String = "warn",
)

sealed interface PerAppMode {
    data object Off : PerAppMode
    data class Include(val packages: List<String>) : PerAppMode
    data class Exclude(val packages: List<String>) : PerAppMode
}

/**
 * The single place where a [VpnProfile] becomes a sing-box configuration.
 * Covered by golden tests: if you change output, you must update the golden file consciously.
 */
class ConfigFactory(
    private val json: Json = Json {
        prettyPrint = true
        encodeDefaults = true
        explicitNulls = false
    },
    /**
     * This app's own package name, always kept out of the TUN.
     *
     * A VPN client must never route its own sockets into the tunnel it owns. sing-box
     * protects its own outbounds through libbox, but the Xray helper core cannot: the
     * bundled libXray needs a `DialerController` for that, and that call aborts the
     * process (see [dev.kentra.vpn.service.XrayVpnEngine]). Without this, Xray's dial
     * to the proxy server is captured by our own TUN, handed back to the SOCKS hop
     * that leads into Xray, and every CONNECT ends in "connection refused" - the
     * whole Xray path carries nothing while looking perfectly healthy.
     *
     * Android gives the exclusion list precedence over the inclusion list, so this
     * holds in per-app Include mode as well.
     */
    private val selfPackage: String? = null,
) {

    /**
     * @param ruleSetPaths tag → absolute path of an installed rule-set file. A filter
     * whose file is missing is left out rather than pointed at a URL: an absent list
     * costs some filtering, a remote list costs the whole tunnel (see [RuleSet]).
     */
    fun build(
        profile: VpnProfile,
        options: TunnelOptions = TunnelOptions(),
        ruleSetPaths: Map<String, String> = emptyMap(),
    ): String {
        if (profile.protocol == VpnProtocol.AMNEZIA_WG) {
            // The AWG config is assembled by string concatenation, so every value must be
            // validated before it reaches the INI text: `parameters` come from a
            // URL-decoded link, i.e. `%0A` is a literal newline and a real INI injection.
            options.validate()
            validateAwgProfile(profile)
            val q = profile.parameters
            require(q["public_key"] != null) { "AmneziaWG требует public_key" }
            val privateKey = requireNotNull(profile.password) { "AmneziaWG требует приватный ключ" }
            return buildString {
                appendLine("[Interface]")
                appendLine("PrivateKey = ${iniValue("PrivateKey", privateKey, allowEquals = true)}")
                val localAddress = q["local_address"] ?: "10.0.0.2/32"
                appendLine("Address = ${iniValue("Address", localAddress)}")
                q["dns"]?.let { appendLine("DNS = ${iniValue("DNS", it)}") }
                q["mtu"]?.let { appendLine("MTU = ${iniValue("MTU", it)}") }
                q["jc"]?.let { appendLine("Jc = ${iniValue("Jc", it)}") }
                q["jmin"]?.let { appendLine("Jmin = ${iniValue("Jmin", it)}") }
                q["jmax"]?.let { appendLine("Jmax = ${iniValue("Jmax", it)}") }
                q["s1"]?.let { appendLine("S1 = ${iniValue("S1", it)}") }
                q["s2"]?.let { appendLine("S2 = ${iniValue("S2", it)}") }
                q["h1"]?.let { appendLine("H1 = ${iniValue("H1", it)}") }
                q["h2"]?.let { appendLine("H2 = ${iniValue("H2", it)}") }
                q["h3"]?.let { appendLine("H3 = ${iniValue("H3", it)}") }
                q["h4"]?.let { appendLine("H4 = ${iniValue("H4", it)}") }
                appendLine()
                appendLine("[Peer]")
                appendLine("PublicKey = ${iniValue("PublicKey", requireNotNull(q["public_key"]), allowEquals = true)}")
                q["preshared_key"]?.let { appendLine("PresharedKey = ${iniValue("PresharedKey", it, allowEquals = true)}") }
                appendLine("Endpoint = ${iniValue("Endpoint", "${profile.server}:${profile.port}")}")
                appendLine("AllowedIPs = 0.0.0.0/0, ::/0")
            }
        }
        return json.encodeToString(SingBoxConfig.serializer(), config(profile, options, ruleSetPaths))
    }

    fun config(
        profile: VpnProfile,
        options: TunnelOptions,
        ruleSetPaths: Map<String, String> = emptyMap(),
    ): SingBoxConfig {
        options.validate()
        when (profile.protocol) {
            VpnProtocol.WIREGUARD -> validateWireguardProfile(profile)
            VpnProtocol.AMNEZIA_WG -> error("AmneziaWG обслуживается только через build()")
            else -> validateProfile(profile)
        }
        require(!options.enableMultiplex || profile.flow != "xtls-rprx-vision") { "Multiplex несовместим с Vision: отключите его в настройках" }
        val proxyTag = "proxy"
        return SingBoxConfig(
            log = LogConfig(level = options.logLevel),
            dns = dns(options),
            inbounds = listOf(if (options.mode == ConnectionMode.VPN) tun(options) else
                Inbound(type = "mixed", tag = "proxy-in", listen = "127.0.0.1", listenPort = options.proxyPort, sniff = true)),
            outbounds = outbounds(profile, proxyTag, options) + buildList {
                add(Outbound(type = "direct", tag = "direct"))
                add(Outbound(type = "block", tag = "block"))
                add(Outbound(type = "dns", tag = "dns-out"))
                if (options.inspectHttps) {
                    // Terminates TLS and forwards through `proxy`, so inspection
                    // cannot become a way out of the tunnel: the request still
                    // leaves through the same outbound it would have used.
                    add(Outbound(type = "mitm", tag = MITM_TAG, detour = proxyTag))
                }
            },
            route = route(proxyTag, options, ruleSetPaths),
        )
    }

    /**
     * Validate a profile against the core that will actually carry it.
     *
     * The library screen used to call [validateProfile] for every row. That method
     * intentionally rejects Xray-only transports because it builds sing-box JSON,
     * so valid xhttp/kcp/quic rows were painted red and users were told to replace
     * working keys. Keep the strict sing-box validator for [build], but expose one
     * engine-aware verdict for the UI/editor.
     */
    fun validateForAnyCore(profile: VpnProfile) {
        when {
            TransportCompat.requiresXray(profile) -> XrayConfigFactory().validateProfile(profile)
            profile.protocol == VpnProtocol.AMNEZIA_WG -> validateAwgProfile(profile)
            profile.protocol == VpnProtocol.WIREGUARD -> validateWireguardProfile(profile)
            else -> validateProfile(profile)
        }
    }

    fun validateProfile(profile: VpnProfile) {
        require(profile.protocol != VpnProtocol.UNKNOWN) { "Неизвестный протокол" }
        require(profile.server.isNotBlank() && profile.port in 1..65535) { "Некорректный адрес или порт" }
        // Synonyms (raw, h2, gun, websocket) are canonicalised first: a supported
        // transport must never be refused because of the name a panel chose.
        val transportType = TransportCompat.normalize(profile.transport.type)
        TransportCompat.singBoxRejection(transportType)?.let { reason -> throw IllegalArgumentException(reason) }
        val q = profile.parameters
        // A pin is a statement about the certificate, not a hardening extra: the key
        // is saying the server's certificate is not one a CA vouches for, and the pin
        // is the whole of the verification.
        //
        // Measured on device with the crystalvps.top hysteria2 key: with the pin
        // dropped but the trust store left in play, the handshake dies with
        //
        //     CRYPTO_ERROR 0x12a (local): tls: failed to verify certificate:
        //     x509: certificate signed by unknown authority
        //
        // and the key carries nothing - the same dead end the old refusal produced,
        // only quieter. So the pin is neither refused nor ignored any more; it is
        // honoured the only way this core can, by not asking the system trust store
        // about a certificate that was never in it. [outbounds] applies that.
        //
        // The pin itself still cannot be checked. sing-box grew
        // `certificate_public_key_sha256` only in 1.13.0 and the pinned build is
        // 1.11.1; Xray does have `pinnedPeerCertificateChainSha256`, but the pinned
        // libgojni.so does not contain that field either - both verified with grep
        // against the shipped .so files. Even where the field exists the values are
        // not the same quantity: the pin is a hex digest of the whole certificate,
        // sing-box's field wants a base64 digest of the public key, so the pin cannot
        // be translated without the certificate itself.
        //
        // The cost is real and deliberately not hidden: a pinned session ends up
        // unverified, so a substituted certificate would be accepted. The alternative
        // was a key that cannot be used at all, which is what users were reporting.
        // `cyrus-unsupported` is the importer reporting behaviour it could not represent.
        // One value of it no longer means that: `quic-fingerprint` was written for
        // hysteria2 keys that carry `fp`, and a uTLS fingerprint is inert on QUIC - there
        // is no behaviour to represent, only a decorative field. Rows imported before
        // that was understood still carry the marker, so it is exempted here and not just
        // no longer emitted: clearing it would mean rewriting stored rows.
        val importMarker = q["cyrus-unsupported"]
        require(
            q.keys.none { it in setOf("extra", "ech", "echConfigList", "pqv") } &&
                (importMarker == null || importMarker in HANDLED_IMPORT_MARKERS),
        ) { "Ключ содержит расширение, которое этот адаптер не реализует" }
        require(q["mode"] in listOf(null, "", "gun")) { "gRPC multiMode / XHTTP mode не поддерживаются этим ядром" }
        require(q["headerType"] in listOf(null, "", "none")) { "TCP header camouflage не поддерживается" }
        require(q["encryption"] in listOf(null, "", "none")) { "VLESS encryption не поддерживается этим ядром" }
        require(q["security"] in listOf(null, "", "none", "tls", "reality")) { "Неизвестная защита транспорта" }
        if (profile.protocol in setOf(VpnProtocol.HYSTERIA2, VpnProtocol.TUIC, VpnProtocol.TROJAN))
            require(profile.tls.enabled) { "Этот протокол требует TLS" }
        if (profile.protocol !in setOf(VpnProtocol.VLESS, VpnProtocol.VMESS, VpnProtocol.TROJAN, VpnProtocol.WIREGUARD, VpnProtocol.AMNEZIA_WG, VpnProtocol.SSH))
            require(transportType == "tcp") { "V2Ray-транспорт не применим к этому протоколу" }
        if ("plugin" in q) require(profile.protocol == VpnProtocol.SHADOWSOCKS &&
            q.getValue("plugin").substringBefore(';') in setOf("obfs-local", "v2ray-plugin", "shadow-tls")) { "SIP003 plugin не поддерживается (доступны: obfs-local, v2ray-plugin, shadow-tls)" }
        if ("obfs" in q || "obfs-password" in q) require(profile.protocol == VpnProtocol.HYSTERIA2 &&
            q["obfs"] == "salamander" && !q["obfs-password"].isNullOrEmpty()) { "Нужны obfs=salamander и obfs-password" }
        for (key in listOf("upmbps", "downmbps", "ed")) q[key]?.let {
            require((it.toIntOrNull() ?: -1) in 1..1_000_000) { "Некорректный числовой параметр" }
        }
        q["congestion_control"]?.let { require(profile.protocol == VpnProtocol.TUIC && it in setOf("cubic", "new_reno", "bbr")) { "Неизвестный congestion_control" } }
        q["udp_relay_mode"]?.let { require(profile.protocol == VpnProtocol.TUIC && it in setOf("native", "quic")) { "Неизвестный udp_relay_mode" } }
        for (key in listOf("udp_over_stream", "zero_rtt_handshake")) q[key]?.let {
            require(profile.protocol == VpnProtocol.TUIC && it in setOf("true", "false", "1", "0")) { "Некорректный TUIC флаг" }
        }
        q["mport"]?.let { ports ->
            require(profile.protocol == VpnProtocol.HYSTERIA2 && ports.split(',').all { range ->
                val ends = range.replace('-', ':').split(':').map { it.toIntOrNull() ?: 0 }
                ends.size in 1..2 && ends.all { it in 1..65535 } && ends.first() <= ends.last()
            }) { "Некорректный диапазон Hysteria2 портов" }
        }
        for (key in listOf("hop_interval", "heartbeat")) q[key]?.let {
            require(Regex("[1-9][0-9]*(ms|s|m)").matches(it)) { "Некорректный интервал" }
            require(if (key == "heartbeat") profile.protocol == VpnProtocol.TUIC else profile.protocol == VpnProtocol.HYSTERIA2) { "Интервал не применим к этому протоколу" }
        }
        q["packetEncoding"]?.let { require(it in setOf("xudp", "packetaddr")) { "Неизвестный packetEncoding" } }

        // Format checks for fields that reach the core verbatim.
        when (profile.protocol) {
            VpnProtocol.VLESS, VpnProtocol.VMESS, VpnProtocol.TUIC -> {
                val uuid = profile.uuid
                require(uuid != null && UUID_REGEX.matches(uuid)) { "Некорректный UUID" }
            }
            else -> Unit
        }
        // A blank flow is an absent flow: the editor writes "" when the user clears
        // the field, and that is not a flow value the core should be asked about.
        profile.flow?.takeIf { it.isNotBlank() }?.let {
            require(profile.protocol == VpnProtocol.VLESS && it in ALLOWED_FLOWS) { "Некорректный flow" }
        }
        profile.tls.fingerprint?.let {
            require(it in ALLOWED_FINGERPRINTS) { "Неизвестный uTLS-отпечаток" }
        }
        if (profile.tls.alpn.isNotEmpty()) {
            require(profile.tls.alpn.all { it in ALLOWED_ALPN }) { "Некорректный ALPN" }
        }
        if (profile.protocol == VpnProtocol.SHADOWSOCKS) {
            val method = profile.method
            require(method != null && method in ALLOWED_SS_METHODS) { "Неподдерживаемый метод шифрования Shadowsocks" }
        }
        if (profile.protocol == VpnProtocol.VMESS) {
            q["scy"]?.let { require(it in ALLOWED_VMESS_SECURITY) { "Неизвестный VMESS security (scy)" } }
        }
        q["plugin"]?.substringAfter(';', "")?.takeIf { it.isNotEmpty() }?.let {
            require(PLUGIN_OPTS_REGEX.matches(it)) { "Некорректные plugin-opts" }
        }
    }

    private fun validateWireguardMaterial(profile: VpnProfile) {
        require(profile.server.isNotBlank() && profile.port in 1..65535) { "Некорректный адрес или порт" }
        val q = profile.parameters
        val privateKey = profile.password
        require(privateKey != null && BASE64_KEY.matches(privateKey)) {
            "Приватный ключ WireGuard должен быть base64 (44 символа)"
        }
        require(q["public_key"] != null && BASE64_KEY.matches(q.getValue("public_key"))) {
            "Публичный ключ WireGuard (public_key) обязателен и должен быть base64 (44 символа)"
        }
        val local = q["local_address"]
        require(!local.isNullOrBlank() && local.split(',').map { it.trim() }.all(::isValidCidr)) {
            "local_address должен содержать CIDR-адреса IPv4/IPv6"
        }
        q["preshared_key"]?.takeIf { it.isNotEmpty() }?.let {
            require(BASE64_KEY.matches(it)) { "preshared_key должен быть base64 (44 символа)" }
        }
        q["dns"]?.let { dns ->
            val parts = dns.split(',').map { it.trim() }.filter { it.isNotEmpty() }
            require(parts.isNotEmpty() && parts.all { isIpLiteral(it) }) { "dns должен содержать валидные IP-адреса" }
        }
        q["mtu"]?.let { requireIntRange("mtu", it, 1280, 9000) }
        q["reserved"]?.let { raw ->
            require(raw.split(',').size == 3 && raw.split(',').all { it.trim().toIntOrNull() in 0..255 }) {
                "reserved должен содержать три числа 0..255"
            }
        }
    }

    private fun isValidCidr(value: String): Boolean {
        val slash = value.lastIndexOf('/')
        if (slash <= 0 || slash == value.lastIndex) return false
        val address = value.substring(0, slash).trim()
        val prefix = value.substring(slash + 1).toIntOrNull() ?: return false
        val max = when {
            IPV4_REGEX.matches(address) -> 32
            IPV6_REGEX.matches(address) -> 128
            else -> return false
        }
        return prefix in 0..max
    }

    /**
     * Validates an AmneziaWG profile before its values are concatenated into an INI file.
     * Every field written to the config is checked here, and [iniValue] rejects characters
     * that could terminate a line or open a new section.
     */
    fun validateWireguardProfile(profile: VpnProfile) {
        require(profile.protocol == VpnProtocol.WIREGUARD) { "Ожидался профиль WireGuard" }
        validateWireguardMaterial(profile)
    }

    fun validateAwgProfile(profile: VpnProfile) {
        require(profile.protocol == VpnProtocol.AMNEZIA_WG) { "Ожидался профиль AmneziaWG" }
        validateWireguardMaterial(profile)
        val q = profile.parameters
        q["jc"]?.let { requireIntRange("jc", it, 1, 128) }
        for (key in listOf("jmin", "jmax", "s1", "s2")) q[key]?.let { requireIntRange(key, it, 1, 1280) }
        for (key in listOf("h1", "h2", "h3", "h4")) q[key]?.let { requireIntRange(key, it, 1, 2_147_483_647) }
        // Reject any remaining parameter that would break the INI structure.
        for ((key, value) in q) iniValue(key, value, allowEquals = key in BASE64_PARAMS)
        iniValue("server", profile.server)
    }

    private fun requireIntRange(name: String, raw: String, min: Int, max: Int) {
        val value = raw.toIntOrNull() ?: throw IllegalArgumentException("Поле $name должно быть целым числом")
        require(value in min..max) { "Поле $name вне диапазона $min..$max" }
    }

    /**
     * Rejects characters that would terminate the current INI line or open a new section.
     * `=` is only allowed for base64 key values, where it is legitimate padding.
     */
    private fun iniValue(name: String, value: String, allowEquals: Boolean = false): String {
        require(value.none { it == '\r' || it == '\n' || it.isISOControl() }) { "Поле $name содержит управляющие символы" }
        require('[' !in value && ']' !in value) { "Поле $name содержит недопустимые символы INI" }
        require(allowEquals || '=' !in value) { "Поле $name содержит недопустимый символ '='" }
        return value
    }

    /**
     * `outbound = ["any"]` reads as "reroute every lookup", but it does not: in sing-box
     * a DNS rule matches the *outbound a lookup belongs to*, so this is the way to say
     * "resolve the outbound's own server address with `dns-direct`". That address has to
     * be known before the proxy can be dialled at all - see the note on [TunnelOptions.dnsLocal].
     *
     * Lookups that come from the device (TUN) belong to no outbound, so they do not match
     * and fall through to `final = dns-remote`, which detours through the proxy. Measured
     * on device: with a dead proxy every lookup fails, with a live one they succeed - see
     * DEVICE_TEST_0.5.0.md §8.1, which refutes the earlier "DNS leak" reading of this rule.
     *
     * The item is deprecated in sing-box 1.12.0 and removed in 1.14.0 in favour of
     * `domain_resolver` on the outbound. The pinned core is 1.11.1, so it is still the
     * correct spelling here - but this is the place to migrate when the core is upgraded.
     */
    private fun dns(options: TunnelOptions): DnsConfig {
        // Threat protection is DNS-backed: Quad9 publishes a resolver that refuses
        // known malicious/phishing domains. AdGuard DNS is used for the lighter DNS
        // protection switch. A user-provided resolver remains untouched when both
        // switches are off.
        val protectedResolver = when {
            options.protectionEnabled && options.blockThreats -> "https://dns.quad9.net/dns-query"
            options.protectionEnabled && options.dnsProtection -> "https://dns.adguard-dns.com/dns-query"
            else -> options.dnsRemote
        }
        return DnsConfig(
        servers = listOf(
            DnsServer(tag = "dns-remote", address = protectedResolver, addressResolver = "dns-direct", detour = "proxy"),
            DnsServer(tag = "dns-direct", address = options.dnsLocal, detour = "direct"),
        ),
        rules = listOf(
            DnsRule(outbound = listOf("any"), server = "dns-direct", disableCache = true),
        ),
        strategy = if (options.ipv6) "prefer_ipv4" else "ipv4_only",
        final = "dns-remote",
        )
    }

    private fun tun(options: TunnelOptions) = Inbound(
        type = "tun",
        tag = "tun-in",
        interfaceName = "tun0",
        address = buildList {
            add("172.19.0.1/28")
            if (options.ipv6) add("fdfe:dcba:9876::1/126")
        },
        mtu = options.mtu,
        autoRoute = true,
        strictRoute = false,
        stack = options.stack,
        sniff = true,
        sniffOverrideDestination = false,
        endpointIndependentNat = true,
        includePackage = (options.perAppMode as? PerAppMode.Include)?.packages,
        // Our own process is excluded unconditionally - see [selfPackage].
        excludePackage = buildList {
            (options.perAppMode as? PerAppMode.Exclude)?.packages?.let { addAll(it) }
            selfPackage?.let { if (it !in this) add(it) }
        }.takeIf { it.isNotEmpty() },
    )

    private fun outbounds(profile: VpnProfile, tag: String, options: TunnelOptions): List<Outbound> {
        val isQuic = profile.protocol in setOf(VpnProtocol.HYSTERIA2, VpnProtocol.TUIC)
        // A pin is the provider saying "this certificate is not CA-vouched - trust it
        // because it hashes to X". The core cannot check X (see [validateProfile]), but
        // the first half of that sentence is exactly what `insecure` encodes, so a pin
        // implies it. Measured on device against the crystalvps.top key, whose QUIC
        // listener serves a self-signed CN=www.bing.com certificate: with verification
        // left on the handshake dies with
        //
        //     CRYPTO_ERROR 0x12a (local): tls: failed to verify certificate:
        //     x509: certificate signed by unknown authority
        //
        // i.e. keeping verification on is not the safe option, it is a guaranteed
        // failure. A key with no pin is untouched and keeps full verification.
        val pinned = profile.parameters["pinSHA256"]?.isNotBlank() == true
        // QUIC protocols still need the key's TLS block. uTLS fingerprints and
        // Reality stay excluded.
        //
        // The uTLS exclusion is not "QUIC cannot be fingerprinted". It is that this core
        // cannot do it, and here the two claims part ways: in sing-box v1.11.1 the uTLS
        // client config implements no QUIC entry point, so sing-quic's `CreateTransport`
        // falls through to `Config.STDConfig()` - which the uTLS config answers with an
        // error instead of a config. So the fingerprint does not merely fail to reach the
        // handshake, it kills the dial.
        //
        // Measured on device, 2026-09-20, the crystalvps.top hysteria2 key (fp=firefox) -
        // eight sessions, four with `utls` and four without, alternating as builds were
        // swapped:
        //
        //     with utls    15:32:05  UNREACHABLE  dialFailures=3
        //     with utls    15:32:12  UNREACHABLE  dialFailures=3
        //     with utls    15:45:56  UNREACHABLE  dialFailures=3
        //     with utls    15:48:03  UNREACHABLE  dialFailures=3
        //     without      15:37:19  HEALTHY      probation passed
        //     without      15:49:52  HEALTHY      probation passed
        //     without      16:07:55  HEALTHY
        //     without      16:16:11  HEALTHY      probation passed
        //
        // Every failing one died inside 545 ms of start with
        //
        //     connection: open outbound connection: unsupported usage for uTLS
        //     dns: exchange failed for <host>. IN A: unsupported usage for uTLS
        //
        // which is the user-visible "Ядро запустилось, но не может открыть соединение".
        // An earlier pass called this a no-op on the strength of one A/B whose traffic
        // test ran while the tunnel was down, so the answer came from Wi-Fi. The
        // symmetric 4-and-4 above is what replaced it.
        //
        // Xray ignores the field on hysteria2 as well, so a key carrying `fp` is not
        // asking for anything either core can deliver - which is why carrying it no
        // longer blocks the key (see [validateProfile]).
        //
        // Discarding the whole object, which the previous shape did, is not an
        // option either: it forced server_name to the dial address and dropped alpn and
        // insecure with it. That breaks the normal hysteria2 shape - a provider
        // host fronted by someone else's certificate (sni=www.bing.com) - because
        // the handshake then asks for the dial host's name instead of the name the
        // certificate is actually for, and it silently ignored allowInsecure.
        val tls = profile.tls.takeIf { it.enabled }?.let { t ->
            OutboundTls(
                enabled = true,
                serverName = t.serverName ?: profile.server,
                insecure = (t.allowInsecure || pinned).takeIf { it },
                alpn = t.alpn.takeIf { it.isNotEmpty() },
                utls = if (isQuic) null else (t.fingerprint?.let { Utls(fingerprint = it) }
                    ?: t.reality?.let { Utls(fingerprint = "chrome") }),
                reality = if (isQuic) null else (t.reality?.let { Reality(publicKey = it.publicKey, shortId = it.shortId) }),
            )
        }
        val transportType = TransportCompat.normalize(profile.transport.type)
        val transport = profile.transport.takeIf { transportType != "tcp" }?.let { tr ->
            OutboundTransport(
                type = transportType,
                path = tr.path.takeIf { transportType != "grpc" },
                headers = tr.host?.takeIf { transportType == "ws" }?.let { mapOf("Host" to it) },
                host = tr.host?.let { h -> when (transportType) {
                    "http" -> JsonArray(h.split(',').map { JsonPrimitive(it.trim()) })
                    "httpupgrade" -> JsonPrimitive(h)
                    else -> null
                } },
                serviceName = (tr.serviceName ?: tr.path).takeIf { transportType == "grpc" },
                maxEarlyData = profile.parameters["ed"]?.toIntOrNull().takeIf { transportType == "ws" },
                earlyDataHeaderName = profile.parameters["eh"].takeIf { transportType == "ws" },
            )
        }
        val multiplex = Multiplex(enabled = options.enableMultiplex).takeIf { options.enableMultiplex }

        return when (profile.protocol) {
            VpnProtocol.VLESS -> listOf(Outbound(
                type = "vless",
                tag = tag,
                server = profile.server,
                serverPort = profile.port,
                uuid = profile.uuid,
                flow = profile.flow?.takeIf { it.isNotBlank() },
                tls = tls,
                transport = transport,
                multiplex = multiplex,
                domainStrategy = if (options.ipv6) "prefer_ipv4" else "ipv4_only",
                packetEncoding = profile.parameters["packetEncoding"],
            ))
            VpnProtocol.VMESS -> listOf(Outbound(
                type = "vmess",
                tag = tag,
                server = profile.server,
                serverPort = profile.port,
                uuid = profile.uuid,
                security = profile.parameters["scy"] ?: "auto",
                packetEncoding = profile.parameters["packetEncoding"],
                alterId = profile.alterId ?: 0,
                tls = tls,
                transport = transport,
                multiplex = multiplex,
            ))
            VpnProtocol.TROJAN -> listOf(Outbound(
                type = "trojan",
                tag = tag,
                server = profile.server,
                serverPort = profile.port,
                password = profile.password,
                tls = tls,
                transport = transport,
                multiplex = multiplex,
            ))
            VpnProtocol.SHADOWSOCKS -> {
                val plugin = profile.parameters["plugin"]?.substringBefore(';')
                val pluginOpts = profile.parameters["plugin"]?.substringAfter(';', "")
                
                if (plugin == "shadow-tls") {
                    val stlsParams = pluginOpts?.split(';')?.associate { 
                        val parts = it.split('=')
                        if (parts.size == 2) parts[0] to parts[1] else it to ""
                    } ?: emptyMap()
                    
                    listOf(
                        Outbound(
                            type = "shadowsocks",
                            tag = tag,
                            server = "127.0.0.1",
                            serverPort = 0,
                            method = profile.method,
                            password = profile.password,
                            detour = "$tag-shadowtls",
                            multiplex = multiplex,
                        ),
                        Outbound(
                            type = "shadowtls",
                            tag = "$tag-shadowtls",
                            server = profile.server,
                            serverPort = profile.port,
                            version = stlsParams["v"] ?: "3",
                            password = stlsParams["password"] ?: "",
                            tls = OutboundTls(enabled = true, serverName = stlsParams["host"] ?: profile.server)
                        )
                    )
                } else {
                    listOf(Outbound(
                        type = "shadowsocks",
                        tag = tag,
                        server = profile.server,
                        serverPort = profile.port,
                        method = profile.method,
                        plugin = plugin,
                        pluginOpts = pluginOpts,
                        password = profile.password,
                        multiplex = multiplex,
                    ))
                }
            }
            VpnProtocol.HYSTERIA2 -> listOf(Outbound(
                type = "hysteria2",
                obfs = profile.parameters["obfs"]?.let { HysteriaObfs(it, profile.parameters.getValue("obfs-password")) },
                upMbps = profile.parameters["upmbps"]?.toIntOrNull(),
                downMbps = profile.parameters["downmbps"]?.toIntOrNull(),
                serverPorts = profile.parameters["mport"]?.split(',')?.map { it.replace('-', ':') },
                hopInterval = profile.parameters["hop_interval"],
                tag = tag,
                server = profile.server,
                serverPort = profile.port,
                password = profile.password,
                tls = tls ?: OutboundTls(enabled = true, serverName = profile.server, insecure = pinned.takeIf { it }),
            ))
            VpnProtocol.TUIC -> listOf(Outbound(
                type = "tuic",
                congestionControl = profile.parameters["congestion_control"],
                udpRelayMode = profile.parameters["udp_relay_mode"],
                udpOverStream = profile.parameters["udp_over_stream"]?.let { it == "true" || it == "1" },
                zeroRttHandshake = profile.parameters["zero_rtt_handshake"]?.let { it == "true" || it == "1" },
                heartbeat = profile.parameters["heartbeat"],
                tag = tag,
                server = profile.server,
                serverPort = profile.port,
                uuid = profile.uuid,
                password = profile.password,
                tls = tls ?: OutboundTls(enabled = true, serverName = profile.server, insecure = pinned.takeIf { it }),
            ))
            VpnProtocol.SOCKS -> listOf(Outbound(type = "socks", tag = tag, server = profile.server,
                serverPort = profile.port, username = profile.parameters["username"], password = profile.password,
                version = profile.parameters["version"] ?: "5"))
            VpnProtocol.HTTP -> listOf(Outbound(type = "http", tag = tag, server = profile.server,
                serverPort = profile.port, username = profile.parameters["username"], password = profile.password, tls = tls))
            VpnProtocol.WIREGUARD -> listOf(Outbound(
                type = "wireguard",
                tag = tag,
                server = profile.server,
                serverPort = profile.port,
                localAddress = profile.parameters["local_address"]?.split(','),
                privateKey = profile.password,
                peerPublicKey = profile.parameters["public_key"],
                preSharedKey = profile.parameters["preshared_key"],
                reserved = profile.parameters["reserved"]?.split(',')?.map {
                    it.trim().toIntOrNull()?.takeIf { v -> v in 0..255 }
                        ?: throw IllegalArgumentException("reserved должен содержать целые числа 0..255")
                },
                mtu = profile.parameters["mtu"]?.toIntOrNull(),
            ))
            // AmneziaWG obfuscation is not representable in sing-box; it is rendered as an
            // INI by build(). Reaching here means config() was called directly, and a
            // "direct" outbound would silently send traffic outside the tunnel.
            VpnProtocol.AMNEZIA_WG -> error("AmneziaWG обслуживается только через build(): sing-box не поддерживает AWG-обфускацию")
            VpnProtocol.SSH -> listOf(Outbound(
                type = "ssh",
                tag = tag,
                server = profile.server,
                serverPort = profile.port,
                user = profile.parameters["username"],
                password = profile.password.takeIf { it?.isNotEmpty() == true },
                privateKey = profile.parameters["private_key"],
            ))
            VpnProtocol.NAIVE -> listOf(Outbound(
                type = "naive",
                tag = tag,
                server = profile.server,
                serverPort = profile.port,
                username = profile.parameters["username"],
                password = profile.password,
                network = profile.parameters["network"] ?: "tcp",
                tls = tls ?: OutboundTls(enabled = true, serverName = profile.server)
            ))
            VpnProtocol.TOR -> listOf(Outbound(
                type = "tor",
                tag = tag,
            ))
            VpnProtocol.UNKNOWN -> error("Неизвестный протокол")
        }
    }

    private fun route(
        proxyTag: String,
        options: TunnelOptions,
        ruleSetPaths: Map<String, String> = emptyMap(),
    ): RouteConfig {
        // `blockAds` is also the compatibility master switch for installations created
        // before the protection screen existed. New settings use protectionEnabled.
        val filteringEnabled = options.protectionEnabled || options.blockAds
        // A filter whose file is not installed is dropped. Filtering is a feature;
        // the tunnel is the product, so a missing list may never keep it from starting.
        val filters = if (filteringEnabled) buildList {
            if (options.blockAds) addFilter("cyrus-ads", ruleSetPaths)
            if (options.blockTrackers) {
                // AdGuard's DNS list is converted to the binary format expected by
                // sing-box. It complements the geosite list with tracker hosts that do
                // not carry a geosite ads category.
                addFilter("cyrus-trackers", ruleSetPaths)
            }
            if (options.blockAnnoyances) {
                // Consent-management domains are the network side of cookie banners and
                // newsletter/popup widgets. The UI can disable this category without
                // affecting ordinary advertising hosts.
                addFilter("cyrus-annoyances", ruleSetPaths)
            }
        } else emptyList()

        val rules = buildList {
            add(RouteRule(protocol = listOf("dns"), outbound = "dns-out"))
            if (options.firewallEnabled && options.blockedPackages.isNotEmpty()) {
                add(RouteRule(packageName = options.blockedPackages, outbound = "block"))
            }
            if (options.bypassLan) add(RouteRule(ipIsPrivate = true, outbound = "direct"))
            // NOTE: do not add a blanket "udp/443 -> block" (QUIC) rule here. The block
            // outbound fails every packet with a bare syscall.EPERM, which apps treat as a
            // dead network and often never fall back from QUIC to TCP ("no internet").
            filters.forEach { filter ->
                add(RouteRule(ruleSet = listOf(filter.tag), outbound = "block"))
            }
            // Last, and only for TCP: everything the filters blocked has already
            // been blocked above. Inspecting before them would hand a blocked
            // host a path straight past the rule that blocks it.
            //
            // UDP/443 is QUIC, which this outbound cannot read and does not try
            // to: it is forwarded untouched like any other packet.
            if (options.inspectHttps) {
                add(RouteRule(network = listOf("tcp"), port = listOf(443), outbound = MITM_TAG))
            }
        }
        val sets = filters.map { filter ->
            RuleSet(tag = filter.tag, path = filter.path)
        }
        return RouteConfig(rules = rules, ruleSet = sets, final = proxyTag)
    }

    private fun MutableList<ProtectionFilter>.addFilter(tag: String, paths: Map<String, String>) {
        val path = paths[tag]
        if (!path.isNullOrBlank()) add(ProtectionFilter(tag = tag, path = path))
    }

    private data class ProtectionFilter(val tag: String, val path: String)

    private companion object {
        const val MITM_TAG = "mitm"
        private val UUID_REGEX = Regex("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")
        private val BASE64_KEY = Regex("[A-Za-z0-9+/=]{44}")
        private val CIDR_V4 = Regex("((25[0-5]|2[0-4]\\d|1?\\d?\\d)\\.){3}(25[0-5]|2[0-4]\\d|1?\\d?\\d)/(3[0-2]|[12]?\\d)")
        private val PLUGIN_OPTS_REGEX = Regex("[A-Za-z0-9._:/=;+,-]*")
        private val BASE64_PARAMS = setOf("public_key", "preshared_key")
        private val ALLOWED_FLOWS = setOf("xtls-rprx-vision", "xtls-rprx-vision-udp443")
        private val ALLOWED_FINGERPRINTS = setOf("chrome", "firefox", "edge", "safari", "ios", "android", "360", "qq", "random", "randomized")
        /**
         * Importer markers that this adapter has since learned to build.
         *
         * `quic-fingerprint` is the only one so far. It was written for hysteria2 nodes
         * carrying `fp`; a uTLS fingerprint cannot be applied to a QUIC handshake by
         * either core, so the field is inert rather than unrepresentable - see
         * [XraySubscriptionReader]'s hysteria branch. It is kept here, and not deleted
         * from the reader alone, because nodes already in the database carry it.
         */
        private val HANDLED_IMPORT_MARKERS = setOf("quic-fingerprint")
        private val ALLOWED_ALPN = setOf("h2", "http/1.1", "http/1.0", "h3", "h3-29", "h2c")
        private val ALLOWED_SS_METHODS = setOf(
            "none", "aes-128-gcm", "aes-192-gcm", "aes-256-gcm", "chacha20-ietf-poly1305",
            "xchacha20-ietf-poly1305", "2022-blake3-aes-128-gcm", "2022-blake3-aes-256-gcm",
            "2022-blake3-chacha20-poly1305", "aes-128-ctr", "aes-192-ctr", "aes-256-ctr",
            "rc4-md5", "chacha20-ietf", "xchacha20",
        )
        private val ALLOWED_VMESS_SECURITY = setOf("auto", "none", "zero", "aes-128-gcm", "chacha20-poly1305")
    }
}
