package dev.kentra.vpn.config

import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.repository.ProfileValidator

/**
 * The config layer's answer to "can this key be built at all?".
 *
 * It delegates to [ConfigFactory.validateForAnyCore], which routes the key to the validator
 * of the core that would actually carry it. Using the sing-box-only validator here would be
 * a silent regression: it rejects xhttp/kcp/quic by design, so every Xray-only key would be
 * thrown out of the search before it was ever probed, and the search would report "no
 * candidates" on a device holding a dozen working ones.
 *
 * Throws rather than returning a verdict, matching the validator it wraps - callers that
 * only need the answer wrap it in `runCatching`.
 */
class ConfigProfileValidator(
    private val factory: ConfigFactory,
) : ProfileValidator {
    override fun validate(profile: VpnProfile) = factory.validateForAnyCore(profile)
}
