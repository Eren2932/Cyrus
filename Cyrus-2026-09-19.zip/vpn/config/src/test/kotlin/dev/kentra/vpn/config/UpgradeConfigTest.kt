package dev.kentra.vpn.config

import dev.kentra.domain.model.*
import kotlinx.serialization.json.*
import org.junit.Assert.*
import org.junit.Test
import java.io.File

class UpgradeConfigTest {
    private val factory=ConfigFactory()
    private val basic=VpnProfile("test","Test only",VpnProtocol.VLESS,"proxy.example",443,
        uuid="11111111-2222-4333-8444-555555555555",tls=TlsSettings(enabled=true,serverName="cdn.example"))
    private fun outbound(p:VpnProfile,options:TunnelOptions=TunnelOptions())=factory.config(p,options).outbounds.first()
    @Test fun `local proxy never creates a TUN or listens on LAN`() { val c=factory.config(basic,TunnelOptions(mode=ConnectionMode.PROXY));assertEquals("mixed",c.inbounds.single().type);assertEquals("127.0.0.1",c.inbounds.single().listen);assertEquals(2080,c.inbounds.single().listenPort);assertNull(c.inbounds.single().address) }
    @Test fun `Hysteria2 salamander emitted`() { val p=basic.copy(protocol=VpnProtocol.HYSTERIA2,password="test-only",parameters=mapOf("obfs" to "salamander","obfs-password" to "test-obfs","mport" to "443,5000-5010","upmbps" to "20"));val o=outbound(p);assertEquals("salamander",o.obfs?.type);assertEquals("test-obfs",o.obfs?.password);assertEquals(listOf("443","5000:5010"),o.serverPorts);assertEquals(20,o.upMbps) }
    @Test fun `TUIC options mapped`() { val p=basic.copy(protocol=VpnProtocol.TUIC,password="test-only",parameters=mapOf("congestion_control" to "bbr","udp_relay_mode" to "quic","zero_rtt_handshake" to "false","udp_over_stream" to "1","heartbeat" to "10s"));val o=outbound(p);assertEquals("bbr",o.congestionControl);assertEquals("quic",o.udpRelayMode);assertEquals(false,o.zeroRttHandshake);assertEquals(true,o.udpOverStream);assertEquals("10s",o.heartbeat) }
    @Test fun `SIP003 split plugin name from options`() { val o=outbound(basic.copy(protocol=VpnProtocol.SHADOWSOCKS,method="aes-256-gcm",password="test-only",parameters=mapOf("plugin" to "v2ray-plugin;tls;host=cdn.example")));assertEquals("v2ray-plugin",o.plugin);assertEquals("tls;host=cdn.example",o.pluginOpts) }
    @Test fun `HTTPUpgrade host is JSON string and HTTP host is JSON array`() { val upgrade=outbound(basic.copy(transport=TransportSettings("httpupgrade","/edge","cdn.example")));assertEquals(JsonPrimitive("cdn.example"),upgrade.transport?.host);assertNull(upgrade.transport?.headers)
        val http=outbound(basic.copy(transport=TransportSettings("http","/edge","a.example,b.example")));assertEquals(JsonArray(listOf(JsonPrimitive("a.example"),JsonPrimitive("b.example"))),http.transport?.host) }
    @Test fun `gRPC does not serialize ws path or headers`() { val o=outbound(basic.copy(transport=TransportSettings("grpc","legacy-service","cdn.example","service")));assertNull(o.transport?.path);assertNull(o.transport?.headers);assertEquals("service",o.transport?.serviceName) }
    @Test fun `per app include uses Android TUN filtering not ineffective route matching`() { val c=factory.config(basic,TunnelOptions(perAppMode=PerAppMode.Include(listOf("org.example.app"))));assertEquals(listOf("org.example.app"),c.inbounds.single().includePackage);assertFalse(c.route.rules.any { it.packageName != null }) }
    @Test fun `IPv6 setting affects VLESS resolution`() { assertEquals("prefer_ipv4",outbound(basic,TunnelOptions(ipv6=true)).domainStrategy) }
    // 20 of the 46 nodes in the 2026-09-19 device pool (7 ws + 13 tcp/reality) were refused
    // only because the subscription importer flagged `mux`, `show`, `heartbeatPeriod` and
    // `header.type=none` as unsupported -- see DEVICE_TEST_0.5.0.md §13.2б. None of those
    // changes what sing-box has to be told; these two pin that the adapter can express
    // such nodes, i.e. the refusal was the importer's, not the core's.
    @Test fun `websocket node from a multiplexed subscription is expressible`() {
        // `fp`/`alpn` reach the profile as TLS settings (the link parser maps them there),
        // not as raw parameters -- keep the shape the importer actually produces.
        val o=outbound(basic.copy(transport=TransportSettings("ws","/edge","edge-cache.example"),
            tls=TlsSettings(enabled=true,serverName="edge-cache.example",fingerprint="firefox",alpn=listOf("http/1.1")),
            parameters=mapOf("type" to "ws","security" to "tls")))
        assertEquals("ws",o.transport?.type);assertEquals("/edge",o.transport?.path)
        assertEquals("firefox",o.tls?.utls?.fingerprint);assertEquals(listOf("http/1.1"),o.tls?.alpn)
    }
    @Test fun `reality tcp node from a multiplexed subscription is expressible`() {
        val o=outbound(basic.copy(transport=TransportSettings("tcp"),
            tls=TlsSettings(enabled=true,serverName="cdn.example",fingerprint="firefox",
                reality=RealitySettings(publicKey="test-only-pbk",shortId="test-only-sid")),
            parameters=mapOf("type" to "tcp","security" to "reality","fp" to "firefox")))
        assertEquals("test-only-pbk",o.tls?.reality?.publicKey);assertEquals("test-only-sid",o.tls?.reality?.shortId)
    }
    // The chained Xray path (xhttp/kcp/quic): Xray terminates the transport on loopback,
    // sing-box keeps owning the TUN and forwards to it. It had no coverage at all.
    @Test fun `Xray chained inbound is loopback only and never the sing-box proxy port`() {
        val options=TunnelOptions(proxyPort=2080)
        val port=xrayInboundPort(options)
        assertNotEquals("a shared port points the chain at itself",options.proxyPort,port)
        assertTrue(port in 1024..65535)
        val p=basic.copy(transport=TransportSettings("xhttp","/x","cdn.example"),
            parameters=mapOf("type" to "xhttp","security" to "tls"))
        val root=Json.parseToJsonElement(XrayConfigFactory().config(p,options,port)).jsonObject
        val inb=root.getValue("inbounds").jsonArray.single().jsonObject
        assertEquals("127.0.0.1",inb.getValue("listen").jsonPrimitive.content)
        assertEquals(port,inb.getValue("port").jsonPrimitive.int)
        val out=root.getValue("outbounds").jsonArray.first().jsonObject
        assertEquals("xhttp",out.getValue("streamSettings").jsonObject.getValue("network").jsonPrimitive.content)
    }
    @Test fun `Xray inbound port wraps instead of leaving the allowed range`() {
        assertTrue(xrayInboundPort(TunnelOptions(proxyPort=65535)) in 1024..65535)
        assertTrue(xrayInboundPort(TunnelOptions(proxyPort=1024)) in 1024..65535)
    }
    @Test(expected=IllegalArgumentException::class) fun `Xray refuses a transport sing-box already carries`() {
        XrayConfigFactory().config(basic.copy(parameters=mapOf("type" to "ws")),TunnelOptions(),2081)
    }
    // The pinned sing-box is 1.11.1, which has no pin field at all
    // (`certificate_public_key_sha256` only arrived in 1.13.0), and the Hysteria2 pin is
    // a digest of the whole certificate while sing-box's field wants a digest of the
    // public key - not the same quantity, so the pin cannot even be translated without
    // the certificate. Refusing the key only made a working server unusable. Dropping
    // the pin while keeping verification is no better, and is a *guaranteed* failure:
    // measured on device, the crystalvps.top QUIC listener serves a self-signed
    // CN=www.bing.com certificate and the handshake dies with `x509: certificate signed
    // by unknown authority`. So a pin relaxes verification - and only a pin does.
    @Test fun `a pin the core cannot enforce no longer blocks the key`() {
        val o=outbound(basic.copy(protocol=VpnProtocol.HYSTERIA2,password="test-only",
            parameters=mapOf("pinSHA256" to "test-only-pin")))
        assertEquals("hysteria2",o.type)
        assertEquals(true,o.tls?.enabled)
        assertEquals(true,o.tls?.insecure)
    }
    @Test fun `a key with no pin keeps full certificate verification`() {
        val o=outbound(basic.copy(protocol=VpnProtocol.HYSTERIA2,password="test-only"))
        assertNull("only a pin may relax verification",o.tls?.insecure)
    }
    @Test fun `a pin combined with allowInsecure runs the same way`() {
        val o=outbound(basic.copy(protocol=VpnProtocol.HYSTERIA2,password="test-only",
            tls=TlsSettings(enabled=true,serverName="cdn.example",allowInsecure=true),
            parameters=mapOf("pinSHA256" to "test-only-pin")))
        assertEquals(true,o.tls?.insecure)
    }
    // The chained Xray path needs the same treatment, or a pinned xhttp/kcp/quic key
    // fails on the same self-signed certificate one hop later.
    @Test fun `a pin relaxes verification on the Xray path too`() {
        val p=basic.copy(transport=TransportSettings("xhttp","/x","cdn.example"),
            parameters=mapOf("type" to "xhttp","security" to "tls","pinSHA256" to "test-only-pin"))
        val tls=Json.parseToJsonElement(XrayConfigFactory().config(p,TunnelOptions(),2081)).jsonObject
            .getValue("outbounds").jsonArray.first().jsonObject
            .getValue("streamSettings").jsonObject.getValue("tlsSettings").jsonObject
        assertEquals(true,tls.getValue("allowInsecure").jsonPrimitive.boolean)
    }
    // QUIC protocols used to lose their whole TLS block. That forced server_name to the
    // dial address and dropped alpn/insecure, which breaks the ordinary hysteria2 shape:
    // a provider host fronted by another domain's certificate (sni=www.bing.com).
    @Test fun `hysteria2 keeps the key's sni and alpn but not the tcp-only tls extras`() {
        val o=outbound(basic.copy(protocol=VpnProtocol.HYSTERIA2,password="test-only",
            tls=TlsSettings(enabled=true,serverName="www.bing.com",alpn=listOf("h3"),
                fingerprint="firefox",reality=RealitySettings(publicKey="test-only-pbk"))))
        assertEquals("www.bing.com",o.tls?.serverName)
        assertEquals(listOf("h3"),o.tls?.alpn)
        assertNull("uTLS fingerprints are a TCP-TLS feature",o.tls?.utls)
        assertNull("Reality is a TCP-TLS feature",o.tls?.reality)
    }
    @Test fun `tuic keeps the key's sni and allowInsecure`() {
        val o=outbound(basic.copy(protocol=VpnProtocol.TUIC,password="test-only",uuid="11111111-2222-4333-8444-555555555555",
            tls=TlsSettings(enabled=true,serverName="front.example",allowInsecure=true)))
        assertEquals("front.example",o.tls?.serverName)
        assertEquals(true,o.tls?.insecure)
    }
    @Test(expected=IllegalArgumentException::class) fun `XHTTP blocked before native startup`() { outbound(basic.copy(transport=TransportSettings("xhttp"))) }
    @Test(expected=IllegalArgumentException::class) fun `gRPC multiMode blocked`() { outbound(basic.copy(transport=TransportSettings("grpc"),parameters=mapOf("mode" to "multi"))) }
    @Test(expected=IllegalArgumentException::class) fun `unknown xray behavior blocked`() { outbound(basic.copy(parameters=mapOf("cyrus-unsupported" to "xray-options"))) }
    @Test(expected=IllegalArgumentException::class) fun `incomplete salamander blocked`() { outbound(basic.copy(protocol=VpnProtocol.HYSTERIA2,parameters=mapOf("obfs" to "salamander"))) }
    @Test(expected=IllegalArgumentException::class) fun `unknown SIP plugin blocked`() { outbound(basic.copy(protocol=VpnProtocol.SHADOWSOCKS,parameters=mapOf("plugin" to "unknown"))) }
    @Test(expected=IllegalArgumentException::class) fun `invalid proxy port blocked`() { factory.config(basic,TunnelOptions(mode=ConnectionMode.PROXY,proxyPort=0)) }
    @Test(expected=IllegalArgumentException::class) fun `empty include is not accidentally all apps`() { TunnelOptions(perAppMode=PerAppMode.Include(emptyList())).validate() }
    @Test(expected=IllegalArgumentException::class) fun `Vision cannot enable multiplex`() { outbound(basic.copy(flow="xtls-rprx-vision"),TunnelOptions(enableMultiplex=true)) }
    @Test fun `SOCKS HTTP config credentials map without changing TLS`() { val socks=outbound(basic.copy(protocol=VpnProtocol.SOCKS,password="test-only",parameters=mapOf("username" to "test-user","version" to "5")));assertEquals("socks",socks.type);assertNull(socks.tls);assertEquals("test-user",socks.username)
        val http=outbound(basic.copy(protocol=VpnProtocol.HTTP,password="test-only"));assertEquals("http",http.type);assertEquals(true,http.tls?.enabled) }
    @Test fun `WireGuard profile is validated and serialized`() {
        val key = "sJPzZtUlYtG7AeIWuBUbCnEjrXvPRQjLPfKpBcJpQXY="
        val p = basic.copy(protocol=VpnProtocol.WIREGUARD, server="wg.example", port=51820,
            password=key, parameters=mapOf("public_key" to key, "local_address" to "10.0.0.2/32"))
        val o = outbound(p)
        assertEquals("wireguard", o.type)
        assertEquals(listOf("10.0.0.2/32"), o.localAddress)
        assertEquals(key, o.privateKey)
    }
    @Test fun `emit synthetic configs for independent native schema check in CI`() {
        val dir=File("build/native-fixtures").apply { mkdirs() }
        val profiles=listOf(basic,basic.copy(protocol=VpnProtocol.TROJAN,password="test-only"),
            basic.copy(protocol=VpnProtocol.HYSTERIA2,password="test-only",parameters=mapOf("obfs" to "salamander","obfs-password" to "test-only-obfs")),
            basic.copy(protocol=VpnProtocol.TUIC,password="test-only",parameters=mapOf("congestion_control" to "bbr")),
            basic.copy(protocol=VpnProtocol.SHADOWSOCKS,method="aes-256-gcm",password="test-only"),
            basic.copy(protocol=VpnProtocol.HTTP),basic.copy(protocol=VpnProtocol.SOCKS)) +
            listOf("ws","grpc","http","httpupgrade").map { basic.copy(transport=TransportSettings(it,"/edge","cdn.example","service")) }
        profiles.forEachIndexed { index,p -> File(dir,"config-$index.json").writeText(factory.build(p,TunnelOptions(mode=ConnectionMode.PROXY))) }
        File(dir,"config-tun.json").writeText(factory.build(basic))
        assertEquals(12,dir.listFiles { f->f.extension=="json" }!!.size)
    }
}
