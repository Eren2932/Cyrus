package dev.kentra.vpn.config

import dev.kentra.domain.model.RealitySettings
import dev.kentra.domain.model.TlsSettings
import dev.kentra.domain.model.TransportSettings
import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.model.VpnProtocol
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ConfigFactoryTest {

    private val factory = ConfigFactory()

    private val reality = VpnProfile(
        id = "1",
        name = "NL",
        protocol = VpnProtocol.VLESS,
        server = "1.2.3.4",
        port = 443,
        uuid = "11111111-2222-3333-4444-555555555555",
        flow = "xtls-rprx-vision",
        tls = TlsSettings(
            enabled = true,
            serverName = "www.microsoft.com",
            fingerprint = "chrome",
            reality = RealitySettings(publicKey = "PK", shortId = "ab"),
        ),
    )

    @Test
    fun `vless reality maps to sing-box outbound`() {
        val config = factory.config(reality, TunnelOptions())
        val proxy = config.outbounds.first { it.tag == "proxy" }

        assertEquals("vless", proxy.type)
        assertEquals("11111111-2222-3333-4444-555555555555", proxy.uuid)
        assertEquals("xtls-rprx-vision", proxy.flow)
        assertEquals("www.microsoft.com", proxy.tls?.serverName)
        assertEquals("PK", proxy.tls?.reality?.publicKey)
        assertEquals("chrome", proxy.tls?.utls?.fingerprint)
    }

    @Test
    fun `tun inbound respects options`() {
        val config = factory.config(reality, TunnelOptions(mtu = 1420, stack = "gvisor", ipv6 = true))
        val tun = config.inbounds.single()

        assertEquals(1420, tun.mtu)
        assertEquals("gvisor", tun.stack)
        assertEquals(2, tun.address?.size)
    }

    @Test
    fun `dns route targets dns-out and default route targets proxy`() {
        val config = factory.config(reality, TunnelOptions())
        assertTrue(config.route.rules.any { it.protocol == listOf("dns") && it.outbound == "dns-out" })
        assertEquals("proxy", config.route.final)
    }

    @Test
    fun `udp443 is never blanket-blocked - block outbound fails QUIC with EPERM`() {
        // sing-box's `block` outbound returns a bare syscall.EPERM for packet
        // connections; apps never fall back from QUIC to TCP, which reads as
        // "no internet through VPN". Regression guard against reintroducing it.
        for (ipv6 in listOf(true, false)) {
            val config = factory.config(reality, TunnelOptions(ipv6 = ipv6))
            assertFalse(
                config.route.rules.any {
                    it.network?.contains("udp") == true && it.port?.contains(443) == true && it.outbound == "block"
                },
            )
        }
    }

    @Test
    fun `ws transport is emitted with host header`() {
        val profile = reality.copy(transport = TransportSettings(type = "ws", path = "/ws", host = "cdn.tld"))
        val proxy = factory.config(profile, TunnelOptions()).outbounds.first { it.tag == "proxy" }

        assertEquals("ws", proxy.transport?.type)
        assertEquals("/ws", proxy.transport?.path)
        assertEquals("cdn.tld", proxy.transport?.headers?.get("Host"))
    }

    @Test
    fun `serialized json contains no null noise`() {
        val out = factory.build(reality.copy(transport = TransportSettings(type = "tcp")))
        assertFalse(out.contains(": null"))
        assertTrue(out.contains("\"type\": \"tun\""))
    }

    // A VPN client must not route its own sockets into the tunnel it owns. sing-box
    // protects its own outbounds, but the Xray helper core cannot, so without this the
    // whole xhttp/kcp/quic path carries nothing while looking perfectly healthy.
    @Test
    fun `the app always keeps itself out of its own tunnel`() {
        val config = ConfigFactory(selfPackage = "dev.kentra.app").config(reality, TunnelOptions())
        assertEquals(listOf("dev.kentra.app"), config.inbounds.single().excludePackage)
    }

    @Test
    fun `self exclusion is merged with a user exclude list rather than replacing it`() {
        val config = ConfigFactory(selfPackage = "dev.kentra.app").config(
            reality,
            TunnelOptions(perAppMode = PerAppMode.Exclude(listOf("com.example.other"))),
        )
        assertEquals(listOf("com.example.other", "dev.kentra.app"), config.inbounds.single().excludePackage)
    }

    @Test
    fun `self exclusion also holds when only listed apps are tunnelled`() {
        val config = ConfigFactory(selfPackage = "dev.kentra.app").config(
            reality,
            TunnelOptions(perAppMode = PerAppMode.Include(listOf("org.example.app"))),
        )
        assertEquals(listOf("org.example.app"), config.inbounds.single().includePackage)
        assertEquals(listOf("dev.kentra.app"), config.inbounds.single().excludePackage)
    }

    @Test
    fun `protection switches create independent blocking rule sets`() {
        val config = factory.config(
            reality,
            TunnelOptions(
                protectionEnabled = true,
                blockAds = true,
                blockTrackers = true,
                blockAnnoyances = true,
            ),
            ruleSetPaths = mapOf(
                "cyrus-ads" to "/data/data/dev.kentra.app/files/rulesets/cyrus-ads.srs",
                "cyrus-trackers" to "/data/data/dev.kentra.app/files/rulesets/cyrus-trackers.srs",
                "cyrus-annoyances" to "/data/data/dev.kentra.app/files/rulesets/cyrus-annoyances.srs",
            ),
        )
        val tags = config.route.rules.mapNotNull { it.ruleSet?.singleOrNull() }
        assertEquals(listOf("cyrus-ads", "cyrus-trackers", "cyrus-annoyances"), tags)
        assertEquals(tags.toSet(), config.route.ruleSet.map { it.tag }.toSet())
        // Local only: a remote rule-set is fetched inside the core's start(), where
        // the TUN is already up and no physical interface is bound, and a failed
        // download then takes the whole tunnel down with it.
        assertTrue(config.route.ruleSet.all { it.type == "local" })
        assertTrue(config.route.ruleSet.all { it.path.isNotBlank() })
    }

    @Test
    fun `a filter whose file is not installed is dropped rather than fetched`() {
        val config = factory.config(
            reality,
            TunnelOptions(protectionEnabled = true, blockAds = true, blockTrackers = true),
            ruleSetPaths = mapOf("cyrus-ads" to "/rulesets/cyrus-ads.srs"),
        )
        assertEquals(listOf("cyrus-ads"), config.route.ruleSet.map { it.tag })
        assertEquals(listOf("cyrus-ads"), config.route.rules.mapNotNull { it.ruleSet?.singleOrNull() })
    }

    @Test
    fun `protection master switch is required for new category switches`() {
        val config = factory.config(reality, TunnelOptions(blockTrackers = true))
        assertTrue(config.route.rules.none { it.outbound == "block" })
        assertTrue(config.route.ruleSet.isEmpty())
    }

    @Test
    fun `threat protection selects a protected DNS resolver`() {
        val config = factory.config(
            reality,
            TunnelOptions(protectionEnabled = true, blockThreats = true),
        )
        assertEquals("https://dns.quad9.net/dns-query", config.dns.servers.first { it.tag == "dns-remote" }.address)
    }

    @Test
    fun `firewall blocks selected packages before lan bypass`() {
        val config = factory.config(
            reality,
            TunnelOptions(firewallEnabled = true, blockedPackages = listOf("com.example.video")),
        )
        val firewall = config.route.rules.first { it.packageName != null }
        assertEquals(listOf("com.example.video"), firewall.packageName)
        assertEquals("block", firewall.outbound)
    }

    @Test
    fun `invalid firewall package ids are rejected`() {
        val error = runCatching {
            TunnelOptions(firewallEnabled = true, blockedPackages = listOf("not valid")).validate()
        }.exceptionOrNull()
        assertTrue(error is IllegalArgumentException)
    }

    @Test
    fun `no self package configured means no exclusion list`() {
        val config = ConfigFactory().config(reality, TunnelOptions())
        assertEquals(null, config.inbounds.single().excludePackage)
    }

    @Test
    fun `https inspection is off unless the user turned it on`() {
        val config = factory.config(reality, TunnelOptions())
        assertTrue(config.outbounds.none { it.type == "mitm" })
        assertTrue(config.route.rules.none { it.outbound == "mitm" })
    }

    @Test
    fun `https inspection intercepts tcp 443 through the proxy outbound`() {
        val config = factory.config(reality, TunnelOptions(inspectHttps = true))
        val mitm = config.outbounds.single { it.type == "mitm" }
        // The request must still leave through the tunnel: inspection is not a
        // second way out of it.
        assertEquals("proxy", mitm.detour)
        val rule = config.route.rules.single { it.outbound == "mitm" }
        assertEquals(listOf("tcp"), rule.network)
        assertEquals(listOf(443), rule.port)
    }

    @Test
    fun `blocked domains are still blocked when inspection is on`() {
        // The mitm rule must come after the blocking rules: intercepting first
        // would hand a blocked host a path straight past the rule that blocks it.
        val config = factory.config(
            reality,
            TunnelOptions(protectionEnabled = true, blockAds = true, inspectHttps = true),
            ruleSetPaths = mapOf("cyrus-ads" to "/rulesets/cyrus-ads.srs"),
        )
        val blockIndex = config.route.rules.indexOfFirst { it.outbound == "block" }
        val mitmIndex = config.route.rules.indexOfFirst { it.outbound == "mitm" }
        assertTrue(blockIndex >= 0 && mitmIndex > blockIndex)
    }
}
