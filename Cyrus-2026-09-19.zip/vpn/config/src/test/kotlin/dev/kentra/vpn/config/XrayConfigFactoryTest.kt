package dev.kentra.vpn.config

import dev.kentra.domain.model.ProfileOrigin
import dev.kentra.domain.model.RealitySettings
import dev.kentra.domain.model.TlsSettings
import dev.kentra.domain.model.TransportCompat
import dev.kentra.domain.model.TransportSettings
import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.model.VpnProtocol
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

/**
 * H-3 regression: the Xray core used to be unusable in both modes - VPN threw
 * `error(...)` outright, and PROXY bound the chained sing-box and Xray to the same
 * port. These tests pin the two things that were broken and the fail-closed
 * validation added on top.
 */
class XrayConfigFactoryTest {

    private val json = Json { ignoreUnknownKeys = true }

    private fun vless(
        type: String = "xhttp",
        uuid: String = "4c7a0b95-1dcb-4044-b948-69e1b4881733",
        server: String = "edge.example.com",
        port: Int = 443,
        extra: Map<String, String> = emptyMap(),
    ) = VpnProfile(
        id = "p1",
        name = "edge",
        protocol = VpnProtocol.VLESS,
        server = server,
        port = port,
        uuid = uuid,
        origin = ProfileOrigin.Manual,
        // The typed field is the canonical transport; `parameters["type"]` is only
        // what the link happened to write. A fixture that sets one and leaves the
        // other at its default describes a profile the app cannot produce.
        transport = TransportSettings(type = TransportCompat.normalize(type)),
        parameters = mapOf("type" to type, "security" to "tls") + extra,
    )

    private fun inboundPortOf(configJson: String): Int =
        json.parseToJsonElement(configJson).jsonObject["inbounds"]!!.jsonArray[0]
            .jsonObject["port"]!!.jsonPrimitive.content.toInt()

    // --- the port collision -------------------------------------------------

    @Test
    fun `derived inbound port never equals the proxy port`() {
        for (proxyPort in listOf(1024, 1080, 2080, 8080, 30_000, 65533, 65534, 65535)) {
            val derived = xrayInboundPort(TunnelOptions(proxyPort = proxyPort))
            assertNotEquals("collision at proxyPort=$proxyPort", proxyPort, derived)
            assertTrue(
                "derived port $derived out of range for proxyPort=$proxyPort",
                derived in 1024..65535,
            )
        }
    }

    @Test
    fun `derived port wraps instead of overflowing the range`() {
        // At the top of the range there is no "+1" left, so it steps down.
        assertEquals(65534, xrayInboundPort(TunnelOptions(proxyPort = 65535)))
        assertEquals(65535, xrayInboundPort(TunnelOptions(proxyPort = 65534)))
    }

    // --- both modes work ----------------------------------------------------

    @Test
    fun `vpn mode no longer refuses to build a config`() {
        // Used to be: error("Xray engine does not support native VPN mode ...").
        val options = TunnelOptions(mode = ConnectionMode.VPN, proxyPort = 2080)
        val config = XrayConfigFactory().config(vless(), options, xrayInboundPort(options))
        assertTrue(config.contains("\"inbounds\""))
    }

    @Test
    fun `proxy mode and vpn mode produce the same inbound`() {
        val profile = vless()
        val proxy = XrayConfigFactory().config(
            profile, TunnelOptions(mode = ConnectionMode.PROXY, proxyPort = 2080), 2081,
        )
        val vpn = XrayConfigFactory().config(
            profile, TunnelOptions(mode = ConnectionMode.VPN, proxyPort = 2080), 2081,
        )
        assertEquals(
            "the loopback inbound is mode-independent",
            json.parseToJsonElement(proxy).jsonObject["inbounds"],
            json.parseToJsonElement(vpn).jsonObject["inbounds"],
        )
    }

    @Test
    fun `the inbound listens on the explicit port, not on the proxy port`() {
        val options = TunnelOptions(proxyPort = 2080)
        val config = XrayConfigFactory().config(vless(), options, 4444)
        assertEquals(4444, inboundPortOf(config))
        assertNotEquals(options.proxyPort, inboundPortOf(config))
    }

    // --- the self-referencing outbound ---------------------------------------

    @Test
    fun `the outbound targets the real server, not the local inbound`() {
        // The chained configuration used to point the outbound back at 127.0.0.1,
        // i.e. at itself, so nothing ever left the device.
        val config = XrayConfigFactory().config(
            vless(server = "edge.example.com"), TunnelOptions(), 2081,
        )
        val outbound = json.parseToJsonElement(config).jsonObject["outbounds"]!!
            .jsonArray.first { it.jsonObject["tag"]?.jsonPrimitive?.content == "proxy" }
        val vnext = outbound.jsonObject["settings"]!!.jsonObject["vnext"]!!.jsonArray[0].jsonObject
        assertEquals("edge.example.com", vnext["address"]!!.jsonPrimitive.content)
        assertEquals("443", vnext["port"]!!.jsonPrimitive.content)
    }

    // --- fail-closed validation ----------------------------------------------

    @Test
    fun `a transport sing-box can carry is refused`() {
        // Xray is only brought up for transports sing-box cannot do; building it
        // for anything else would silently double the cores on the device.
        // The refusal must name the canonical transport, not whatever spelling the
        // link used - otherwise the user is told about a transport they never asked for.
        for ((written, canonical) in listOf(
            "ws" to "ws", "grpc" to "grpc", "tcp" to "tcp",
            "raw" to "tcp", "h2" to "http", "gun" to "grpc",
        )) {
            val ex = assertRejects { XrayConfigFactory().config(vless(type = written), TunnelOptions(), 2081) }
            assertTrue(
                "written=$written: expected the canonical '$canonical' in: ${ex.message}",
                ex.message!!.contains(canonical, ignoreCase = true),
            )
        }
    }

    @Test
    fun `grpc multiMode uses Xray while ordinary grpc stays sing-box`() {
        val multi = vless(type = "grpc", extra = mapOf("mode" to "multi", "serviceName" to "svc"))
        val config = json.parseToJsonElement(XrayConfigFactory().config(multi, TunnelOptions(), 2081)).jsonObject
        val grpc = config["outbounds"]!!.jsonArray.first { it.jsonObject["tag"]!!.jsonPrimitive.content == "proxy" }
            .jsonObject["streamSettings"]!!.jsonObject["grpcSettings"]!!.jsonObject
        assertEquals("true", grpc["multiMode"]!!.jsonPrimitive.content)

        val ordinary = multi.copy(parameters = mapOf("type" to "grpc", "security" to "tls"))
        assertTrue(assertRejects { XrayConfigFactory().config(ordinary, TunnelOptions(), 2081) }.message!!.contains("grpc"))
    }

    @Test
    fun `vmess xray-only transport uses the typed transport field`() {
        val profile = vless(type = "xhttp").copy(
            protocol = VpnProtocol.VMESS,
            parameters = mapOf("type" to "xhttp", "security" to "tls", "scy" to "auto"),
            tls = dev.kentra.domain.model.TlsSettings(enabled = true, serverName = "cdn.example"),
        )
        val root = json.parseToJsonElement(XrayConfigFactory().config(profile, TunnelOptions(), 2081)).jsonObject
        val outbound = root["outbounds"]!!.jsonArray.first { it.jsonObject["tag"]!!.jsonPrimitive.content == "proxy" }.jsonObject
        assertEquals("vmess", outbound["protocol"]!!.jsonPrimitive.content)
        assertEquals("xhttp", outbound["streamSettings"]!!.jsonObject["network"]!!.jsonPrimitive.content)
    }

    @Test
    fun `a malformed uuid is refused before it reaches the core`() {
        val ex = assertRejects {
            XrayConfigFactory().config(vless(uuid = "not-a-uuid"), TunnelOptions(), 2081)
        }
        assertTrue(ex.message!!.contains("UUID", ignoreCase = true))
    }

    @Test
    fun `trojan without a password is refused`() {
        val profile = vless().copy(protocol = VpnProtocol.TROJAN, password = "")
        assertRejects { XrayConfigFactory().config(profile, TunnelOptions(), 2081) }
    }

    @Test
    fun `a protocol xray cannot carry is refused`() {
        val profile = vless().copy(protocol = VpnProtocol.SHADOWSOCKS)
        assertRejects { XrayConfigFactory().config(profile, TunnelOptions(), 2081) }
    }

    @Test
    fun `a local port outside the usable range is refused`() {
        for (port in listOf(0, 80, 1023, 65536, -1)) {
            assertRejects("port=$port") {
                XrayConfigFactory().config(vless(), TunnelOptions(), port)
            }
        }
    }

    // --- routing knobs --------------------------------------------------------

    /**
     * The typed model is the canonical source, so its values have to reach the core
     * even when the raw parameters carry no such key. `put(k, v) ?: remove(k)` used
     * to delete each of these one line after writing it, because `MutableMap.put`
     * returns the previous value - null for a key that was not there.
     */
    @Test
    fun `typed transport and tls fields reach the config without help from parameters`() {
        val profile = vless(type = "xhttp").copy(
            transport = TransportSettings(type = "xhttp", path = "/typed", host = "front.example"),
            tls = TlsSettings(
                enabled = true,
                serverName = "sni.example",
                fingerprint = "firefox",
                alpn = listOf("h2"),
            ),
            flow = "xtls-rprx-vision",
            // Deliberately no path/host/sni/fp/flow here: the typed fields are the
            // only source, which is exactly the case the old idiom dropped.
            parameters = mapOf("type" to "xhttp"),
        )
        val out = json.parseToJsonElement(
            XrayConfigFactory().config(profile, TunnelOptions(), 2081),
        ).jsonObject["outbounds"]!!.jsonArray[0].jsonObject
        val stream = out["streamSettings"]!!.jsonObject

        val xhttp = stream["xhttpSettings"]!!.jsonObject
        assertEquals("/typed", xhttp["path"]!!.jsonPrimitive.content)
        assertEquals("front.example", xhttp["host"]!!.jsonPrimitive.content)

        val tls = stream["tlsSettings"]!!.jsonObject
        assertEquals("sni.example", tls["serverName"]!!.jsonPrimitive.content)
        assertEquals("firefox", tls["fingerprint"]!!.jsonPrimitive.content)
        assertEquals(listOf("h2"), tls["alpn"]!!.jsonArray.map { it.jsonPrimitive.content })

        val user = out["settings"]!!.jsonObject["vnext"]!!.jsonArray[0]
            .jsonObject["users"]!!.jsonArray[0].jsonObject
        assertEquals("xtls-rprx-vision", user["flow"]!!.jsonPrimitive.content)
    }

    @Test
    fun `reality fields survive when only the typed model carries them`() {
        val profile = vless(type = "xhttp").copy(
            transport = TransportSettings(type = "xhttp", path = "/x"),
            tls = TlsSettings(
                enabled = true,
                serverName = "cdn.example",
                reality = RealitySettings(publicKey = "pbk-value", shortId = "sid-value", spiderX = "/spx"),
            ),
            parameters = mapOf("type" to "xhttp"),
        )
        val stream = json.parseToJsonElement(
            XrayConfigFactory().config(profile, TunnelOptions(), 2081),
        ).jsonObject["outbounds"]!!.jsonArray[0].jsonObject["streamSettings"]!!.jsonObject

        val reality = stream["realitySettings"]!!.jsonObject
        assertEquals("pbk-value", reality["publicKey"]!!.jsonPrimitive.content)
        assertEquals("sid-value", reality["shortId"]!!.jsonPrimitive.content)
        assertEquals("/spx", reality["spiderX"]!!.jsonPrimitive.content)
    }

    /**
     * Xray refuses the *entire* config with `"headers" can't contain "host"` when the
     * XHTTP transport is handed a Host header, so the host has to travel in its own
     * field. That single mistake is what made every xhttp key report
     * "Ядро не запустилось" even after the geo-data problem was removed.
     */
    @Test
    fun `xhttp puts the host in its own field and never in headers`() {
        val profile = vless(type = "xhttp").copy(
            transport = TransportSettings(type = "xhttp", path = "/x", host = "front.example"),
            parameters = mapOf("type" to "xhttp", "security" to "tls", "mode" to "auto"),
        )
        val out = json.parseToJsonElement(
            XrayConfigFactory().config(profile, TunnelOptions(), 2081),
        ).jsonObject["outbounds"]!!.jsonArray[0].jsonObject
        val xhttp = out["streamSettings"]!!.jsonObject["xhttpSettings"]!!.jsonObject

        assertEquals("front.example", xhttp["host"]!!.jsonPrimitive.content)
        assertEquals("/x", xhttp["path"]!!.jsonPrimitive.content)
        assertEquals("auto", xhttp["mode"]!!.jsonPrimitive.content)
        assertTrue("headers must not carry host: $xhttp", "headers" !in xhttp)
    }

    /** The core rejects a secured QUIC transport with no key at load time. */
    @Test
    fun `a secured quic transport without a key is refused before the core sees it`() {
        assertRejects("quicSecurity=aes-128-gcm") {
            XrayConfigFactory().config(
                vless(type = "quic", extra = mapOf("quicSecurity" to "aes-128-gcm")),
                TunnelOptions(),
                2081,
            )
        }
    }

    @Test
    fun `kcp header camouflage outside the supported set is refused`() {
        assertRejects("headerType=bogus") {
            XrayConfigFactory().config(
                vless(type = "kcp", extra = mapOf("headerType" to "bogus")),
                TunnelOptions(),
                2081,
            )
        }
    }

    @Test
    fun `kcp and quic settings use the field names the core expects`() {
        val kcp = json.parseToJsonElement(
            XrayConfigFactory().config(
                vless(type = "kcp", extra = mapOf("headerType" to "srtp")), TunnelOptions(), 2081,
            ),
        ).jsonObject["outbounds"]!!.jsonArray[0].jsonObject["streamSettings"]!!.jsonObject
        assertEquals("srtp", kcp["kcpSettings"]!!.jsonObject["header"]!!.jsonObject["type"]!!.jsonPrimitive.content)

        val quic = json.parseToJsonElement(
            XrayConfigFactory().config(
                vless(type = "quic", extra = mapOf("quicSecurity" to "aes-128-gcm", "key" to "shared")),
                TunnelOptions(),
                2081,
            ),
        ).jsonObject["outbounds"]!!.jsonArray[0].jsonObject["streamSettings"]!!.jsonObject
        val quicSettings = quic["quicSettings"]!!.jsonObject
        assertEquals("aes-128-gcm", quicSettings["security"]!!.jsonPrimitive.content)
        assertEquals("shared", quicSettings["key"]!!.jsonPrimitive.content)
    }

    @Test
    fun `lan bypass lists private ranges explicitly instead of a geoip reference`() {
        val options = TunnelOptions(bypassLan = true)
        val rules: JsonArray = json.parseToJsonElement(
            XrayConfigFactory().config(vless(), options, 2081),
        ).jsonObject["routing"]!!.jsonObject["rules"]!!.jsonArray

        assertEquals(1, rules.size)
        val lan = rules[0].jsonObject
        assertEquals("direct", lan["outboundTag"]!!.jsonPrimitive.content)

        val cidrs = lan["ip"]!!.jsonArray.map { it.jsonPrimitive.content }
        // The ranges sing-box's ip_is_private covers, plus loopback/link-local/CGNAT.
        assertTrue("RFC1918 10/8 missing", "10.0.0.0/8" in cidrs)
        assertTrue("RFC1918 172.16/12 missing", "172.16.0.0/12" in cidrs)
        assertTrue("RFC1918 192.168/16 missing", "192.168.0.0/16" in cidrs)
        assertTrue("loopback missing", "127.0.0.0/8" in cidrs)
        assertTrue("ULA missing", "fc00::/7" in cidrs)
        assertTrue("geoip reference survived: $cidrs", cidrs.none { it.startsWith("geoip") })
    }

    /**
     * The pinned Xray has no `geoip.dat`/`geosite.dat` (libXray.aar ships only
     * `classes.jar` and `jni/`, and the core looks for the data in `/system/bin`).
     * A single `geoip:`/`geosite:` string anywhere in the config aborts the whole
     * load with `failed to open geoip.dat`, which the UI reports as
     * "Ядро не запустилось" for every Xray-only key. This walks the emitted JSON
     * for every protocol/transport/option combination and fails on any geo token,
     * so the regression cannot come back through a new rule.
     */
    @Test
    fun `no configuration ever references geo data files`() {
        // The Xray-only transports; plain grpc is carried by sing-box and is refused here.
        val transports = listOf("xhttp", "kcp", "quic")
        val protocols = listOf(VpnProtocol.VLESS, VpnProtocol.VMESS, VpnProtocol.TROJAN)
        val optionSets = listOf(
            TunnelOptions(),
            TunnelOptions(bypassLan = true),
            TunnelOptions(blockAds = true),
            TunnelOptions(bypassLan = true, blockAds = true, ipv6 = true),
        )

        for (protocol in protocols) {
            for (transport in transports) {
                for (options in optionSets) {
                    val profile = when (protocol) {
                        VpnProtocol.VMESS -> vless(type = transport).copy(
                            protocol = protocol,
                            parameters = mapOf("type" to transport, "security" to "tls"),
                        )
                        VpnProtocol.TROJAN -> vless(type = transport).copy(
                            protocol = protocol,
                            password = "secret",
                            parameters = mapOf("type" to transport, "security" to "tls"),
                        )
                        else -> vless(type = transport)
                    }
                    val config = XrayConfigFactory().config(profile, options, 2081)
                    val label = "$protocol/$transport/$options"
                    assertTrue("geoip token in $label", !config.contains("geoip"))
                    assertTrue("geosite token in $label", !config.contains("geosite"))
                }
            }
        }
    }

    @Test
    fun `sing-box log levels are translated into levels xray actually has`() {
        // Xray accepts debug|info|warning|error|none. "warn" and "fatal" are not
        // among them, and an unknown level is swallowed silently rather than
        // reported - so passing the sing-box value through loses the diagnostics
        // without saying so.
        val expected = mapOf("warn" to "warning", "error" to "error", "fatal" to "error")
        for ((singBoxLevel, xrayLevel) in expected) {
            val config = XrayConfigFactory().config(
                vless(), TunnelOptions(logLevel = singBoxLevel), 2081,
            )
            val log: JsonObject = json.parseToJsonElement(config).jsonObject["log"]!!.jsonObject
            assertEquals("$singBoxLevel -> $xrayLevel", xrayLevel, log["loglevel"]!!.jsonPrimitive.content)
        }
    }

    @Test
    fun `no log level the validator allows is passed through untranslated`() {
        val xrayLevels = setOf("debug", "info", "warning", "error", "none")
        for (level in listOf("warn", "error", "fatal")) {
            val config = XrayConfigFactory().config(vless(), TunnelOptions(logLevel = level), 2081)
            val actual = json.parseToJsonElement(config).jsonObject["log"]!!
                .jsonObject["loglevel"]!!.jsonPrimitive.content
            assertTrue("loglevel=$level produced '$actual', which Xray does not define", actual in xrayLevels)
        }
    }

    // --- the chain: sing-box in front of the Xray listener ------------------

    /**
     * `TunnelControllerImpl` rewrites an Xray-only profile into a SOCKS hop that
     * points at the Xray loopback listener. It overrides protocol/server/port/
     * parameters and clears the original Xray-only transport, so the sing-box
     * hop is an ordinary local SOCKS outbound. Pins the rewrite to be complete.
     */
    @Test
    fun `chained sing-box hop builds once the Xray-only transport is cleared`() {
        for (type in listOf("xhttp", "quic", "kcp")) {
            val chained = vless(type = type).copy(
                transport = TransportSettings(type = "tcp"),
                protocol = VpnProtocol.SOCKS,
                server = "127.0.0.1",
                port = 2081,
                parameters = emptyMap(),
            )
            try {
                ConfigFactory().build(chained, TunnelOptions())
            } catch (e: IllegalArgumentException) {
                fail("chained hop for '$type' rejected: ${e.message}")
            }
        }
    }

    /** Why the hop must clear transport - a leaked one is refused, and rightly so. */
    @Test
    fun `a transport only Xray speaks is still refused on the chained hop`() {
        for (type in listOf("xhttp", "quic", "kcp")) {
            val leaked = vless(type = type).copy(
                transport = TransportSettings(type = type),
                protocol = VpnProtocol.SOCKS,
                server = "127.0.0.1",
                port = 2081,
                parameters = emptyMap(),
            )
            val e = assertRejects("leaked transport '$type'") { ConfigFactory().build(leaked, TunnelOptions()) }
            assertTrue(e.message!!.contains(type))
        }
    }

    private fun assertRejects(what: String = "", block: () -> String): IllegalArgumentException {
        return try {
            val produced = block()
            fail("expected a rejection $what; instead got: ${produced.take(120)}")
            throw AssertionError("unreachable")
        } catch (e: IllegalArgumentException) {
            e
        }
    }
}
