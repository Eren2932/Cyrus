package dev.kentra.vpn.config

import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.model.VpnProtocol
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * C-2: the AmneziaWG config is built by string concatenation, so every value must be
 * validated before it reaches the INI text. These tests feed the parser's real vector
 * (`%0A` decoded to `\n`) and assert refusal instead of injection.
 */
class AwgIniInjectionTest {
    private val factory = ConfigFactory()
    private val privateKey = "a".repeat(43) + "="
    private val publicKey = "b".repeat(43) + "="

    private fun awg(parameters: Map<String, String>) = VpnProfile(
        id = "id",
        name = "awg",
        protocol = VpnProtocol.AMNEZIA_WG,
        server = "1.2.3.4",
        port = 51820,
        password = privateKey,
        parameters = mapOf("public_key" to publicKey, "local_address" to "10.0.0.2/32") + parameters,
    )

    private fun failure(block: () -> Unit): Throwable? = runCatching(block).exceptionOrNull()

    @Test
    fun `newline in public_key is refused`() {
        val p = awg(mapOf("public_key" to "$publicKey\nEndpoint = attacker:51820"))
        assertTrue(failure { factory.build(p) } is IllegalArgumentException)
    }

    @Test
    fun `newline in jc is refused`() {
        val p = awg(mapOf("jc" to "4\n[Peer]"))
        assertTrue(failure { factory.build(p) } is IllegalArgumentException)
    }

    @Test
    fun `newline in local_address is refused`() {
        val p = awg(mapOf("local_address" to "10.0.0.2/32\nPrivateKey = leaked"))
        assertTrue(failure { factory.build(p) } is IllegalArgumentException)
    }

    @Test
    fun `bracket injection in a numeric field is refused`() {
        val p = awg(mapOf("s1" to "1\n[Peer]\nPublicKey = x"))
        assertTrue(failure { factory.build(p) } is IllegalArgumentException)
    }

    @Test
    fun `out of range numeric values are refused`() {
        for (bad in listOf("jc" to "129", "jc" to "0", "jmin" to "1281", "h1" to "0", "mtu" to "1279")) {
            assertTrue(
                "must reject ${bad.first}=${bad.second}",
                failure { factory.build(awg(mapOf(bad.first to bad.second))) } is IllegalArgumentException,
            )
        }
    }

    @Test
    fun `missing public_key is refused instead of writing the null literal`() {
        val p = VpnProfile(
            id = "id", name = "awg", protocol = VpnProtocol.AMNEZIA_WG,
            server = "1.2.3.4", port = 51820, password = privateKey,
            parameters = mapOf("local_address" to "10.0.0.2/32"),
        )
        assertTrue(failure { factory.build(p) } is IllegalArgumentException)
    }

    @Test
    fun `valid awg profile renders a complete ini`() {
        val ini = factory.build(awg(mapOf("jc" to "4", "jmin" to "10", "jmax" to "50", "s1" to "1", "s2" to "2", "h1" to "1", "mtu" to "1420")))
        assertTrue(ini.startsWith("[Interface]"))
        assertTrue(ini.contains("PublicKey = $publicKey"))
        assertTrue(ini.contains("Jc = 4"))
        assertTrue(ini.contains("MTU = 1420"))
        assertTrue(ini.contains("Endpoint = 1.2.3.4:51820"))
    }

    @Test
    fun `calling config directly for awg fails closed`() {
        val error = failure { factory.config(awg(emptyMap()), TunnelOptions()) }
        assertTrue(error is IllegalStateException)
        assertTrue(error!!.message!!.contains("build"))
    }
}
