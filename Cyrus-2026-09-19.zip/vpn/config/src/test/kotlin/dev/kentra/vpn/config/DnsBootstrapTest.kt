package dev.kentra.vpn.config

import dev.kentra.domain.model.TlsSettings
import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.model.VpnProtocol
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The DNS section has exactly two jobs, and they pull in opposite directions:
 *
 * 1. resolve the proxy's own server address *without* the tunnel - it must be known
 *    before the proxy can be dialled at all (the `dns-direct` server plus the rule
 *    that points outbound-scoped lookups at it);
 * 2. send everything the device asks for *through* the tunnel (`final = dns-remote`,
 *    whose `detour` is `proxy`).
 *
 * These tests pin that wiring. They cannot prove which path a lookup really takes -
 * that was settled by measurement on a device, see DEVICE_TEST_0.5.0.md §8.1: with a
 * dead proxy every lookup fails, with a live one they succeed, so client DNS does go
 * through the proxy despite the `any` rule. An earlier reading called this rule a
 * leak; the device disagreed, and the device is the evidence that counts.
 */
class DnsBootstrapTest {

    private val factory = ConfigFactory()

    private fun profile() = VpnProfile(
        id = "1",
        name = "n",
        protocol = VpnProtocol.VLESS,
        server = "edge.example.com",
        port = 443,
        uuid = "11111111-2222-3333-4444-555555555555",
        tls = TlsSettings(enabled = true),
    )

    @Test
    fun `the proxy server address is resolved without the tunnel`() {
        // Drop this rule and every hostname-based profile becomes undialable:
        // resolving the proxy through the proxy has no answer.
        val dns = factory.config(profile(), TunnelOptions()).dns

        assertEquals(listOf("any"), dns.rules.single().outbound)
        assertEquals("dns-direct", dns.rules.single().server)
        assertEquals("direct", dns.servers.single { it.tag == "dns-direct" }.detour)
    }

    @Test
    fun `everything the device asks for falls through to the tunneled resolver`() {
        val dns = factory.config(profile(), TunnelOptions()).dns

        assertEquals("dns-remote", dns.final)
        assertEquals("proxy", dns.servers.single { it.tag == "dns-remote" }.detour)
        // The bootstrap rule is scoped to outbounds; it must not name domains or
        // inbounds, which would widen it onto device traffic.
        assertTrue(dns.rules.single().ruleSet == null)
    }

    @Test
    fun `the shipped json keeps both halves`() {
        val root = Json { ignoreUnknownKeys = true }
            .parseToJsonElement(factory.build(profile()))
            .jsonObject["dns"]!!.jsonObject

        assertEquals("dns-remote", root["final"]!!.jsonPrimitive.content)
        val rules = root["rules"]!!.jsonArray
        assertEquals(1, rules.size)
        assertEquals("dns-direct", rules[0].jsonObject["server"]!!.jsonPrimitive.content)
    }
}
