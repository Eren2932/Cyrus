package dev.kentra.vpn.config

import dev.kentra.domain.model.TlsSettings
import dev.kentra.domain.model.TransportSettings
import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.model.VpnProtocol
import org.junit.Assert.assertTrue
import org.junit.Test

class ProfileAndOptionsValidationTest {
    private val factory = ConfigFactory()
    private val uuid = "11111111-2222-3333-4444-555555555555"

    private fun failure(block: () -> Unit): Throwable? = runCatching(block).exceptionOrNull()

    private val vless = VpnProfile(
        id = "id", name = "n", protocol = VpnProtocol.VLESS, server = "h.tld", port = 443,
        uuid = uuid, tls = TlsSettings(enabled = true),
    )

    private val hysteria2 = VpnProfile(
        id = "id", name = "n", protocol = VpnProtocol.HYSTERIA2, server = "h.tld", port = 443,
        tls = TlsSettings(enabled = true, fingerprint = "firefox", alpn = listOf("h3")),
        transport = TransportSettings(type = "tcp"),
    )

    @Test
    fun `invalid uuid is refused`() {
        assertTrue(failure { factory.validateProfile(vless.copy(uuid = "uuid-1")) } is IllegalArgumentException)
        assertTrue(failure { factory.validateProfile(vless) } == null)
    }

    @Test
    fun `unknown fingerprint is refused`() {
        assertTrue(failure { factory.validateProfile(vless.copy(tls = TlsSettings(enabled = true, fingerprint = "evil"))) } is IllegalArgumentException)
        assertTrue(failure { factory.validateProfile(vless.copy(tls = TlsSettings(enabled = true, fingerprint = "chrome"))) } == null)
    }

    @Test
    fun `unknown flow is refused`() {
        assertTrue(failure { factory.validateProfile(vless.copy(flow = "evil-flow")) } is IllegalArgumentException)
        assertTrue(failure { factory.validateProfile(vless.copy(flow = "xtls-rprx-vision")) } == null)
    }

    @Test
    fun `blank flow is treated as absent`() {
        assertTrue(failure { factory.validateProfile(vless.copy(flow = "")) } == null)
    }

    @Test
    fun `xray-only modes are accepted by the engine-aware validator`() {
        val xhttp = vless.copy(
            transport = dev.kentra.domain.model.TransportSettings("xhttp"),
            parameters = mapOf("type" to "xhttp", "security" to "tls", "mode" to "auto"),
        )
        assertTrue(failure { factory.validateForAnyCore(xhttp) } == null)
    }

    @Test
    fun `unknown alpn token is refused`() {
        assertTrue(failure { factory.validateProfile(vless.copy(tls = TlsSettings(enabled = true, alpn = listOf("evil")))) } is IllegalArgumentException)
        assertTrue(failure { factory.validateProfile(vless.copy(tls = TlsSettings(enabled = true, alpn = listOf("h2", "http/1.1")))) } == null)
    }

    @Test
    fun `shadowsocks method is whitelisted`() {
        val ss = VpnProfile(id = "id", name = "n", protocol = VpnProtocol.SHADOWSOCKS, server = "h.tld", port = 8388, method = "aes-256-gcm", password = "p")
        assertTrue(failure { factory.validateProfile(ss) } == null)
        assertTrue(failure { factory.validateProfile(ss.copy(method = "evil")) } is IllegalArgumentException)
    }

    @Test
    fun `vmess scy is whitelisted`() {
        val vmess = VpnProfile(id = "id", name = "n", protocol = VpnProtocol.VMESS, server = "h.tld", port = 443, uuid = uuid, parameters = mapOf("scy" to "auto"))
        assertTrue(failure { factory.validateProfile(vmess) } == null)
        assertTrue(failure { factory.validateProfile(vmess.copy(parameters = mapOf("scy" to "evil"))) } is IllegalArgumentException)
    }

    @Test
    fun `dns must be an ip, ip port or scheme url`() {
        assertTrue(failure { TunnelOptions(dnsRemote = "not a dns").validate() } is IllegalArgumentException)
        assertTrue(failure { TunnelOptions(dnsRemote = "1.1.1.1:53").validate() } == null)
        assertTrue(failure { TunnelOptions(dnsRemote = "tls://1.1.1.1").validate() } == null)
        assertTrue(failure { TunnelOptions(dnsRemote = "https://dns.google/dns-query").validate() } == null)
        assertTrue(failure { TunnelOptions(dnsRemote = "2606:4700:4700::1111").validate() } == null)
    }

    @Test
    fun `local dns rejects free text`() {
        assertTrue(failure { TunnelOptions(dnsLocal = "evil dns").validate() } is IllegalArgumentException)
        assertTrue(failure { TunnelOptions(dnsLocal = "local").validate() } == null)
        assertTrue(failure { TunnelOptions(dnsLocal = "1.1.1.1").validate() } == null)
    }

    // A uTLS fingerprint is inert on QUIC: neither core can apply it to a QUIC handshake,
    // so it describes nothing the connection needs. The importer used to mark such a node
    // unsupported anyway, which is how the hysteria2 key at
    // dbkv4jecap48.minecraft.webcam:443 (fp=firefox) became the one node out of four that
    // never reached the prober - while the three without `fp` connected normally.
    @Test
    fun `a hysteria2 key marked with a QUIC fingerprint is accepted`() {
        val marked = hysteria2.copy(parameters = mapOf("cyrus-unsupported" to "quic-fingerprint"))
        assertTrue("${marked.parameters}", failure { factory.validateProfile(marked) } == null)
    }

    @Test
    fun `every other unsupported marker still blocks the key`() {
        // Only `quic-fingerprint` stopped meaning "behaviour I cannot represent". The
        // rest still do, and a whitelist that grew by accident would let a node through
        // whose behaviour the adapter genuinely does not implement.
        for (marker in listOf("xray-options", "settings-options", "server-options", "user-options", "anything-else")) {
            val marked = hysteria2.copy(parameters = mapOf("cyrus-unsupported" to marker))
            assertTrue("$marker должен блокировать ключ", failure { factory.validateProfile(marked) } is IllegalArgumentException)
        }
    }
}
