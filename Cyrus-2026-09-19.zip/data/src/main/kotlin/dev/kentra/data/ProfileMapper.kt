package dev.kentra.data

import dev.kentra.core.database.ProfileEntity
import dev.kentra.domain.model.ProfileOrigin
import dev.kentra.domain.model.RealitySettings
import dev.kentra.domain.model.TlsSettings
import dev.kentra.domain.model.TransportSettings
import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.model.VpnProtocol
import dev.kentra.domain.model.connectionIdentity
import kotlinx.serialization.DeserializationStrategy
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/**
 * Storage DTOs are separate from domain models on purpose: the domain must be free to change
 * without forcing a database migration, and vice versa.
 */
@Serializable
private data class TlsDto(
    val enabled: Boolean = false,
    val serverName: String? = null,
    val allowInsecure: Boolean = false,
    val alpn: List<String> = emptyList(),
    val fingerprint: String? = null,
    val realityPublicKey: String? = null,
    val realityShortId: String? = null,
    val realitySpiderX: String? = null,
)

@Serializable
private data class TransportDto(
    val type: String = "tcp",
    val path: String? = null,
    val host: String? = null,
    val serviceName: String? = null,
    val rawLink: String? = null,
    val parameters: Map<String, String> = emptyMap(),
)

internal object ProfileMapper {

    private val json = Json {
        ignoreUnknownKeys = true
        // A malformed/legacy row must not break the whole profile list: unknown enum values
        // and nulls for non-nullable fields fall back to their defaults instead of throwing.
        coerceInputValues = true
        explicitNulls = false
    }

    /**
     * Decodes one column without ever letting a single corrupt row propagate. A missing or
     * damaged JSON blob yields null so the caller can substitute storage defaults (H-10).
     */
    private fun <T> decodeOrNull(deserializer: DeserializationStrategy<T>, value: String): T? =
        try {
            json.decodeFromString(deserializer, value)
        } catch (_: Exception) {
            // SerializationException/IllegalArgumentException/IllegalStateException: treat the
            // row as having no TLS/Transport settings rather than failing observeProfiles().
            null
        }

    fun toEntity(profile: VpnProfile): ProfileEntity = ProfileEntity(
        id = profile.id,
        name = profile.name,
        protocol = profile.protocol.name,
        server = profile.server,
        port = profile.port,
        uuid = profile.uuid,
        password = profile.password,
        method = profile.method,
        flow = profile.flow,
        alterId = profile.alterId,
        tlsJson = json.encodeToString(
            TlsDto.serializer(),
            TlsDto(
                enabled = profile.tls.enabled,
                serverName = profile.tls.serverName,
                allowInsecure = profile.tls.allowInsecure,
                alpn = profile.tls.alpn,
                fingerprint = profile.tls.fingerprint,
                realityPublicKey = profile.tls.reality?.publicKey,
                realityShortId = profile.tls.reality?.shortId,
                realitySpiderX = profile.tls.reality?.spiderX,
            ),
        ),
        transportJson = json.encodeToString(
            TransportDto.serializer(),
            TransportDto(
                type = profile.transport.type,
                path = profile.transport.path,
                host = profile.transport.host,
                serviceName = profile.transport.serviceName,
                rawLink = profile.rawLink,
                parameters = profile.parameters,
            ),
        ),
        originType = when (profile.origin) {
            is ProfileOrigin.Manual -> "manual"
            is ProfileOrigin.Subscription -> "subscription"
            is ProfileOrigin.Store -> "store"
        },
        originSourceId = (profile.origin as? ProfileOrigin.Subscription)?.sourceId,
        connectionIdentity = profile.connectionIdentity(),
        createdAt = profile.createdAt,
    )

    fun toDomain(entity: ProfileEntity): VpnProfile {
        val tls = decodeOrNull(TlsDto.serializer(), entity.tlsJson) ?: TlsDto()
        val transport = decodeOrNull(TransportDto.serializer(), entity.transportJson) ?: TransportDto()
        return VpnProfile(
            id = entity.id,
            name = entity.name,
            protocol = runCatching { VpnProtocol.valueOf(entity.protocol) }.getOrDefault(VpnProtocol.UNKNOWN),
            server = entity.server,
            port = entity.port,
            uuid = entity.uuid,
            password = entity.password,
            method = entity.method,
            flow = entity.flow,
            alterId = entity.alterId,
            tls = TlsSettings(
                enabled = tls.enabled,
                serverName = tls.serverName,
                allowInsecure = tls.allowInsecure,
                alpn = tls.alpn,
                fingerprint = tls.fingerprint,
                reality = tls.realityPublicKey?.let {
                    RealitySettings(publicKey = it, shortId = tls.realityShortId, spiderX = tls.realitySpiderX)
                },
            ),
            transport = TransportSettings(
                type = transport.type,
                path = transport.path,
                host = transport.host,
                serviceName = transport.serviceName,
            ),
            origin = when (entity.originType) {
                "subscription" -> ProfileOrigin.Subscription(entity.originSourceId.orEmpty())
                "store" -> ProfileOrigin.Store
                else -> ProfileOrigin.Manual
            },
            createdAt = entity.createdAt,
            rawLink = transport.rawLink,
            parameters = transport.parameters,
        )
    }
}
