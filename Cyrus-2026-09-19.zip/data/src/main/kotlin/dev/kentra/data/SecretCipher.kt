package dev.kentra.data

import android.content.Context
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyPermanentlyInvalidatedException
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import java.security.ProviderException
import java.security.SecureRandom
import javax.crypto.AEADBadTagException
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/** Versioned AES-256-GCM envelope. DEK is software-based for speed, KEK is hardware-bound. */
class SecretCipher(context: Context) {
    private val kek: SecretKey by lazy {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(ALIAS, null) as? SecretKey) ?: generateKek()
    }

    /**
     * Generates the KEK, preferring a StrongBox-backed key on API 28+. StrongBox is optional
     * hardware, so an unavailable secure element falls back to the normal AndroidKeyStore.
     */
    private fun generateKek(): SecretKey {
        val generator = KeyGenerator.getInstance("AES", "AndroidKeyStore")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                generator.init(kekSpec(strongBox = true))
                return generator.generateKey()
            } catch (_: ProviderException) {
                // StrongBoxUnavailableException (and similar provider failures): retry in TEE.
            }
        }
        generator.init(kekSpec(strongBox = false))
        return generator.generateKey()
    }

    private fun kekSpec(strongBox: Boolean): KeyGenParameterSpec {
        val builder = KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            // StrongBox is a preference, not a requirement: when the secure element is
            // unavailable the caller retries in the regular TEE.
            if (strongBox) builder.setIsStrongBoxBacked(true)
        }
        // Intentionally NOT setUnlockedDeviceRequired(true). Android's always-on VPN
        // and boot-time reconnect start this service before the device has ever been
        // unlocked; a key bound to the unlocked state makes every such start fail to
        // read the stored credentials, so the tunnel would stay down until the user
        // unlocks. Availability beats cold-boot hardening for a VPN client.
        // Intentionally NOT setUserAuthenticationRequired(true): the VPN foreground service
        // must read credentials for background reconnects while the screen is locked, and an
        // auth-bound key would make decryption fail there.
        return builder.build()
    }

    private val dek: SecretKey by lazy {
        val prefs = context.getSharedPreferences("cyrus_secure_storage", Context.MODE_PRIVATE)
        val existingEncryptedDek = prefs.getString("dek_v1", null)
        if (existingEncryptedDek != null) {
            val bytes = Base64.decode(existingEncryptedDek.removePrefix(PREFIX_V1), Base64.NO_WRAP)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, kek, GCMParameterSpec(128, bytes.copyOfRange(0, 12)))
            cipher.updateAAD("DEK".toByteArray(Charsets.UTF_8))
            SecretKeySpec(cipher.doFinal(bytes.copyOfRange(12, bytes.size)), "AES")
        } else {
            val generator = KeyGenerator.getInstance("AES")
            generator.init(256)
            val newDek = generator.generateKey()
            
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, kek)
            cipher.updateAAD("DEK".toByteArray(Charsets.UTF_8))
            val encryptedDekBytes = cipher.iv + cipher.doFinal(newDek.encoded)
            val encryptedDek = PREFIX_V1 + Base64.encodeToString(encryptedDekBytes, Base64.NO_WRAP)
            
            prefs.edit().putString("dek_v1", encryptedDek).apply()
            newDek
        }
    }

    private val random = SecureRandom()

    fun isEncrypted(value: String): Boolean = value.startsWith(PREFIX_V1) || value.startsWith(PREFIX_V2)
    fun isLegacy(value: String): Boolean = value.startsWith(PREFIX_V1)

    fun encrypt(value: String, context: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val iv = ByteArray(12).apply { random.nextBytes(this) }
        cipher.init(Cipher.ENCRYPT_MODE, dek, GCMParameterSpec(128, iv))
        cipher.updateAAD(context.toByteArray(Charsets.UTF_8))
        return PREFIX_V2 + Base64.encodeToString(iv + cipher.doFinal(value.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
    }

    fun decrypt(value: String, context: String): String {
        if (!isEncrypted(value)) return value // Read-only compatibility with original plaintext database.
        try {
            val isV1 = value.startsWith(PREFIX_V1)
            val prefix = if (isV1) PREFIX_V1 else PREFIX_V2
            val activeKey = if (isV1) kek else dek

            val bytes = Base64.decode(value.removePrefix(prefix), Base64.NO_WRAP)
            require(bytes.size >= 28)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, activeKey, GCMParameterSpec(128, bytes.copyOfRange(0, 12)))
            cipher.updateAAD(context.toByteArray(Charsets.UTF_8))
            return String(cipher.doFinal(bytes.copyOfRange(12, bytes.size)), Charsets.UTF_8)
        } catch (e: AEADBadTagException) {
            // Wrong key, tampered ciphertext or mismatched AAD. Fail closed: never return the
            // unreadable value as if it were valid.
            throw IllegalStateException("Данные защищённого хранилища повреждены или подменены", e)
        } catch (e: KeyPermanentlyInvalidatedException) {
            throw IllegalStateException("Ключ шифрования отозван системой. Требуется повторный импорт ключей.", e)
        } catch (e: Exception) {
            // Fail closed: never replace an unreadable credential with an empty one.
            throw IllegalStateException("Не удалось открыть защищённое хранилище", e)
        }
    }

    companion object {
        private const val ALIAS = "cyrus.credentials.v1"
        private const val PREFIX_V1 = "cyrus:enc:v1:"
        private const val PREFIX_V2 = "cyrus:enc:v2:"
    }
}
