package dev.kentra.data

import dev.kentra.core.common.AppError
import java.net.Inet4Address
import java.net.InetAddress
import java.net.UnknownHostException

/**
 * SSRF guard for subscription URLs.
 *
 * Lives outside the repository so it can be unit tested on the JVM: it touches nothing
 * but [InetAddress], and instantiating the repository would drag in Room, Keystore and
 * Ktor, none of which a check this small should depend on.
 */

/**
 * Rejects a host that resolves to an internal or reserved address: loopback, RFC1918
 * private, link-local (including 169.254.169.254, the cloud metadata endpoint),
 * multicast, unspecified, CGNAT, TEST-NET and other non-routable ranges.
 *
 * DNS-rebinding: the host is resolved here, immediately before the request, and every
 * returned address is checked, so a name that currently points at an internal service is
 * blocked. The window is narrowed but not eliminated - a hostile resolver can still
 * answer with a public address here and a private one to the HTTP stack moments later.
 * Closing it completely requires pinning the validated IP into the connection (a custom
 * DNS resolver) plus TLS verification against the original hostname.
 */
internal fun assertPublicTarget(host: String) {
    if (host.isBlank()) throw AppError.Parse("Некорректная ссылка подписки")
    val literal = host.removeSurrounding("[", "]")
    val addresses = try {
        InetAddress.getAllByName(literal)
    } catch (e: UnknownHostException) {
        throw AppError.Network("Не удалось разрешить адрес подписки.")
    }
    if (addresses.isEmpty() || addresses.any { isBlockedAddress(it) })
        throw AppError.Parse("Подписка указывает на внутренний или зарезервированный адрес.")
}

internal fun isBlockedAddress(address: InetAddress): Boolean {
    if (address.isAnyLocalAddress || address.isLoopbackAddress || address.isLinkLocalAddress ||
        address.isSiteLocalAddress || address.isMulticastAddress
    ) return true
    val bytes = address.address
    if (address is Inet4Address) {
        val a = bytes[0].toInt() and 0xFF
        val b = bytes[1].toInt() and 0xFF
        val c = bytes[2].toInt() and 0xFF
        return a == 0 ||                                   // 0.0.0.0/8 "this network"
            (a == 100 && b in 64..127) ||                  // 100.64.0.0/10 CGNAT (RFC 6598)
            (a == 192 && b == 0 && c == 0) ||              // 192.0.0.0/24 IETF protocol assignments
            (a == 192 && b == 0 && c == 2) ||              // 192.0.2.0/24 TEST-NET-1
            (a == 198 && (b == 18 || b == 19)) ||          // 198.18.0.0/15 benchmarking
            (a == 198 && b == 51 && c == 100) ||           // 198.51.100.0/24 TEST-NET-2
            (a == 203 && b == 0 && c == 113) ||            // 203.0.113.0/24 TEST-NET-3
            a >= 240                                       // 240.0.0.0/4 reserved + 255.255.255.255
    }
    // IPv6: fc00::/7 unique local, 2001:db8::/32 documentation.
    val first = bytes[0].toInt() and 0xFF
    val isUniqueLocal = (first and 0xFE) == 0xFC
    val isDocumentation = first == 0x20 && (bytes[1].toInt() and 0xFF) == 0x01 &&
        (bytes[2].toInt() and 0xFF) == 0x0D && (bytes[3].toInt() and 0xFF) == 0xB8
    return isUniqueLocal || isDocumentation
}
