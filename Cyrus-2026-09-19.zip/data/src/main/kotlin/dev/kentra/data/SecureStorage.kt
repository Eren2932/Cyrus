package dev.kentra.data

import androidx.room.withTransaction
import dev.kentra.core.database.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/** Encrypts credential columns before Room sees them; plaintext endpoint/name never hits new rows. */
class SecureStorage(private val db: CyrusDatabase, private val cipher: SecretCipher) {
    private val mutex = Mutex()
    private var ready = false
    suspend fun prepare() = withContext(Dispatchers.IO) {
        mutex.withLock {
            if (!ready) {
                db.withTransaction {
                    db.profileDao().observeAll().first().forEach { row ->
                        if (listOfNotNull(row.name, row.server, row.uuid, row.password, row.tlsJson, row.transportJson).any { !cipher.isEncrypted(it) || cipher.isLegacy(it) })
                            db.profileDao().upsert(seal(open(row)))
                    }
                    db.subscriptionDao().observeAll().first().forEach { row ->
                        if (!cipher.isEncrypted(row.url) || !cipher.isEncrypted(row.name) || cipher.isLegacy(row.url) || cipher.isLegacy(row.name))
                            db.subscriptionDao().upsert(seal(open(row).copy(lastError = row.lastError?.let { "Предыдущее обновление завершилось ошибкой" })))
                    }
                }
                ready = true
            }
        }
    }
    fun seal(e: ProfileEntity): ProfileEntity = transform(e, cipher::encrypt)
    fun open(e: ProfileEntity): ProfileEntity = transform(e, cipher::decrypt)
    private fun transform(e: ProfileEntity, f: (String, String) -> String): ProfileEntity {
        fun field(value: String, name: String) = f(value, "profile:${e.id}:$name")
        return e.copy(name = field(e.name, "name"), server = field(e.server, "server"),
            uuid = e.uuid?.let { field(it, "uuid") }, password = e.password?.let { field(it, "password") },
            tlsJson = field(e.tlsJson, "tls"), transportJson = field(e.transportJson, "transport"))
    }
    fun seal(e: SubscriptionEntity): SubscriptionEntity = e.copy(
        url = cipher.encrypt(e.url, "source:${e.id}:url"), name = cipher.encrypt(e.name, "source:${e.id}:name"))
    fun open(e: SubscriptionEntity): SubscriptionEntity = e.copy(
        url = cipher.decrypt(e.url, "source:${e.id}:url"), name = cipher.decrypt(e.name, "source:${e.id}:name"))
}
