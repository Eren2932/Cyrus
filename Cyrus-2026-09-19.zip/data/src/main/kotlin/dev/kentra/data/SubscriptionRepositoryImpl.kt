package dev.kentra.data

import android.util.Log
import androidx.room.withTransaction
import dev.kentra.core.common.AppError
import dev.kentra.core.common.appRunCatching
import dev.kentra.core.database.*
import dev.kentra.core.datastore.SettingsStore
import dev.kentra.domain.model.*
import dev.kentra.domain.repository.*
import io.ktor.client.HttpClient
import io.ktor.client.request.prepareGet
import io.ktor.client.statement.bodyAsChannel
import io.ktor.utils.io.readAvailable
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.net.Inet4Address
import java.net.InetAddress
import java.net.URI
import java.net.UnknownHostException
import java.util.UUID

class SubscriptionRepositoryImpl(
    private val db: CyrusDatabase,
    private val client: HttpClient,
    private val parser: LinkParser,
    private val secure: SecureStorage,
    private val settings: SettingsStore,
    private val clock: () -> Long = { System.currentTimeMillis() },
) : SubscriptionRepository {
    private val dao get() = db.subscriptionDao()
    private val profileDao get() = db.profileDao()
    private val mutex = Mutex()

    override fun observeSources(): Flow<List<SubscriptionSource>> = dao.observeAll()
        .onStart { secure.prepare() }.map { list -> list.map { domain(secure.open(it)) }.sortedBy { it.name.lowercase() } }.flowOn(Dispatchers.IO)

    override suspend fun add(name: String, url: String): Result<SubscriptionSource> = appRunCatching {
        secure.prepare()
        val uri = validate(url)
        val source = mutex.withLock {
            val existing = dao.observeAll().first().map { secure.open(it) }.firstOrNull { it.url == url }
            existing ?: SubscriptionEntity(UUID.randomUUID().toString(), name.ifBlank { uri.host }, url, null, 0, null)
        }
        // Network I/O runs outside the state mutex: holding it across a slow fetch would block
        // every other source's refresh/remove for the whole request.
        val parsed = fetch(url)
        mutex.withLock {
            save(source, parsed)
            domain(source.copy(lastSyncEpochMs = clock(), profileCount = parsed.size, lastError = null))
        }
    }

    override suspend fun refresh(sourceId: String): Result<Int> = appRunCatching {
        secure.prepare()
        val source = mutex.withLock {
            dao.byId(sourceId)?.let { secure.open(it) } ?: throw AppError.NotFound("Подписка")
        }
        try {
            // Network I/O outside the mutex; only the atomic profile replacement is locked.
            val parsed = fetch(source.url)
            mutex.withLock { save(source, parsed) }
            parsed.size
        } catch (e: Exception) {
            if (e is kotlinx.coroutines.CancellationException) throw e
            mutex.withLock {
                dao.upsert(secure.seal(source.copy(lastError = "Обновление не выполнено. Предыдущие ключи сохранены.")))
            }
            throw AppError.Network("Не удалось обновить подписку. Проверьте сеть и формат ответа.")
        }
    }

    override suspend fun refreshAll(): Result<Int> = appRunCatching {
        secure.prepare()
        var total = 0
        var failed = 0
        dao.observeAll().first().forEach { source ->
            refresh(source.id).onSuccess { total += it }.onFailure { failed++ }
        }
        if (failed > 0) throw AppError.Network("Обновлено ключей: $total. Ошибок источников: $failed; старые ключи сохранены.")
        total
    }

    override suspend fun remove(sourceId: String) {
        mutex.withLock {
            secure.prepare()
            val oldIds = profileDao.bySource(sourceId).map { it.id }.toSet()
            db.withTransaction { profileDao.deleteBySource(sourceId); dao.deleteById(sourceId) }
            if (settings.activeProfileId.first() in oldIds) settings.setActiveProfileId(profileDao.observeAll().first().firstOrNull()?.id)
        }
    }

    private suspend fun save(source: SubscriptionEntity, profiles: List<VpnProfile>) {
        val entities = withContext(Dispatchers.IO) {
            profiles.map { profile ->
                val id = UUID.nameUUIDFromBytes((source.id + ":" + profile.connectionIdentity()).toByteArray(Charsets.UTF_8)).toString()
                secure.seal(ProfileMapper.toEntity(profile.copy(id = id, origin = ProfileOrigin.Subscription(source.id))))
            }
        }
        val oldIds = profileDao.bySource(source.id).map { it.id }.toSet()
        db.withTransaction {
            profileDao.deleteBySource(source.id)
            profileDao.upsertAll(entities)
            dao.upsert(secure.seal(source.copy(lastSyncEpochMs = clock(), profileCount = entities.size, lastError = null)))
        }
        val active = settings.activeProfileId.first()
        if (active == null || (active in oldIds && entities.none { it.id == active })) settings.setActiveProfileId(entities.first().id)
    }

    private suspend fun fetch(url: String): List<VpnProfile> = withContext(Dispatchers.IO) {
        val uri = validate(url)
        assertPublicTarget(uri.host.orEmpty())
        // Diagnosis helper: AppError.Unknown flattens every non-AppError throwable to the
        // string "unknown", so a failed import used to be unexplainable from the outside.
        // Log the cause's type and message here, with URLs stripped: the subscription URL
        // is a credential and must never reach logcat.
        val started = System.currentTimeMillis()
        val payload = try { fetchBody(url) } catch (t: Throwable) {
            if (t is kotlinx.coroutines.CancellationException) throw t
            val addrs = runCatching { InetAddress.getAllByName(uri.host).map { it.hostAddress } }.getOrDefault(listOf("?"))
            Log.w(TAG, "subscription download failed after ${System.currentTimeMillis() - started}ms: " +
                "${t.javaClass.name}: ${redact(t.message)}; host=${uri.host} addrs=$addrs")
            // Do not let a Ktor/OkHttp exception escape as AppError.Unknown: the UI
            // used to show only "unknown: ConnectTimeoutException". Keep the cause
            // for logcat/diagnostics, but expose a safe actionable category to users.
            throw if (t is AppError) t else AppError.Network(
                "Не удалось загрузить подписку. Проверьте интернет и доступность сервера.", t,
            )
        }
        try {
            parse(payload)
        } catch (t: Throwable) {
            if (t is kotlinx.coroutines.CancellationException) throw t
            val report = runCatching { parser.inspect(payload) }.getOrNull()
            Log.w(TAG, "subscription parse failed: ${t.javaClass.name}: ${redact(t.message)}; " +
                "profiles=${report?.profiles?.size} issues=${report?.issues?.size} payload=${payload.length}B")
            throw t
        }
    }

    private suspend fun fetchBody(url: String): String = client.prepareGet(url).execute { response ->
        require(response.status.value in 200..299) { "HTTP status" }
        val channel = response.bodyAsChannel()
        val output = ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        while (true) {
            val read = channel.readAvailable(buffer, 0, buffer.size)
            if (read == -1) break
            require(output.size() + read <= 52_428_800) { "Response too large" }
            output.write(buffer, 0, read)
        }
        output.toString("UTF-8")
    }

    private fun parse(payload: String): List<VpnProfile> {
        val report = parser.inspect(payload)
        if (report.profiles.isEmpty() || report.issues.isNotEmpty()) throw AppError.Parse("Ответ содержит неподдерживаемые или повреждённые строки")
        return report.profiles
    }

    private fun validate(url: String): URI {
        val uri = runCatching { URI(url) }.getOrElse { throw AppError.Parse("Некорректная ссылка подписки") }
        if (!uri.scheme.equals("https", ignoreCase = true) || uri.host.isNullOrBlank() || uri.rawUserInfo != null || uri.fragment != null)
            throw AppError.Parse("Нужна HTTPS-ссылка без логина и фрагмента. HTTP не защищает ключи при передаче.")
        return uri
    }

    private fun domain(e: SubscriptionEntity) = SubscriptionSource(e.id, e.name, e.url, e.lastSyncEpochMs, e.profileCount, e.lastError)

    private companion object {
        const val TAG = "CyrusSub"
        private val URLISH = Regex("https?://\\S+")
        /** Subscription URLs are credentials: strip them before anything reaches logcat. */
        fun redact(s: String?): String? = s?.replace(URLISH, "<url>")
    }
}
