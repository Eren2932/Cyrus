package dev.kentra.data

import dev.kentra.domain.model.ProbeOutcome
import dev.kentra.domain.model.TransportCompat
import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.model.WireKind
import dev.kentra.domain.repository.LatencyProber
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NoRouteToHostException
import java.net.PortUnreachableException
import java.net.UnknownHostException

/**
 * Measures a QUIC endpoint by asking it to negotiate its version - see [QuicProbe] for the
 * exchange itself and the evidence that real servers answer it.
 *
 * What this does and does not measure, because the difference decides how the result may be
 * used:
 *
 * - It measures one round trip to the endpoint, **including name resolution** for a
 *   hostname-addressed key. That is the cost the real connection also pays, so it belongs in
 *   the number, and it is the same quantity [TcpLatencyProber] reports for a TCP key. The
 *   two are therefore comparable, which is the entire point: without this, a hysteria2 key
 *   could never outrank a measured TCP key no matter how much closer it was.
 * - It says nothing about throughput, nothing about TLS, and nothing about whether the proxy
 *   will accept the credentials. Authorisation happens after the QUIC handshake, in a layer
 *   this probe never reaches - exactly as a TCP connect never reaches a proxy's auth. The
 *   caller does not stop here either way.
 *
 * The one thing this probe will not do is call an endpoint dead on silence. A UDP packet can
 * be dropped, rate-limited, or - on a key whose wire is obfuscated before the QUIC layer sees
 * it - deobfuscated to noise, and all three look identical from here. Only the peer's own IP
 * stack saying "nothing is listening on that port" is treated as a negative; everything else
 * is reported as [ProbeOutcome.NotMeasurable], which leaves the key a candidate instead of
 * removing a working one from the search on the strength of a probe that could not reach it.
 *
 * Unlike [TcpLatencyProber] there is no `Proxy.NO_PROXY` equivalent to insist on, and this is
 * not an omission. A JVM's `socksProxyHost` hijacks plain [java.net.Socket]s; [DatagramSocket]
 * is never routed through it, so a UDP measurement cannot be silently redirected to an
 * intermediary in the first place.
 */
class UdpLatencyProber : LatencyProber {

    override suspend fun measure(profile: VpnProfile, timeoutMillis: Long): ProbeOutcome =
        withContext(Dispatchers.IO) {
            // Anything whose wire is not QUIC is refused rather than probed: a version
            // negotiation sent to a WireGuard or mKCP endpoint would be ignored, and
            // reporting that silence as a measurement would be reporting the absence of an
            // answer as if it were one.
            if (TransportCompat.wireKind(profile) != WireKind.QUIC) {
                return@withContext ProbeOutcome.NotMeasurable
            }

            // Brackets are URI syntax; InetSocketAddress wants the bare literal.
            val host = profile.server.removeSurrounding("[", "]")
            val peer = runCatching { InetSocketAddress(InetAddress.getByName(host), profile.port) }
                .getOrElse { return@withContext negative(it) }

            runCatching {
                DatagramSocket().use { socket ->
                    socket.soTimeout = timeoutMillis.toInt()
                    // Connected, so the kernel discards datagrams from anyone else and a
                    // reply cannot be a stray packet from a third party.
                    socket.connect(peer)

                    val started = System.nanoTime()
                    val request = QuicProbe.request()
                    socket.send(DatagramPacket(request, request.size))

                    val reply = DatagramPacket(ByteArray(REPLY_BYTES), REPLY_BYTES)
                    socket.receive(reply)
                    val elapsed = (System.nanoTime() - started) / 1_000_000

                    if (QuicProbe.isVersionNegotiation(reply.data, reply.length)) {
                        ProbeOutcome.Reachable(elapsed)
                    } else {
                        // Something answered, but not as a QUIC server answering this. That
                        // is not evidence of a usable endpoint, and it is not evidence
                        // against one either.
                        ProbeOutcome.NotMeasurable
                    }
                }
            }.getOrElse { negative(it) }
        }

    /**
     * What a failure means. Only the first group is evidence about the server.
     */
    private fun negative(failure: Throwable): ProbeOutcome = when (failure) {
        // The peer's own IP stack answered "nothing is listening on that port". That is the
        // server speaking, and it is the one negative this probe can honestly report.
        is PortUnreachableException,
        is NoRouteToHostException,
        is UnknownHostException,
        -> ProbeOutcome.Unreachable(failure.message ?: failure::class.java.simpleName)

        // Silence, which is what a timeout and every unclassified socket error look like from
        // here. See the class comment: this is reported as unmeasured, never as dead.
        else -> ProbeOutcome.NotMeasurable
    }

    private companion object {
        /**
         * A Version Negotiation packet is tiny - 27 and 35 bytes in the two measured above.
         * This is a datagram buffer, not a stream buffer: anything larger than one MTU would
         * be truncated, and truncation would be indistinguishable from a malformed reply.
         */
        const val REPLY_BYTES = 1500
    }
}
