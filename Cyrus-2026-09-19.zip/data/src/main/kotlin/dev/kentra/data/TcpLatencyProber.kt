package dev.kentra.data

import dev.kentra.domain.model.ProbeOutcome
import dev.kentra.domain.model.TransportCompat
import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.model.WireKind
import dev.kentra.domain.repository.LatencyProber
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.Socket

/**
 * Measures a key's endpoint with a bare TCP connect.
 *
 * What this does and does not measure, because the difference decides how the result may
 * be used:
 *
 * - It measures the time to complete a TCP handshake, **including name resolution** for a
 *   hostname-addressed key. That is the cost the real connection also pays, so it belongs
 *   in the number; it does mean a key on a slow resolver looks further away than it is.
 * - It says nothing about throughput, nothing about TLS, and nothing about whether the
 *   proxy will accept the credentials. A server can answer this probe and still carry no
 *   traffic - which is why the caller does not stop here.
 *
 * UDP-only keys are reported as [ProbeOutcome.NotMeasurable] rather than probed: hysteria2
 * and tuic speak QUIC, `kcp`/`quic` are UDP by definition, and WireGuard is UDP too, so there
 * is no TCP listener that belongs to the proxy. Connecting to that port anyway would, on a
 * host running something else there, produce a confident number about a service the user is
 * not buying - which is worse than having no number.
 *
 * Which keys those are is decided by [TransportCompat.wireKind], not here: the same
 * classification routes a QUIC key to [UdpLatencyProber], which does have something to
 * measure, and keeping one answer to "what kind of wire is this" is what stops the two
 * probers from disagreeing about it.
 *
 * The socket is created with [Proxy.NO_PROXY] on purpose, and this is load-bearing rather
 * than defensive. A JVM that has `socksProxyHost` set - which macOS fills in automatically
 * from the system network settings, so any developer machine running a proxy client has it
 * - routes *every* plain `Socket` through that proxy. SOCKS5 resolves the target name
 * remotely, so the connect then succeeds for hosts that do not exist at all: measured on
 * such a machine, `does-not-exist.invalid:443` "connected" in 17 ms, to a reported remote
 * address of `0.0.0.0:443`. A measurement taken through an intermediary describes the
 * intermediary, not the server being ranked, so the prober refuses to take one.
 */
class TcpLatencyProber : LatencyProber {

    override suspend fun measure(profile: VpnProfile, timeoutMillis: Long): ProbeOutcome =
        withContext(Dispatchers.IO) {
            if (TransportCompat.wireKind(profile) != WireKind.TCP) {
                return@withContext ProbeOutcome.NotMeasurable
            }

            // Brackets are URI syntax; InetSocketAddress wants the bare literal.
            val host = profile.server.removeSurrounding("[", "]")
            val started = System.nanoTime()
            runCatching {
                Socket(Proxy.NO_PROXY).use { socket ->
                    socket.tcpNoDelay = true
                    socket.connect(InetSocketAddress(host, profile.port), timeoutMillis.toInt())
                }
            }.fold(
                onSuccess = { ProbeOutcome.Reachable((System.nanoTime() - started) / 1_000_000) },
                onFailure = { ProbeOutcome.Unreachable(it.message ?: it::class.java.simpleName) },
            )
        }
}
