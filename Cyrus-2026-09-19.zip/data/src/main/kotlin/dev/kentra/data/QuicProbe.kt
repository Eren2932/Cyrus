package dev.kentra.data

import kotlin.random.Random

/**
 * The datagram that makes a QUIC listener answer, and the test that its answer is real.
 *
 * QUIC has no handshake a prober can time the way TCP's SYN/SYN-ACK can be timed, which is
 * why hysteria2 and tuic keys used to be unmeasurable. They need not be. RFC 9000 §6 gives
 * every QUIC server a second, much cheaper obligation: a packet carrying a version the
 * server does not support MUST be answered with a Version Negotiation packet. That exchange
 * is one round trip to the same endpoint on the same port - the same quantity a TCP connect
 * measures, obtained the same way.
 *
 * The version used here is not a guess about what the server speaks. RFC 9000 §15 reserves
 * every version matching `0x?a?a?a?a` for precisely this purpose, so a conforming server
 * cannot mistake it for a real connection attempt.
 *
 * Measured from a developer machine on 2026-09-21, against three independent implementations,
 * because the one that matters is the one the app's own keys run on:
 *
 * | Server | Implementation | Answer |
 * |---|---|---|
 * | `interop.seemann.io:443` | quic-go - what hysteria2 and tuic use | Version Negotiation, 172 ms |
 * | `quic.tech:4433` | quic-go | Version Negotiation, 229 ms |
 * | Cloudflare | quiche | Version Negotiation, 136 ms |
 * | Google | their QUIC stack | Version Negotiation, 142 ms |
 *
 * The datagram sent in those measurements was exactly [request]'s: 1200 bytes, reserved
 * version, random connection IDs. quic-go is the load-bearing row - it is the implementation
 * behind both protocols this probe exists for - and it answers, which is why the padding to
 * [DATAGRAM_BYTES] is not decoration: quic-go drops a packet with an unknown version that is
 * below its own size floor rather than negotiating with it.
 *
 * What this does NOT prove is that the proxy will accept the key: authorisation happens
 * after the QUIC handshake, in a layer this probe never reaches. That is exactly the
 * strength of the TCP probe - reachability, not permission - so the two numbers mean the
 * same thing and may be compared.
 */
internal object QuicProbe {

    /**
     * A version no server supports. See the class comment: this is a request for the server
     * to state its versions, not a claim about them.
     */
    const val RESERVED_VERSION: Int = 0x1A2A3A4A

    /** Long header (0x80) plus the fixed bit (0x40) that every versioned packet carries. */
    private const val LONG_HEADER: Int = 0xC0

    private const val HEADER_BYTES = 5

    private const val CONNECTION_ID_BYTES = 8

    /** RFC 9000 §17.2: a connection ID is at most 20 bytes. */
    private const val MAX_CONNECTION_ID_BYTES = 20

    /**
     * RFC 9000 §14.1: the smallest datagram a server will consider. Anything shorter may be
     * dropped before its version is even read, and §6.1 forbids negotiating with it.
     */
    const val DATAGRAM_BYTES: Int = 1200

    /**
     * A long-header datagram carrying [RESERVED_VERSION] and two random connection IDs,
     * padded to [DATAGRAM_BYTES].
     *
     * Everything after the connection IDs is zero and is never parsed: the server stops
     * reading at the version it does not support. It is there only to clear the size floor
     * above. The IDs are random rather than fixed so that two probes to the same endpoint -
     * or two endpoints behind one address - cannot be correlated by anything watching.
     */
    fun request(random: Random = Random.Default): ByteArray {
        val packet = ByteArray(DATAGRAM_BYTES)
        packet[0] = LONG_HEADER.toByte()
        packet[1] = (RESERVED_VERSION ushr 24).toByte()
        packet[2] = (RESERVED_VERSION ushr 16).toByte()
        packet[3] = (RESERVED_VERSION ushr 8).toByte()
        packet[4] = RESERVED_VERSION.toByte()
        packet.writeConnectionId(HEADER_BYTES, random)
            .let { packet.writeConnectionId(it, random) }
        return packet
    }

    /**
     * Whether the first [length] bytes of [datagram] are a well-formed Version Negotiation
     * packet.
     *
     * Structural rather than "some datagram arrived", and that distinction is the whole
     * value of the probe: a QUIC server answers an unsupported version with exactly this
     * packet and with nothing else, so requiring its shape is what separates measuring a
     * QUIC listener from counting whatever else happened to reply.
     *
     * The connection IDs are deliberately not compared against the ones that were sent. The
     * socket is connected to the peer, so a datagram from anywhere else cannot arrive at
     * all, and an extra check that only some implementations would pass - RFC 9000 §17.2.1
     * requires the server to swap the two IDs, and both servers measured above do - could
     * only ever turn a working endpoint into an unmeasured one.
     */
    fun isVersionNegotiation(datagram: ByteArray, length: Int): Boolean {
        if (length < HEADER_BYTES) return false
        // Header form set: a long-header packet. The remaining seven bits are unused in a
        // Version Negotiation packet and servers set them arbitrarily - 0xbd and 0xc0 were
        // both observed - so they must not be inspected.
        if ((datagram[0].toInt() and 0x80) == 0) return false
        // Version zero is what marks the packet as negotiation rather than traffic.
        for (index in 1..4) if (datagram[index].toInt() != 0) return false

        var at = HEADER_BYTES
        at = datagram.afterConnectionId(at, length) ?: return false
        at = datagram.afterConnectionId(at, length) ?: return false

        // At least one version must be advertised, in whole four-byte words. A packet that
        // advertises nothing is not a version list, and reporting it as an answer would be
        // reporting a malformed reply as a measurement.
        val advertised = length - at
        return advertised >= 4 && advertised % 4 == 0
    }

    private fun ByteArray.writeConnectionId(at: Int, random: Random): Int {
        this[at] = CONNECTION_ID_BYTES.toByte()
        val id = ByteArray(CONNECTION_ID_BYTES)
        random.nextBytes(id)
        id.copyInto(this, at + 1)
        return at + 1 + CONNECTION_ID_BYTES
    }

    /**
     * Position just past a length-prefixed connection ID, or null if the datagram does not
     * hold one. Bounded by [limit] rather than by the buffer: a caller may hand over a buffer
     * longer than the datagram in it, and a packet must never be read past its own end.
     */
    private fun ByteArray.afterConnectionId(at: Int, limit: Int): Int? {
        if (at >= limit) return null
        val length = this[at].toInt() and 0xFF
        if (length > MAX_CONNECTION_ID_BYTES) return null
        return at + 1 + length
    }
}
