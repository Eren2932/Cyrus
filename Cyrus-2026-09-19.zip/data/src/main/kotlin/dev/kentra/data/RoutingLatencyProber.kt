package dev.kentra.data

import dev.kentra.domain.model.ProbeOutcome
import dev.kentra.domain.model.TransportCompat
import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.model.WireKind
import dev.kentra.domain.repository.LatencyProber

/**
 * Sends each key to the prober that can actually measure its wire.
 *
 * The choice belongs in one readable place rather than inside each prober, because it is a
 * statement about the key - what kind of wire it is - and not about how a socket is opened.
 * It also keeps the two probers honest: neither has to know about the other's transports, so
 * neither can quietly start measuring something it cannot measure.
 *
 * [WireKind.OPAQUE_UDP] is answered here rather than delegated. There is no prober for those
 * endpoints, and inventing one that returns a number without evidence would put a fabricated
 * value into a ranking that the user acts on. [ProbeOutcome.NotMeasurable] keeps such a key a
 * candidate while telling the search that nothing is known about it - see
 * [dev.kentra.domain.usecase.SelectBestServerUseCase].
 */
class RoutingLatencyProber(
    private val tcp: LatencyProber = TcpLatencyProber(),
    private val quic: LatencyProber = UdpLatencyProber(),
) : LatencyProber {

    override suspend fun measure(profile: VpnProfile, timeoutMillis: Long): ProbeOutcome =
        when (TransportCompat.wireKind(profile)) {
            WireKind.TCP -> tcp.measure(profile, timeoutMillis)
            WireKind.QUIC -> quic.measure(profile, timeoutMillis)
            WireKind.OPAQUE_UDP -> ProbeOutcome.NotMeasurable
        }
}
