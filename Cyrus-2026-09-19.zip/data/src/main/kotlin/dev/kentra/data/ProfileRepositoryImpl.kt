package dev.kentra.data

import dev.kentra.core.database.ProfileDao
import dev.kentra.core.datastore.SettingsStore
import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.repository.ProfileRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ProfileRepositoryImpl(
    private val dao: ProfileDao,
    private val settings: SettingsStore,
    private val secure: SecureStorage,
) : ProfileRepository {

    override fun observeProfiles(): Flow<List<VpnProfile>> =
        dao.observeAll().onStart { secure.prepare() }.map { list -> list.map { ProfileMapper.toDomain(secure.open(it)) } }.flowOn(Dispatchers.IO)

    override fun observeActiveProfileId(): Flow<String?> = settings.activeProfileId

    override suspend fun getProfile(id: String): VpnProfile? = withContext(Dispatchers.IO) {
        secure.prepare()
        dao.byId(id)?.let { ProfileMapper.toDomain(secure.open(it)) }
    }

    override suspend fun upsert(profile: VpnProfile): Unit = withContext(Dispatchers.IO) {
        secure.prepare()
        dao.upsert(secure.seal(ProfileMapper.toEntity(profile)))
    }

    override suspend fun upsertAll(profiles: List<VpnProfile>): Unit = withContext(Dispatchers.IO) {
        secure.prepare()
        dao.upsertAll(profiles.map { secure.seal(ProfileMapper.toEntity(it)) })
    }

    override suspend fun delete(id: String) {
        dao.deleteById(id)
        // Deleting the active profile must never leave a dangling selection.
        if (settings.activeProfileId.first() == id) settings.setActiveProfileId(dao.observeAll().first().firstOrNull()?.id)
    }

    override suspend fun setActiveProfileId(id: String?) {
        settings.setActiveProfileId(id)
    }

    override suspend fun getAllIdentities(): List<String> = withContext(Dispatchers.IO) {
        // Safe to expose: since C-1 these values are one-way SHA-256 fingerprints ("v3:" + hex),
        // not raw share links, so the column no longer carries UUID/password (see ImportReport).
        dao.getAllIdentities()
    }
}
