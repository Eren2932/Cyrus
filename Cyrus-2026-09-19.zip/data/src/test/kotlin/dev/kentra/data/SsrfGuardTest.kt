package dev.kentra.data

import dev.kentra.core.common.AppError
import java.net.InetAddress
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

/**
 * H-6 regression: the subscription fetch used to check the scheme only, so a URL
 * pointing at loopback or a cloud metadata endpoint was fetched as-is.
 *
 * Only literals are used - a name would make these tests depend on DNS, which is
 * precisely what the guard is meant to interrogate rather than trust.
 */
class SsrfGuardTest {

    private val blocked = listOf(
        "127.0.0.1", "127.1.2.3",                 // loopback
        "0.0.0.0",                                 // "this network"
        "10.0.0.1", "10.255.255.254",              // RFC1918
        "172.16.0.1", "172.31.255.254",            // RFC1918
        "192.168.1.1",                             // RFC1918
        "169.254.169.254",                         // cloud metadata - the one that matters
        "169.254.1.1",                             // link-local
        "100.64.0.1", "100.127.255.255",           // CGNAT (RFC 6598)
        "192.0.0.1", "192.0.2.1",                  // IETF assignments, TEST-NET-1
        "198.18.0.1", "198.19.255.255",            // benchmarking
        "198.51.100.1", "203.0.113.1",             // TEST-NET-2, TEST-NET-3
        "224.0.0.1", "239.255.255.255",            // multicast
        "240.0.0.1", "255.255.255.255",            // reserved
        "::1",                                     // IPv6 loopback
        "fe80::1",                                 // IPv6 link-local
        "fc00::1", "fd00::1",                      // IPv6 unique local
        "2001:db8::1",                             // IPv6 documentation
    )

    private val allowed = listOf(
        "1.1.1.1", "8.8.8.8", "93.184.216.34",
        "172.15.0.1", "172.32.0.1",                // just outside the RFC1918 172.16/12 block
        "100.63.255.255", "100.128.0.1",           // just outside CGNAT
        "2606:4700:4700::1111",                    // public IPv6
    )

    @Test
    fun `internal and reserved addresses are blocked`() {
        for (literal in blocked) {
            assertTrue("$literal must be blocked", isBlockedAddress(InetAddress.getByName(literal)))
        }
    }

    @Test
    fun `public addresses are not blocked`() {
        for (literal in allowed) {
            assertFalse("$literal must be allowed", isBlockedAddress(InetAddress.getByName(literal)))
        }
    }

    @Test
    fun `the guard rejects a host resolving to an internal address`() {
        for (literal in listOf("127.0.0.1", "169.254.169.254", "10.0.0.1", "::1")) {
            val error = assertRejects(literal) { assertPublicTarget(literal) }
            assertTrue(
                "expected a parse error for $literal but got ${error::class.java.simpleName}",
                error is AppError.Parse,
            )
        }
    }

    @Test
    fun `the guard accepts a public host`() {
        // Would throw on failure.
        assertPublicTarget("1.1.1.1")
    }

    @Test
    fun `the guard brackets-strips an ipv6 literal`() {
        // "[::1]" is the URL form; without stripping, InetAddress would not parse it
        // and the guard would report a resolution failure instead of a block.
        val error = assertRejects("[::1]") { assertPublicTarget("[::1]") }
        assertTrue(
            "expected a block, not a resolution failure: ${error::class.java.simpleName}",
            error is AppError.Parse,
        )
    }

    @Test
    fun `a blank host is rejected before any resolution is attempted`() {
        assertRejects("blank") { assertPublicTarget("   ") }
    }

    @Test
    fun `an unresolvable host is reported as a network failure, not as a block`() {
        // Distinguishing matters: "blocked" tells the user the URL is hostile,
        // "cannot resolve" tells them to check their connection.
        val error = assertRejects("nonexistent") {
            assertPublicTarget("nonexistent.invalid")
        }
        assertTrue(
            "expected AppError.Network but got ${error::class.java.simpleName}: ${error.message}",
            error is AppError.Network,
        )
    }

    private fun assertRejects(what: String, block: () -> Unit): Throwable {
        return try {
            block()
            fail("expected a rejection for $what")
            error("unreachable")
        } catch (e: AppError) {
            e
        }
    }
}
