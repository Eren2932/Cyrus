package dev.kentra.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

/**
 * The probe's value is entirely in the shape of the two packets - the one it sends and the
 * one it accepts - so the tests are about bytes, not about behaviour at a distance.
 */
class QuicProbeTest {

    @Test
    fun `the request is a long header carrying the reserved version`() {
        val packet = QuicProbe.request(Random(1))

        assertEquals(QuicProbe.DATAGRAM_BYTES, packet.size)
        // Header form (0x80) and the fixed bit (0x40) that every versioned packet carries.
        assertEquals(0xC0, packet[0].toInt() and 0xFF)
        assertEquals(QuicProbe.RESERVED_VERSION, readInt(packet, 1))
        // Two connection IDs, each length-prefixed, laid out end to end.
        assertEquals(8, packet[5].toInt())
        assertEquals(8, packet[14].toInt())
    }

    @Test
    fun `the version is one RFC 9000 reserves for forcing negotiation`() {
        // 0x?a?a?a?a: the pattern exists so a server cannot mistake the packet for a real
        // connection attempt, which is what makes this safe to send to any endpoint. The
        // reserved nibbles are every second one from the least significant end.
        for (shift in intArrayOf(0, 8, 16, 24)) {
            assertEquals(0xa, (QuicProbe.RESERVED_VERSION ushr shift) and 0xf)
        }
    }

    @Test
    fun `two probes share no connection id`() {
        // Nothing watching the path should be able to tell that both probes came from here.
        val first = QuicProbe.request(Random(1))
        val second = QuicProbe.request(Random(2))
        assertFalse(
            "идентификаторы соединения совпали",
            first.copyOfRange(6, 14).contentEquals(second.copyOfRange(6, 14)),
        )
    }

    @Test
    fun `a version negotiation packet is recognised`() {
        val packet = versionNegotiationPacket(versions = intArrayOf(1))
        assertTrue(QuicProbe.isVersionNegotiation(packet, packet.size))
    }

    @Test
    fun `the two first bytes real servers send are both accepted`() {
        // Captured from Cloudflare (0xbd) and Google (0xc0) on 2026-09-21. The seven bits
        // beside the header-form bit are unused in this packet and servers set them
        // arbitrarily, so a check that read them would reject a real answer.
        for (firstByte in intArrayOf(0xBD, 0xC0)) {
            val packet = versionNegotiationPacket(firstByte = firstByte, versions = intArrayOf(1))
            assertTrue(
                "отвергнут настоящий ответ 0x${firstByte.toString(16)}",
                QuicProbe.isVersionNegotiation(packet, packet.size),
            )
        }
    }

    @Test
    fun `several advertised versions are still a version negotiation packet`() {
        // Google advertises three: 0x1, 0x6afaea6a and 0xff00001d.
        val packet = versionNegotiationPacket(versions = intArrayOf(1, 0x6AFAEA6A, 0xFF00001D.toInt()))
        assertTrue(QuicProbe.isVersionNegotiation(packet, packet.size))
    }

    @Test
    fun `a short-header packet is not an answer`() {
        // Header form clear: this is traffic, not negotiation.
        val packet = versionNegotiationPacket(firstByte = 0x40)
        assertFalse(QuicProbe.isVersionNegotiation(packet, packet.size))
    }

    @Test
    fun `a packet carrying a real version is not an answer`() {
        // Version 1 is what a server speaks; a reply labelled with it is not negotiation.
        val packet = versionNegotiationPacket(versions = intArrayOf(1))
        writeInt(packet, 1, 1)
        assertFalse(QuicProbe.isVersionNegotiation(packet, packet.size))
    }

    @Test
    fun `an over-long connection id is not an answer`() {
        // RFC 9000 s17.2 caps a connection ID at 20 bytes, so this is not a QUIC packet at
        // all and the version list cannot be found where it claims to be.
        val packet = versionNegotiationPacket(versions = intArrayOf(1))
        packet[5] = 21
        assertFalse(QuicProbe.isVersionNegotiation(packet, packet.size))
    }

    @Test
    fun `an empty version list is not an answer`() {
        val packet = versionNegotiationPacket(versions = intArrayOf())
        assertFalse(QuicProbe.isVersionNegotiation(packet, packet.size))
    }

    @Test
    fun `a truncated version list is not an answer`() {
        // Three bytes where four are needed: a malformed reply must not be reported as a
        // measurement, and the version list is walked in whole words for exactly that reason.
        val packet = versionNegotiationPacket(versions = intArrayOf(1)) + byteArrayOf(0, 0, 0)
        assertFalse(QuicProbe.isVersionNegotiation(packet, packet.size))
    }

    @Test
    fun `a datagram that stops before its connection ids is not an answer`() {
        // The buffer is longer than the datagram here, which is the real situation: a receive
        // buffer is reused and only its first `length` bytes belong to this packet.
        val packet = versionNegotiationPacket(versions = intArrayOf(1))
        assertFalse(QuicProbe.isVersionNegotiation(packet, 6))
        assertFalse(QuicProbe.isVersionNegotiation(packet, 0))
    }

    @Test
    fun `an echo of the request is not an answer`() {
        // The failure this guards against: a socket that answers anything at all would
        // otherwise be indistinguishable from a QUIC server.
        val request = QuicProbe.request(Random(1))
        assertFalse(QuicProbe.isVersionNegotiation(request, request.size))
    }
}
