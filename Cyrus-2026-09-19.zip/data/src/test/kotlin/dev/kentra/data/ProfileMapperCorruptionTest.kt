package dev.kentra.data

import dev.kentra.core.database.ProfileEntity
import dev.kentra.domain.model.TlsSettings
import dev.kentra.domain.model.TransportSettings
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * H-10 regression: one corrupt `tlsJson`/`transportJson` row must not throw out of
 * `observeProfiles()`; it degrades to storage defaults instead.
 */
class ProfileMapperCorruptionTest {

    private fun entity(tlsJson: String, transportJson: String) = ProfileEntity(
        id = "id",
        name = "n",
        protocol = "VLESS",
        server = "example.com",
        port = 443,
        uuid = "u",
        password = "p",
        method = null,
        flow = null,
        alterId = null,
        tlsJson = tlsJson,
        transportJson = transportJson,
        originType = "manual",
        originSourceId = null,
        connectionIdentity = "v3:0",
        createdAt = 1L,
    )

    @Test
    fun `malformed json falls back to defaults instead of throwing`() {
        val profile = ProfileMapper.toDomain(entity(tlsJson = "{not json", transportJson = "not json at all"))

        assertEquals(TlsSettings(), profile.tls)
        assertEquals(TransportSettings(), profile.transport)
        assertNull(profile.rawLink)
        assertTrue(profile.parameters.isEmpty())
    }

    @Test
    fun `empty json falls back to defaults instead of throwing`() {
        val profile = ProfileMapper.toDomain(entity(tlsJson = "", transportJson = ""))

        assertEquals(TlsSettings(), profile.tls)
        assertEquals(TransportSettings(), profile.transport)
    }

    @Test
    fun `unknown keys and known fields still decode`() {
        val profile = ProfileMapper.toDomain(
            entity(
                tlsJson = """{"enabled":true,"futureField":1}""",
                transportJson = """{"type":"ws","path":"/p"}""",
            ),
        )

        assertTrue(profile.tls.enabled)
        assertEquals("ws", profile.transport.type)
        assertEquals("/p", profile.transport.path)
    }
}
