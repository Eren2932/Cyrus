package dev.kentra.data

import dev.kentra.domain.model.ProbeOutcome
import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.model.VpnProtocol
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.Closeable
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.atomic.AtomicInteger
import kotlin.concurrent.thread

/**
 * Tested against a real socket rather than a mocked one: the question is what an actual
 * datagram exchange does, and a mock would only re-assert the assumption.
 */
class UdpLatencyProberTest {

    private val prober = UdpLatencyProber()

    private fun quicKey(server: String = "127.0.0.1", port: Int) =
        VpnProfile("id", "name", VpnProtocol.HYSTERIA2, server, port)

    @Test
    fun `a QUIC listener is measured by the round trip it takes to negotiate`() = runTest {
        UdpStandIn { versionNegotiationPacket() }.use { standIn ->
            val outcome = prober.measure(quicKey(port = standIn.port), 2_000)
            assertTrue("ожидалось Reachable, получено $outcome", outcome is ProbeOutcome.Reachable)
            assertTrue((outcome as ProbeOutcome.Reachable).rttMillis >= 0)
        }
    }

    @Test
    fun `the probe sends a datagram a server will answer`() = runTest {
        // Ties the prober to the packet: the reserved version is what makes a QUIC server
        // reply at all, and the padding is what stops the datagram being dropped unread.
        UdpStandIn { versionNegotiationPacket() }.use { standIn ->
            prober.measure(quicKey(port = standIn.port), 2_000)

            val sent = standIn.lastRequest
            assertNotNull("замер не отправил ни одной датаграммы", sent)
            assertEquals(QuicProbe.DATAGRAM_BYTES, sent!!.size)
            assertEquals(QuicProbe.RESERVED_VERSION, readInt(sent, 1))
        }
    }

    @Test
    fun `an endpoint that answers with something else is not reported reachable`() = runTest {
        // An echo stands in for "something is listening there, and it is not a QUIC server".
        // Reporting that as reachable would put a confident number on a service the user is
        // not buying - the same mistake a TCP connect makes on a UDP-only port.
        UdpStandIn { it.data.copyOf(it.length) }.use { standIn ->
            assertEquals(ProbeOutcome.NotMeasurable, prober.measure(quicKey(port = standIn.port), 300))
        }
    }

    @Test
    fun `silence is never reported as a dead server`() = runTest {
        // A dropped packet, a rate limit and an obfuscated wire all look identical from here.
        // Calling any of them dead would remove a working key from the search.
        UdpStandIn { null }.use { standIn ->
            assertEquals(ProbeOutcome.NotMeasurable, prober.measure(quicKey(port = standIn.port), 300))
        }
    }

    @Test
    fun `an endpoint with no listener is never reported reachable`() = runTest {
        val closedPort = DatagramSocket(0, InetAddress.getByName("127.0.0.1")).use { it.localPort }
        val outcome = prober.measure(quicKey(port = closedPort), 300)
        // Which negative it is depends on the platform delivering the ICMP error: either the
        // peer's stack said so, or nothing came back. Both are honest; claiming reachability
        // is not.
        assertFalse("закрытый порт объявлен достижимым: $outcome", outcome is ProbeOutcome.Reachable)
    }

    @Test
    fun `a non-QUIC key is never sent a QUIC packet`() = runTest {
        UdpStandIn { versionNegotiationPacket() }.use { standIn ->
            val vless = VpnProfile("id", "name", VpnProtocol.VLESS, "127.0.0.1", standIn.port)
            assertEquals(ProbeOutcome.NotMeasurable, prober.measure(vless, 300))
            assertEquals("UDP-проба ушла на TCP-ключ", 0, standIn.requests.get())
        }
    }

    @Test
    fun `an unresolvable name is reported rather than thrown`() = runTest {
        val outcome = prober.measure(quicKey(server = "not a hostname", port = 443), 300)
        assertTrue("ожидалось Unreachable, получено $outcome", outcome is ProbeOutcome.Unreachable)
    }

    /**
     * A UDP endpoint that answers however the test tells it to - with a Version Negotiation
     * packet, with something else, or not at all - and counts what reached it.
     */
    private class UdpStandIn(private val respond: (DatagramPacket) -> ByteArray?) : Closeable {
        private val socket = DatagramSocket(0, InetAddress.getByName("127.0.0.1"))
        val port: Int get() = socket.localPort
        val requests = AtomicInteger(0)

        @Volatile
        var lastRequest: ByteArray? = null

        init {
            thread(isDaemon = true) {
                while (!socket.isClosed) {
                    val incoming = DatagramPacket(ByteArray(2048), 2048)
                    try {
                        socket.receive(incoming)
                    } catch (_: Exception) {
                        return@thread
                    }
                    requests.incrementAndGet()
                    lastRequest = incoming.data.copyOf(incoming.length)
                    val payload = respond(incoming) ?: continue
                    runCatching {
                        socket.send(
                            DatagramPacket(payload, payload.size, incoming.address, incoming.port),
                        )
                    }
                }
            }
        }

        override fun close() = socket.close()
    }
}
