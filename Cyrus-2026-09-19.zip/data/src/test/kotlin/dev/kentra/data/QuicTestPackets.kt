package dev.kentra.data

/**
 * Packet builders shared by the prober tests.
 *
 * A Version Negotiation packet is built here rather than in one test class because two
 * different questions need it - "is this recognised" and "does a socket that answers this
 * way get measured" - and a second copy would let the two drift apart.
 */
internal fun versionNegotiationPacket(
    firstByte: Int = 0xC0,
    versions: IntArray = intArrayOf(1),
    connectionIdBytes: Int = 8,
): ByteArray {
    val packet = ByteArray(1 + 4 + 1 + connectionIdBytes + 1 + connectionIdBytes + versions.size * 4)
    packet[0] = firstByte.toByte()
    // Version stays zero: that is what marks the packet as negotiation.
    packet[5] = connectionIdBytes.toByte()
    packet[6 + connectionIdBytes] = connectionIdBytes.toByte()
    versions.forEachIndexed { index, version ->
        writeInt(packet, 7 + 2 * connectionIdBytes + index * 4, version)
    }
    return packet
}

internal fun readInt(bytes: ByteArray, at: Int): Int =
    ((bytes[at].toInt() and 0xFF) shl 24) or
        ((bytes[at + 1].toInt() and 0xFF) shl 16) or
        ((bytes[at + 2].toInt() and 0xFF) shl 8) or
        (bytes[at + 3].toInt() and 0xFF)

internal fun writeInt(bytes: ByteArray, at: Int, value: Int) {
    bytes[at] = (value ushr 24).toByte()
    bytes[at + 1] = (value ushr 16).toByte()
    bytes[at + 2] = (value ushr 8).toByte()
    bytes[at + 3] = value.toByte()
}
