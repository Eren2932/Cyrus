package dev.kentra.data

import dev.kentra.domain.model.ProbeOutcome
import dev.kentra.domain.model.TransportSettings
import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.model.VpnProtocol
import dev.kentra.domain.repository.LatencyProber
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The routing decision is the one place that decides whether a key is measured with a
 * connect, measured with a datagram, or not measured at all, so it is tested as a decision
 * rather than through the sockets underneath it.
 */
class RoutingLatencyProberTest {

    private class Recorder(private val outcome: ProbeOutcome) : LatencyProber {
        val asked = mutableListOf<String>()
        override suspend fun measure(profile: VpnProfile, timeoutMillis: Long): ProbeOutcome {
            asked += profile.id
            return outcome
        }
    }

    private fun key(protocol: VpnProtocol, transport: String = "tcp") =
        VpnProfile("id", "name", protocol, "proxy.example", 443, transport = TransportSettings(transport))

    @Test
    fun `a TCP key goes to the prober that opens a socket`() = runTest {
        val tcp = Recorder(ProbeOutcome.Reachable(11))
        val quic = Recorder(ProbeOutcome.Reachable(22))

        val outcome = RoutingLatencyProber(tcp, quic).measure(key(VpnProtocol.VLESS), 1_000)

        assertEquals(ProbeOutcome.Reachable(11), outcome)
        assertEquals(listOf("id"), tcp.asked)
        assertTrue("QUIC-проба тронула TCP-ключ", quic.asked.isEmpty())
    }

    @Test
    fun `a hysteria2 key goes to the prober that can actually measure it`() = runTest {
        // This is the whole point of the routing: before it, this key was handed to the TCP
        // prober, which could only answer "not measurable", and it was appended to the end of
        // the shortlist no matter how close it was.
        val tcp = Recorder(ProbeOutcome.Reachable(11))
        val quic = Recorder(ProbeOutcome.Reachable(22))

        val outcome = RoutingLatencyProber(tcp, quic).measure(key(VpnProtocol.HYSTERIA2), 1_000)

        assertEquals(ProbeOutcome.Reachable(22), outcome)
        assertEquals(listOf("id"), quic.asked)
        assertTrue("TCP-проба тронула QUIC-ключ", tcp.asked.isEmpty())
    }

    @Test
    fun `an opaque UDP key reaches neither prober and is reported unmeasured`() = runTest {
        // vless over kcp and a WireGuard key have no handshake a prober can reproduce. The
        // honest answer is that nothing is known - and it must be given without dialling
        // anything, because either prober would report a number about the wrong service.
        val tcp = Recorder(ProbeOutcome.Reachable(11))
        val quic = Recorder(ProbeOutcome.Reachable(22))

        for (profile in listOf(key(VpnProtocol.VLESS, "kcp"), key(VpnProtocol.WIREGUARD))) {
            assertEquals(
                ProbeOutcome.NotMeasurable,
                RoutingLatencyProber(tcp, quic).measure(profile, 1_000),
            )
        }
        assertTrue(tcp.asked.isEmpty())
        assertTrue(quic.asked.isEmpty())
    }
}
