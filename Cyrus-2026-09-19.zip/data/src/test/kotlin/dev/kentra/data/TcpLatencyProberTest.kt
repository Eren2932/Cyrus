package dev.kentra.data

import dev.kentra.domain.model.ProbeOutcome
import dev.kentra.domain.model.TransportSettings
import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.model.VpnProtocol
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.Closeable
import java.io.EOFException
import java.io.InputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.atomic.AtomicInteger
import kotlin.concurrent.thread

/**
 * The prober is tested against real sockets rather than a mocked `Socket`: the whole point
 * of it is what an actual connect does, and a mock would only re-assert the assumption.
 */
class TcpLatencyProberTest {

    private val prober = TcpLatencyProber()

    private fun profile(
        server: String,
        port: Int,
        protocol: VpnProtocol = VpnProtocol.VLESS,
        transport: String = "tcp",
    ) = VpnProfile(
        id = "id", name = "name", protocol = protocol, server = server, port = port,
        transport = TransportSettings(type = transport),
    )

    @Test
    fun `a listening socket is reachable and its round trip is reported`() = runTest {
        ServerSocket(0).use { server ->
            val outcome = prober.measure(profile("127.0.0.1", server.localPort), 2_000)
            assertTrue("ожидалось Reachable, получено $outcome", outcome is ProbeOutcome.Reachable)
            assertTrue((outcome as ProbeOutcome.Reachable).rttMillis >= 0)
        }
    }

    @Test
    fun `a closed port is unreachable, not merely slow`() = runTest {
        val closedPort = ServerSocket(0).use { it.localPort }
        val outcome = prober.measure(profile("127.0.0.1", closedPort), 500)
        assertTrue("ожидалось Unreachable, получено $outcome", outcome is ProbeOutcome.Unreachable)
    }

    @Test
    fun `a QUIC protocol is not measured by a TCP connect`() = runTest {
        // There is no TCP listener belonging to hysteria2, so a connect here would report a
        // number about whatever else answers on that port. It is measured instead by the
        // version-negotiation probe - see UdpLatencyProberTest - but never by this one.
        assertEquals(ProbeOutcome.NotMeasurable, prober.measure(profile("127.0.0.1", 1, VpnProtocol.HYSTERIA2), 100))
    }

    @Test
    fun `a UDP transport is not measured even when the protocol is TCP-based`() = runTest {
        // Same conclusion reached through the other field: vless over kcp is UDP.
        assertEquals(
            ProbeOutcome.NotMeasurable,
            prober.measure(profile("127.0.0.1", 1, VpnProtocol.VLESS, transport = "kcp"), 100),
        )
    }

    @Test
    fun `WireGuard is not measured with a TCP connect either`() = runTest {
        // Found while adding the QUIC probe. WireGuard and AmneziaWG are UDP, and neither was
        // on the list of unmeasurable wires, so a connect was taken and its result reported
        // as the key's distance - a confident number about whatever else the host runs on
        // that port, which the prober's own documentation calls worse than having no number.
        assertEquals(ProbeOutcome.NotMeasurable, prober.measure(profile("127.0.0.1", 1, VpnProtocol.WIREGUARD), 100))
        assertEquals(ProbeOutcome.NotMeasurable, prober.measure(profile("127.0.0.1", 1, VpnProtocol.AMNEZIA_WG), 100))
    }

    @Test
    fun `an unresolvable name is reported as unreachable rather than thrown`() = runTest {
        // A name the resolver rejects by syntax, rather than a reserved TLD such as
        // `.invalid`: a wildcard DNS resolver will happily answer for any well-formed name,
        // which would turn this test into a statement about the environment's DNS. A name
        // that is not a name cannot be rescued that way.
        val outcome = prober.measure(profile("not a hostname", 443), 500)
        assertTrue("ожидалось Unreachable, получено $outcome", outcome is ProbeOutcome.Unreachable)
    }

    /**
     * The trap this guards against was found the hard way: on a machine whose JVM has
     * `socksProxyHost` set - macOS fills it in from the system network settings, so any
     * developer running a proxy client has it - a plain `Socket` is routed through that
     * proxy, SOCKS5 resolves the target name *remotely*, and the connect then succeeds for
     * a host that does not exist. Measured on such a machine, `does-not-exist.invalid:443`
     * "connected" in 17 ms and reported its peer as `0.0.0.0:443`.
     *
     * The assertion is on whether the stand-in was *contacted*, not on the outcome, and
     * that choice is deliberate. On a machine running a TUN-mode proxy client - the routing
     * table on the machine this was written on sends everything into `utun4`, so a connect
     * to the reserved `192.0.2.1` is answered locally in 4 ms - "the connect failed" is not
     * a signal that can be trusted. Contact is. The positive control keeps the test honest:
     * without it, a count of zero would prove only that the stand-in was broken.
     */
    @Test
    fun `an ambient JVM proxy is never consulted for a measurement`() = runTest {
        val savedHost = System.getProperty("socksProxyHost")
        val savedPort = System.getProperty("socksProxyPort")
        val standIn = SocksStandIn()
        try {
            System.setProperty("socksProxyHost", "127.0.0.1")
            System.setProperty("socksProxyPort", standIn.port.toString())

            // Positive control: a default socket must reach the stand-in, otherwise a zero
            // count below would be evidence about the harness rather than about the prober.
            runCatching {
                Socket().use { it.connect(InetSocketAddress("192.0.2.1", 443), 500) }
            }
            assertTrue(
                "стенд-посредник не увидел ни одного обращения — проверка ничего не доказывает",
                standIn.contacted.get() > 0,
            )

            val before = standIn.contacted.get()
            prober.measure(profile("192.0.2.1", 443), 500)

            assertEquals(
                "замер ушёл через прокси, настроенный в JVM, а не на сам сервер",
                before, standIn.contacted.get(),
            )
        } finally {
            restore("socksProxyHost", savedHost)
            restore("socksProxyPort", savedPort)
            standIn.close()
        }
    }

    @Test
    fun `an IPv6 literal is measured with its brackets stripped`() = runTest {
        // `contains(':')` alone makes InetSocketAddress reject or mis-parse "[::1]".
        ServerSocket(0, 1, InetAddress.getByName("::1")).use { server ->
            val outcome = prober.measure(profile("[::1]", server.localPort), 2_000)
            assertTrue("ожидалось Reachable, получено $outcome", outcome is ProbeOutcome.Reachable)
        }
    }

    private fun restore(name: String, value: String?) =
        if (value == null) System.clearProperty(name) else System.setProperty(name, value)

    /**
     * A minimal SOCKS5 stand-in: it answers "succeeded" to any CONNECT without ever dialling
     * the target, and counts every client that reached it.
     *
     * It is deliberately not a proxy implementation. Its job is to be the dishonest
     * intermediary the prober has to refuse, and to observe whether the prober consults the
     * JVM proxy settings at all.
     */
    private class SocksStandIn : Closeable {
        val contacted = AtomicInteger(0)
        private val server = ServerSocket(0, 8, InetAddress.getByName("127.0.0.1"))
        val port: Int get() = server.localPort

        init {
            thread(isDaemon = true) {
                while (!server.isClosed) {
                    val client = try {
                        server.accept()
                    } catch (_: Exception) {
                        return@thread
                    }
                    contacted.incrementAndGet()
                    thread(isDaemon = true) {
                        runCatching {
                            val input = client.getInputStream()
                            val output = client.getOutputStream()
                            // Greeting: VER, NMETHODS, METHODS...
                            val greeting = input.readFully(2)
                            input.readFully(greeting[1].toInt() and 0xFF)
                            output.write(byteArrayOf(0x05, 0x00)); output.flush()
                            // Request: VER, CMD, RSV, ATYP, ADDR, PORT
                            val request = input.readFully(4)
                            when (request[3].toInt() and 0xFF) {
                                0x01 -> input.readFully(4)
                                0x04 -> input.readFully(16)
                                0x03 -> input.readFully(input.readFully(1)[0].toInt() and 0xFF)
                            }
                            input.readFully(2)
                            // "Succeeded", bound address 0.0.0.0:0 - the lie, in ten bytes.
                            output.write(byteArrayOf(0x05, 0x00, 0x00, 0x01, 0, 0, 0, 0, 0, 0))
                            output.flush()
                            while (input.read() >= 0) { /* hold until the peer gives up */ }
                        }.onFailure { client.close() }
                    }
                }
            }
        }

        override fun close() = server.close()
    }
}

/**
 * File scope rather than a member of the test class: [TcpLatencyProberTest.SocksStandIn] is a
 * nested class, and a nested class cannot see its outer class's members.
 */
private fun InputStream.readFully(count: Int): ByteArray {
    val buffer = ByteArray(count)
    var offset = 0
    while (offset < count) {
        val read = read(buffer, offset, count - offset)
        if (read < 0) throw EOFException("peer closed after $offset of $count bytes")
        offset += read
    }
    return buffer
}
