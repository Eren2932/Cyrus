package dev.kentra.data

import dev.kentra.domain.model.ProfileOrigin
import dev.kentra.domain.model.TlsSettings
import dev.kentra.domain.model.TransportSettings
import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.model.VpnProtocol
import dev.kentra.domain.model.connectionIdentity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * C-1 regression: `connectionIdentity()` feeds the unencrypted `profiles.connectionIdentity`
 * column, so it must be an irreversible fingerprint with no UUID, password or link structure.
 */
class ConnectionIdentityTest {

    private val uuid = "4c7a0b95-1dcb-4044-b948-69e1b4881733"
    private val password = "s3cr3t-pa55w0rd"
    private val host = "dbkv4jecap48.minecraft.webcam"
    private val fingerprint = Regex("^v3:[0-9a-f]{64}$")

    private fun profile(rawLink: String? = null) = VpnProfile(
        id = "profile-id",
        name = "NL-01",
        protocol = VpnProtocol.VLESS,
        server = host,
        port = 443,
        uuid = uuid,
        password = password,
        tls = TlsSettings(enabled = true, serverName = "sni.tld"),
        transport = TransportSettings(type = "ws", path = "/p"),
        origin = ProfileOrigin.Manual,
        rawLink = rawLink,
    )

    @Test
    fun `raw link identity is a fingerprint without credentials`() {
        val identity = profile("vless://$uuid:$password@$host:443?type=ws#tag").connectionIdentity()

        assertTrue(identity.matches(fingerprint))
        assertFalse(identity.contains(uuid))
        assertFalse(identity.contains(password))
        assertFalse(identity.contains("://"))
        assertFalse(identity.contains(host))
    }

    @Test
    fun `fallback identity without raw link is a fingerprint without credentials`() {
        val identity = profile(rawLink = null).connectionIdentity()

        assertTrue(identity.matches(fingerprint))
        assertFalse(identity.contains(uuid))
        assertFalse(identity.contains(password))
        assertFalse(identity.contains("://"))
    }

    @Test
    fun `fragment does not affect the identity`() {
        val base = "vless://$uuid:$password@example.com:443?type=ws"

        assertEquals(profile("$base#one").connectionIdentity(), profile("$base#two").connectionIdentity())
    }

    @Test
    fun `different credentials produce different identities`() {
        val first = profile("vless://$uuid:$password@example.com:443").connectionIdentity()
        val second = profile("vless://other-uuid:other-password@example.com:443").connectionIdentity()

        assertNotEquals(first, second)
    }

    @Test
    fun `presentation fields do not affect the identity`() {
        val base = profile("vless://$uuid:$password@example.com:443").connectionIdentity()
        val renamed = profile("vless://$uuid:$password@example.com:443")
            .copy(id = "other-id", name = "other-name", createdAt = 99L)
            .connectionIdentity()

        assertEquals(base, renamed)
    }

    @Test
    fun `identity is deterministic across calls`() {
        val profile = profile("vless://$uuid:$password@example.com:443")

        assertEquals(profile.connectionIdentity(), profile.connectionIdentity())
    }
}
