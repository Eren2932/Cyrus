"""Narrow source guard for HomeScreen's known DSL receiver bug; not a compiler."""
from pathlib import Path
import re

def validate_home_scope(source):
    capture = 'val availableHeight = maxHeight'
    assert source.count(capture) == 1, 'Capture Home height exactly once in the outer scope'
    outer = source.index('BoxWithConstraints(modifier.fillMaxSize()) {')
    inner = source.index('Column(Modifier.fillMaxSize()', outer)
    assert outer < source.index(capture) < inner, 'Capture must precede nested ColumnScope'
    remainder = source.replace(capture, '', 1)
    assert not re.search(r'\bmaxHeight\b', remainder), 'Use captured height, not a hidden DSL receiver'
    assert '(availableHeight - sheetHeight - (178.dp + 45.dp * fontScale))' in source, 'Padding must use captured constraint'

if __name__ == '__main__':
    root = Path(__file__).resolve().parents[1]
    validate_home_scope((root/'feature/home/src/main/kotlin/dev/kentra/feature/home/HomeScreen.kt').read_text())
    print('PASS Home height receiver guard (static, not Kotlin compilation)')
