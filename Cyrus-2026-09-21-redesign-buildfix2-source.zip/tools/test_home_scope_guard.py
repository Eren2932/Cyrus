"""Prove that the static guard rejects the exact run #38 regression."""
from pathlib import Path
import unittest
from check_home_scope import validate_home_scope

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT/'feature/home/src/main/kotlin/dev/kentra/feature/home/HomeScreen.kt').read_text()

class HomeScopeTests(unittest.TestCase):
    def test_fixed_source_passes(self):
        validate_home_scope(SOURCE)

    def test_original_padding_error_is_rejected(self):
        mutant = SOURCE.replace('(availableHeight - sheetHeight -', '(maxHeight - sheetHeight -')
        self.assertNotEqual(mutant, SOURCE)
        with self.assertRaisesRegex(AssertionError, 'hidden DSL receiver'):
            validate_home_scope(mutant)

    def test_missing_capture_is_rejected(self):
        with self.assertRaises(AssertionError):
            validate_home_scope(SOURCE.replace('val availableHeight = maxHeight', ''))

    def test_capture_inside_column_is_rejected(self):
        mutant = SOURCE.replace('        val availableHeight = maxHeight\n', '')
        marker = 'Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {'
        mutant = mutant.replace(marker, marker+'\n val availableHeight = maxHeight')
        with self.assertRaisesRegex(AssertionError, 'precede'):
            validate_home_scope(mutant)

if __name__ == '__main__':
    unittest.main(verbosity=2)
