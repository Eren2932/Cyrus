# Проверка объединённой версии 0.4.2

Дата: 2026-09-17. Среда: the Computer. Все результаты относятся к исходникам, если прямо не указано иное.

| Проверка | Результат |
|---|---|
| check_source.py: Kotlin-скобки, XML, TOML, модули, инварианты | 48 PASS; 62 Kotlin-файла, 16 модулей |
| check_design.py | 10 160 утверждений, 71 цветовая пара — PASS |
| test_design_guard.py | 12 намеренных регрессий отклонены |
| check_merge.py | 16 статических инвариантов — PASS |
| test_merge_guard.py | 10 намеренных регрессий отклонены |
| test_native_guard.py | 6 тестов упаковочного валидатора — PASS, искусственные фикстуры |
| bash -n build.sh build-libbox.sh | PASS |
| Сравнение сохранённых UI/домен/данные-файлов с исходниками | PASS, побайтовое |
| ZIP CRC и FILES.sha256 | Проверены при упаковке |
| Проверка настоящего AAR | BLOCKED: в источниках и результате AAR отсутствует |
| bash build.sh | BLOCKED: Gradle отсутствует; установлена Java 21, а требуется JDK 17 |
| Kotlin-компиляция / JUnit / lint / APK | NOT RUN |
| GitHub Actions / Go-native build | NOT RUN |
| Android instrumentation / DNS / реальный VPN / FPS | NOT RUN |

`validation/source-checks.txt` — полный запуск source gate с дочерними проверками. `native-guard-tests.txt` — тесты упаковки, `native-check.txt` — ожидаемый отказ на отсутствующем настоящем AAR. `build-attempt.txt` — фактическая остановка локальной попытки до Gradle. `merge-map.json` содержит происхождение каждого пути исходных деревьев.

Счётчики статических утверждений не являются количеством Android-тестов или доказательством эксплуатационной готовности. Исторические документы 0.2–0.4.1 не подтверждают состояние этой версии. Для допуска к использованию нужен успешный внешний workflow с run_checks=true и проверка на Android-устройстве.
