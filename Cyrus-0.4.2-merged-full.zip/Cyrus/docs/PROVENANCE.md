# Происхождение Cyrus 0.4.2

Источник: публичный https://github.com/Eren2932/Cyrus, ветка main. Загружен 2026-09-17. Git commit из комментария codeload ZIP: `144be358d87a454100cfd36c99b0db2dac4a8e5d`.

| Архив | SHA-256 |
|---|---|
| Cyrus (1).zip | `147b72cff696d5e56ce083a301690b7e0622caf5bfb17a1a2e80ad4746a61fda` |
| Cyrus-0.4.1-full.zip | `c32c644d1a2ea794b41bc816a6db2633ea39f70b71dc9ab21592d480555d9189` |

Дополнительно прочитан sing-box commit `92d245ad040cbda2f84b21c2a847a470e532c179`, закреплённый внешним workflow проекта: проверены TUN ownership, BoxService start/close и CommandClient/CommandServer. Код sing-box и его бинарники не добавлены в итоговый ZIP.

`validation/merge-map.json` хранит хеши обеих входных версий и выбранный источник по каждому входному пути. Для новых и обновлённых файлов итоговые хеши находятся в `FILES.sha256`. Сам манифест не включает свой хеш; хеш готового ZIP вынесен в соседний файл `.sha256`.

Никакие файлы в GitHub не изменены, workflow не запускался, коммиты/релизы не публиковались. Оригинальные архивы оставлены без изменений.
