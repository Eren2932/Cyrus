package dev.kentra.vpn.config

import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.model.VpnProtocol
import kotlinx.serialization.json.Json

/** User-tunable knobs that must never leak into the UI layer as raw JSON. */
data class TunnelOptions(
    val mtu: Int = 9000,
    /** "system" is lighter on battery, "gvisor" is more compatible. */
    val stack: String = "system",
    val bypassLan: Boolean = true,
    val blockAds: Boolean = false,
    val ipv6: Boolean = false,
    val perAppMode: PerAppMode = PerAppMode.Off,
    val dnsRemote: String = "tls://1.1.1.1",
    val dnsLocal: String = "local",
    val enableMultiplex: Boolean = false,
    val logLevel: String = "warn",
)

sealed interface PerAppMode {
    data object Off : PerAppMode
    data class Include(val packages: List<String>) : PerAppMode
    data class Exclude(val packages: List<String>) : PerAppMode
}

/**
 * The single place where a [VpnProfile] becomes a sing-box configuration.
 * Covered by golden tests: if you change output, you must update the golden file consciously.
 */
class ConfigFactory(
    private val json: Json = Json {
        prettyPrint = true
        encodeDefaults = true
        explicitNulls = false
    },
) {

    fun build(profile: VpnProfile, options: TunnelOptions = TunnelOptions()): String =
        json.encodeToString(SingBoxConfig.serializer(), config(profile, options))

    fun config(profile: VpnProfile, options: TunnelOptions): SingBoxConfig {
        require(profile.transport.type in setOf("tcp", "ws", "grpc", "http", "httpupgrade")) {
            "Transport requires a compatible native adapter"
        }
        require(profile.parameters.keys.none { it in setOf("plugin", "obfs", "obfs-password", "congestion_control", "udp_relay_mode", "extra", "mode", "mport") }) {
            "Extended options are preserved, but are not supported by this legacy config adapter"
        }
        val proxyTag = "proxy"
        return SingBoxConfig(
            log = LogConfig(level = options.logLevel),
            dns = dns(options),
            inbounds = listOf(tun(options)),
            outbounds = listOf(
                outbound(profile, proxyTag, options),
                Outbound(type = "direct", tag = "direct"),
                Outbound(type = "block", tag = "block"),
                Outbound(type = "dns", tag = "dns-out"),
            ),
            route = route(proxyTag, options),
        )
    }

    private fun dns(options: TunnelOptions) = DnsConfig(
        servers = listOf(
            DnsServer(tag = "dns-remote", address = options.dnsRemote, detour = "proxy"),
            DnsServer(tag = "dns-direct", address = options.dnsLocal, detour = "direct"),
        ),
        rules = listOf(
            DnsRule(outbound = listOf("any"), server = "dns-direct", disableCache = true),
        ),
        strategy = if (options.ipv6) "prefer_ipv4" else "ipv4_only",
        final = "dns-remote",
    )

    private fun tun(options: TunnelOptions) = Inbound(
        type = "tun",
        tag = "tun-in",
        interfaceName = "tun0",
        address = buildList {
            add("172.19.0.1/28")
            if (options.ipv6) add("fdfe:dcba:9876::1/126")
        },
        mtu = options.mtu,
        autoRoute = true,
        strictRoute = false,
        stack = options.stack,
        sniff = true,
        sniffOverrideDestination = false,
        endpointIndependentNat = true,
    )

    private fun outbound(profile: VpnProfile, tag: String, options: TunnelOptions): Outbound {
        val tls = profile.tls.takeIf { it.enabled }?.let { t ->
            OutboundTls(
                enabled = true,
                serverName = t.serverName ?: profile.server,
                insecure = t.allowInsecure.takeIf { it },
                alpn = t.alpn.takeIf { it.isNotEmpty() },
                utls = t.fingerprint?.let { Utls(fingerprint = it) }
                    ?: t.reality?.let { Utls(fingerprint = "chrome") },
                reality = t.reality?.let { Reality(publicKey = it.publicKey, shortId = it.shortId) },
            )
        }
        val transport = profile.transport.takeIf { it.type != "tcp" && it.type.isNotBlank() }?.let { tr ->
            OutboundTransport(
                type = tr.type,
                path = tr.path,
                headers = tr.host?.let { mapOf("Host" to it) },
                serviceName = tr.serviceName,
            )
        }
        val multiplex = Multiplex(enabled = options.enableMultiplex).takeIf { options.enableMultiplex }

        return when (profile.protocol) {
            VpnProtocol.VLESS -> Outbound(
                type = "vless",
                tag = tag,
                server = profile.server,
                serverPort = profile.port,
                uuid = profile.uuid,
                flow = profile.flow?.takeIf { it.isNotBlank() },
                tls = tls,
                transport = transport,
                multiplex = multiplex,
                domainStrategy = "ipv4_only",
            )
            VpnProtocol.VMESS -> Outbound(
                type = "vmess",
                tag = tag,
                server = profile.server,
                serverPort = profile.port,
                uuid = profile.uuid,
                security = "auto",
                alterId = profile.alterId ?: 0,
                tls = tls,
                transport = transport,
                multiplex = multiplex,
            )
            VpnProtocol.TROJAN -> Outbound(
                type = "trojan",
                tag = tag,
                server = profile.server,
                serverPort = profile.port,
                password = profile.password,
                tls = tls,
                transport = transport,
                multiplex = multiplex,
            )
            VpnProtocol.SHADOWSOCKS -> Outbound(
                type = "shadowsocks",
                tag = tag,
                server = profile.server,
                serverPort = profile.port,
                method = profile.method,
                password = profile.password,
                multiplex = multiplex,
            )
            VpnProtocol.HYSTERIA2 -> Outbound(
                type = "hysteria2",
                tag = tag,
                server = profile.server,
                serverPort = profile.port,
                password = profile.password,
                tls = tls ?: OutboundTls(enabled = true, serverName = profile.server),
            )
            VpnProtocol.TUIC -> Outbound(
                type = "tuic",
                tag = tag,
                server = profile.server,
                serverPort = profile.port,
                uuid = profile.uuid,
                password = profile.password,
                tls = tls ?: OutboundTls(enabled = true, serverName = profile.server),
            )
            VpnProtocol.UNKNOWN -> error("unsupported protocol for profile ${profile.id}")
        }
    }

    private fun route(proxyTag: String, options: TunnelOptions): RouteConfig {
        val rules = buildList {
            add(RouteRule(protocol = listOf("dns"), outbound = "dns-out"))
            if (options.bypassLan) add(RouteRule(ipIsPrivate = true, outbound = "direct"))
            // NOTE: do not add a blanket "udp/443 -> block" (QUIC) rule here. The block
            // outbound fails every packet with a bare syscall.EPERM, which apps treat as a
            // dead network and often never fall back from QUIC to TCP ("no internet").
            if (options.blockAds) add(RouteRule(ruleSet = listOf("geosite-ads"), outbound = "block"))
            when (val mode = options.perAppMode) {
                is PerAppMode.Include -> if (mode.packages.isNotEmpty()) {
                    add(RouteRule(packageName = mode.packages, outbound = proxyTag))
                }
                is PerAppMode.Exclude -> if (mode.packages.isNotEmpty()) {
                    add(RouteRule(packageName = mode.packages, outbound = "direct"))
                }
                PerAppMode.Off -> Unit
            }
        }
        val sets = buildList {
            if (options.blockAds) {
                add(
                    RuleSet(
                        tag = "geosite-ads",
                        url = "https://raw.githubusercontent.com/SagerNet/sing-geosite/rule-set/geosite-category-ads-all.srs",
                        downloadDetour = "direct",
                    ),
                )
            }
        }
        return RouteConfig(rules = rules, ruleSet = sets, final = proxyTag)
    }
}
