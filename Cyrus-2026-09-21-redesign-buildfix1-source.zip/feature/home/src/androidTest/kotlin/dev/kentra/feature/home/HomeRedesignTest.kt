package dev.kentra.feature.home

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import dev.kentra.core.designsystem.CyrusTheme
import dev.kentra.core.designsystem.LocalReducedMotion
import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.model.VpnProtocol
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test

/** Device tests; source guards do not substitute for running these on Android. */
class HomeRedesignTest {
    @get:Rule val compose = createComposeRule()
    private val de = VpnProfile("de", "DE", VpnProtocol.VLESS, "de.example", 443)
    private val nl = VpnProfile("nl", "NL", VpnProtocol.VLESS, "nl.example", 443)

    private fun render(compact: Boolean = false, fontScale: Float = 1f, onToggle: () -> Unit = {}) {
        compose.setContent {
            val density = LocalDensity.current.density
            CompositionLocalProvider(LocalReducedMotion provides true, LocalDensity provides Density(density, fontScale)) {
                CyrusTheme {
                    var selected by remember { mutableStateOf(de) }
                    Box(Modifier.size(360.dp, if (compact) 280.dp else 640.dp)) {
                        HomeContent(HomeState(profiles = listOf(de, nl), profileCount = 2, activeProfile = selected),
                            pageActive = true, onToggle = onToggle, onPickProfile = {}, onSelectBest = {},
                            onSelectProfile = { id -> selected = if (id == "nl") nl else de }, onRefreshLatency = {})
                    }
                }
            }
        }
    }

    @Test fun collapseRemovesSearchHitTargetAndCanReopen() {
        render()
        compose.onNodeWithContentDescription("Поиск сервера").assertExists()
        compose.onNodeWithContentDescription("Свернуть серверы").performClick()
        compose.onNodeWithContentDescription("Поиск сервера").assertDoesNotExist()
        compose.onNodeWithContentDescription("Развернуть серверы").performClick()
        compose.onNodeWithContentDescription("Поиск сервера").assertExists()
    }

    @Test fun searchMatchesCountryAndClears() {
        render()
        compose.onNodeWithContentDescription("Поиск сервера").performTextInput("Германия")
        compose.onNode(hasText("Германия") and SemanticsMatcher.keyIsDefined(SemanticsProperties.Selected)).assertExists()
        compose.onNodeWithText("Нидерланды").assertDoesNotExist()
        compose.onNodeWithContentDescription("Очистить поиск").performClick()
        compose.onNodeWithText("Нидерланды").assertExists()
    }

    @Test fun rowSelectionUpdatesRadioSemantics() {
        render()
        compose.onNode(hasText("Нидерланды") and hasClickAction()).performClick().assertIsSelected()
        compose.onNode(hasText("Германия") and hasClickAction()).assertIsNotSelected()
    }

    @Test fun compactViewportKeepsConnectionActionAvailable() {
        var taps = 0
        render(compact = true, onToggle = { taps++ })
        compose.onNodeWithContentDescription("Подключить").performClick()
        compose.runOnIdle { assertEquals(1, taps) }
    }

    @Test fun enlargedFontRetainsCollapseControl() {
        render(fontScale = 1.6f)
        compose.onNodeWithContentDescription("Свернуть серверы").assertIsDisplayed().performClick()
        compose.onNodeWithContentDescription("Развернуть серверы").assertIsDisplayed()
    }
}
