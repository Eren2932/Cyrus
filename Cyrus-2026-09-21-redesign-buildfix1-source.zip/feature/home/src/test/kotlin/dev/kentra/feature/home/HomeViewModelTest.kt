package dev.kentra.feature.home

import app.cash.turbine.test
import dev.kentra.core.common.AppError
import dev.kentra.domain.model.ProbeOutcome
import dev.kentra.domain.model.TrafficSample
import dev.kentra.domain.model.TunnelState
import dev.kentra.domain.model.VpnProfile
import dev.kentra.domain.model.VpnProtocol
import dev.kentra.domain.repository.LatencyProber
import dev.kentra.domain.repository.ProfileRepository
import dev.kentra.domain.repository.ProfileValidator
import dev.kentra.domain.repository.TunnelController
import dev.kentra.domain.usecase.ConnectUseCase
import dev.kentra.domain.usecase.DisconnectUseCase
import dev.kentra.domain.usecase.SelectBestServerUseCase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class HomeViewModelTest {

    private val profile = VpnProfile(
        id = "p1",
        name = "NL",
        protocol = VpnProtocol.VLESS,
        server = "1.2.3.4",
        port = 443,
        uuid = "u",
    )

    private val secondProfile = profile.copy(id = "p2", name = "DE", server = "5.6.7.8")
    private val activeId = MutableStateFlow<String?>("p1")
    private val tunnelState = MutableStateFlow<TunnelState>(TunnelState.Idle)
    private var connectResult: Result<Unit> = Result.success(Unit)
    private var disconnectCalls = 0

    private val profileRepo = object : ProfileRepository {
        override fun observeProfiles(): Flow<List<VpnProfile>> = flowOf(listOf(profile, secondProfile))
        override fun observeActiveProfileId(): Flow<String?> = activeId
        override suspend fun getProfile(id: String): VpnProfile? = listOf(profile, secondProfile).firstOrNull { it.id == id }
        override suspend fun upsert(profile: VpnProfile) = Unit
        override suspend fun upsertAll(profiles: List<VpnProfile>) = Unit
        override suspend fun delete(id: String) = Unit
        override suspend fun setActiveProfileId(id: String?) { activeId.value = id }
        // The Home flow never imports, so this fake stores no identities. Required to
        // satisfy ProfileRepository — see REVIEW_0.5.0.md C7.
        override suspend fun getAllIdentities(): List<String> = emptyList()
    }

    private val controller = object : TunnelController {
        override val state: StateFlow<TunnelState> = tunnelState
        override val traffic: Flow<TrafficSample> = MutableStateFlow(TrafficSample())
        override suspend fun connect(profile: VpnProfile) {
            connectResult.getOrThrow()
            tunnelState.value = TunnelState.Connected(profile.id, 0L)
        }
        override suspend fun disconnect() {
            disconnectCalls++
            tunnelState.value = TunnelState.Idle
        }
    }

    /** Nothing answers: the ranking itself is covered by SelectBestServerUseCaseTest. */
    private val unreachableProber = object : LatencyProber {
        override suspend fun measure(profile: VpnProfile, timeoutMillis: Long) =
            ProbeOutcome.Unreachable("нет ответа")
    }

    private val acceptingValidator = object : ProfileValidator {
        override fun validate(profile: VpnProfile) = Unit
    }

    private fun viewModel(
        notificationPermissionMissing: () -> Boolean = { false },
    ) = HomeViewModel(
        profiles = profileRepo,
        tunnel = controller,
        connect = ConnectUseCase(profileRepo, controller),
        disconnect = DisconnectUseCase(controller),
        selectBestServer = SelectBestServerUseCase(
            profiles = profileRepo,
            prober = unreachableProber,
            validator = acceptingValidator,
            tunnel = controller,
        ),
        notificationPermissionMissing = notificationPermissionMissing,
    )

    @Before
    fun setUp() = Dispatchers.setMain(UnconfinedTestDispatcher())

    @After
    fun tearDown() = Dispatchers.resetMain()

    @Test
    fun `toggle connects the active profile`() = runTest {
        val vm = viewModel()

        vm.dispatch(HomeIntent.ToggleConnection)

        assertEquals(TunnelState.Connected("p1", 0L), vm.state.value.tunnel)
    }

    @Test
    fun `toggle while connected disconnects`() = runTest {
        val vm = viewModel()
        tunnelState.value = TunnelState.Connected("p1", 0L)

        vm.dispatch(HomeIntent.ToggleConnection)

        assertEquals(1, disconnectCalls)
    }

    @Test
    fun `connect asks for the notification permission the stop action lives in`() = runTest {
        // Android 13+ keeps the service notification out of the shade without it, and
        // "Отключить" is published as an action on that very notification.
        val vm = viewModel(notificationPermissionMissing = { true })

        vm.effects.test {
            vm.dispatch(HomeIntent.ToggleConnection)
            assertEquals(HomeEffect.RequestNotificationPermission, awaitItem())
            cancelAndIgnoreRemainingEvents()
        }
        // Asking must not gate the tunnel: it works without the notification, the user
        // just loses the shortcut.
        assertEquals(TunnelState.Connected("p1", 0L), vm.state.value.tunnel)
    }

    @Test
    fun `a granted notification permission is not asked for again`() = runTest {
        val vm = viewModel(notificationPermissionMissing = { false })

        vm.effects.test {
            vm.dispatch(HomeIntent.ToggleConnection)
            assertEquals(emptyList<HomeEffect>(), cancelAndConsumeRemainingEvents())
        }
        assertEquals(TunnelState.Connected("p1", 0L), vm.state.value.tunnel)
    }

    @Test
    fun `disconnecting does not ask for notifications`() = runTest {
        val vm = viewModel(notificationPermissionMissing = { true })
        tunnelState.value = TunnelState.Connected("p1", 0L)

        vm.effects.test {
            vm.dispatch(HomeIntent.ToggleConnection)
            assertEquals(emptyList<HomeEffect>(), cancelAndConsumeRemainingEvents())
        }
        assertEquals(1, disconnectCalls)
    }

    @Test
    fun `missing vpn consent asks for permission instead of failing silently`() = runTest {
        connectResult = Result.failure(AppError.Permission("vpn-consent"))
        val vm = viewModel()

        vm.effects.test {
            vm.dispatch(HomeIntent.ToggleConnection)
            assertEquals(HomeEffect.RequestVpnPermission, awaitItem())
            cancelAndIgnoreRemainingEvents()
        }
    }

    @Test
    fun `selecting the best server reports the outcome instead of switching silently`() = runTest {
        // A search moves the active key on its own, so the user has to be told why. A
        // silent switch would look like the app changed servers at random.
        val vm = viewModel()

        vm.effects.test {
            vm.dispatch(HomeIntent.SelectBestServer)
            val message = awaitItem()
            assertTrue(
                "ожидалось сообщение об исходе, получено $message",
                (message as HomeEffect.ShowMessage).text.contains("не отвечает"),
            )
            cancelAndIgnoreRemainingEvents()
        }
        assertFalse("поиск обязан снять флаг по завершении", vm.state.value.searching)
    }

    @Test
    fun `a search in flight blocks the connect button`() = runTest {
        // The search dials candidates itself; a connect pressed in the middle of one would
        // tear down the candidate being verified and produce a result for a key that was
        // never actually up.
        val vm = viewModel()
        vm.dispatch(HomeIntent.SelectBestServer)

        assertFalse(vm.state.value.canConnect)
    }
    @Test fun `home publishes saved profiles rather than reference countries`() = runTest {
        val vm = viewModel()
        assertEquals(listOf("p1", "p2"), vm.state.value.profiles.map { it.id })
    }

    @Test fun `idle selection persists without starting VPN`() = runTest {
        val vm = viewModel()
        vm.dispatch(HomeIntent.SelectProfile("p2"))
        assertEquals("p2", activeId.value)
        assertEquals(TunnelState.Idle, tunnelState.value)
        assertEquals("p2", vm.state.value.activeProfile?.id)
    }

    @Test fun `connected selection switches through existing use case`() = runTest {
        val vm = viewModel()
        tunnelState.value = TunnelState.Connected("p1", 0L)
        vm.dispatch(HomeIntent.SelectProfile("p2"))
        assertEquals(TunnelState.Connected("p2", 0L), tunnelState.value)
        assertEquals("p2", activeId.value)
        assertFalse(vm.state.value.selecting)
    }

    @Test fun `selection during transition does not mutate active key`() = runTest {
        val vm = viewModel()
        for (transition in listOf(TunnelState.Preparing, TunnelState.Stopping)) {
            tunnelState.value = transition
            vm.dispatch(HomeIntent.SelectProfile("p2"))
            assertEquals("p1", activeId.value)
            assertEquals(transition, tunnelState.value)
        }
    }

    @Test fun `failed switch retains saved selection and clears busy flag`() = runTest {
        val vm = viewModel()
        tunnelState.value = TunnelState.Connected("p1", 0L)
        connectResult = Result.failure(AppError.Permission("vpn-consent"))
        vm.effects.test {
            vm.dispatch(HomeIntent.SelectProfile("p2"))
            assertTrue(awaitItem() is HomeEffect.ShowMessage)
            cancelAndIgnoreRemainingEvents()
        }
        assertEquals("p1", activeId.value)
        assertFalse(vm.state.value.selecting)
    }

    @Test fun `selecting a missing profile reports failure`() = runTest {
        val vm = viewModel()
        vm.effects.test {
            vm.dispatch(HomeIntent.SelectProfile("deleted"))
            assertTrue(awaitItem() is HomeEffect.ShowMessage)
            cancelAndIgnoreRemainingEvents()
        }
        assertEquals("p1", activeId.value)
        assertFalse(vm.state.value.selecting)
    }

}
