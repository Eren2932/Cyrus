package dev.kentra.feature.home

import org.junit.Assert.*
import org.junit.Test

class ServerRegionsTest {
    @Test fun `reference countries resolve from explicit labels`() {
        mapOf("🇩🇪 Frankfurt #1" to "DE", "USA premium" to "US", "France" to "FR",
            "UK | London" to "GB", "Нидерланды" to "NL").forEach { (label, code) ->
            assertEquals(code, ServerRegions.fromLabel(label)?.code)
        }
    }
    @Test fun `flags use regional indicators`() {
        assertEquals("🇩🇪", ServerRegions.fromLabel("DE")?.flag)
        assertEquals("🇬🇧", ServerRegions.fromLabel("UK")?.flag)
    }
    @Test fun `country is not guessed from arbitrary names or IP addresses`() {
        listOf("proxy-1", "1.2.3.4", "Undefined", "Trust", "Premium", "", "node01").forEach {
            assertNull(it, ServerRegions.fromLabel(it))
        }
    }
    @Test fun `name matches are case insensitive and token bounded`() {
        assertEquals("DE", ServerRegions.fromLabel("germany-2")?.code)
        assertEquals("NL", ServerRegions.fromLabel("[nl] 03")?.code)
        assertNull(ServerRegions.fromLabel("usable"))
    }
}
