package dev.kentra.feature.home

import dev.kentra.core.mvi.MviEffect
import dev.kentra.core.mvi.MviIntent
import dev.kentra.core.mvi.MviState
import dev.kentra.domain.model.ProbeOutcome
import dev.kentra.domain.model.TrafficSample
import dev.kentra.domain.model.TunnelState
import dev.kentra.domain.model.VpnProfile

/**
 * The whole screen contract in one file: state, the intents it accepts, the effects it emits.
 * Reviewers can understand a feature without reading the Compose code.
 */
data class HomeState(
    val tunnel: TunnelState = TunnelState.Idle,
    val activeProfile: VpnProfile? = null,
    val profileCount: Int = 0,
    val profiles: List<VpnProfile> = emptyList(),
    val latencies: Map<String, ProbeOutcome> = emptyMap(),
    val probing: Boolean = false,
    val selecting: Boolean = false,
    val traffic: TrafficSample = TrafficSample(),
    val busy: Boolean = false,
    val message: String? = null,
    /**
     * True while the best-server search runs. Separate from [busy] because the search is
     * busy even between dials - while it is measuring, the tunnel is idle but the user must
     * not be allowed to start a connection that would fight the search for the same TUN.
     */
    val searching: Boolean = false,
    /** What the search is doing right now. The whole run can take half a minute. */
    val searchProgress: String? = null,
) : MviState {
    val canConnect: Boolean get() = activeProfile != null && !busy && !searching && !selecting
    val canSearch: Boolean get() = profileCount > 0 && !busy && !searching && !selecting
}

sealed interface HomeIntent : MviIntent {
    data object ToggleConnection : HomeIntent
    data object VpnPermissionGranted : HomeIntent
    data object VpnPermissionDenied : HomeIntent
    data object OpenProfiles : HomeIntent
    data object SelectBestServer : HomeIntent
    data class SelectProfile(val id: String) : HomeIntent
    data object RefreshLatency : HomeIntent
    data object MessageShown : HomeIntent
}

sealed interface HomeEffect : MviEffect {
    data object RequestVpnPermission : HomeEffect
    /**
     * Android 13+ hides a foreground-service notification unless `POST_NOTIFICATIONS`
     * was granted - it stays reachable only in the task manager, so the "Отключить"
     * action the service publishes is not reachable from the notification shade at
     * all. Ask before the tunnel comes up; the connection is not gated on the answer.
     */
    data object RequestNotificationPermission : HomeEffect
    data object NavigateToProfiles : HomeEffect
    data class ShowMessage(val text: String) : HomeEffect
}
