package dev.kentra.feature.home

/** Display hints from explicit profile labels only. No invented GeoIP from host names. */
internal data class ServerRegion(val code: String, val title: String, val aliases: List<String>) {
    val flag: String get() = code.map { Character.toChars(0x1F1E6 + (it - 'A')).concatToString() }.joinToString("")
}

internal object ServerRegions {
    private val regions = listOf(
        ServerRegion("DE", "Германия", listOf("DE", "Germany", "Deutschland", "Германия")),
        ServerRegion("US", "США", listOf("US", "USA", "United States", "США")),
        ServerRegion("FR", "Франция", listOf("FR", "France", "Франция")),
        ServerRegion("GB", "Великобритания", listOf("GB", "UK", "United Kingdom", "Britain", "Великобритания")),
        ServerRegion("NL", "Нидерланды", listOf("NL", "Netherlands", "Holland", "Нидерланды", "Голландия")),
        ServerRegion("FI", "Финляндия", listOf("FI", "Finland", "Финляндия")),
        ServerRegion("SE", "Швеция", listOf("SE", "Sweden", "Швеция")),
        ServerRegion("CH", "Швейцария", listOf("CH", "Switzerland", "Швейцария")),
        ServerRegion("PL", "Польша", listOf("PL", "Poland", "Польша")),
        ServerRegion("TR", "Турция", listOf("TR", "Turkey", "Türkiye", "Турция")),
        ServerRegion("RU", "Россия", listOf("RU", "Russia", "Россия")),
        ServerRegion("JP", "Япония", listOf("JP", "Japan", "Япония")),
        ServerRegion("SG", "Сингапур", listOf("SG", "Singapore", "Сингапур")),
        ServerRegion("CA", "Канада", listOf("CA", "Canada", "Канада")),
        ServerRegion("AU", "Австралия", listOf("AU", "Australia", "Австралия")),
        ServerRegion("ES", "Испания", listOf("ES", "Spain", "Испания")),
        ServerRegion("IT", "Италия", listOf("IT", "Italy", "Италия")),
        ServerRegion("EE", "Эстония", listOf("EE", "Estonia", "Эстония")),
        ServerRegion("LV", "Латвия", listOf("LV", "Latvia", "Латвия")),
        ServerRegion("KZ", "Казахстан", listOf("KZ", "Kazakhstan", "Казахстан")),
    )
    private val patterns = regions.map { region ->
        region to Regex("(?<![\\p{L}\\p{N}])(?:${region.aliases.joinToString("|") { Regex.escape(it) }})(?![\\p{L}\\p{N}])", RegexOption.IGNORE_CASE)
    }
    fun fromLabel(name: String): ServerRegion? =
        regions.firstOrNull { it.flag in name } ?: patterns.firstOrNull { it.second.containsMatchIn(name) }?.first
}
