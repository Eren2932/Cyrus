package dev.kentra.feature.home

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.kentra.core.designsystem.*
import dev.kentra.domain.model.ProbeOutcome
import dev.kentra.domain.model.TunnelState
import dev.kentra.domain.model.VpnProfile

@Composable
internal fun ServerPanel(
    state: HomeState, expanded: Boolean, query: String, onQuery: (String) -> Unit,
    onExpanded: (Boolean) -> Unit, onSelect: (String) -> Unit,
    onManage: () -> Unit, onAuto: () -> Unit, onRefresh: () -> Unit,
    modifier: Modifier = Modifier,
    compactToggle: (() -> Unit)? = null,
    bodyVisible: Boolean = expanded,
) {
    val colors = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp)
    val reduced = LocalReducedMotion.current
    val chevron = animateFloatAsState(if (expanded) 0f else 180f,
        tween(if (reduced) 0 else CyrusMotion.Settle), label = "serverChevron")
    val listState = rememberLazyListState()
    val focus = LocalFocusManager.current
    val selectedId = (state.tunnel as? TunnelState.Connected)?.profileId ?: state.activeProfile?.id
    val rows = remember(state.profiles, query) {
        val needle = query.trim()
        state.profiles.filter { profile ->
            needle.isEmpty() || profile.name.contains(needle, ignoreCase = true) ||
                ServerRegions.fromLabel(profile.name)?.let { it.title.contains(needle, ignoreCase = true) ||
                    it.code.equals(needle, ignoreCase = true) } == true
        }
    }
    LaunchedEffect(query) { listState.scrollToItem(0) }
    val latestExpanded by rememberUpdatedState(onExpanded)
    Column(modifier.clip(shape).background(Brush.verticalGradient(listOf(colors.surface, colors.background)))
        .border(1.dp, colors.outlineVariant, shape).padding(horizontal = 16.dp).clipToBounds()) {
        Column(Modifier.fillMaxWidth()
            .pointerInput(Unit) {
                var distance = 0f
                detectVerticalDragGestures(onDragStart = { distance = 0f },
                    onDragEnd = {
                        if (distance > 24.dp.toPx()) latestExpanded(false)
                        else if (distance < -24.dp.toPx()) latestExpanded(true)
                    }, onVerticalDrag = { change, delta -> change.consume(); distance += delta })
            }
            .clickable(role = Role.Button) { onExpanded(!expanded) }
            .semantics { contentDescription = if (expanded) "Свернуть серверы" else "Развернуть серверы";
                stateDescription = if (expanded) "Развёрнуто" else "Свёрнуто" },
            horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.padding(top = 8.dp, bottom = 10.dp).size(34.dp, 4.dp)
                .background(colors.onSurfaceVariant.copy(alpha = .7f), CircleShape))
            Row(Modifier.fillMaxWidth().heightIn(min = 50.dp)
                .background(colors.surfaceVariant, RoundedCornerShape(16.dp)).padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(38.dp).background(colors.onSurface.copy(alpha = .04f), RoundedCornerShape(11.dp)),
                    contentAlignment = Alignment.Center) {
                    // Deliberately neutral white in dark mode, never brand orange.
                    CyrusIcon(CyrusSymbol.Globe, Modifier.size(26.dp), colors.onSurface)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Серверы", fontSize = 16.sp, lineHeight = 20.sp)
                    Text(if (expanded) "Выберите страну" else state.activeProfile?.let {
                        ServerRegions.fromLabel(it.name)?.title ?: it.name
                    } ?: "Добавьте ключ подключения", style = MaterialTheme.typography.labelSmall,
                        color = colors.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                if (compactToggle != null) IconButton(onClick = compactToggle,
                    enabled = !state.busy && !state.searching && !state.selecting,
                    modifier = Modifier.semantics {
                        contentDescription = if (state.tunnel is TunnelState.Connected) "Отключить" else "Подключить"
                    }) { CyrusIcon(CyrusSymbol.Power, Modifier.size(24.dp), colors.onSurface) }
                CyrusIcon(CyrusSymbol.Chevron, Modifier.size(20.dp).graphicsLayer { rotationZ = chevron.value }, colors.onSurface)
            }
        }
        // Keep drawing rows during the height transition, but immediately remove
        // their hit targets and semantics when collapsing. No disappearing flash.
        if (bodyVisible) {
            Column(Modifier.weight(1f).fillMaxWidth()
                .then(if (!expanded) Modifier.clearAndSetSemantics { } else Modifier)
                .pointerInput(expanded) {
                    if (!expanded) awaitPointerEventScope {
                        while (true) awaitPointerEvent(PointerEventPass.Initial).changes.forEach { it.consume() }
                    }
                }) {
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth().heightIn(min = 44.dp)
                .background(colors.surfaceVariant, RoundedCornerShape(22.dp)).padding(start = 12.dp),
                verticalAlignment = Alignment.CenterVertically) {
                CyrusIcon(CyrusSymbol.Search, Modifier.size(20.dp), colors.onSurfaceVariant)
                Spacer(Modifier.width(8.dp))
                BasicTextField(query, onQuery, Modifier.weight(1f).padding(vertical = 10.dp)
                    .semantics { contentDescription = "Поиск сервера" },
                    singleLine = true, textStyle = MaterialTheme.typography.bodyMedium.copy(color = colors.onSurface),
                    cursorBrush = Brush.verticalGradient(listOf(colors.primary, colors.primary)),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { focus.clearFocus() }),
                    decorationBox = { input ->
                        Box {
                            if (query.isEmpty()) Text("Поиск сервера…", color = colors.onSurfaceVariant,
                                style = MaterialTheme.typography.bodyMedium, maxLines = 1)
                            input()
                        }
                    })
                IconButton(onClick = { if (query.isNotEmpty()) onQuery("") else onRefresh() },
                    enabled = query.isNotEmpty() || (!state.probing && !state.searching && !state.busy && !state.selecting),
                    modifier = Modifier.size(48.dp).semantics {
                        contentDescription = if (query.isNotEmpty()) "Очистить поиск" else "Обновить задержку серверов"
                    }) {
                    if (state.probing && query.isEmpty()) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 1.5.dp)
                    else CyrusIcon(if (query.isNotEmpty()) CyrusSymbol.Close else CyrusSymbol.Refresh,
                        Modifier.size(18.dp), colors.onSurfaceVariant)
                }
            }
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState,
                contentPadding = PaddingValues(bottom = 12.dp)) {
                if (rows.isEmpty()) item(key = "empty") {
                    Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (state.profiles.isEmpty()) "Пока нет серверов" else "Сервер не найден",
                            style = MaterialTheme.typography.titleMedium)
                        Text(if (state.profiles.isEmpty()) "Добавьте ключ или подписку — серверы появятся здесь."
                            else "Попробуйте другое название страны или ключа.",
                            style = MaterialTheme.typography.bodyMedium, color = colors.onSurfaceVariant)
                        if (state.profiles.isEmpty()) TextButton(onClick = onManage) { Text("Добавить ключ") }
                    }
                }
                items(rows, key = { "server:${it.id}" }, contentType = { "server" }) { profile ->
                    ServerRow(profile, state.latencies[profile.id], selectedId == profile.id,
                        enabled = !state.busy && !state.searching && !state.selecting,
                        probing = state.probing, onClick = { onSelect(profile.id) })
                }
                if (state.profiles.isNotEmpty()) item(key = "actions") {
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        TextButton(onClick = onAuto, enabled = state.canSearch) { Text("Автовыбор") }
                        TextButton(onClick = onManage) { Text("Управление ключами") }
                    }
                    Text("Задержка до сервера, не скорость VPN", color = colors.onSurfaceVariant,
                        style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 10.dp))
                }
            }
            }
        }
    }
}

@Composable
private fun ServerRow(profile: VpnProfile, outcome: ProbeOutcome?, selected: Boolean,
                      enabled: Boolean, probing: Boolean, onClick: () -> Unit) {
    val colors = MaterialTheme.colorScheme
    val region = remember(profile.name) { ServerRegions.fromLabel(profile.name) }
    val rtt = (outcome as? ProbeOutcome.Reachable)?.rttMillis
    val subtitle = when (outcome) {
        is ProbeOutcome.Reachable -> "${outcome.rttMillis} мс"
        is ProbeOutcome.Unreachable -> "Нет ответа"
        ProbeOutcome.NotMeasurable -> "Без замера"
        null -> if (probing) "Замер…" else "— мс"
    }
    val title = region?.title ?: profile.name
    val detail = if (region != null && profile.name != region.title && profile.name != region.code && profile.name != region.flag)
        "${profile.name} · $subtitle" else subtitle
    val shape = RoundedCornerShape(12.dp)
    Row(Modifier.fillMaxWidth().heightIn(min = 48.dp).clip(shape)
        .background(if (selected) colors.surface else Color.Transparent)
        .then(if (selected) Modifier.border(1.dp, colors.primary, shape) else Modifier)
        .selectable(selected, enabled = enabled, role = Role.RadioButton, onClick = onClick)
        .padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        ServerFlag(region, Modifier.size(28.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp, lineHeight = 20.sp, color = colors.onSurface,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(detail, fontSize = 12.sp, lineHeight = 16.sp, color = colors.onSurfaceVariant,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(8.dp))
        SignalBars(rtt, if (selected) colors.primary else colors.onSurfaceVariant)
        Spacer(Modifier.width(22.dp))
        Box(Modifier.size(18.dp)
            .then(if (selected) Modifier.background(colors.primary, CircleShape)
                else Modifier.border(1.5.dp, colors.onSurfaceVariant.copy(alpha = .65f), CircleShape)),
            contentAlignment = Alignment.Center) {
            if (selected) CyrusIcon(CyrusSymbol.Check, Modifier.size(13.dp), colors.onPrimary)
        }
    }
    if (!selected) HorizontalDivider(Modifier.padding(start = 54.dp), color = colors.outlineVariant.copy(alpha = .5f))
}

@Composable
private fun SignalBars(rtt: Long?, tint: Color) {
    val level = when { rtt == null -> 0; rtt < 80 -> 4; rtt < 160 -> 3; rtt < 300 -> 2; else -> 1 }
    Canvas(Modifier.size(18.dp).clearAndSetSemantics { }) {
        val step = size.width / 5f
        repeat(4) { i ->
            drawLine(tint.copy(alpha = if (i < level) 1f else .24f),
                Offset(step * (i + .5f), size.height * .87f),
                Offset(step * (i + .5f), size.height * (.65f - i * .17f)),
                strokeWidth = step * .65f, cap = StrokeCap.Round)
        }
    }
}

/** Deterministic vector flags for the five reference countries; no downloaded assets. */
@Composable
private fun ServerFlag(region: ServerRegion?, modifier: Modifier) {
    val colors = MaterialTheme.colorScheme
    val code = region?.code
    Box(modifier.clip(CircleShape).background(colors.surfaceVariant).clearAndSetSemantics { },
        contentAlignment = Alignment.Center) {
        when (code) {
            "DE", "FR", "NL", "US", "GB" -> Canvas(Modifier.fillMaxSize()) {
                val w = size.width; val h = size.height
                val red = Color(0xFFD91F35); val blue = Color(0xFF1557A8); val white = Color.White
                when (code) {
                    "DE" -> listOf(Color(0xFF141414), red, Color(0xFFFFCE32)).forEachIndexed { i, c ->
                        drawRect(c, Offset(0f, i*h/3), Size(w,h/3+1)) }
                    "NL" -> listOf(red, white, blue).forEachIndexed { i, c ->
                        drawRect(c, Offset(0f,i*h/3),Size(w,h/3+1)) }
                    "FR" -> listOf(blue,white,red).forEachIndexed { i,c ->
                        drawRect(c,Offset(i*w/3,0f),Size(w/3+1,h)) }
                    "US" -> {
                        drawRect(white)
                        repeat(7) { drawRect(red,Offset(0f,it*2*h/13),Size(w,h/13)) }
                        drawRect(blue, size=Size(w*.55f,h*.54f))
                        repeat(4) { y -> repeat(4) { x -> drawCircle(white,w*.022f,Offset(w*(.10f+x*.12f),h*(.07f+y*.12f))) } }
                    }
                    "GB" -> {
                        drawRect(Color(0xFF17396D))
                        drawLine(white,Offset.Zero,Offset(w,h),w*.20f)
                        drawLine(white,Offset(w,0f),Offset(0f,h),w*.20f)
                        drawLine(red,Offset.Zero,Offset(w,h),w*.07f)
                        drawLine(red,Offset(w,0f),Offset(0f,h),w*.07f)
                        drawRect(white,Offset(w*.34f,0f),Size(w*.32f,h))
                        drawRect(white,Offset(0f,h*.34f),Size(w,h*.32f))
                        drawRect(red,Offset(w*.40f,0f),Size(w*.20f,h))
                        drawRect(red,Offset(0f,h*.40f),Size(w,h*.20f))
                    }
                }
                drawCircle(Color.Black.copy(alpha=.12f),style=Stroke(1.dp.toPx()))
            }
            null -> CyrusIcon(CyrusSymbol.Globe, Modifier.size(23.dp), colors.onSurface)
            else -> Text(region?.flag.orEmpty(), fontSize = 24.sp)
        }
    }
}
