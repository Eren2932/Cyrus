package dev.kentra.feature.home

import android.Manifest
import android.app.Activity
import android.net.VpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.currentStateAsState
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.kentra.core.designsystem.*
import dev.kentra.core.ui.CollectEffects
import dev.kentra.core.ui.formatBytes
import dev.kentra.domain.model.TunnelState
import kotlinx.coroutines.launch
import org.koin.androidx.compose.koinViewModel

@Composable
fun HomeRoute(
    onNavigateToProfiles: () -> Unit,
    viewModel: HomeViewModel = koinViewModel(),
    pageActive: Boolean = true,
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    // One initial measurement per loaded endpoint set; no continuous polling timer.
    val endpoints = remember(state.profiles) { state.profiles.map { Triple(it.id, it.server, it.port) } }
    LaunchedEffect(pageActive, endpoints) {
        if (pageActive && endpoints.isNotEmpty() && state.latencies.isEmpty())
            viewModel.dispatch(HomeIntent.RefreshLatency)
    }
    val snackbar = remember { SnackbarHostState() }

    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        viewModel.dispatch(
            if (result.resultCode == Activity.RESULT_OK) HomeIntent.VpnPermissionGranted
            else HomeIntent.VpnPermissionDenied,
        )
    }

    // The service publishes "Отключить" as a notification action. Without
    // POST_NOTIFICATIONS (Android 13+) that notification never reaches the shade,
    // so the only way to stop the tunnel would be to find the app again.
    val scope = rememberCoroutineScope()
    val notificationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted ->
        if (!granted) scope.launch {
            snackbar.showSnackbar("Уведомления запрещены: отключить туннель можно только из приложения")
        }
    }

    CollectEffects(viewModel.effects) { effect ->
        when (effect) {
            HomeEffect.RequestVpnPermission ->
                VpnService.prepare(context)?.let { vpnPermissionLauncher.launch(it) }
                    ?: viewModel.dispatch(HomeIntent.VpnPermissionGranted)
            HomeEffect.RequestNotificationPermission ->
                notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            HomeEffect.NavigateToProfiles -> onNavigateToProfiles()
            is HomeEffect.ShowMessage -> snackbar.showSnackbar(effect.text)
        }
    }

    Scaffold(containerColor = Color.Transparent, contentColor = MaterialTheme.colorScheme.onBackground, contentWindowInsets = WindowInsets(0,0,0,0), snackbarHost = { SnackbarHost(snackbar) }) { padding ->
        HomeContent(
            state = state,
            pageActive = pageActive,
            onToggle = { viewModel.dispatch(HomeIntent.ToggleConnection) },
            onPickProfile = { viewModel.dispatch(HomeIntent.OpenProfiles) },
            onSelectBest = { viewModel.dispatch(HomeIntent.SelectBestServer) },
            onSelectProfile = { viewModel.dispatch(HomeIntent.SelectProfile(it)) },
            onRefreshLatency = { viewModel.dispatch(HomeIntent.RefreshLatency) },
            modifier = Modifier.padding(padding),
        )
    }
}

@Composable
internal fun HomeContent(
    state: HomeState,
    pageActive: Boolean,
    onToggle: () -> Unit,
    onPickProfile: () -> Unit,
    onSelectBest: () -> Unit,
    onSelectProfile: (String) -> Unit,
    onRefreshLatency: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val lifecycle by LocalLifecycleOwner.current.lifecycle.currentStateAsState()
    val active = state.tunnel is TunnelState.Connected
    var expanded by rememberSaveable { mutableStateOf(true) }
    var query by rememberSaveable { mutableStateOf("") }
    val reduced = LocalReducedMotion.current
    val fontScale = LocalDensity.current.fontScale
    val focus = LocalFocusManager.current
    BoxWithConstraints(modifier.fillMaxSize()) {
        // Insets are consumed by the shell. Only the sheet/list changes size;
        // the navigation is outside this layout and cannot be pushed by its rows.
        val keyboardLayout = maxHeight < 360.dp
        val compact = maxHeight < 520.dp || fontScale > 1.3f
        val expandedHeight = when {
            keyboardLayout -> maxHeight
            compact -> (maxHeight - (150.dp + 42.dp * fontScale)).coerceAtLeast(164.dp).coerceAtMost(maxHeight)
            else -> maxHeight * if (fontScale > 1.15f) .60f else .54f
        }
        val collapsedHeight = (34.dp + 38.dp * fontScale).coerceAtLeast(80.dp)
        val sheetHeight by animateDpAsState(
            if (expanded) expandedHeight else collapsedHeight.coerceAtMost(maxHeight),
            tween(if (reduced || keyboardLayout) 0 else CyrusMotion.Screen, easing = CyrusMotion.Ease),
            label = "serverSheetHeight")
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
            if (!keyboardLayout) Box(Modifier.weight(1f).fillMaxWidth()
                .padding(top = if (compact) 0.dp else
                    (maxHeight - sheetHeight - (178.dp + 45.dp * fontScale)).coerceIn(0.dp, 72.dp)),
                contentAlignment = Alignment.Center) {
                Column(Modifier.padding(horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    TacticalCore(
                        label = if (state.selecting) "Переключение…" else state.tunnel.label(),
                        status = when {
                            state.busy || state.selecting || state.searching -> CoreStatus.Busy
                            active -> CoreStatus.Active
                            state.tunnel is TunnelState.Failed -> CoreStatus.Failed
                            else -> CoreStatus.Idle
                        },
                        animate = pageActive && lifecycle == Lifecycle.State.RESUMED,
                        onClick = onToggle, compact = compact,
                    )
                    Spacer(Modifier.height(3.dp))
                    Text(when {
                        state.searching -> state.searchProgress ?: "Выбираем сервер…"
                        state.selecting -> "Подключаем выбранный сервер"
                        active -> if ((state.tunnel as? TunnelState.Connected)?.proxyOnly == true)
                            "Локальный прокси · не весь трафик" else "Вы подключены"
                        state.tunnel is TunnelState.Failed -> "Не удалось подключиться"
                        else -> "Вы не подключены"
                    }, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center,
                        maxLines = if (compact) 1 else 2, overflow = TextOverflow.Ellipsis)
                    if (active && state.traffic.available && !compact) {
                        Spacer(Modifier.height(8.dp))
                        Text("↓ ${state.traffic.downlinkBytes.formatBytes()}    ↑ ${state.traffic.uplinkBytes.formatBytes()}",
                            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else if (!expanded) Spacer(Modifier.weight(1f))
            ServerPanel(state = state, expanded = expanded, query = query,
                bodyVisible = expanded || sheetHeight > collapsedHeight + 1.dp,
                onQuery = { query = it },
                onExpanded = { open -> expanded = open; if (!open) focus.clearFocus() },
                onSelect = { focus.clearFocus(); onSelectProfile(it) },
                onManage = { focus.clearFocus(); onPickProfile() }, onAuto = onSelectBest, onRefresh = onRefreshLatency,
                compactToggle = if (keyboardLayout) onToggle else null,
                modifier = Modifier.fillMaxWidth().height(sheetHeight))
        }
    }
}

private fun TunnelState.label(): String = when (this) {
    TunnelState.Idle -> "Подключить"
    TunnelState.Preparing -> "Подключение…"
    is TunnelState.Connected -> "Отключить"
    TunnelState.Stopping -> "Отключение…"
    is TunnelState.Failed -> "Повторить"
}
