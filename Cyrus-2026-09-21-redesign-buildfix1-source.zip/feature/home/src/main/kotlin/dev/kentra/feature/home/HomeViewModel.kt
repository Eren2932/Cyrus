package dev.kentra.feature.home

import androidx.lifecycle.viewModelScope
import dev.kentra.core.common.AppError
import dev.kentra.core.ui.MviViewModel
import dev.kentra.domain.model.BestServerResult
import dev.kentra.domain.model.SelectionStep
import dev.kentra.domain.model.TunnelState
import dev.kentra.domain.repository.LatencyProber
import dev.kentra.domain.model.ProbeOutcome
import dev.kentra.domain.repository.ProfileRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import dev.kentra.domain.repository.TunnelController
import dev.kentra.domain.usecase.ConnectUseCase
import dev.kentra.domain.usecase.DisconnectUseCase
import dev.kentra.domain.usecase.SelectBestServerUseCase
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch

class HomeViewModel(
    private val profiles: ProfileRepository,
    private val tunnel: TunnelController,
    private val connect: ConnectUseCase,
    private val disconnect: DisconnectUseCase,
    private val selectBestServer: SelectBestServerUseCase,
    /** Whether `POST_NOTIFICATIONS` still has to be asked for. Read at connect time,
     *  because the user can grant or revoke it in system settings at any moment. */
    private val notificationPermissionMissing: () -> Boolean = { false },
    private val latencyProber: LatencyProber? = null,
) : MviViewModel<HomeIntent, HomeState, HomeEffect>(HomeState()) {

    init {
        // Selection is derived, never stored twice: the DB and the active id are the only truth.
        //
        // The `.catch` used to sit *after* `combine`. One error there ends the collection
        // for good: Flow contracts forbid further emissions after a terminal exception, so
        // a single failed read would freeze the home screen at its last known state —
        // and it would never recover, because the DB did not stop working.
        // Each source is caught separately and falls back to an empty view, which keeps
        // the combine alive; the user is told once why the list is empty.
        var storageUnavailable = false
        fun reportStorageFailure() {
            if (storageUnavailable) return
            storageUnavailable = true
            effect(HomeEffect.ShowMessage("Не удалось открыть защищённое хранилище. Данные не удалены."))
        }
        combine(
            profiles.observeProfiles().catch { reportStorageFailure(); emit(emptyList()) },
            profiles.observeActiveProfileId().catch { emit(null) },
        ) { list, activeId ->
            val active = list.firstOrNull { it.id == activeId } ?: list.firstOrNull()
            reduce { copy(activeProfile = active, profileCount = list.size, profiles = list,
                latencies = latencies.filterKeys { id ->
                    val before = this.profiles.firstOrNull { it.id == id }
                    list.any { it.id == id && before != null && it.server == before.server && it.port == before.port && it.protocol == before.protocol }
                }) }
        }.launchIn(viewModelScope)

        tunnel.state
            .onEach { state ->
                reduce {
                    copy(
                        tunnel = state,
                        busy = state is TunnelState.Preparing || state is TunnelState.Stopping,
                    )
                }
                if (state is TunnelState.Failed) effect(HomeEffect.ShowMessage(state.reason))
            }
            .launchIn(viewModelScope)

        tunnel.traffic
            .onEach { sample -> reduce { copy(traffic = sample) } }
            .launchIn(viewModelScope)
    }

    override suspend fun handle(intent: HomeIntent) {
        when (intent) {
            HomeIntent.ToggleConnection -> toggle()
            HomeIntent.VpnPermissionGranted -> toggle()
            HomeIntent.VpnPermissionDenied ->
                effect(HomeEffect.ShowMessage("Без разрешения VPN подключение невозможно"))
            HomeIntent.OpenProfiles -> effect(HomeEffect.NavigateToProfiles)
            HomeIntent.SelectBestServer -> selectBest()
            is HomeIntent.SelectProfile -> selectProfile(intent.id)
            HomeIntent.RefreshLatency -> measureLatency()
            HomeIntent.MessageShown -> reduce { copy(message = null) }
        }
    }

    private fun toggle() {
        val state = currentState
        // A search owns the tunnel while it runs: it dials candidates itself, so a connect
        // pressed in the middle of one would either be thrown away or tear down the
        // candidate being verified - and the user would see a result for a key that was
        // never actually up.
        if (state.busy || state.searching || state.selecting) return
        viewModelScope.launch {
            if (state.tunnel.isActive) {
                disconnect()
                return@launch
            }
            val profile = state.activeProfile
            if (profile == null) {
                effect(HomeEffect.NavigateToProfiles)
                return@launch
            }
            // Ask, but do not wait: the tunnel works without the notification, the user
            // just loses the way to stop it from the shade. Blocking the connection on a
            // permission dialog would trade a working tunnel for a decorous one.
            if (notificationPermissionMissing()) effect(HomeEffect.RequestNotificationPermission)
            connect(profile.id).onFailure { error ->
                when (error) {
                    is AppError.Permission -> effect(HomeEffect.RequestVpnPermission)
                    else -> effect(HomeEffect.ShowMessage(error.message ?: "Не удалось подключиться"))
                }
            }
        }
    }

    private val selectionLock = Mutex()

    /** Idle selection only persists an id; connected selection uses the existing connect use case. */
    private suspend fun selectProfile(id: String) {
        if (!selectionLock.tryLock()) return
        try {
            if (currentState.busy || currentState.searching || currentState.selecting) return
            val live = tunnel.state.value
            if (live is TunnelState.Preparing || live is TunnelState.Stopping) return
            if (id == (live as? TunnelState.Connected)?.profileId) return
            reduce { copy(selecting = true) }
            try {
                if (profiles.getProfile(id) == null) {
                    effect(HomeEffect.ShowMessage("Сервер больше не доступен в списке ключей"))
                } else if (live is TunnelState.Connected) {
                    connect(id).onFailure {
                        effect(HomeEffect.ShowMessage("Не удалось переключить сервер. Проверьте соединение."))
                    }
                } else {
                    profiles.setActiveProfileId(id)
                }
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) { effect(HomeEffect.ShowMessage("Не удалось выбрать сервер")) }
            finally { reduce { copy(selecting = false) } }
        } finally { selectionLock.unlock() }
    }

    private val probeLock = Mutex()

    /** Endpoint RTT only, not a claim about tunnel throughput. Four workers, no unbounded jobs. */
    private suspend fun measureLatency() {
        val prober = latencyProber ?: return
        if (!probeLock.tryLock()) return
        try {
            if (currentState.searching || currentState.busy || currentState.selecting) return
            val list = currentState.profiles
            if (list.isEmpty()) return
            reduce { copy(probing = true) }
            val queue = java.util.concurrent.ConcurrentLinkedQueue(list)
            coroutineScope {
                repeat(minOf(4, list.size)) {
                    launch(Dispatchers.IO) {
                        while (true) {
                            val profile = queue.poll() ?: break
                            val outcome = try { prober.measure(profile, 2000L) }
                            catch (e: CancellationException) { throw e }
                            catch (_: Exception) { ProbeOutcome.Unreachable("Нет ответа") }
                            reduce {
                                // Do not resurrect results for a deleted or changed endpoint.
                                if (this.profiles.any { it.id == profile.id && it.server == profile.server && it.port == profile.port && it.protocol == profile.protocol })
                                    copy(latencies = latencies + (profile.id to outcome)) else this
                            }
                        }
                    }
                }
            }
        } finally {
            reduce { copy(probing = false) }
            probeLock.unlock()
        }
    }

    /**
     * Runs the search and reports it. Progress is pushed into the state because the run can
     * take half a minute and the screen would otherwise show nothing at all; the outcome is
     * a message rather than a silent switch, so the user learns *why* the active key moved.
     */
    private fun selectBest() {
        val state = currentState
        if (state.searching || state.busy || state.selecting) return
        viewModelScope.launch {
            reduce { copy(searching = true, searchProgress = "Замеряю задержку…") }
            selectBestServer()
                .catch { error ->
                    reduce { copy(searching = false, searchProgress = null) }
                    effect(HomeEffect.ShowMessage(error.message ?: "Не удалось выбрать сервер"))
                }
                .collect { step ->
                    when (step) {
                        is SelectionStep.Measuring ->
                            reduce { copy(searchProgress = "Замеряю задержку… ${step.done} из ${step.total}") }
                        is SelectionStep.Verifying ->
                            reduce { copy(searchProgress = "Проверяю «${step.name}» (${step.index} из ${step.total})…") }
                        is SelectionStep.Finished -> {
                            reduce { copy(searching = false, searchProgress = null) }
                            effect(HomeEffect.ShowMessage(step.result.describe()))
                        }
                    }
                }
        }
    }
}

/**
 * What to tell the user after a search. The counts are included on purpose: "не найден"
 * after checking 3 keys and "не найден" after checking 57 are different statements, and
 * the user is the only one who can act on the difference.
 */
private fun BestServerResult.describe(): String = when (this) {
    is BestServerResult.Found ->
        "Выбран «${profile.name}»" + (rttMillis?.let { ", $it мс" } ?: "") +
            if (report.verified > 1) ". Проверено ключей: ${report.verified}." else "."
    is BestServerResult.NotFound ->
        if (report.verified == 0) "Ни один сервер не отвечает: из ${report.considered} ключей доступных нет."
        else "Рабочий сервер не найден: проверено ${report.verified} из ${report.considered}, все отвалились."
    is BestServerResult.NoCandidates ->
        if (report.considered == 0) "Нет ключей для поиска"
        else "Нет пригодных ключей: ${report.rejectedByValidation} из ${report.considered} не собираются ядром."
}
