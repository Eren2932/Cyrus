package dev.kentra.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import dev.kentra.domain.repository.ProfileValidator
import dev.kentra.domain.usecase.ConnectUseCase
import dev.kentra.domain.usecase.DeleteProfileUseCase
import dev.kentra.domain.usecase.DisconnectUseCase
import dev.kentra.domain.usecase.ImportKeysUseCase
import dev.kentra.domain.usecase.SelectBestServerUseCase
import dev.kentra.feature.home.HomeViewModel
import dev.kentra.feature.profiles.ProfilesViewModel
import dev.kentra.feature.store.StoreViewModel
import dev.kentra.vpn.config.ConfigProfileValidator
import org.koin.android.ext.koin.androidContext
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module

/**
 * Use cases and view models live here because :app is the only module allowed to know
 * about every other module. Features stay independent of each other.
 */
val appModule = module {
    single { ImportKeysUseCase(parser = get(), profiles = get()) }
    factory { ConnectUseCase(profiles = get(), tunnel = get()) }
    factory { DisconnectUseCase(tunnel = get()) }
    factory { DeleteProfileUseCase(profiles = get(), tunnel = get()) }
    // :vpn:config knows both cores' rules but not Koin, so the binding is declared here.
    single<ProfileValidator> { ConfigProfileValidator(get()) }
    // A `single`, unlike the other use cases, because it holds the mutex that serialises
    // searches. A `factory` would hand every caller its own mutex and the serialisation -
    // the whole reason the mutex is there - would silently not happen.
    single { SelectBestServerUseCase(profiles = get(), prober = get(), validator = get(), tunnel = get()) }

    viewModel {
        val app = androidContext()
        HomeViewModel(
            profiles = get(),
            tunnel = get(),
            connect = get(),
            disconnect = get(),
            selectBestServer = get(),
            latencyProber = get(),
            notificationPermissionMissing = { notificationPermissionMissing(app) },
        )
    }
    viewModel {
        ProfilesViewModel(
            profiles = get(),
            subscriptions = get(),
            importKeys = get(),
            deleteProfile = get(),
            parser = get(),
            tunnel = get(),
        )
    }
    viewModel { StoreViewModel(billing = get()) }
}

/**
 * `POST_NOTIFICATIONS` exists from Android 13; below that the service notification is
 * shown unconditionally and there is nothing to ask for.
 */
private fun notificationPermissionMissing(context: Context): Boolean =
    Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
        PackageManager.PERMISSION_GRANTED
