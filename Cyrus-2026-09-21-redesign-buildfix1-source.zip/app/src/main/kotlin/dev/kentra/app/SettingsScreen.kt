package dev.kentra.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.core.tween
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import dev.kentra.core.datastore.*
import dev.kentra.core.designsystem.*
import dev.kentra.vpn.config.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(appearance: AppearanceSettings, settings: SettingsStore,
    onProtection: () -> Unit = {}, onApplications: () -> Unit = {}, onStatistics: () -> Unit = {}) {
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val stored by settings.tunnelOptions.collectAsState(initial = null)
    var wizard by rememberSaveable { mutableStateOf(false) }
    var advanced by rememberSaveable { mutableStateOf(false) }
    BackHandler(enabled = wizard) { wizard = false }
    if (wizard) { ServerWizardScreen(onBack = { wizard = false }); return }
    fun save(action: suspend () -> Unit) {
        scope.launch {
            try { action() } catch (e: Exception) {
                if (e is CancellationException) throw e
                snackbar.showSnackbar("Не удалось сохранить: ${e.message ?: "проверьте параметры"}")
            }
        }
    }
    Scaffold(containerColor = androidx.compose.ui.graphics.Color.Transparent, contentColor = MaterialTheme.colorScheme.onBackground,
        contentWindowInsets = WindowInsets(0, 0, 0, 0), snackbarHost = { SnackbarHost(snackbar) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Оформление", style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 8.dp))
            CyrusCard {
                SettingsHeading(CyrusSymbol.Settings, "Внешний вид")
                val modes = ThemeMode.entries
                CyrusSegmented(labels = listOf("Система", "Тёмная", "Светлая"), selectedIndex = modes.indexOf(appearance.theme),
                    onSelect = { save { settings.setTheme(modes[it]) } })
            }
            Text("Управление", style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 8.dp))
            CyrusCard {
                SettingsDestination(CyrusSymbol.Protection, "Защита", "Фильтры, реклама и безопасность", onProtection)
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                SettingsDestination(CyrusSymbol.Apps, "Приложения", "Какие приложения используют VPN", onApplications)
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                SettingsDestination(CyrusSymbol.Statistics, "Статистика", "Трафик и события защиты", onStatistics)
            }
            stored?.let { options -> NetworkSettings(options, advanced, { advanced = !advanced }) { updated -> save {
                settings.setTunnelOptions(updated)
                snackbar.showSnackbar("Сохранено. Настройки применятся при следующем подключении; перед сменой VPN/прокси отключитесь.")
            } } } ?: Text("Чтение настроек…")
            CyrusCard {
                SettingsHeading(CyrusSymbol.Store, "Свой сервер")
                Text("Мастер конфигурации sing-box и команд для Linux VPS. Ничего не выполняет на сервере автоматически.")
                OutlinedButton(onClick = { wizard = true }) { Text("Настроить протокол на VPS") }
            }
        }
    }
}

@Composable
private fun NetworkSettings(initial: TunnelOptions, advanced: Boolean, onAdvanced: () -> Unit, onSave: (TunnelOptions) -> Unit) {
    var mode by rememberSaveable(initial) { mutableStateOf(initial.mode) }
    var port by rememberSaveable(initial) { mutableStateOf(initial.proxyPort.toString()) }
    var mtu by rememberSaveable(initial) { mutableStateOf(initial.mtu.toString()) }
    var stack by rememberSaveable(initial) { mutableStateOf(initial.stack) }
    var ipv6 by rememberSaveable(initial) { mutableStateOf(initial.ipv6) }
    var bypass by rememberSaveable(initial) { mutableStateOf(initial.bypassLan) }
    var mux by rememberSaveable(initial) { mutableStateOf(initial.enableMultiplex) }
    var dns by rememberSaveable(initial) { mutableStateOf(initial.dnsRemote) }
    var localDns by rememberSaveable(initial) { mutableStateOf(initial.dnsLocal) }
    var log by rememberSaveable(initial) { mutableStateOf(initial.logLevel) }
    var appMode by rememberSaveable(initial) { mutableIntStateOf(when(initial.perAppMode) { is PerAppMode.Include -> 1; is PerAppMode.Exclude -> 2; else -> 0 }) }
    var packages by rememberSaveable(initial) { mutableStateOf(when(val p = initial.perAppMode) { is PerAppMode.Include -> p.packages; is PerAppMode.Exclude -> p.packages; else -> emptyList() }.joinToString("\n")) }
    var error by remember { mutableStateOf<String?>(null) }
    CyrusCard {
        SettingsHeading(CyrusSymbol.Globe, "Подключение")
        CyrusSegmented(listOf("VPN", "Прокси"), if (mode == ConnectionMode.VPN) 0 else 1, onSelect = {
            mode = if (it == 0) ConnectionMode.VPN else ConnectionMode.PROXY
        })
        Text(if (mode == ConnectionMode.VPN) "Системный VPN через TUN. Требует согласия Android."
            else "HTTP CONNECT и SOCKS5 на 127.0.0.1. Укажите адрес и порт в нужном приложении. Системный трафик не перехватывается; UDP у HTTP-прокси отсутствует.")
        if (mode == ConnectionMode.PROXY) {
            SettingsField("Локальный порт (1024–65535)", port) { port = it }
            Text("Доступ только с этого устройства, без авторизации. Другие локальные приложения тоже могут использовать этот порт.")
        } else {
            SettingsField("MTU (1280–9000)", mtu) { mtu = it }
            Text("TUN stack")
            val stacks = listOf("system", "gvisor", "mixed")
            CyrusSegmented(stacks, stacks.indexOf(stack).coerceAtLeast(0), onSelect = { stack = stacks[it] })
        }
    }
    SettingsDestination(CyrusSymbol.Settings, "Дополнительные параметры",
        if (advanced) "Свернуть DNS, IPv6 и маршрутизацию" else "DNS, IPv6, Multiplex и журнал", onAdvanced)
    val reduced = LocalReducedMotion.current
    AnimatedVisibility(visible = advanced,
        enter = expandVertically(tween(if (reduced) 0 else CyrusMotion.Screen)),
        exit = shrinkVertically(tween(if (reduced) 0 else CyrusMotion.Screen))) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            CyrusCard {
                SettingSwitch("IPv6 в туннеле", ipv6) { ipv6 = it }
                SettingSwitch("Локальная сеть напрямую", bypass) { bypass = it }
                Text("Блокировка рекламы, трекеров и раздражителей теперь в разделе «Защита».", style = MaterialTheme.typography.labelSmall)
                SettingSwitch("Multiplex (только совместимые серверы)", mux) { mux = it }
                Text("Multiplex не нужен для Vision, Hysteria2 и TUIC. Сервер должен поддерживать выбранный режим.", style = MaterialTheme.typography.labelSmall)
            }
            CyrusCard {
                Text("DNS и журнал", style = MaterialTheme.typography.titleMedium)
                SettingsField("Удалённый DNS", dns) { dns = it }
                SettingsField("DNS для прямых запросов", localDns) { localDns = it }
                Text("Например tls://1.1.1.1. Значение local резолвит через DNS VPN-сети и может сорвать запуск прокси: адрес сервера не разрешится, и туннель поднимется без связи. Содержимое ключей в журнал не выводится.")
                val levels = listOf("warn", "error", "fatal")
                CyrusSegmented(levels, levels.indexOf(log).coerceAtLeast(0), onSelect = { log = levels[it] })
            }
            if (mode == ConnectionMode.VPN) CyrusCard {
                Text("Приложения в VPN", style = MaterialTheme.typography.titleMedium)
                CyrusSegmented(listOf("Все", "Только", "Кроме"), appMode, onSelect = { appMode = it })
                if (appMode != 0) {
                    OutlinedTextField(packages, { packages = it }, modifier = Modifier.fillMaxWidth(), minLines = 3,
                    label = { Text("Package IDs, по одному в строке") })
                    Text("Например org.mozilla.firefox. Указывайте только установленные приложения; неверный ID может помешать запуску VPN.")
                }
            }
        }
    }
    error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    Button(onClick = {
        val updated = initial.copy(mode = mode, proxyPort = port.toIntOrNull() ?: 0, mtu = mtu.toIntOrNull() ?: 0,
            stack = stack, ipv6 = ipv6, bypassLan = bypass, enableMultiplex = mux,
            dnsRemote = dns.trim(), dnsLocal = localDns.trim(), logLevel = log,
            perAppMode = if (mode == ConnectionMode.PROXY || appMode == 0) PerAppMode.Off else {
                val list = packages.lines().map { it.trim() }.filter { it.isNotEmpty() }.distinct()
                if (appMode == 1) PerAppMode.Include(list) else PerAppMode.Exclude(list)
            })
        error = runCatching { updated.validate() }.exceptionOrNull()?.message
        if (error == null) onSave(updated)
    }, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp), shape = RoundedCornerShape(18.dp)) { Text("Сохранить сетевые настройки") }
}

@Composable
private fun SettingsField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(value, onChange, label = { Text(label) }, singleLine = true, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth())
}
@Composable
private fun SettingSwitch(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f)); Switch(value, onChange)
    }
}

@Composable
private fun SettingsHeading(symbol: CyrusSymbol, title: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        CyrusIcon(symbol, Modifier.size(22.dp), MaterialTheme.colorScheme.onSurface)
        Text(title, style = MaterialTheme.typography.titleMedium)
    }
    Spacer(Modifier.height(4.dp))
}

@Composable
private fun SettingsDestination(symbol: CyrusSymbol, title: String, subtitle: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick)
        .heightIn(min = 64.dp).padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(38.dp).background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center) { CyrusIcon(symbol, Modifier.size(22.dp)) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(8.dp))
        CyrusIcon(CyrusSymbol.Arrow, Modifier.size(18.dp), MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
