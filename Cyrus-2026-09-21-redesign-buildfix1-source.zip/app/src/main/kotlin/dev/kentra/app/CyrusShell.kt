package dev.kentra.app

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import dev.kentra.core.datastore.AppearanceSettings
import dev.kentra.core.datastore.ProtectionStatsStore
import dev.kentra.core.datastore.SettingsStore
import dev.kentra.core.designsystem.*
import dev.kentra.feature.home.HomeRoute
import dev.kentra.feature.profiles.ProfilesRoute
import dev.kentra.feature.store.StoreRoute
import dev.kentra.vpn.service.ProtectionCa

private val tabs = listOf(
    CyrusNavigationItem("home", "Главная", CyrusSymbol.Shield),
    CyrusNavigationItem("profiles", "Ключи", CyrusSymbol.Key),
    CyrusNavigationItem("store", "Подписка", CyrusSymbol.Store),
)
private const val ProfilesIndex = 1
private const val StoreIndex = 2
private const val SettingsIndex = 3
private const val ProtectionIndex = 4
private const val ApplicationsIndex = 5
private const val StatisticsIndex = 6
private const val InspectionIndex = 7

/** Immediate selection; no queue, delayed callbacks or navigation back-stack feedback. */
@Composable
fun CyrusShell(
    appearance: AppearanceSettings,
    settings: SettingsStore,
    protectionStats: ProtectionStatsStore,
    protectionCa: ProtectionCa,
) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var settingsOpen by rememberSaveable { mutableStateOf(false) }
    var detail by rememberSaveable { mutableStateOf<Int?>(null) }
    val stateHolder = rememberSaveableStateHolder()
    val reduced = LocalReducedMotion.current
    val overlayOpen = settingsOpen || detail != null
    val primaryTab = tab.coerceIn(0, tabs.lastIndex)
    val target = detail ?: if (settingsOpen) SettingsIndex else primaryTab
    fun closeDetail() {
        if (detail == InspectionIndex) detail = ProtectionIndex
        else if (detail != null) detail = null
        else settingsOpen = false
    }
    BackHandler(enabled = overlayOpen) { closeDetail() }
    BackHandler(enabled = !overlayOpen && tab != 0) { tab = 0 }
    val title = when (target) {
        0 -> ""
        ProfilesIndex -> "Ключи"
        StoreIndex -> "Подписка"
        SettingsIndex -> "Настройки"
        ProtectionIndex -> "Защита"
        ApplicationsIndex -> "Приложения"
        StatisticsIndex -> "Статистика"
        else -> "HTTPS-инспекция"
    }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Scaffold(
            modifier = Modifier.windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Horizontal)),
            containerColor = Color.Transparent, contentColor = MaterialTheme.colorScheme.onBackground,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            topBar = {
                Row(Modifier.fillMaxWidth().windowInsetsPadding(WindowInsets.statusBars)
                    .padding(horizontal = 16.dp).heightIn(min = 48.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (overlayOpen) {
                        IconButton(onClick = { closeDetail() },
                            modifier = Modifier.semantics { contentDescription = "Назад" }) {
                            CyrusIcon(CyrusSymbol.Back)
                        }
                    }
                    Text(title, modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
                    if (!overlayOpen) {
                        IconButton(onClick = { settingsOpen = true },
                            modifier = Modifier.semantics { contentDescription = "Настройки" }) {
                            CyrusIcon(CyrusSymbol.Settings)
                        }
                    }
                }
            },
            bottomBar = {
                // Reserve the same height, but remove hidden hit targets and TalkBack nodes.
                Box(Modifier.fillMaxWidth().navigationBarsPadding()
                    .padding(horizontal = 24.dp).padding(top = 12.dp).height(56.dp),
                    contentAlignment = Alignment.Center) {
                    if (!overlayOpen) CyrusNavigationBar(tabs, tabs[primaryTab].route) { route ->
                        tab = tabs.indexOfFirst { it.route == route }.coerceAtLeast(0)
                    }
                }
            },
        ) { padding ->
            CyrusPagePush(target = target, reduced = reduced,
                modifier = Modifier.padding(padding).consumeWindowInsets(padding).imePadding().fillMaxSize()) { index ->
                stateHolder.SaveableStateProvider(index) {
                    when (index) {
                        ProtectionIndex -> ProtectionScreen(
                            settings = settings,
                            onNavigateToApplications = { detail = ApplicationsIndex },
                            onNavigateToStatistics = { detail = StatisticsIndex },
                            onNavigateToInspection = { detail = InspectionIndex },
                        )
                        ApplicationsIndex -> ApplicationsScreen(settings)
                        ProfilesIndex -> ProfilesRoute()
                        StatisticsIndex -> StatisticsScreen(settings, protectionStats)
                        StoreIndex -> StoreRoute(onImport = { tab = ProfilesIndex })
                        SettingsIndex -> SettingsScreen(appearance, settings,
                            onProtection = { detail = ProtectionIndex },
                            onApplications = { detail = ApplicationsIndex },
                            onStatistics = { detail = StatisticsIndex })
                        InspectionIndex -> InspectionScreen(protectionCa, settings)
                        else -> HomeRoute(onNavigateToProfiles = { tab = ProfilesIndex }, pageActive = target == 0)
                    }
                }
            }
        }
    }
}

/** Full-width push: xIncoming = sign*W*(1-p), xOutgoing = -sign*W*p.
 * Their separation is exactly W for uninterrupted transitions. Compose retargets
 * interrupted motion from its current position. No fade, scale or size animation.
 */
@Composable
internal fun CyrusPagePush(
    target: Int,
    reduced: Boolean,
    modifier: Modifier = Modifier,
    content: @Composable (Int) -> Unit,
) {
    AnimatedContent(
        targetState = target,
        modifier = modifier.clipToBounds(),
        contentAlignment = Alignment.TopStart,
        label = "pagePush",
        transitionSpec = {
            val sign = if (targetState > initialState) 1 else -1
            val duration = if (reduced) 0 else CyrusMotion.Screen
            (slideInHorizontally(tween(duration, easing = CyrusMotion.Ease)) { sign * it } togetherWith
                slideOutHorizontally(tween(duration, easing = CyrusMotion.Ease)) { -sign * it })
                .using(null)
        },
    ) { index ->
        val outgoing = index != target
        Box(Modifier.fillMaxSize()
            .then(if (outgoing) Modifier.clearAndSetSemantics { } else Modifier)
            .pointerInput(outgoing) {
                if (outgoing) awaitPointerEventScope {
                    while (true) awaitPointerEvent(PointerEventPass.Initial).changes.forEach { it.consume() }
                }
            }) { content(index) }
    }
}
