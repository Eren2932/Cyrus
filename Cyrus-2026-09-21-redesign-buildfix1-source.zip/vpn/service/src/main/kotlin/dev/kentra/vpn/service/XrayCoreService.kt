package dev.kentra.vpn.service

import android.app.Service
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Message
import android.os.Messenger
import android.util.Log
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import java.util.concurrent.Executors
import java.lang.reflect.InvocationTargetException

/**
 * Wire contract between [XrayVpnEngine] (the main process) and [XrayCoreService] (`:xray`).
 *
 * Both ends read the same constants, so a rename on one side is a compile error rather
 * than a silent "the helper never answers" on a device.
 */
internal object XrayCoreProtocol {

    const val MSG_RUN = 1
    const val MSG_STOP = 2
    const val MSG_REPLY = 3

    /** Request: the Xray JSON to run. */
    const val KEY_CONFIG = "xray_config"

    /** Reply: non-blank when the helper failed, absent on success. */
    const val KEY_ERROR = "xray_error"

    /** Binding the helper is local IPC; slower than this means the process is not coming up. */
    const val BIND_TIMEOUT_MS = 10_000L

    /**
     * `runXray` builds the whole core. A helper that hangs must fail the session rather
     * than hold the UI in `Preparing` forever.
     */
    const val REPLY_TIMEOUT_MS = 20_000L

    private val json = Json { encodeDefaults = true; explicitNulls = false }

    /**
     * The `runXray` request. Built with the JSON tree builder rather than string
     * concatenation for the same reason the sing-box config is: the payload embeds a whole
     * JSON document as a string, and one unescaped quote is a rejected key on a user's
     * phone.
     */
    fun runRequest(xrayJson: String): String = encode("runXray", xrayJson)

    fun stopRequest(): String = encode("stopXray", null)

    private fun encode(method: String, xrayJson: String?): String = json.encodeToString(
        JsonObject.serializer(),
        buildJsonObject {
            put("apiVersion", 3)
            put("method", method)
            put("payload", buildJsonObject {
                if (xrayJson != null) put("xrayJson", xrayJson)
            })
        },
    )
}

/**
 * Hosts the Xray core in a process of its own.
 *
 * ## Why this service exists
 *
 * `libbox.so` (sing-box) and `libgojni.so` (libXray) each embed a complete Go runtime, and
 * a Go runtime is a singleton by design: it owns the thread-local `g` slot, the signal
 * handlers and the GC's heap metadata. Loading both into one process corrupts that state,
 * and the process is then killed by the runtime itself:
 *
 *     E Go: fatal error: bad sweepgen in refill
 *
 * Measured on device (POCO 2511FPC34G, arm64): the app died 5 ms after
 * `Xray start result: 37 chars`, with **no tombstone at all** — Go's `fatal error` path
 * exits the process directly, which is why this failure never showed up in a crash report
 * and only ever surfaced to the user as a tunnel that "started" and then carried nothing.
 *
 * The two cores also share one Java class. `go.Seq` ships only in `libbox.aar`, and its
 * native methods (`Java_go_Seq_init`, `Java_go_Seq_incGoRef`, …) exist in **both** shared
 * objects, so the JVM binds them to whichever library was loaded first — libbox. In a
 * process that also holds sing-box, `go.Seq` therefore always drives libbox's Go runtime,
 * and every libXray API that passes a Java object (the dialer controller, the listener
 * controller, the process finder) aborts with
 * `CallStaticIntMethod received NULL jclass`.
 *
 * A separate process fixes both: `:xray` loads `libgojni.so` alone, so it gets a runtime
 * entirely its own and a `go.Seq` that binds to it. The main process keeps `libbox.so`
 * alone and never loads `libgojni` — see [XrayVpnEngine], which no longer imports libXray.
 *
 * Android's `addDisallowedApplication("dev.kentra.app")` is per package, so the helper is
 * already excluded from the TUN it feeds and its dial to the proxy server cannot be
 * captured by the tunnel (see `ConfigFactory.selfPackage`).
 */
class XrayCoreService : Service() {

    private var handlerThread: HandlerThread? = null
    private var messenger: Messenger? = null

    /**
     * `runXray` blocks for as long as it takes to build the core. It must not run on the
     * IPC thread, or a `stop` arriving during a slow start would sit behind it in the
     * queue and the teardown would time out.
     */
    private val executor = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "xray-core").apply { isDaemon = true }
    }

    /** True between an accepted `run` and a `stop`, so a stray stop is a no-op. */
    @Volatile
    private var running = false

    // Retain initialization failures so IPC reports them instead of killing the helper.
    private var nativeLoadFailure: Throwable? = null

    override fun onCreate() {
        super.onCreate()
        // Explicit and last-resort: nothing else loads libgojni. `libXray.LibXray` only
        // pulls in `go.Seq`, and that class ships in libbox.aar and loads `libbox.so`.
        // Loading it here — in a method that only the helper process runs, never a static
        // initializer — is what keeps the main process free of the second Go runtime.
        nativeLoadFailure = runCatching { System.loadLibrary("gojni") }
            .onFailure { Log.e(TAG, "Xray native core unavailable: ${it::class.java.simpleName}") }
            .exceptionOrNull()
        val thread = HandlerThread("xray-ipc").also { it.start() }
        handlerThread = thread
        messenger = Messenger(Handler(thread.looper) { message ->
            onRequest(message)
            true
        })
    }

    override fun onBind(intent: Intent?): IBinder? = messenger?.binder

    override fun onDestroy() {
        executor.shutdownNow()
        handlerThread?.quitSafely()
        handlerThread = null
        messenger = null
        super.onDestroy()
    }

    private fun onRequest(message: Message) {
        val replyTo = message.replyTo
        when (message.what) {
            XrayCoreProtocol.MSG_RUN -> {
                val config = message.data?.getString(XrayCoreProtocol.KEY_CONFIG).orEmpty()
                executor.execute {
                    val error = invoke { nativeInvoke(XrayCoreProtocol.runRequest(config)) }
                    if (error == null) running = true
                    reply(replyTo, error)
                }
            }

            XrayCoreProtocol.MSG_STOP -> executor.execute {
                val error = if (running) invoke { nativeInvoke(XrayCoreProtocol.stopRequest()) } else null
                running = false
                reply(replyTo, error)
                // Bound-only: this is reached only if the client asks, and the client
                // unbinds right after. Stopping here keeps the helper's lifetime honest
                // even when the client's unbind is delayed.
                stopSelf()
            }
        }
    }

    private fun nativeInvoke(request: String): String? {
        // The source-ZIP CI bundles libbox only. Resolve the optional Xray binding
        // here, in the isolated helper process, never in the main VPN process.
        // app/proguard-rules.pro keeps libXray.** when the AAR is supplied.
        nativeLoadFailure?.let { throw it }
        return try {
            Class.forName("libXray.LibXray")
                .getMethod("invoke", String::class.java)
                .invoke(null, request) as String?
        } catch (e: InvocationTargetException) {
            // Preserve the native failure type without logging requests or keys.
            throw (e.cause ?: e)
        }
    }

    /**
     * Runs one native call and returns the failure text, or null on success.
     *
     * The native side reports failures *inside* the JSON rather than by throwing, so
     * "invoke returned" is not evidence that Xray started. The response can also echo the
     * request payload, which carries the key: it crosses Binder (same app, same signature)
     * but is never written to logcat — see [XrayVpnEngine].
     */
    private fun invoke(block: () -> String?): String? = try {
        val response = block()
        readNativeError(response)
    } catch (e: Throwable) {
        // Native code also throws Error subclasses (e.g. UnsatisfiedLinkError).
        Log.e(TAG, "Xray helper call failed: ${e::class.java.simpleName}")
        e::class.java.simpleName
    }

    private fun reply(replyTo: Messenger?, error: String?) {
        if (replyTo == null) return
        val data = Bundle().apply {
            if (error != null) putString(XrayCoreProtocol.KEY_ERROR, error)
        }
        runCatching { replyTo.send(Message.obtain(null, XrayCoreProtocol.MSG_REPLY).apply { this.data = data }) }
            .onFailure { Log.w(TAG, "helper reply dropped: ${it::class.java.simpleName}") }
    }

    /**
     * Extracts the failure text from a libXray response, or null on success.
     *
     * The response shape is `{"success": …, "error": …}`, optionally nested under
     * `"result"`. Parsing is best-effort: a response we cannot read is treated as success
     * rather than blocking every session on a shape change, which would be a worse failure
     * than the one being guarded against.
     */
    private fun readNativeError(response: String?): String? {
        if (response.isNullOrBlank()) return null
        return runCatching {
            val root = org.json.JSONObject(response)
            root.optString("error").takeIf { it.isNotBlank() }
                ?: root.optJSONObject("error")?.optString("message")?.takeIf { it.isNotBlank() }
                ?: root.optJSONObject("result")?.optString("error")?.takeIf { it.isNotBlank() }
                ?: root.optString("success").takeIf { it.equals("false", ignoreCase = true) }
        }.getOrNull()
    }

    private companion object {
        const val TAG = "XrayCoreService"
    }
}
