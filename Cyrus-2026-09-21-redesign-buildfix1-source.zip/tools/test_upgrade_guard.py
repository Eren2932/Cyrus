#!/usr/bin/env python3
"""Checks that source guards reject deliberate regressions; not application runtime tests."""
from pathlib import Path
import os, subprocess, sys, tempfile
from guard_support import copy_tree
R=Path(__file__).resolve().parents[1]
service='vpn/service/src/main/kotlin/dev/kentra/vpn/service/'
config='vpn/config/src/main/kotlin/dev/kentra/vpn/config/ConfigFactory.kt'
ui='feature/profiles/src/main/kotlin/dev/kentra/feature/profiles/'
mutations=[
 ('public proxy listener',config,'listen = "127.0.0.1"','listen = "0.0.0.0"'),
 ('unsupported sing-box multimode accepted',config,'require(q["mode"] in listOf(null, "", "gun"))','require(true)'),
 ('unjoined old tunnel',service+'TunnelServiceRunner.kt','tunnelJob?.cancelAndJoin()','tunnelJob?.cancel()'),
 ('raw native error shown',service+'TunnelServiceRunner.kt','var failure: String? = null','var failure: String? = null\n// error.message'),
 ('proxy asks for VPN consent',service+'TunnelControllerImpl.kt','options.mode == ConnectionMode.VPN && VpnService.prepare(context)','VpnService.prepare(context)'),
 ('QR image written to storage',ui+'ProfilesScreen.kt','setBarcodeImageEnabled(false)','setBarcodeImageEnabled(true)'),
 ('editor window no longer protected',ui+'ProfileEditor.kt','SecureFlagPolicy.SecureOn','SecureFlagPolicy.Inherit'),
 ('unknown stats shown as zero','feature/home/src/main/kotlin/dev/kentra/feature/home/HomeScreen.kt','active && state.traffic.available','active'),
 ('socket protection failure ignored',service+'LibboxVpnEngine.kt','Не удалось защитить сокет','ignore failure'),
 ('proxy port not saved','core/datastore/src/main/kotlin/dev/kentra/core/datastore/SettingsStore.kt','prefs[Keys.proxyPort] = options.proxyPort','// removed proxy port write'),
]
with tempfile.TemporaryDirectory() as d:
 root=Path(d)/'Cyrus';copy_tree(R,root)
 env={**os.environ,'CYRUS_CHECK_ROOT':str(root)}
 def run():return subprocess.run([sys.executable,str(R/'tools/check_upgrade.py')],env=env,capture_output=True,text=True)
 assert run().returncode==0,'Unmodified source guard failed'
 for name,path,old,new in mutations:
  p=root/path;s=p.read_text();assert old in s,name;p.write_text(s.replace(old,new))
  try:assert run().returncode!=0,'Guard failed to detect '+name
  finally:p.write_text(s)
  print('PASS rejected:',name)
print(f'{len(mutations)} source mutation tests passed; Kotlin/native/device tests not executed.')
