#!/usr/bin/env python3
"""Offline design regression gate. No Android/compiler/performance claims.
Uses actual Kotlin token/role values. Asset bounds are trusted ONLY when their
SHA256 matches the audited images; changing an image requires a new pixel audit.
"""
from pathlib import Path
import re, math, hashlib, json
R = Path(__file__).resolve().parents[1]
T = (R/'core/designsystem/src/main/kotlin/dev/kentra/core/designsystem/Theme.kt').read_text()
C = (R/'core/designsystem/src/main/kotlin/dev/kentra/core/designsystem/Components.kt').read_text()
N = (R/'app/src/main/kotlin/dev/kentra/app/CyrusShell.kt').read_text()
P = (R/'feature/home/src/main/kotlin/dev/kentra/feature/home/ServerPanel.kt').read_text()
H = (R/'feature/home/src/main/kotlin/dev/kentra/feature/home/HomeScreen.kt').read_text()
checks = 0
ratios = []
def check(ok, message):
    global checks
    if not ok: raise AssertionError(message)
    checks += 1

def color(hex):
    v = int(hex,16)
    check(v >> 24 == 255, 'Audited role must be opaque: '+hex)
    return tuple((v >> s & 255)/255 for s in (16,8,0))
tokens = {k:color(v) for k,v in re.findall(r'val (\w+) = Color\(0x([A-Fa-f0-9]{8})\)', T)}
def resolve(expr):
    if expr.startswith('CyrusTokens.'): return tokens[expr.split('.')[1]]
    if expr == 'Color.Transparent': return (0,0,0)  # excluded from contrast pairs
    if expr == 'Color.White': return (1,1,1)
    return color(re.fullmatch(r'Color\(0x([A-Fa-f0-9]{8})\)',expr)[1])
def scheme(name):
    body = T.split('val '+name+' = ',1)[1].split('\n)',1)[0]
    return {k:resolve(v) for k,v in re.findall(r'(\w+)\s*=\s*(CyrusTokens\.\w+|Color\(0x[0-9A-Fa-f]{8}\)|Color\.\w+)',body)}
def lum(rgb):
    channels=[c/12.92 if c<=.04045 else ((c+.055)/1.055)**2.4 for c in rgb]
    return sum(a*b for a,b in zip(channels,(.2126,.7152,.0722)))
def contrast(a,b):
    x,y=sorted((lum(a),lum(b)))
    return (y+.05)/(x+.05)
def pair(label,fg,bg,threshold):
    ratio=contrast(fg,bg);ratios.append((label,ratio,threshold))
    check(ratio>=threshold,f'{label}: {ratio:.4f} < {threshold}')
for name in ('DarkScheme','LightScheme'):
    s=scheme(name)
    for a,b in [('onBackground','background'),('onSurface','surface'),('onSurfaceVariant','surfaceVariant'),
                ('onPrimary','primary'),('onPrimaryContainer','primaryContainer'),('onSecondary','secondary'),
                ('onSecondaryContainer','secondaryContainer'),('onError','error'),('onErrorContainer','errorContainer'),
                ('inverseOnSurface','inverseSurface')]:
        pair(name+' '+a+'/'+b,s[a],s[b],4.5)
    for bg in ('surface','surfaceContainer','surfaceContainerHigh','surfaceContainerHighest'):
        for fg in ('onSurface','onSurfaceVariant','primary','error'):
            pair(name+' '+fg+'/'+bg,s[fg],s[bg],4.5)
    pair(name+' control outline',s['outline'],s['surface'],3)
    body = tokens['CoreDark' if name=='DarkScheme' else 'CoreLight']
    for fg in ('onBackground','primary','error'):
        pair(name+' core '+fg,s[fg],body,3)
pair('Selected bar/segment/FAB foreground',tokens['OnAccent'],tokens['Accent'],4.5)
check('CyrusWallpaper(' not in N, 'Decorative wallpaper returned')
check('.background(MaterialTheme.colorScheme.background)' in N, 'Solid background missing')
check('0 -> ""' in N, 'Home brand title returned')
check('val Ink = Color(0xFF000000)' in T, 'Canvas must be true black')
check('CyrusSymbol.Globe, Modifier.size(26.dp), colors.onSurface' in P, 'Globe must be neutral, not orange')
check('LazyColumn(' in P and 'key = { "server:${it.id}" }' in P, 'Bounded keyed list missing')
check('if (bodyVisible)' in P and 'if (!expanded) Modifier.clearAndSetSemantics' in P and 'rememberLazyListState()' in P, 'Collapsed list state/hidden targets regressed')
check('rememberSaveable' in H and 'serverSheetHeight' in H, 'Sheet state/animation missing')
check('compactToggle = if (keyboardLayout) onToggle else null' in H, 'Compact layout lost connect action')
check('imePadding()' in N, 'Keyboard insets missing')
# All transparent Scaffold sites must carry an explicit foreground.
for p in R.rglob('*.kt'):
    if '/src/main/' not in str(p): continue
    text=p.read_text()
    for match in re.finditer(r'containerColor\s*=\s*(?:androidx\.compose\.ui\.graphics\.)?Color.Transparent,',text):
        check(bool(re.match(r'\s*contentColor\s*=\s*MaterialTheme.colorScheme.onBackground',text[match.end():])),str(p)+' transparent foreground missing')
check('LocalContentColor provides MaterialTheme.colorScheme.onBackground' in T,'Theme foreground fallback missing')
check('android:forceDarkAllowed">false' in (R/'app/src/main/res/values-v29/themes.xml').read_text(),'Force dark opt-out missing')
# API 29 attribute in the unqualified folder is a lint NewApi error at minSdk 24.
check('android:forceDarkAllowed">false' not in (R/'app/src/main/res/values/themes.xml').read_text(),'Force dark opt-out must stay in values-v29')
bar=C.split('fun CyrusNavigationBar',1)[1].split('/** Three-way segmented',1)[0]
check('Brush' not in bar and '.background(pill,' in bar,'Bar must use flat fill')
check('drawCircle(ring, radius' in C and 'val bracket = ring' not in C,'Core boundary opacity regressed')
check('active && animate && !reduced' in C and 'if (!busy && animate' not in C,'Idle infinite animation returned')
check('rememberSaveableStateHolder()' in N,'Page scroll state restoration missing')
check('if (!overlayOpen) CyrusNavigationBar' in N,'Invisible bar hit targets returned')
page=N.split('internal fun CyrusPagePush',1)[1]
for expected in ['slideInHorizontally','slideOutHorizontally','{ sign * it }','{ -sign * it }','.using(null)','clipToBounds()', 'clearAndSetSemantics', 'PointerEventPass.Initial']:
    check(expected in page,'Page contract missing '+expected)
check('fadeIn' not in page and 'fadeOut' not in page,'Page cross-fade returned')
check(page.count('tween(duration, easing = CyrusMotion.Ease)')==2,'Page motion specs must match')
# Geometric invariant, both directions and multiple viewport widths/progresses.
for width in (320,360,412,600,1080):
    for sign in (-1,1):
        for frame in range(1001):
            p=frame/1000
            incoming=sign*width*(1-p);outgoing=-sign*width*p
            check(math.isclose(incoming-outgoing,sign*width,abs_tol=1e-9),'Push seam geometry')
for label,ratio,minimum in ratios: print(f'CONTRAST {label}: {ratio:.4f}:1 (min {minimum})')
print(f'PASS design gate: {checks} assertions, {len(ratios)} contrast pairs. No device/FPS claim.')
