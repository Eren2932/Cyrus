#!/usr/bin/env python3
"""Offline source invariants. Not a Kotlin compiler, Android lint or runtime test suite."""
from pathlib import Path
import fnmatch
import os
import re
import sys
import tomllib
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
passed=[]
def check(name, condition):
    if not condition: raise AssertionError(name)
    passed.append(name)
def text(path):return (ROOT/path).read_text(encoding='utf-8')

# Read once: `tracked()` consults this for every directory it walks.
GITIGNORE_PATTERNS = [
    line.strip() for line in text('.gitignore').splitlines()
]

def delimiters(source):
    """Check Kotlin delimiter nesting, respecting comments, strings and interpolation."""
    n=len(source)
    def string(i, quote):
        i+=len(quote)
        while i<n:
            if source.startswith(quote,i):return i+len(quote)
            if quote!='"""' and source[i]=='\\':i+=2;continue
            if quote!="'" and source.startswith('${',i):i=code(i+2,'}');continue
            i+=1
        raise AssertionError('Unclosed string')
    def code(i,end=None):
        while i<n:
            if source.startswith('//',i):
                j=source.find('\n',i);i=n if j<0 else j+1;continue
            if source.startswith('/*',i):
                depth=1;i+=2
                while i<n and depth:
                    if source.startswith('/*',i):depth+=1;i+=2
                    elif source.startswith('*/',i):depth-=1;i+=2
                    else:i+=1
                if depth:raise AssertionError('Unclosed comment')
                continue
            # Backtick-quoted identifier: `fun \`it's a test\`()`. Its contents are an
            # identifier, not code, so nothing inside may be scanned - a quote or an
            # apostrophe in there would otherwise open a string that never closes and
            # fail this check on perfectly valid Kotlin.
            if source.startswith('`',i):
                j=source.find('`',i+1)
                i=n if j<0 else j+1
                continue
            if source.startswith('"""',i):i=string(i,'"""');continue
            ch=source[i]
            if ch in ['"',"'"]:i=string(i,ch);continue
            if ch in '([{':i=code(i+1,{'(':')','[':']','{':'}'}[ch]);continue
            if ch in ')]}':
                if ch!=end:raise AssertionError(f'Unexpected {ch} at offset {i}, expected {end}')
                return i+1
            i+=1
        if end:raise AssertionError(f'Missing {end}')
        return i
    code(0)

def gitignore_ignored(path):
    """True when the repository's .gitignore would ignore this path.

    Only the pattern shapes this repository uses are handled: directory patterns
    ending in '/' and bare globs such as '*.apk' that match at any depth. This is
    what keeps build output from failing the packaged-APK check.
    """
    relative = path.relative_to(ROOT)
    parts = relative.parts
    for pattern in GITIGNORE_PATTERNS:

        if not pattern or pattern.startswith('#') or pattern.startswith('!'):
            continue
        if pattern.endswith('/'):
            if pattern.rstrip('/') in parts:
                return True
        elif '/' not in pattern and fnmatch.fnmatch(relative.name, pattern):
            return True
    return False

def tracked(suffix):
    """Files ending in `suffix` that .gitignore would keep.

    Gradle writes empty or half-written XML into `build/` (for example
    `lint_partial_results/.../lint-resources.xml`) and copies sources there too.
    Those are generated artefacts, not sources, and parsing them makes the guard
    fail on a tree that merely happens to have been built.

    Directories are pruned during the walk rather than filtered afterwards: the
    build tree holds hundreds of thousands of files, and walking all of them just
    to discard them is what made this script too slow to run after a build.
    """
    out = []
    for dirpath, dirnames, filenames in os.walk(ROOT):
        dirnames[:] = [
            d for d in dirnames
            if not gitignore_ignored(Path(dirpath) / d)
        ]
        out.extend(Path(dirpath) / f for f in filenames if f.endswith(suffix))
    return [p for p in out if not gitignore_ignored(p)]

kt=tracked('.kt')
check('Kotlin sources are present',bool(kt))
for f in kt:
    try:delimiters(f.read_text())
    except AssertionError as e:raise AssertionError(f'{f.relative_to(ROOT)}: {e}') from e
check('Kotlin lexical delimiter balance',True)
xml=tracked('.xml')
check('Android XML resources are present',bool(xml))
for f in xml:ET.parse(f)
check('All Android XML parses',True)
tomllib.loads(text('gradle/libs.versions.toml'))
check('Version catalogue parses',True)
modules=re.findall(r'include\("(:[^\"]+)"\)',text('settings.gradle.kts'))
check('Gradle modules are declared',bool(modules))
check('Every included Gradle module exists',all((ROOT/m.strip(':').replace(':','/')/'build.gradle.kts').exists() for m in modules))
main='\n'.join(f.read_text() for f in kt if '/src/main/' in str(f))
check('No hard Kotlin keyword variable names',not re.search(r'\b(?:val|var)\s+(?:import|class|object|when|fun|is|in|return|break|continue|interface|package|this|super)\b',main))
check('No simulator implementation in production','class SimulatedVpnEngine' not in main and all('kotlin.random.Random' not in f.read_text() for f in kt if '/feature/' in str(f) and '/src/main/' in str(f)))
check('No fake billing repository','StubBillingRepository' not in main)
check('No phase-4 UI placeholders',not re.search(r'этап[ае]?\s*4|phase\s*4',main,re.I))
check('Brand orange preserved','0xFFFF7908' in text('core/designsystem/src/main/kotlin/dev/kentra/core/designsystem/Theme.kt'))
check('Brand foreground preserved','0xFF1B0C00' in main)
check('Application identity preserved','applicationId = "dev.kentra.app"' in text('app/build.gradle.kts'))
check('Database identity preserved','"kentra.db"' in text('core/database/src/main/kotlin/dev/kentra/core/database/CyrusDatabase.kt'))
check('Backups disabled','android:allowBackup="false"' in text('app/src/main/AndroidManifest.xml'))
check('Cleartext network disabled','android:usesCleartextTraffic="false"' in text('app/src/main/AndroidManifest.xml'))
check('Release is not debug signed','signingConfig = signingConfigs.getByName("debug")' not in text('app/build.gradle.kts'))
check('Android Keystore and authenticated encryption','AES/GCM/NoPadding' in main and 'updateAAD' in main and 'AndroidKeyStore' in main)
check('Cancellation is rethrown',bool(re.search(r'catch\s*\([^)]*CancellationException[^)]*\)\s*\{\s*throw\b', text('core/common/src/main/kotlin/dev/kentra/core/common/AppError.kt'))))
check('Subscription replacement is transactional','db.withTransaction' in text('data/src/main/kotlin/dev/kentra/data/SubscriptionRepositoryImpl.kt'))
check('Subscription redirects disabled','followRedirects = false' in text('core/network/src/main/kotlin/dev/kentra/core/network/HttpClientFactory.kt'))
check('Native start precedes connected event',text('vpn/service/src/main/kotlin/dev/kentra/vpn/service/TunnelServiceRunner.kt').index('engine.start(')<text('vpn/service/src/main/kotlin/dev/kentra/vpn/service/TunnelServiceRunner.kt').index('bus.publish(TunnelState.Connected'))
check('Original link survives storage mapping','rawLink = profile.rawLink' in main and 'rawLink = transport.rawLink' in main)
activity = text('app/src/main/kotlin/dev/kentra/app/MainActivity.kt')
profiles_ui = text('feature/profiles/src/main/kotlin/dev/kentra/feature/profiles/ProfilesScreen.kt')
home_ui = text('feature/home/src/main/kotlin/dev/kentra/feature/home/HomeScreen.kt')
components = text('core/designsystem/src/main/kotlin/dev/kentra/core/designsystem/Components.kt')
settings = text('core/datastore/src/main/kotlin/dev/kentra/core/datastore/SettingsStore.kt')
nav = text('app/src/main/kotlin/dev/kentra/app/CyrusShell.kt')
check('Ordinary Activity is screenshot-capable', 'FLAG_SECURE' not in activity and 'setRecentsScreenshotEnabled(false)' not in main)
check('Credential import window is protected', 'ModalBottomSheetProperties(securePolicy = SecureFlagPolicy.SecureOn)' in profiles_ui)
check('Credential details window is protected', 'DialogProperties(securePolicy=SecureFlagPolicy.SecureOn)' in profiles_ui)
check('Both sensitive windows opt in explicitly', profiles_ui.count('SecureFlagPolicy.SecureOn') == 2)
check('Full VPN configuration is not logged', 'Starting with config:' not in main)
theme = text('core/designsystem/src/main/kotlin/dev/kentra/core/designsystem/Theme.kt')
check('Matte black and warm white palettes present', all(c in theme for c in ['0xFF000000','0xFFF4F5F5','0xFFF7F7F3','0xFF17171A']))
check('No blue-cast greys left in the dark palette', all(c not in theme for c in ['0xFF111827','0xFF232D3E','0xFF485264']))
check('Theme choice is persistent under the original key', all(x in settings for x in ['appearance_theme','suspend fun setTheme']))
check('Removed appearance settings are really gone', all(x not in settings for x in ['appearance_wallpaper','appearance_reduced_motion','setWallpaper','setReducedMotion']))
check('Connect control is the Tactical Core', all(x in components for x in ['fun TacticalCore(', 'enum class CoreStatus', 'Brush.sweepGradient', 'rotate(spin.value']))
check('Continuous animation is busy-only, route-aware and reduced-motion aware', 'busy && animate && !reduced' in components)
check('Core animation values are read in draw/layer scopes only', all(x in components for x in ['graphicsLayer {', 'press.value', 'engaged.value']))
check('Bar slots are fixed and contain no delayed relayout', 'Modifier.weight(1f)' in components and 'delay(' not in components and 'expandHorizontally(' not in components)
check('Bar indicator uses the brand accent, not white', 'val pill = CyrusTokens.Accent' in components and 'CyrusTokens.OnAccent' in components)
check('Screen state is immediate, not read back from a navigation back stack', all(x not in nav for x in ['NavHost(','nav.navigate(','rememberNavController']) and 'rememberSaveable' in nav and 'BackHandler' in nav)
check('Back always has a way home', nav.count('BackHandler(enabled') == 2)
check('Theme retained and network settings explicitly saved', all(x in text('app/src/main/kotlin/dev/kentra/app/SettingsScreen.kt') for x in ['CyrusSegmented(', 'Switch(', 'settings.setTunnelOptions(updated)', 'updated.validate()']))
check('Background route cannot run contour animation', 'lifecycle == Lifecycle.State.RESUMED' in home_ui)
check('Home action reflects actual tunnel state', all(x in home_ui for x in ['TunnelState.Preparing', 'TunnelState.Stopping', 'TunnelState.Connected', 'state.tunnel.label()']))
check('No stale core warning or promotional headings', 'VPN-ядро не установлено' not in home_ui and 'SectionHeading(' not in main)
check('Existing three primary tabs preserved', nav.count('CyrusNavigationItem(') == 3)
check('Navigation-compose dependency dropped with the back stack', 'navigation.compose' not in text('app/build.gradle.kts'))
check('Only real traffic counters, no reference ping/jitter/loss added', 'downlinkBytes.formatBytes()' in home_ui and 'uplinkBytes.formatBytes()' in home_ui and 'Jitter' not in home_ui)
check('No decorative wallpaper rendered or packaged', 'CyrusWallpaper(' not in nav and not list((ROOT/'app/src/main/res/drawable-nodpi').glob('wallpaper_camo*.webp')))
check('Root uses a solid theme background', '.background(MaterialTheme.colorScheme.background)' in nav)
check('Home exposes real saved servers', 'ServerPanel(' in home_ui and 'onSelectProfile' in home_ui)
check('No packaged APK accidentally included in source tree',not [p for p in ROOT.rglob('*.apk') if not gitignore_ignored(p)])
for name in passed:print('PASS',name)
print(f'\n{len(passed)} source checks passed; {len(kt)} Kotlin files; {len(modules)} modules.')
print('NOT RUN: Kotlin compilation, JUnit, Android lint, emulator/device, VPN/DNS tests.')

# Required on every source check, including the existing ZIP build workflow.
import subprocess
subprocess.run([sys.executable, str(ROOT/'tools/check_design.py')], check=True)
subprocess.run([sys.executable, str(ROOT/"tools/test_design_guard.py")], check=True)

# Merge-specific source guards preserve backend fixes alongside the visual guards.
subprocess.run([sys.executable, str(ROOT/'tools/check_merge.py')], check=True)
subprocess.run([sys.executable, str(ROOT/'tools/test_merge_guard.py')], check=True)
subprocess.run([sys.executable, str(ROOT/"tools/test_native_guard.py")], check=True)

subprocess.run([sys.executable, str(ROOT/"tools/check_upgrade.py")], check=True)
subprocess.run([sys.executable, str(ROOT/"tools/test_upgrade_guard.py")], check=True)

# Regression guards for the Service/VpnService compilation repair and CI inputs.
subprocess.run([sys.executable, str(ROOT/'tools/check_buildfix.py')], check=True)
subprocess.run([sys.executable, str(ROOT/'tools/test_buildfix_guard.py')], check=True)
