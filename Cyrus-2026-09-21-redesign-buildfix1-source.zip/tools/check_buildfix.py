#!/usr/bin/env python3
"""Narrow source regression guards. NOT Kotlin compilation or runtime tests."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
ENGINE = 'vpn/service/src/main/kotlin/dev/kentra/vpn/service/LibboxVpnEngine.kt'
CONFIG_BUILD = 'vpn/config/build.gradle.kts'
ZIP_WORKFLOW = 'docs/workflows/build-zip.yml'
SOURCE_WORKFLOW = '.github/workflows/android.yml'
BASE_THEME = 'app/src/main/res/values/themes.xml'
V29_THEME = 'app/src/main/res/values-v29/themes.xml'
SHELL = 'app/src/main/kotlin/dev/kentra/app/CyrusShell.kt'
APP_BUILD = 'app/build.gradle.kts'


def validate(root=ROOT):
    text = lambda path: (root / path).read_text(encoding='utf-8')
    engine = text(ENGINE)
    start = engine.index('override fun autoDetectInterfaceControl(fd: Int)')
    end = engine.index('override fun usePlatformAutoDetectInterfaceControl()', start)
    callback = engine[start:end]
    checks = {
        'VPN-only API captured in explicitly typed local':
            'val vpnService: VpnService = vpn as? VpnService ?: return' in callback,
        'Protection uses typed receiver and Boolean result':
            'val protected: Boolean = runCatching { vpnService.protect(fd) }.getOrDefault(false)' in callback,
        'Protection failure aborts callback':
            bool(re.search(r'if\s*\(!protected\)\s*\{\s*error\("Не удалось защитить сокет VPN от петли маршрутизации"\)', callback)),
        'No stale Service.protect expression': 'vpn.protect(fd)' not in callback,
        'Native callback remains enabled':
            'override fun usePlatformAutoDetectInterfaceControl(): Boolean = true' in engine,
        'Proxy cannot create TUN':
            'vpn as? VpnService ?: error("TUN запрещён в режиме прокси")' in engine,
        'Native fixtures registered as Gradle outputs':
            'outputs.dir(layout.buildDirectory.dir("native-fixtures"))' in text(CONFIG_BUILD),
        'Server fixtures registered as Gradle outputs':
            'outputs.dir(layout.buildDirectory.dir("server-script-fixtures"))' in text(CONFIG_BUILD),
    }
    parser_test = text('vpn/link/src/test/kotlin/dev/kentra/vpn/link/DefaultLinkParserTest.kt')
    import_tests = text('vpn/link/src/test/kotlin/dev/kentra/vpn/link/UpgradeImportTest.kt')
    checks['Garbage test rejects unsupported input, not valid HTTPS proxies'] = (
        'assertNull(parser.parse("https://example.com"))' not in parser_test
        and 'assertNull(parser.parse("unsupported://example.com"))' in parser_test
        and 'assertEquals(0, parser.parseMany("hello world").size)' in parser_test
    )
    checks['Positive anonymous HTTPS regression is retained'] = (
        'anonymous HTTPS endpoint is a TLS proxy not garbage' in import_tests
        and 'requireNotNull(parser.parse("https://example.com"))' in import_tests
    )
    checks['Subscription URL and invalid proxy regressions are retained'] = all(
        name in import_tests for name in (
            'subscription URL is rejected by single proxy parser and reported by key importer',
            'HTTPS proxy malformed authority and credentials are rejected',
            'HTTPS proxy survives canonical export without credentials',
        )
    )
    checks['Network request declares its normal permission'] = (
        'android.permission.CHANGE_NETWORK_STATE' in text('vpn/service/src/main/AndroidManifest.xml')
    )
    checks['API 26 Handler overload has an API 24 compatible fallback'] = bool(re.search(
        r'if \(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O\) \{\s*'
        r'val handlerThread = android.os.HandlerThread.*?'
        r'cm.requestNetwork\(request, defaultNetworkCallback!!, handler\).*?'
        r'\} else \{.*?cm.requestNetwork\(request, defaultNetworkCallback!!\)', engine, re.S
    ))
    runner = text('vpn/service/src/main/kotlin/dev/kentra/vpn/service/TunnelServiceRunner.kt')
    checks['Connected notification updates the existing foreground service'] = (
        'service.startForeground(notificationId, notification(true))' in runner
        and '.notify(notificationId, notification(true))' not in runner
    )
    zip_workflow = text(ZIP_WORKFLOW)
    go_step = zip_workflow.split('- name: Set up matching Go toolchain\n', 1)[1].split('\n      - name:', 1)[0]
    checks['Go pin is unconditional for native validation'] = (
        not re.search(r'^\s*if:', go_step, re.M)
        and 'go-version: ${{ env.GO_VERSION }}' in go_step
    )
    # Lint runs with abortOnError, so a lint error is a build failure, not advice.
    base_theme = text(BASE_THEME)
    v29_theme = text(V29_THEME)
    item = '<item name="android:forceDarkAllowed">false</item>'
    checks['API 29 force-dark opt-out is out of the unqualified values folder'] = item not in base_theme
    checks['API 29 force-dark opt-out is kept in values-v29'] = item in v29_theme
    # Styles do not merge across qualifiers: the v29 copy must repeat every base item.
    base_items = re.findall(r'<item name="([^"]+)">([^<]*)</item>', base_theme)
    v29_items = re.findall(r'<item name="([^"]+)">([^<]*)</item>', v29_theme)
    checks['values-v29 theme repeats every base item'] = set(base_items) <= set(v29_items)
    checks['values-v29 theme adds only the force-dark opt-out'] = (
        set(v29_items) - set(base_items) == {('android:forceDarkAllowed', 'false')}
    )
    checks['Both theme variants keep the same parent'] = (
        base_theme.count('parent="android:Theme.Material.NoActionBar"') == 1
        and v29_theme.count('parent="android:Theme.Material.NoActionBar"') == 1
    )
    shell = text(SHELL)
    checks['Redesigned canvas does not decode a wallpaper'] = 'CyrusWallpaper(' not in shell
    checks['Solid canvas background retained'] = '.background(MaterialTheme.colorScheme.background)' in shell
    app_build = text(APP_BUILD)
    checks['Lint still fails the build on errors'] = 'abortOnError = true' in app_build
    checks['Lint prints every error to the CI console'] = (
        'textReport = true' in app_build and 'textOutput = file("stdout")' in app_build
    )
    for workflow in (ZIP_WORKFLOW, SOURCE_WORKFLOW):
        source = text(workflow)
        compile_step = source.find(':app:compileDebugKotlin :app:compileReleaseKotlin')
        test_step = source.index('- name: Mandatory unit tests' if workflow == ZIP_WORKFLOW else '- name: Unit tests')
        checks['Both variants compiled before tests in ' + workflow] = 0 <= compile_step < test_step
    for name, ok in checks.items():
        if not ok:
            raise AssertionError(name)
    return list(checks)


if __name__ == '__main__':
    names = validate()
    for name in names:
        print('PASS', name)
    print(f'{len(names)} buildfix source checks passed. NOT compilation or runtime validation.')
