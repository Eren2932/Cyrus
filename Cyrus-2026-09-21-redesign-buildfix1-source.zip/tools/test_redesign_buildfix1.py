"""Static regression checks only; not Kotlin compilation or native execution."""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
SERVICE = ROOT / 'vpn/service/src/main/kotlin/dev/kentra/vpn/service/XrayCoreService.kt'

class OptionalXraySourceTests(unittest.TestCase):
    def test_no_compile_time_binding(self):
        for path in (ROOT / 'vpn/service/src').rglob('*.kt'):
            self.assertIsNone(re.search(r'^\s*import\s+libXray\.', path.read_text(), re.M), str(path))

    def test_both_requests_use_bridge(self):
        code = SERVICE.read_text()
        self.assertIn('nativeInvoke(XrayCoreProtocol.runRequest(config))', code)
        self.assertIn('nativeInvoke(XrayCoreProtocol.stopRequest())', code)
        self.assertIn('Class.forName("libXray.LibXray")', code)
        self.assertIn('.getMethod("invoke", String::class.java)', code)

    def test_load_failure_is_retained_and_reported(self):
        code = SERVICE.read_text()
        self.assertIn('nativeLoadFailure = runCatching { System.loadLibrary("gojni") }', code)
        self.assertIn('nativeLoadFailure?.let { throw it }', code)
        self.assertIn('catch (e: Throwable)', code)
        self.assertIn('if (error == null) running = true', code)

    def test_reflection_does_not_hide_native_error(self):
        code = SERVICE.read_text()
        self.assertIn('catch (e: InvocationTargetException)', code)
        self.assertIn('throw (e.cause ?: e)', code)
        self.assertNotIn('as? String', code)

    def test_release_keeps_optional_binding(self):
        self.assertIn('-keep class libXray.** { *; }', (ROOT / 'app/proguard-rules.pro').read_text())

    def test_home_has_explicit_bom(self):
        self.assertIn('implementation(platform(libs.compose.bom))', (ROOT / 'feature/home/build.gradle.kts').read_text())

if __name__ == '__main__':
    unittest.main(verbosity=2)
