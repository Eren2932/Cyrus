#!/usr/bin/env python3
"""Mutation-test the source guards; these do not execute Android or Kotlin."""
from pathlib import Path
import tempfile
from check_buildfix import (validate, ROOT, ENGINE, CONFIG_BUILD, ZIP_WORKFLOW, SOURCE_WORKFLOW,
                            BASE_THEME, V29_THEME, SHELL, APP_BUILD)
from guard_support import copy_tree

mutations = [
    ('original broken callback restored', ENGINE,
     'val vpnService: VpnService = vpn as? VpnService ?: return\n            val protected: Boolean = runCatching { vpnService.protect(fd) }.getOrDefault(false)',
     'if (vpn !is VpnService) return\n            val protected = runCatching { vpn.protect(fd) }.getOrDefault(false)'),
    ('unsafe proxy cast', ENGINE, 'vpn as? VpnService ?: return', 'vpn as VpnService'),
    ('exception treated as success', ENGINE, 'vpnService.protect(fd) }.getOrDefault(false)', 'vpnService.protect(fd) }.getOrDefault(true)'),
    ('false return ignored', ENGINE, 'if (!protected)', 'if (false)'),
    ('callback disabled', ENGINE, 'usePlatformAutoDetectInterfaceControl(): Boolean = true', 'usePlatformAutoDetectInterfaceControl(): Boolean = false'),
    ('proxy allowed to create TUN', ENGINE, 'vpn as? VpnService ?: error("TUN запрещён в режиме прокси")', 'vpn as VpnService'),
    ('native fixture outputs lost', CONFIG_BUILD, 'outputs.dir(layout.buildDirectory.dir("native-fixtures"))', '// removed'),
    ('server fixture outputs lost', CONFIG_BUILD, 'outputs.dir(layout.buildDirectory.dir("server-script-fixtures"))', '// removed'),
    ('Go setup skipped on cache hit', ZIP_WORKFLOW, '- name: Set up matching Go toolchain\n', '- name: Set up matching Go toolchain\n        if: false\n'),
    ('ZIP release preflight lost', ZIP_WORKFLOW, ':app:compileDebugKotlin :app:compileReleaseKotlin', ':app:compileDebugKotlin'),
    ('source release preflight lost', SOURCE_WORKFLOW, ':app:compileDebugKotlin :app:compileReleaseKotlin', ':app:compileDebugKotlin'),
    ('outdated HTTPS rejection restored', 'vpn/link/src/test/kotlin/dev/kentra/vpn/link/DefaultLinkParserTest.kt', 'assertNull(parser.parse("unsupported://example.com"))', 'assertNull(parser.parse("https://example.com"))'),
    ('HTTPS acceptance regression removed', 'vpn/link/src/test/kotlin/dev/kentra/vpn/link/UpgradeImportTest.kt', 'anonymous HTTPS endpoint is a TLS proxy not garbage', 'removed positive regression'),
    ('network request permission removed', 'vpn/service/src/main/AndroidManifest.xml', 'android.permission.CHANGE_NETWORK_STATE', 'removed.permission'),
    ('API 24 fallback removed', ENGINE, 'cm.requestNetwork(request, defaultNetworkCallback!!)','Unit'),
    ('ordinary notification permission dependency restored', 'vpn/service/src/main/kotlin/dev/kentra/vpn/service/TunnelServiceRunner.kt', 'service.startForeground(notificationId, notification(true))', '(service.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(notificationId, notification(true))'),
    ('API 29 attribute back in the default values folder', BASE_THEME,
     '<item name="android:windowBackground">',
     '<item name="android:forceDarkAllowed">false</item>\n        <item name="android:windowBackground">'),
    ('v29 force-dark opt-out deleted', V29_THEME, '<item name="android:forceDarkAllowed">false</item>', ''),
    ('v29 theme silently drops a base item', V29_THEME, '<item name="android:navigationBarColor">@color/surface</item>', ''),
    ('wallpaper decode restored', SHELL, 'val overlayOpen =', 'CyrusWallpaper()\n    val overlayOpen ='),
    ('solid background lost', SHELL, '.background(MaterialTheme.colorScheme.background)', ''),
    ('lint stops failing the build', APP_BUILD, 'abortOnError = true', 'abortOnError = false'),
    ('lint console report silenced', APP_BUILD, 'textOutput = file("stdout")', ''),
]

with tempfile.TemporaryDirectory() as directory:
    root = Path(directory) / 'Cyrus'
    copy_tree(ROOT, root)
    validate(root)
    for name, path, old, new in mutations:
        p = root / path
        original = p.read_text()
        assert old in original, name
        p.write_text(original.replace(old, new))
        try:
            validate(root)
        except (AssertionError, ValueError):
            print('PASS rejected:', name)
        else:
            raise AssertionError('Undetected mutation: ' + name)
        finally:
            p.write_text(original)
print(f'{len(mutations)} buildfix guard mutation cases passed. NOT Kotlin/runtime tests.')
