package dev.kentra.core.designsystem

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.luminance
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup

@Composable
fun CyrusCard(modifier: Modifier = Modifier, highlighted: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier = modifier.fillMaxWidth(), shape = RoundedCornerShape(CyrusTokens.RadiusCard),
        border = BorderStroke(1.dp, if (highlighted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface)) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
    }
}

/** Visual state of the main control, derived from TunnelState by the caller. */
enum class CoreStatus { Idle, Busy, Active, Failed }

private val CoreSize = 168.dp

/** Compact reference control. Halo is painted, not blurred; no bitmap or idle timer.
 * Finite feedback and the busy sweep are read only during draw/layer work. */
@Composable
fun TacticalCore(
    label: String,
    status: CoreStatus,
    animate: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    compact: Boolean = false,
) {
    val reduced = LocalReducedMotion.current
    val interactions = remember { MutableInteractionSource() }
    val pressed by interactions.collectIsPressedAsState()
    val busy = status == CoreStatus.Busy
    val active = status == CoreStatus.Active
    val scheme = MaterialTheme.colorScheme
    val dark = scheme.background.luminance() < .5f
    val body = if (dark) CyrusTokens.CoreDark else CyrusTokens.CoreLight
    val ring = if (status == CoreStatus.Failed) scheme.error else scheme.primary
    val ringHot = if (status == CoreStatus.Failed) scheme.error else if (dark) CyrusTokens.AccentHot else ring

    val press = animateFloatAsState(if (pressed && !busy) 1f else 0f,
        tween(if (reduced) 0 else CyrusMotion.Fast, easing = CyrusMotion.Ease), label = "corePress")
    val engaged = animateFloatAsState(if (active) 1f else 0f,
        tween(if (reduced) 0 else CyrusMotion.Settle, easing = CyrusMotion.Ease), label = "coreEngaged")
    val working = animateFloatAsState(if (busy) 1f else 0f,
        tween(if (reduced) 0 else CyrusMotion.Screen, easing = CyrusMotion.Ease), label = "coreWorking")

    // No infinite work while idle; one clock only while busy or connected.
    val spin: State<Float> = if (busy && animate && !reduced) {
        rememberInfiniteTransition(label = "coreSpin").animateFloat(0f, 360f,
            infiniteRepeatable(tween(CyrusMotion.Spin, easing = LinearEasing)), label = "coreAngle")
    } else remember { mutableFloatStateOf(0f) }
    val breath: State<Float> = if (active && animate && !reduced) {
        rememberInfiniteTransition(label = "coreBreath").animateFloat(0f, 1f,
            infiniteRepeatable(tween(CyrusMotion.Breath, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "coreBreathValue")
    } else remember { mutableFloatStateOf(0f) }

    val glyphTint by animateColorAsState(
        if (active || busy || status == CoreStatus.Failed) ring else scheme.onBackground,
        tween(if (reduced) 0 else CyrusMotion.Screen), label = "coreGlyph")

    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(if (compact) 116.dp else CoreSize)
                .graphicsLayer {
                    // No infinite term here. Reading `breath` — an infinite transition —
                    // re-recorded this GPU layer every frame while connected; re-recording
                    // stroked paths (ring, brackets, glyph) made the Mali driver churn
                    // ~616 kB of temporaries per frame up to a ~700 MB plateau, which is
                    // fatal on low-RAM devices. `press`/`engaged` are finite, so the layer
                    // is re-recorded only on press and on the connect settle. The breathing
                    // cue lives on in the bloom below, whose alpha-only animation measured
                    // harmless (0 MB growth over 60 s).
                    val s = 1f - .04f * press.value + .009f * engaged.value
                    scaleX = s; scaleY = s
                }
                .clickable(enabled = !busy, role = Role.Button, interactionSource = interactions,
                    indication = null, onClick = onClick)
                .semantics {
                    contentDescription = label
                    stateDescription = when (status) {
                        CoreStatus.Active -> "Подключено"
                        CoreStatus.Busy -> label
                        CoreStatus.Failed -> "Ошибка подключения"
                        CoreStatus.Idle -> "Не подключено"
                    }
                },
            contentAlignment = Alignment.Center,
        ) {
            // Bloom: pure layer work, never invalidates draw of anything else.
            Box(Modifier.fillMaxSize(.86f).graphicsLayer {
                alpha = engaged.value * (.55f + .35f * breath.value)
            }.background(Brush.radialGradient(listOf(CyrusTokens.Accent.copy(alpha = .30f), Color.Transparent)), CircleShape))

            Canvas(Modifier.fillMaxSize()) {
                val side = size.minDimension
                val center = Offset(side / 2f, side / 2f)
                val trackWidth = 2.8.dp.toPx()
                val radius = side * .395f
                val e = engaged.value
                val wk = working.value

                drawCircle(Brush.radialGradient(listOf(ring.copy(alpha = .10f), Color.Transparent),
                    center = center, radius = side / 2f), side / 2f, center)
                drawCircle(body, radius - trackWidth, center)

                // Opaque boundary in ALL states; geometry and label communicate status.
                drawCircle(ring, radius, center,
                    style = Stroke(trackWidth))
                if (e > 0f) {
                    drawCircle(ring.copy(alpha = .18f * e), radius + 5.dp.toPx(), center,
                        style = Stroke(6.dp.toPx()))
                }

                // Running sweep: a single rotated sweep-gradient stroke. Constant
                // angular speed, one full turn per 700ms, no per-frame layout.
                if (wk > 0.01f) {
                    rotate(spin.value, center) {
                        drawCircle(
                            brush = Brush.sweepGradient(
                                0.00f to Color.Transparent,
                                0.55f to ring.copy(alpha = .10f * wk),
                                0.88f to ring.copy(alpha = .75f * wk),
                                1.00f to ringHot.copy(alpha = wk),
                                center = center,
                            ),
                            radius = radius, center = center, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round),
                        )
                    }
                }


            }

            CyrusIcon(CyrusSymbol.Power, Modifier.size(if (compact) 32.dp else 42.dp), glyphTint)
        }

        Spacer(Modifier.height(if (compact) 4.dp else 7.dp))
        AnimatedContent(targetState = label, label = "coreLabel", transitionSpec = {
            fadeIn(tween(if (reduced) 0 else CyrusMotion.Screen)) togetherWith
                fadeOut(tween(if (reduced) 0 else CyrusMotion.Fast))
        }) { text ->
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.size(8.dp).background(ring, CircleShape))
                Text(text, fontSize = 18.sp, fontWeight = FontWeight.Normal,
                    textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onBackground)
            }
        }
    }
}

data class CyrusNavigationItem(val route: String, val title: String, val icon: CyrusSymbol)

/** Three equal hit slots and one moving indicator. Layout never follows the animation. */
@Composable
fun CyrusNavigationBar(items: List<CyrusNavigationItem>, current: String, onSelect: (String) -> Unit) {
    require(items.isNotEmpty())
    val reduced = LocalReducedMotion.current
    val direction = if (LocalLayoutDirection.current == LayoutDirection.Rtl) -1f else 1f
    val index = items.indexOfFirst { it.route == current }.coerceAtLeast(0)
    val position = animateFloatAsState(index.toFloat(),
        tween(if (reduced) 0 else CyrusMotion.Screen, easing = CyrusMotion.Ease), label = "navIndicator")
    val surface = MaterialTheme.colorScheme.surface
    BoxWithConstraints(
        Modifier.widthIn(max = 440.dp).fillMaxWidth().height(56.dp)
            .clip(RoundedCornerShape(30.dp)).background(surface)
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .35f), RoundedCornerShape(30.dp))
            .selectableGroup().padding(horizontal = 6.dp, vertical = 4.dp),
    ) {
        val slotWidth = maxWidth / items.size
        val pillHeight = maxHeight
        val pill = CyrusTokens.Accent
        Box(Modifier.width(slotWidth).fillMaxHeight().graphicsLayer {
            translationX = direction * position.value * slotWidth.toPx()
        }.background(pill, RoundedCornerShape(24.dp)))
        Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
            items.forEachIndexed { i, item ->
                Box(Modifier.weight(1f).fillMaxHeight()
                    .clip(RoundedCornerShape(24.dp))
                    .selectable(selected = i == index, role = Role.Tab,
                        interactionSource = remember { MutableInteractionSource() }, indication = null,
                        onClick = { if (item.route != current) onSelect(item.route) })
                    .semantics { contentDescription = item.title },
                    contentAlignment = Alignment.Center) {
                    CyrusIcon(item.icon, Modifier.size(24.dp), MaterialTheme.colorScheme.onSurfaceVariant)
                    // Two identical paths: neutral outside the moving pill, dark
                    // inside it. The mask is read at draw time, never in layout.
                    CyrusIcon(item.icon, Modifier.size(24.dp).drawWithContent {
                        val width = slotWidth.toPx()
                        val left = direction * (position.value - i) * width - (width - size.width) / 2f
                        val top = (size.height - pillHeight.toPx()) / 2f
                        val mask = Path().apply {
                            addRoundRect(RoundRect(left, top, left + width, top + pillHeight.toPx(),
                                CornerRadius(24.dp.toPx()), CornerRadius(24.dp.toPx()),
                                CornerRadius(24.dp.toPx()), CornerRadius(24.dp.toPx())))
                        }
                        clipPath(mask) { this@drawWithContent.drawContent() }
                    }.clearAndSetSemantics { }, CyrusTokens.OnAccent)
                }
            }
        }
    }
}

/** Three-way segmented control used by the only remaining setting. */
@Composable
fun CyrusSegmented(labels: List<String>, selectedIndex: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    require(labels.isNotEmpty())
    BoxWithConstraints(modifier.fillMaxWidth().height(52.dp)
        .clip(RoundedCornerShape(26.dp))
        .background(MaterialTheme.colorScheme.surfaceVariant)
        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(26.dp))
        .padding(5.dp)) {
        val itemWidth = maxWidth / labels.size
        Box(Modifier.width(itemWidth).fillMaxHeight().graphicsLayer {
            translationX = selectedIndex.coerceIn(0, labels.lastIndex) * itemWidth.toPx()
        }.background(CyrusTokens.Accent, RoundedCornerShape(22.dp)))
        Row(Modifier.fillMaxSize()) {
            labels.forEachIndexed { i, text ->
                val tint = if (i == selectedIndex) CyrusTokens.OnAccent else MaterialTheme.colorScheme.onSurfaceVariant
                Box(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(22.dp))
                    .clickable(role = Role.RadioButton, indication = null,
                        interactionSource = remember { MutableInteractionSource() },
                        onClick = { onSelect(i) })
                    .semantics { selected = i == selectedIndex }, contentAlignment = Alignment.Center) {
                    Text(text, style = MaterialTheme.typography.bodyMedium, color = tint, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
fun StatPill(title: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(MaterialTheme.colorScheme.surface, RoundedCornerShape(18.dp)).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text(title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.titleMedium)
    }
}

enum class CyrusSymbol { Shield, Protection, Apps, Statistics, Key, Store, Power, Plus, Arrow, Check, Settings, Back, Globe, Search, Chevron, Refresh, Close }

@Composable
fun CyrusIcon(symbol: CyrusSymbol, modifier: Modifier = Modifier, color: Color = MaterialTheme.colorScheme.onSurface) {
    Canvas(modifier.size(24.dp)) {
        val s = size.minDimension / 24f
        fun point(x: Float, y: Float) = Offset(x * s, y * s)
        val stroke = Stroke(width = 1.8f * s, cap = StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round)
        fun line(x: Float, y: Float, x2: Float, y2: Float) = drawLine(color, point(x,y), point(x2,y2), 1.8f*s, StrokeCap.Round)
        when (symbol) {
            CyrusSymbol.Globe -> {
                drawCircle(color, 9f*s, point(12f,12f), style = stroke)
                drawOval(color, point(8f,3f), androidx.compose.ui.geometry.Size(8*s,18*s), style = stroke)
                line(3f,12f,21f,12f)
                drawArc(color, 22f, 136f, false, point(3f,1f), androidx.compose.ui.geometry.Size(18*s,9*s), style = stroke)
                drawArc(color, 202f, 136f, false, point(3f,14f), androidx.compose.ui.geometry.Size(18*s,9*s), style = stroke)
            }
            CyrusSymbol.Search -> { drawCircle(color,6.5f*s,point(10f,10f),style=stroke); line(15f,15f,21f,21f) }
            CyrusSymbol.Chevron -> { line(7f,14f,12f,9f); line(12f,9f,17f,14f) }
            CyrusSymbol.Close -> { line(6f,6f,18f,18f); line(18f,6f,6f,18f) }
            CyrusSymbol.Refresh -> {
                drawArc(color, -60f, 295f, false, point(4f,4f), androidx.compose.ui.geometry.Size(16*s,16*s), style=stroke)
                line(16f,3f,16f,8f); line(16f,8f,21f,8f)
            }
            CyrusSymbol.Power -> { drawArc(color, -42f, 264f, false, point(4f,4f), androidx.compose.ui.geometry.Size(16*s,16*s), style=stroke); line(12f,2f,12f,11f) }
            CyrusSymbol.Shield -> {
                val path = Path().apply {
                    moveTo(12*s,2.5f*s); cubicTo(14.8f*s,4*s,17.6f*s,4.8f*s,20*s,5.2f*s)
                    lineTo(20*s,11.5f*s); cubicTo(20*s,16.2f*s,16.8f*s,19.8f*s,12*s,21.5f*s)
                    cubicTo(7.2f*s,19.8f*s,4*s,16.2f*s,4*s,11.5f*s); lineTo(4*s,5.2f*s)
                    cubicTo(6.4f*s,4.8f*s,9.2f*s,4*s,12*s,2.5f*s); close()
                }
                drawPath(path,color,style=stroke); line(8f,12f,11f,15f); line(11f,15f,16f,9f)
            }
            CyrusSymbol.Protection -> {
                val path = Path().apply {
                    moveTo(12*s,2.5f*s); cubicTo(14.8f*s,4*s,17.6f*s,4.8f*s,20*s,5.2f*s)
                    lineTo(20*s,11.5f*s); cubicTo(20*s,16.2f*s,16.8f*s,19.8f*s,12*s,21.5f*s)
                    cubicTo(7.2f*s,19.8f*s,4*s,16.2f*s,4*s,11.5f*s); lineTo(4*s,5.2f*s)
                    cubicTo(6.4f*s,4.8f*s,9.2f*s,4*s,12*s,2.5f*s); close()
                }
                drawPath(path, color, style = stroke)
                line(7f,16f,17f,6f)
            }
            CyrusSymbol.Apps -> {
                for ((x, y) in listOf(4f to 4f, 14f to 4f, 4f to 14f, 14f to 14f)) {
                    drawRoundRect(color, point(x, y), androidx.compose.ui.geometry.Size(6*s, 6*s), androidx.compose.ui.geometry.CornerRadius(1.5f*s), style = stroke)
                }
            }
            CyrusSymbol.Statistics -> {
                drawArc(color, -90f, 270f, false, point(3f,3f), androidx.compose.ui.geometry.Size(18*s,18*s), style = stroke)
                drawLine(color, point(12f,12f), point(12f,3f), 1.8f*s, StrokeCap.Round)
                drawLine(color, point(12f,12f), point(20f,16f), 1.8f*s, StrokeCap.Round)
            }
            // Bow and shaft stay inside the 24 box once the 1.8 stroke is added:
            // the old shaft reached 22 and was clipped on the trailing edge.
            CyrusSymbol.Key -> { drawCircle(color,4.6f*s,point(9f,9f),style=stroke); line(12.3f,12.3f,20f,20f); line(15.6f,15.6f,18f,13.2f); line(17.4f,17.4f,19.8f,15f) }
            CyrusSymbol.Store -> { drawRoundRect(color,point(3f,6f),androidx.compose.ui.geometry.Size(18*s,15*s),androidx.compose.ui.geometry.CornerRadius(3*s),style=stroke); line(8f,6f,8f,3f); line(8f,3f,16f,3f); line(16f,3f,16f,6f); line(8f,12f,16f,12f) }
            CyrusSymbol.Plus -> { line(12f,5f,12f,19f); line(5f,12f,19f,12f) }
            CyrusSymbol.Arrow -> { line(5f,12f,19f,12f); line(14f,7f,19f,12f); line(19f,12f,14f,17f) }
            CyrusSymbol.Settings -> {
                // Sliders, not three lines with blobs on top: each rail is cut around
                // its knob so the glyph stays readable at 24dp instead of smearing.
                val rails = listOf(6f to 8f, 12f to 16f, 18f to 10f)
                for ((y, cx) in rails) {
                    if (cx - 2.6f > 3f) line(3f, y, cx - 2.6f, y)
                    if (cx + 2.6f < 21f) line(cx + 2.6f, y, 21f, y)
                    drawCircle(color, 2.2f * s, point(cx, y), style = stroke)
                }
            }
            CyrusSymbol.Back -> { line(19f,12f,5f,12f); line(5f,12f,10f,7f); line(5f,12f,10f,17f) }
            CyrusSymbol.Check -> { line(5f,12f,10f,17f); line(10f,17f,19f,7f) }
        }
    }
}
