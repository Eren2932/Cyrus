package dev.kentra.core.designsystem

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.SpringSpec
import androidx.compose.animation.core.spring
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Reference palette: true black canvas, graphite surfaces and one warm accent. */
object CyrusTokens {
    val Accent = Color(0xFFFF7908)
    val AccentHot = Color(0xFFFFA24C)
    val AccentPressed = Color(0xFFD95F0E)
    // Accessible orange for outlines/text on paper; fill remains brand orange.
    val AccentOnPaper = Color(0xFF9C3E00)
    val CoreDark = Color(0xFF0D1012)
    val CoreLight = Color(0xFFFFF4E8)
    val OnAccent = Color(0xFF1B0C00)
    val Danger = Color(0xFFFF7A7A)
    val Warning = Color(0xFFF8C578)

    // Dark: matte black stack.
    val Ink = Color(0xFF000000)
    val InkSurface = Color(0xFF090B0C)
    val InkControl = Color(0xFF111416)
    val InkOutline = Color(0xFF9B9B9B)
    val InkOutlineSoft = Color(0xFF202426)
    val OnInk = Color(0xFFF4F5F5)
    val OnInkMuted = Color(0xFF9FA3A6)

    // Light: warm paper white.
    val Paper = Color(0xFFF7F7F3)
    val PaperSurface = Color(0xFFFFFFFF)
    val PaperControl = Color(0xFFEDEDE7)
    val PaperOutline = Color(0xFF787872)
    val OnPaper = Color(0xFF17171A)
    val OnPaperMuted = Color(0xFF5C5C60)

    val RadiusCard = 24.dp
    val RadiusControl = 16.dp
    val SpaceXs = 4.dp
    val SpaceSm = 8.dp
    val SpaceMd = 16.dp
    val SpaceLg = 24.dp
    val SpaceXl = 32.dp
}

/**
 * Input selection is immediate. Full-width page pushes settle in 240 ms;
 * both pages use the same easing and duration (no fading/size animation).
 * Control feedback is 90 ms. System duration scale is respected by Compose.
 */
object CyrusMotion {
    const val Instant = 0
    const val Fast = 90
    const val Screen = 220
    const val Settle = 190
    const val Spin = 700
    const val Breath = 2600

    /** Emphasized decelerate: fast off the mark, soft landing. */
    val Ease = CubicBezierEasing(0.16f, 1f, 0.3f, 1f)
    val EaseIn = CubicBezierEasing(0.4f, 0f, 0.9f, 1f)

    fun <T> settle(): SpringSpec<T> = spring(dampingRatio = 0.82f, stiffness = 900f)
    fun <T> snap(): SpringSpec<T> = spring(dampingRatio = 0.9f, stiffness = 1600f)
}

internal val DarkScheme = darkColorScheme(
    primary = CyrusTokens.Accent, onPrimary = CyrusTokens.OnAccent,
    primaryContainer = Color(0xFF2A1608), onPrimaryContainer = CyrusTokens.AccentHot,
    secondary = CyrusTokens.Accent, onSecondary = CyrusTokens.OnAccent,
    secondaryContainer = CyrusTokens.InkControl, onSecondaryContainer = CyrusTokens.AccentHot,
    background = CyrusTokens.Ink, onBackground = CyrusTokens.OnInk,
    surface = CyrusTokens.InkSurface, onSurface = CyrusTokens.OnInk,
    surfaceVariant = CyrusTokens.InkControl, onSurfaceVariant = CyrusTokens.OnInkMuted,
    outline = CyrusTokens.InkOutline, outlineVariant = CyrusTokens.InkOutlineSoft,
    surfaceDim = CyrusTokens.Ink, surfaceBright = Color(0xFF303030),
    surfaceContainerLowest = CyrusTokens.Ink, surfaceContainerLow = CyrusTokens.InkSurface,
    surfaceContainer = CyrusTokens.InkControl, surfaceContainerHigh = Color(0xFF242424),
    surfaceContainerHighest = Color(0xFF303030),
    inverseSurface = CyrusTokens.PaperControl, inverseOnSurface = CyrusTokens.OnPaper,
    inversePrimary = CyrusTokens.AccentOnPaper,
    surfaceTint = Color.Transparent, error = CyrusTokens.Danger,
    onError = Color(0xFF370000), errorContainer = Color(0xFF530E0E), onErrorContainer = Color(0xFFFFDAD6),
)
internal val LightScheme = lightColorScheme(
    primary = CyrusTokens.AccentOnPaper, onPrimary = Color.White,
    primaryContainer = Color(0xFFFFE7D5), onPrimaryContainer = Color(0xFF7C3109),
    secondary = Color(0xFF7C3109), onSecondary = Color.White,
    secondaryContainer = CyrusTokens.PaperControl, onSecondaryContainer = CyrusTokens.OnPaper,
    background = CyrusTokens.Paper, onBackground = CyrusTokens.OnPaper,
    surface = CyrusTokens.PaperSurface, onSurface = CyrusTokens.OnPaper,
    surfaceVariant = CyrusTokens.PaperControl, onSurfaceVariant = CyrusTokens.OnPaperMuted,
    outline = CyrusTokens.PaperOutline, outlineVariant = Color(0xFFE2E2DC),
    surfaceDim = CyrusTokens.PaperControl, surfaceBright = CyrusTokens.PaperSurface,
    surfaceContainerLowest = CyrusTokens.PaperSurface, surfaceContainerLow = CyrusTokens.Paper,
    surfaceContainer = Color(0xFFF1F1EB), surfaceContainerHigh = CyrusTokens.PaperControl,
    surfaceContainerHighest = Color(0xFFE2E2DC),
    inverseSurface = CyrusTokens.InkControl, inverseOnSurface = CyrusTokens.OnInk,
    inversePrimary = CyrusTokens.AccentHot,
    surfaceTint = Color.Transparent, error = Color(0xFFB3261E),
    onError = Color.White, errorContainer = Color(0xFFFFDAD6), onErrorContainer = Color(0xFF410002),
)

/**
 * Mirrors the system animator-duration scale (Settings > Developer options /
 * accessibility). There is no in-app switch any more: the platform value wins.
 */
val LocalReducedMotion = staticCompositionLocalOf { false }

private val CyrusTypography = Typography(
    displaySmall = TextStyle(fontSize = 38.sp, fontWeight = FontWeight.Bold, letterSpacing = (-1).sp),
    headlineLarge = TextStyle(fontSize = 32.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.8).sp),
    titleLarge = TextStyle(fontSize = 23.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 21.sp),
    labelSmall = TextStyle(fontSize = 12.sp, lineHeight = 17.sp, fontWeight = FontWeight.Medium),
)

@Composable
fun CyrusTheme(darkTheme: Boolean = true, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (darkTheme) DarkScheme else LightScheme, typography = CyrusTypography, shapes = Shapes(
        small = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
        medium = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
        large = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
        extraLarge = androidx.compose.foundation.shape.RoundedCornerShape(28.dp),
    )) {
        // MaterialTheme alone does not establish LocalContentColor. Transparent
        // scaffolds must never inherit Compose's default black foreground.
        CompositionLocalProvider(LocalContentColor provides MaterialTheme.colorScheme.onBackground) {
            content()
        }
    }
}
